.class public final Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
.super Lcom/google/protobuf/GeneratedMessageV3$Builder;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResultOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
        "Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;",
        ">;",
        "Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResultOrBuilder;"
    }
.end annotation


# instance fields
.field private awardId_:Ljava/lang/Object;

.field private bitField0_:I

.field private buttonColor_:Ljava/lang/Object;

.field private buttonType_:Ljava/lang/Object;

.field private content_:Ljava/lang/Object;

.field private dev_:Ljava/lang/Object;

.field private gameIcon_:Ljava/lang/Object;

.field private gameId_:Ljava/lang/Object;

.field private gameName_:Ljava/lang/Object;

.field private gameUrl_:Ljava/lang/Object;

.field private icon_:Ljava/lang/Object;

.field private isH5Game_:Ljava/lang/Object;

.field private isReceive_:Ljava/lang/Object;

.field private jumpType_:Ljava/lang/Object;

.field private jumpUrl_:Ljava/lang/Object;

.field private messageId_:Ljava/lang/Object;

.field private page_:Ljava/lang/Object;

.field private platformId_:Ljava/lang/Object;

.field private showTime_:Ljava/lang/Object;

.field private showType_:Ljava/lang/Object;

.field private source_:Ljava/lang/Object;

.field private type_:Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const/4 v1, 0x3

    or-int/2addr v2, v1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->page_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->dev_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->content_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpType_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpUrl_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->type_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->icon_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->platformId_:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameId_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showType_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isH5Game_:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameUrl_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameName_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonType_:Ljava/lang/Object;

    const/4 v1, 0x0

    xor-int/2addr v2, v1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonColor_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showTime_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->messageId_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameIcon_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->source_:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->awardId_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isReceive_:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v0, 0x6

    move v1, v0

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x0

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->page_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->dev_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->content_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpType_:Ljava/lang/Object;

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpUrl_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->type_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->icon_:Ljava/lang/Object;

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->platformId_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameId_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showType_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isH5Game_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameUrl_:Ljava/lang/Object;

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameName_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonType_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonColor_:Ljava/lang/Object;

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showTime_:Ljava/lang/Object;

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->messageId_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameIcon_:Ljava/lang/Object;

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->source_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->awardId_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isReceive_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method synthetic constructor <init>(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method private buildPartial0(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "result"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " @s~vtid@~4/~o@ @~    @ solbcf~o~ l@@S@@@ ~@b~~nr/M ~  o  ~Ko~i-~i@@o~~@~ 1.u@ya@b~~f@ m~@t~ ~~@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    and-int/lit8 v1, v0, 0x1

    const/4 v4, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->page_:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x0

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$24502(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v1, 0x1

    move v5, v1

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    and-int/lit8 v2, v0, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->dev_:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$24602(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x6

    or-int/lit8 v1, v1, 0x2

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    and-int/lit8 v2, v0, 0x4

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->content_:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$24702(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    or-int/lit8 v1, v1, 0x4

    :cond_2
    const/4 v4, 0x6

    const/4 v5, 0x6

    and-int/lit8 v2, v0, 0x8

    const/4 v5, 0x0

    const/4 v4, 0x5

    if-eqz v2, :cond_3

    const/4 v4, 0x0

    move v5, v4

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpType_:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$24802(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x2

    or-int/lit8 v1, v1, 0x8

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    and-int/lit8 v2, v0, 0x10

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v2, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpUrl_:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$24902(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    or-int/lit8 v1, v1, 0x10

    :cond_4
    const/4 v5, 0x4

    and-int/lit8 v2, v0, 0x20

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v2, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->type_:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x5

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25002(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    or-int/lit8 v1, v1, 0x20

    :cond_5
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    and-int/lit8 v2, v0, 0x40

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v2, :cond_6

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->icon_:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25102(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    or-int/lit8 v1, v1, 0x40

    :cond_6
    const/4 v5, 0x2

    and-int/lit16 v2, v0, 0x80

    const/4 v5, 0x1

    if-eqz v2, :cond_7

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->platformId_:Ljava/lang/Object;

    const/4 v5, 0x1

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25202(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    or-int/lit16 v1, v1, 0x80

    :cond_7
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    and-int/lit16 v2, v0, 0x100

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v2, :cond_8

    const/4 v4, 0x4

    move v5, v4

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameId_:Ljava/lang/Object;

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25302(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    or-int/lit16 v1, v1, 0x100

    :cond_8
    const/4 v5, 0x0

    and-int/lit16 v2, v0, 0x200

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v2, :cond_9

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showType_:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25402(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    or-int/lit16 v1, v1, 0x200

    :cond_9
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    and-int/lit16 v2, v0, 0x400

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v2, :cond_a

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isH5Game_:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25502(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    or-int/lit16 v1, v1, 0x400

    :cond_a
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    and-int/lit16 v2, v0, 0x800

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz v2, :cond_b

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameUrl_:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25602(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    or-int/lit16 v1, v1, 0x800

    :cond_b
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    and-int/lit16 v2, v0, 0x1000

    const/4 v5, 0x0

    const/4 v4, 0x4

    if-eqz v2, :cond_c

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameName_:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25702(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    or-int/lit16 v1, v1, 0x1000

    :cond_c
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    and-int/lit16 v2, v0, 0x2000

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v2, :cond_d

    const/4 v4, 0x3

    move v5, v4

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonType_:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25802(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    or-int/lit16 v1, v1, 0x2000

    :cond_d
    const/4 v5, 0x3

    const/4 v4, 0x1

    and-int/lit16 v2, v0, 0x4000

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v2, :cond_e

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonColor_:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25902(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    move v5, v4

    or-int/lit16 v1, v1, 0x4000

    :cond_e
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    const v2, 0x8000

    const/4 v5, 0x6

    const/4 v4, 0x5

    and-int v3, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v3, :cond_f

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v3, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showTime_:Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p1, v3}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26002(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    or-int/2addr v1, v2

    :cond_f
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/high16 v2, 0x10000

    const/4 v5, 0x6

    and-int v3, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v3, :cond_10

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v3, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->messageId_:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {p1, v3}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26102(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    or-int/2addr v1, v2

    :cond_10
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/high16 v2, 0x20000

    const/4 v4, 0x1

    and-int/2addr v5, v4

    and-int v3, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v3, :cond_11

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v3, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameIcon_:Ljava/lang/Object;

    const/4 v5, 0x3

    invoke-static {p1, v3}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26202(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    or-int/2addr v1, v2

    :cond_11
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/high16 v2, 0x40000

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    and-int v3, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v3, :cond_12

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v3, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->source_:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {p1, v3}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26302(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    or-int/2addr v1, v2

    :cond_12
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/high16 v2, 0x80000

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    and-int v3, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v3, :cond_13

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v3, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->awardId_:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p1, v3}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26402(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    or-int/2addr v1, v2

    :cond_13
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/high16 v2, 0x100000

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    and-int/2addr v0, v2

    const/4 v5, 0x2

    if-eqz v0, :cond_14

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isReceive_:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {p1, v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26502(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    or-int/2addr v1, v2

    :cond_14
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26676(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;I)I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-void
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto;->access$24000()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p1
.end method

.method public addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic build()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic build()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public build()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->isInitialized()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/protobuf/AbstractMessage$Builder;->newUninitializedMessageException(Lcom/google/protobuf/Message;)Lcom/google/protobuf/UninitializedMessageException;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    throw v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public buildPartial()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, p0, v1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buildPartial0(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onBuilt()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object v0

    const/4 v1, 0x4

    shr-int/2addr v2, v1

    return-object v0
.end method

.method public clear()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    const/4 v1, 0x6

    shl-int/2addr v2, v1

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->page_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->dev_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->content_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpType_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpUrl_:Ljava/lang/Object;

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->type_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->icon_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->platformId_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameId_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showType_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isH5Game_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameUrl_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameName_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonType_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonColor_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showTime_:Ljava/lang/Object;

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->messageId_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameIcon_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->source_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->awardId_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isReceive_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public clearAwardId()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 4

    const/4 v2, 0x4

    move v3, v2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getAwardId()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->awardId_:Ljava/lang/Object;

    const/4 v3, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const v1, -0x80001

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    and-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p0
.end method

.method public clearButtonColor()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getButtonColor()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonColor_:Ljava/lang/Object;

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    and-int/lit16 v0, v0, -0x4001

    const/4 v2, 0x3

    const/4 v1, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x1

    return-object p0
.end method

.method public clearButtonType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getButtonType()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonType_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    and-int/lit16 v0, v0, -0x2001

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p0
.end method

.method public clearContent()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getContent()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->content_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    and-int/lit8 v0, v0, -0x5

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    and-int/2addr v2, v1

    return-object p0
.end method

.method public clearDev()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDev()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->dev_:Ljava/lang/Object;

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    and-int/lit8 v0, v0, -0x3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p1
.end method

.method public clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x2

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p1
.end method

.method public clearGameIcon()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getGameIcon()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameIcon_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const v1, -0x20001

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    and-int/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object p0
.end method

.method public clearGameId()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getGameId()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameId_:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    and-int/lit16 v0, v0, -0x101

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p0
.end method

.method public clearGameName()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getGameName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameName_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    and-int/lit16 v0, v0, -0x1001

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public clearGameUrl()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getGameUrl()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameUrl_:Ljava/lang/Object;

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    and-int/lit16 v0, v0, -0x801

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    move v2, v1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p0
.end method

.method public clearIcon()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getIcon()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->icon_:Ljava/lang/Object;

    const/4 v1, 0x1

    move v2, v1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    and-int/lit8 v0, v0, -0x41

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0
.end method

.method public clearIsH5Game()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getIsH5Game()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isH5Game_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    and-int/lit16 v0, v0, -0x401

    const/4 v2, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    return-object p0
.end method

.method public clearIsReceive()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getIsReceive()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isReceive_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const v1, -0x100001

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    and-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p0
.end method

.method public clearJumpType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getJumpType()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpType_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    and-int/lit8 v0, v0, -0x9

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0
.end method

.method public clearJumpUrl()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getJumpUrl()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpUrl_:Ljava/lang/Object;

    const/4 v1, 0x3

    move v2, v1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    and-int/lit8 v0, v0, -0x11

    const/4 v2, 0x2

    const/4 v1, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public clearMessageId()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getMessageId()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->messageId_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    const v1, -0x10001

    const/4 v3, 0x1

    and-int/2addr v0, v1

    const/4 v2, 0x7

    move v3, v2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p1
.end method

.method public clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v0, 0x4

    move v1, v0

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p1
.end method

.method public clearPage()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getPage()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->page_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    and-int/lit8 v0, v0, -0x2

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0
.end method

.method public clearPlatformId()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getPlatformId()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->platformId_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    and-int/lit16 v0, v0, -0x81

    const/4 v2, 0x1

    const/4 v1, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x7

    return-object p0
.end method

.method public clearShowTime()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 4

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getShowTime()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showTime_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const v1, -0x8001

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    and-int/2addr v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p0
.end method

.method public clearShowType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getShowType()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showType_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    and-int/lit16 v0, v0, -0x201

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0
.end method

.method public clearSource()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getSource()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->source_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    const v1, -0x40001

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    and-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object p0
.end method

.method public clearType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getType()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->type_:Ljava/lang/Object;

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    move v2, v1

    and-int/lit8 v0, v0, -0x21

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public clone()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    check-cast v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public getAwardId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->awardId_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->awardId_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0
.end method

.method public getAwardIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->awardId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->awardId_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0
.end method

.method public getButtonColor()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonColor_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x5

    xor-int/2addr v3, v2

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonColor_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public getButtonColorBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonColor_:Ljava/lang/Object;

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v2, 0x4

    move v3, v2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonColor_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0
.end method

.method public getButtonType()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonType_:Ljava/lang/Object;

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonType_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0
.end method

.method public getButtonTypeBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonType_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonType_:Ljava/lang/Object;

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method

.method public getContent()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->content_:Ljava/lang/Object;

    const/4 v2, 0x7

    move v3, v2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->content_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0
.end method

.method public getContentBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->content_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->content_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public getDescriptorForType()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto;->access$24000()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public getDev()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->dev_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v2, 0x5

    const/4 v2, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->dev_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0
.end method

.method public getDevBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->dev_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->dev_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0
.end method

.method public getGameIcon()Ljava/lang/String;
    .locals 4

    const/4 v2, 0x7

    move v3, v2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameIcon_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameIcon_:Ljava/lang/Object;

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0
.end method

.method public getGameIconBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameIcon_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameIcon_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0
.end method

.method public getGameId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v0
.end method

.method public getGameIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x5

    move v3, v2

    return-object v0
.end method

.method public getGameName()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0
.end method

.method public getGameNameBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0
.end method

.method public getGameUrl()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameUrl_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameUrl_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0
.end method

.method public getGameUrlBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameUrl_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameUrl_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0
.end method

.method public getIcon()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->icon_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x2

    move v3, v2

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->icon_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0
.end method

.method public getIconBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->icon_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x6

    move v3, v2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->icon_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object v0
.end method

.method public getIsH5Game()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isH5Game_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isH5Game_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    return-object v0
.end method

.method public getIsH5GameBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isH5Game_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x1

    move v3, v2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isH5Game_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public getIsReceive()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isReceive_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isReceive_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v0
.end method

.method public getIsReceiveBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isReceive_:Ljava/lang/Object;

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isReceive_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x5

    move v3, v2

    return-object v0
.end method

.method public getJumpType()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpType_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpType_:Ljava/lang/Object;

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object v0
.end method

.method public getJumpTypeBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpType_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x3

    move v3, v2

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpType_:Ljava/lang/Object;

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0
.end method

.method public getJumpUrl()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpUrl_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpUrl_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0
.end method

.method public getJumpUrlBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpUrl_:Ljava/lang/Object;

    const/4 v2, 0x3

    move v3, v2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x1

    shr-int/2addr v3, v2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpUrl_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0
.end method

.method public getMessageId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->messageId_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->messageId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    return-object v0
.end method

.method public getMessageIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->messageId_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->messageId_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v0
.end method

.method public getPage()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->page_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->page_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v0
.end method

.method public getPageBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->page_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->page_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v2, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0
.end method

.method public getPlatformId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->platformId_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez v1, :cond_0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->platformId_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0
.end method

.method public getPlatformIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->platformId_:Ljava/lang/Object;

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->platformId_:Ljava/lang/Object;

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0
.end method

.method public getShowTime()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showTime_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showTime_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object v0
.end method

.method public getShowTimeBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showTime_:Ljava/lang/Object;

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showTime_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0
.end method

.method public getShowType()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showType_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showType_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0
.end method

.method public getShowTypeBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showType_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showType_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0
.end method

.method public getSource()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->source_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->source_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0
.end method

.method public getSourceBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->source_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v2, 0x1

    move v3, v2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->source_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0
.end method

.method public getType()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->type_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->type_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0
.end method

.method public getTypeBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->type_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->type_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0
.end method

.method public hasAwardId()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/high16 v1, 0x80000

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    and-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    return v0
.end method

.method public hasButtonColor()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    move v2, v1

    and-int/lit16 v0, v0, 0x4000

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public hasButtonType()Z
    .locals 3

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    and-int/lit16 v0, v0, 0x2000

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public hasContent()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public hasDev()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    return v0
.end method

.method public hasGameIcon()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/high16 v1, 0x20000

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    and-int/2addr v0, v1

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    return v0
.end method

.method public hasGameId()Z
    .locals 3

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    move v2, v1

    and-int/lit16 v0, v0, 0x100

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public hasGameName()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    and-int/lit16 v0, v0, 0x1000

    const/4 v2, 0x5

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method public hasGameUrl()Z
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    move v2, v1

    and-int/lit16 v0, v0, 0x800

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public hasIcon()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    and-int/lit8 v0, v0, 0x40

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public hasIsH5Game()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v2, 0x3

    and-int/lit16 v0, v0, 0x400

    const/4 v2, 0x2

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public hasIsReceive()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/high16 v1, 0x100000

    const/4 v3, 0x6

    const/4 v2, 0x2

    and-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public hasJumpType()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    and-int/lit8 v0, v0, 0x8

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public hasJumpUrl()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    and-int/lit8 v0, v0, 0x10

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public hasMessageId()Z
    .locals 4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/high16 v1, 0x10000

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    and-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x0

    return v0
.end method

.method public hasPage()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x3

    and-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    return v1
.end method

.method public hasPlatformId()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    and-int/lit16 v0, v0, 0x80

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public hasShowTime()Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    const v1, 0x8000

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    and-int/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    return v0
.end method

.method public hasShowType()Z
    .locals 3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    and-int/lit16 v0, v0, 0x200

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public hasSource()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/high16 v1, 0x40000

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    and-int/2addr v0, v1

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    return v0
.end method

.method public hasType()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    and-int/lit8 v0, v0, 0x20

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v0, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto;->access$24100()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    const/4 v4, 0x7

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p1
.end method

.method public mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v0, 0x0

    :cond_0
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-nez v0, :cond_1

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readTag()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    sparse-switch v1, :sswitch_data_0

    const/4 v3, 0x7

    and-int/2addr v4, v3

    invoke-super {p0, p1, p2, v1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->parseUnknownField(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;I)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    goto/16 :goto_2

    :sswitch_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isReceive_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/high16 v2, 0x100000

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    or-int/2addr v1, v2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    goto :goto_0

    :sswitch_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->awardId_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/high16 v2, 0x80000

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    or-int/2addr v1, v2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x4

    shl-int/2addr v4, v3

    goto :goto_0

    :sswitch_2
    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->source_:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x1

    const/high16 v2, 0x40000

    const/4 v3, 0x2

    move v4, v3

    or-int/2addr v1, v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto/16 :goto_0

    :sswitch_3
    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameIcon_:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/high16 v2, 0x20000

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    or-int/2addr v1, v2

    const/4 v3, 0x2

    and-int/2addr v4, v3

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto/16 :goto_0

    :sswitch_4
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->messageId_:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/high16 v2, 0x10000

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    or-int/2addr v1, v2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto/16 :goto_0

    :sswitch_5
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showTime_:Ljava/lang/Object;

    const/4 v4, 0x4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    const v2, 0x8000

    const/4 v3, 0x3

    and-int/2addr v4, v3

    or-int/2addr v1, v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto/16 :goto_0

    :sswitch_6
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonColor_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    or-int/lit16 v1, v1, 0x4000

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto/16 :goto_0

    :sswitch_7
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonType_:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    or-int/lit16 v1, v1, 0x2000

    const/4 v4, 0x6

    const/4 v3, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x6

    xor-int/2addr v4, v3

    goto/16 :goto_0

    :sswitch_8
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x0

    move v4, v3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    or-int/lit16 v1, v1, 0x1000

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    goto/16 :goto_0

    :sswitch_9
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameUrl_:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x7

    move v4, v3

    or-int/lit16 v1, v1, 0x800

    const/4 v4, 0x1

    const/4 v3, 0x5

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto/16 :goto_0

    :sswitch_a
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isH5Game_:Ljava/lang/Object;

    const/4 v4, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    or-int/lit16 v1, v1, 0x400

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    goto/16 :goto_0

    :sswitch_b
    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showType_:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    or-int/lit16 v1, v1, 0x200

    const/4 v4, 0x7

    const/4 v3, 0x0

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto/16 :goto_0

    :sswitch_c
    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameId_:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    or-int/lit16 v1, v1, 0x100

    const/4 v4, 0x0

    const/4 v3, 0x0

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto/16 :goto_0

    :sswitch_d
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->platformId_:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x7

    and-int/2addr v4, v3

    or-int/lit16 v1, v1, 0x80

    const/4 v4, 0x5

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    goto/16 :goto_0

    :sswitch_e
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->icon_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    or-int/lit8 v1, v1, 0x40

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    goto/16 :goto_0

    :sswitch_f
    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->type_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    or-int/lit8 v1, v1, 0x20

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x4

    and-int/2addr v4, v3

    goto/16 :goto_0

    :sswitch_10
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpUrl_:Ljava/lang/Object;

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    or-int/lit8 v1, v1, 0x10

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto/16 :goto_0

    :sswitch_11
    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpType_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    or-int/lit8 v1, v1, 0x8

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto/16 :goto_0

    :sswitch_12
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->content_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    or-int/lit8 v1, v1, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto/16 :goto_0

    :sswitch_13
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->dev_:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    or-int/lit8 v1, v1, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    goto/16 :goto_0

    :sswitch_14
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->page_:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    or-int/2addr v1, v2

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I
    :try_end_0
    .catch Lcom/google/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto/16 :goto_0

    :goto_1
    :sswitch_15
    const/4 v4, 0x1

    const/4 v3, 0x6

    move v0, v2

    move v0, v2

    const/4 v4, 0x4

    move v0, v2

    move v0, v2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    goto/16 :goto_0

    :goto_2
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-nez v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto :goto_3

    :catch_0
    move-exception p1

    :try_start_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/InvalidProtocolBufferException;->unwrapIOException()Ljava/io/IOException;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_3
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v4, 0x0

    throw p1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object p0

    :sswitch_data_0
    .sparse-switch
        0x0 -> :sswitch_15
        0xa -> :sswitch_14
        0x12 -> :sswitch_13
        0x1a -> :sswitch_12
        0x22 -> :sswitch_11
        0x2a -> :sswitch_10
        0x32 -> :sswitch_f
        0x3a -> :sswitch_e
        0x42 -> :sswitch_d
        0x4a -> :sswitch_c
        0x52 -> :sswitch_b
        0x5a -> :sswitch_a
        0x62 -> :sswitch_9
        0x6a -> :sswitch_8
        0x72 -> :sswitch_7
        0x7a -> :sswitch_6
        0x82 -> :sswitch_5
        0x8a -> :sswitch_4
        0x92 -> :sswitch_3
        0x9a -> :sswitch_2
        0xa2 -> :sswitch_1
        0xaa -> :sswitch_0
    .end sparse-switch
.end method

.method public mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    instance-of v0, p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;

    const/4 v2, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method public mergeFrom(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-ne p1, v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object p0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasPage()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$24500(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->page_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    or-int/lit8 v0, v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasDev()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$24600(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->dev_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x4

    or-int/lit8 v0, v0, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasContent()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$24700(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->content_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    or-int/lit8 v0, v0, 0x4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasJumpType()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$24800(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpType_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    or-int/lit8 v0, v0, 0x8

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasJumpUrl()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_5

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$24900(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpUrl_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    or-int/lit8 v0, v0, 0x10

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_5
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasType()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_6

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25000(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->type_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    or-int/lit8 v0, v0, 0x20

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_6
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasIcon()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v0, :cond_7

    const/4 v2, 0x5

    move v3, v2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25100(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->icon_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    or-int/lit8 v0, v0, 0x40

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_7
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasPlatformId()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_8

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25200(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->platformId_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    or-int/lit16 v0, v0, 0x80

    const/4 v3, 0x1

    const/4 v2, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_8
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasGameId()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_9

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25300(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    or-int/lit16 v0, v0, 0x100

    const/4 v3, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_9
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasShowType()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_a

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25400(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showType_:Ljava/lang/Object;

    const/4 v3, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    or-int/lit16 v0, v0, 0x200

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_a
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasIsH5Game()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_b

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25500(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isH5Game_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    or-int/lit16 v0, v0, 0x400

    const/4 v3, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_b
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasGameUrl()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_c

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25600(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameUrl_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    or-int/lit16 v0, v0, 0x800

    const/4 v3, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_c
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasGameName()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v0, :cond_d

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25700(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    or-int/lit16 v0, v0, 0x1000

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_d
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasButtonType()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_e

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25800(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonType_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    or-int/lit16 v0, v0, 0x2000

    const/4 v3, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_e
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasButtonColor()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_f

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$25900(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonColor_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    or-int/lit16 v0, v0, 0x4000

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_f
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasShowTime()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_10

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26000(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showTime_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    const v1, 0x8000

    const/4 v2, 0x3

    const/4 v3, 0x2

    or-int/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_10
    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasMessageId()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v0, :cond_11

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26100(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->messageId_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/high16 v1, 0x10000

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    or-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_11
    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasGameIcon()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_12

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26200(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameIcon_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/high16 v1, 0x20000

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    or-int/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_12
    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasSource()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_13

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26300(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->source_:Ljava/lang/Object;

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/high16 v1, 0x40000

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    or-int/2addr v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_13
    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasAwardId()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_14

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26400(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->awardId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/high16 v1, 0x80000

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    or-int/2addr v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_14
    const/4 v3, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->hasIsReceive()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_15

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26500(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isReceive_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/high16 v1, 0x100000

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    or-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_15
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x5

    move v3, v2

    return-object p0
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p1
.end method

.method public final mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p1
.end method

.method public setAwardId(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->awardId_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/high16 v0, 0x80000

    const/4 v2, 0x5

    or-int/2addr p1, v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0
.end method

.method public setAwardIdBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$28600(Lcom/google/protobuf/ByteString;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->awardId_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/high16 v0, 0x80000

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    or-int/2addr p1, v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0
.end method

.method public setButtonColor(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonColor_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x1

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    or-int/lit16 p1, p1, 0x4000

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method public setButtonColorBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$28100(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonColor_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    or-int/lit16 p1, p1, 0x4000

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    return-object p0
.end method

.method public setButtonType(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonType_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    or-int/lit16 p1, p1, 0x2000

    const/4 v0, 0x3

    move v1, v0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x1

    return-object p0
.end method

.method public setButtonTypeBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$28000(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->buttonType_:Ljava/lang/Object;

    const/4 v0, 0x6

    move v1, v0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    or-int/lit16 p1, p1, 0x2000

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v0, 0x3

    and-int/2addr v1, v0

    return-object p0
.end method

.method public setContent(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v0, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->content_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    or-int/lit8 p1, p1, 0x4

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method public setContentBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26900(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->content_:Ljava/lang/Object;

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    or-int/lit8 p1, p1, 0x4

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v0, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method public setDev(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->dev_:Ljava/lang/Object;

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p0
.end method

.method public setDevBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26800(Lcom/google/protobuf/ByteString;)V

    const/4 v0, 0x4

    shl-int/2addr v1, v0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->dev_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p0
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    return-object p1
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p1
.end method

.method public setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p1
.end method

.method public setGameIcon(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameIcon_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/high16 v0, 0x20000

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    or-int/2addr p1, v0

    const/4 v1, 0x6

    and-int/2addr v2, v1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method public setGameIconBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$28400(Lcom/google/protobuf/ByteString;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameIcon_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/high16 v0, 0x20000

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    or-int/2addr p1, v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public setGameId(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameId_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v0, 0x1

    const/4 v1, 0x3

    or-int/lit16 p1, p1, 0x100

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p0
.end method

.method public setGameIdBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$27500(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameId_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    or-int/lit16 p1, p1, 0x100

    const/4 v1, 0x4

    const/4 v0, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v0, 0x6

    and-int/2addr v1, v0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p0
.end method

.method public setGameName(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v0, 0x1

    move v1, v0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameName_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    or-int/lit16 p1, p1, 0x1000

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    return-object p0
.end method

.method public setGameNameBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$27900(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameName_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    or-int/lit16 p1, p1, 0x1000

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method public setGameUrl(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameUrl_:Ljava/lang/Object;

    const/4 v1, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    or-int/lit16 p1, p1, 0x800

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p0
.end method

.method public setGameUrlBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$27800(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->gameUrl_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    or-int/lit16 p1, p1, 0x800

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method public setIcon(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->icon_:Ljava/lang/Object;

    const/4 v0, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    or-int/lit8 p1, p1, 0x40

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p0
.end method

.method public setIconBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v0, 0x6

    move v1, v0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$27300(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->icon_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v0, 0x3

    const/4 v1, 0x1

    or-int/lit8 p1, p1, 0x40

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p0
.end method

.method public setIsH5Game(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x7

    move v1, v0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isH5Game_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    or-int/lit16 p1, p1, 0x400

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    return-object p0
.end method

.method public setIsH5GameBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$27700(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isH5Game_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    or-int/lit16 p1, p1, 0x400

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v0, 0x4

    return-object p0
.end method

.method public setIsReceive(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isReceive_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/high16 v0, 0x100000

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    or-int/2addr p1, v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x6

    return-object p0
.end method

.method public setIsReceiveBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$28700(Lcom/google/protobuf/ByteString;)V

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->isReceive_:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/high16 v0, 0x100000

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    or-int/2addr p1, v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method public setJumpType(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpType_:Ljava/lang/Object;

    const/4 v0, 0x4

    move v1, v0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    or-int/lit8 p1, p1, 0x8

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0
.end method

.method public setJumpTypeBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$27000(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpType_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    or-int/lit8 p1, p1, 0x8

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method public setJumpUrl(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpUrl_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    or-int/lit8 p1, p1, 0x10

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method public setJumpUrlBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$27100(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->jumpUrl_:Ljava/lang/Object;

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    or-int/lit8 p1, p1, 0x10

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v0, 0x7

    const/4 v0, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x5

    return-object p0
.end method

.method public setMessageId(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->messageId_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/high16 v0, 0x10000

    const/4 v2, 0x1

    or-int/2addr p1, v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    xor-int/2addr v2, v1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method public setMessageIdBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$28300(Lcom/google/protobuf/ByteString;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->messageId_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/high16 v0, 0x10000

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    or-int/2addr p1, v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public setPage(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->page_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    return-object p0
.end method

.method public setPageBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$26700(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->page_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method

.method public setPlatformId(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x4

    const/4 v0, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->platformId_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x1

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    or-int/lit16 p1, p1, 0x80

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p0
.end method

.method public setPlatformIdBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$27400(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->platformId_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    or-int/lit16 p1, p1, 0x80

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p0
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p1
.end method

.method public setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-super {p0, p1, p2, p3}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p1
.end method

.method public setShowTime(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showTime_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const v0, 0x8000

    const/4 v2, 0x4

    or-int/2addr p1, v0

    const/4 v1, 0x4

    move v2, v1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0
.end method

.method public setShowTimeBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$28200(Lcom/google/protobuf/ByteString;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showTime_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    const v0, 0x8000

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    or-int/2addr p1, v0

    const/4 v2, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public setShowType(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showType_:Ljava/lang/Object;

    const/4 v0, 0x2

    xor-int/2addr v1, v0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    or-int/lit16 p1, p1, 0x200

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method public setShowTypeBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$27600(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->showType_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    or-int/lit16 p1, p1, 0x200

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p0
.end method

.method public setSource(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->source_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/high16 v0, 0x40000

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    or-int/2addr p1, v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p0
.end method

.method public setSourceBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$28500(Lcom/google/protobuf/ByteString;)V

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->source_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/high16 v0, 0x40000

    const/4 v2, 0x2

    or-int/2addr p1, v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0
.end method

.method public setType(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->type_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    or-int/lit8 p1, p1, 0x20

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x2

    return-object p0
.end method

.method public setTypeBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult;->access$27200(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->type_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    or-int/lit8 p1, p1, 0x20

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    return-object p0
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p1
.end method

.method public final setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$TipResult$Builder;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method
