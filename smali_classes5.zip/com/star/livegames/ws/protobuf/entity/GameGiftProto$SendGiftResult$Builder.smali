.class public final Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
.super Lcom/google/protobuf/GeneratedMessageV3$Builder;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResultOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
        "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;",
        ">;",
        "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResultOrBuilder;"
    }
.end annotation


# instance fields
.field private anchorId_:Ljava/lang/Object;

.field private area_:Ljava/lang/Object;

.field private bitField0_:I

.field private giftAmount_:Ljava/lang/Object;

.field private giftId_:Ljava/lang/Object;

.field private giftInfoBuilder_:Lcom/google/protobuf/SingleFieldBuilderV3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/SingleFieldBuilderV3<",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo$Builder;",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfoOrBuilder;",
            ">;"
        }
    .end annotation
.end field

.field private giftInfo_:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

.field private giftNumber_:I

.field private giftRank_:I

.field private imgUrl_:Ljava/lang/Object;

.field private memberId_:Ljava/lang/Object;

.field private nickname_:Ljava/lang/Object;

.field private time_:Ljava/lang/Object;

.field private totalPrice_:Ljava/lang/Object;

.field private userRole_:I

.field private vipLevelId_:I


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->area_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftId_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->time_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->maybeForceBuilderInitialization()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v0, 0x1

    move v1, v0

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x7

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v0, 0x1

    and-int/2addr v1, v0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->area_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftId_:Ljava/lang/Object;

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->time_:Ljava/lang/Object;

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v0, 0x6

    move v1, v0

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->maybeForceBuilderInitialization()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$1;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method synthetic constructor <init>(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$1;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method private buildPartial0(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "result"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~os S~~~t~s@ r i4@@o~ofcuo1yvd@a@@o@M~~~/~lb~l   b@@n-t@ @m  ~@@/ @i@@ o.~~~ @~~~K@b~i ~@  ~@ f "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    and-int/lit8 v1, v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$1602(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x6

    and-int/lit8 v2, v0, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x5

    if-eqz v2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->area_:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$1702(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    or-int/lit8 v1, v1, 0x2

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    and-int/lit8 v2, v0, 0x4

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v2, :cond_2

    const/4 v3, 0x7

    move v4, v3

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftRank_:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$1802(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;I)I

    const/4 v3, 0x1

    move v4, v3

    or-int/lit8 v1, v1, 0x4

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    and-int/lit8 v2, v0, 0x8

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v2, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$1902(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    or-int/lit8 v1, v1, 0x8

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    and-int/lit8 v2, v0, 0x10

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v2, :cond_4

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2002(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    or-int/lit8 v1, v1, 0x10

    :cond_4
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    and-int/lit8 v2, v0, 0x20

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v2, :cond_5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2102(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    or-int/lit8 v1, v1, 0x20

    :cond_5
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    and-int/lit8 v2, v0, 0x40

    const/4 v3, 0x0

    move v4, v3

    if-eqz v2, :cond_6

    const/4 v4, 0x1

    const/4 v3, 0x1

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftId_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2202(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    or-int/lit8 v1, v1, 0x40

    :cond_6
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    and-int/lit16 v2, v0, 0x80

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz v2, :cond_7

    const/4 v4, 0x3

    const/4 v3, 0x5

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->vipLevelId_:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2302(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;I)I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    or-int/lit16 v1, v1, 0x80

    :cond_7
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    and-int/lit16 v2, v0, 0x100

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz v2, :cond_8

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2402(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    or-int/lit16 v1, v1, 0x100

    :cond_8
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    and-int/lit16 v2, v0, 0x200

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v2, :cond_9

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->time_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2502(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    or-int/lit16 v1, v1, 0x200

    :cond_9
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    and-int/lit16 v2, v0, 0x400

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v2, :cond_a

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->userRole_:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2602(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;I)I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    or-int/lit16 v1, v1, 0x400

    :cond_a
    const/4 v4, 0x6

    const/4 v3, 0x3

    and-int/lit16 v2, v0, 0x800

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz v2, :cond_b

    const/4 v4, 0x5

    const/4 v3, 0x7

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v3, 0x6

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2702(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x1

    or-int/lit16 v1, v1, 0x800

    :cond_b
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    and-int/lit16 v2, v0, 0x1000

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v2, :cond_c

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftNumber_:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2802(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;I)I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    or-int/lit16 v1, v1, 0x1000

    :cond_c
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    and-int/lit16 v0, v0, 0x2000

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz v0, :cond_e

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfoBuilder_:Lcom/google/protobuf/SingleFieldBuilderV3;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez v0, :cond_d

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfo_:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto :goto_1

    :cond_d
    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/SingleFieldBuilderV3;->build()Lcom/google/protobuf/AbstractMessage;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    check-cast v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p1, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2902(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    or-int/lit16 v1, v1, 0x2000

    :cond_e
    const/4 v3, 0x2

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$3076(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;I)I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto;->access$1000()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method private getGiftInfoFieldBuilder()Lcom/google/protobuf/SingleFieldBuilderV3;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/SingleFieldBuilderV3<",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo$Builder;",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfoOrBuilder;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfoBuilder_:Lcom/google/protobuf/SingleFieldBuilderV3;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-nez v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    new-instance v0, Lcom/google/protobuf/SingleFieldBuilderV3;

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->getGiftInfo()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->getParentForChildren()Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->isClean()Z

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v0, v1, v2, v3}, Lcom/google/protobuf/SingleFieldBuilderV3;-><init>(Lcom/google/protobuf/AbstractMessage;Lcom/google/protobuf/AbstractMessage$BuilderParent;Z)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfoBuilder_:Lcom/google/protobuf/SingleFieldBuilderV3;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfo_:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    :cond_0
    const/4 v4, 0x5

    move v5, v4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfoBuilder_:Lcom/google/protobuf/SingleFieldBuilderV3;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-object v0
.end method

.method private maybeForceBuilderInitialization()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$1400()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->getGiftInfoFieldBuilder()Lcom/google/protobuf/SingleFieldBuilderV3;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p1
.end method

.method public addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic build()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-object v0
.end method

.method public bridge synthetic build()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;
    .locals 4

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->isInitialized()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/protobuf/AbstractMessage$Builder;->newUninitializedMessageException(Lcom/google/protobuf/Message;)Lcom/google/protobuf/UninitializedMessageException;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    throw v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public buildPartial()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;
    .locals 4

    const/4 v3, 0x7

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x4

    invoke-direct {v0, p0, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$1;)V

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->buildPartial0(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onBuilt()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public clear()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x6

    const-string v1, ""

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->area_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftRank_:I

    const/4 v3, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftId_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->vipLevelId_:I

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->time_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->userRole_:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftNumber_:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x0

    move v3, v0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfo_:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfoBuilder_:Lcom/google/protobuf/SingleFieldBuilderV3;

    const/4 v2, 0x2

    const/4 v2, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-virtual {v1}, Lcom/google/protobuf/SingleFieldBuilderV3;->dispose()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfoBuilder_:Lcom/google/protobuf/SingleFieldBuilderV3;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    return-object p0
.end method

.method public clearAnchorId()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getAnchorId()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    and-int/lit8 v0, v0, -0x11

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p0
.end method

.method public clearArea()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getArea()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->area_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    and-int/lit8 v0, v0, -0x3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p0
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    return-object p1
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method public clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x0

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method public clearGiftAmount()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getGiftAmount()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    and-int/lit8 v0, v0, -0x2

    const/4 v2, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0
.end method

.method public clearGiftId()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getGiftId()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftId_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    and-int/lit8 v0, v0, -0x41

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method public clearGiftInfo()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    and-int/lit16 v0, v0, -0x2001

    const/4 v3, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfo_:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfoBuilder_:Lcom/google/protobuf/SingleFieldBuilderV3;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v1}, Lcom/google/protobuf/SingleFieldBuilderV3;->dispose()V

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfoBuilder_:Lcom/google/protobuf/SingleFieldBuilderV3;

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p0
.end method

.method public clearGiftNumber()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    and-int/lit16 v0, v0, -0x1001

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftNumber_:I

    const/4 v1, 0x5

    and-int/2addr v2, v1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p0
.end method

.method public clearGiftRank()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    and-int/lit8 v0, v0, -0x5

    const/4 v2, 0x1

    const/4 v1, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftRank_:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public clearImgUrl()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getImgUrl()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    and-int/lit8 v0, v0, -0x21

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public clearMemberId()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getMemberId()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v1, 0x0

    move v2, v1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    and-int/2addr v2, v1

    and-int/lit16 v0, v0, -0x801

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x7

    return-object p0
.end method

.method public clearNickname()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getNickname()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    and-int/lit16 v0, v0, -0x101

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x2

    return-object p0
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    return-object p1
.end method

.method public clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    const/4 v1, 0x0

    return-object p1
.end method

.method public clearTime()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getTime()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->time_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    and-int/lit16 v0, v0, -0x201

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0
.end method

.method public clearTotalPrice()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getTotalPrice()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->totalPrice_:Ljava/lang/Object;

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    and-int/lit8 v0, v0, -0x9

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object p0
.end method

.method public clearUserRole()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    and-int/lit16 v0, v0, -0x401

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v0, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->userRole_:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p0
.end method

.method public clearVipLevelId()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    and-int/lit16 v0, v0, -0x81

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->vipLevelId_:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method public clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public getAnchorId()Ljava/lang/String;
    .locals 4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0
.end method

.method public getAnchorIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0
.end method

.method public getArea()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->area_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez v1, :cond_0

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->area_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0
.end method

.method public getAreaBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->area_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->area_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x3

    return-object v0
.end method

.method public getDescriptorForType()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto;->access$1000()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public getGiftAmount()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0
.end method

.method public getGiftAmountBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    return-object v0
.end method

.method public getGiftId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftId_:Ljava/lang/Object;

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftId_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0
.end method

.method public getGiftIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftId_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftId_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object v0
.end method

.method public getGiftInfo()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfoBuilder_:Lcom/google/protobuf/SingleFieldBuilderV3;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfo_:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    const/4 v1, 0x4

    move v2, v1

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    move-result-object v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/SingleFieldBuilderV3;->getMessage()Lcom/google/protobuf/AbstractMessage;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    check-cast v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public getGiftInfoBuilder()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    or-int/lit16 v0, v0, 0x2000

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->getGiftInfoFieldBuilder()Lcom/google/protobuf/SingleFieldBuilderV3;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/SingleFieldBuilderV3;->getBuilder()Lcom/google/protobuf/AbstractMessage$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    check-cast v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo$Builder;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public getGiftInfoOrBuilder()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfoOrBuilder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfoBuilder_:Lcom/google/protobuf/SingleFieldBuilderV3;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/SingleFieldBuilderV3;->getMessageOrBuilder()Lcom/google/protobuf/MessageOrBuilder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    check-cast v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfoOrBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfo_:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    move-result-object v0

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public getGiftNumber()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftNumber_:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method public getGiftRank()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftRank_:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public getImgUrl()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public getImgUrlBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0
.end method

.method public getMemberId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0
.end method

.method public getMemberIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0
.end method

.method public getNickname()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x0

    move v3, v2

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v0
.end method

.method public getNicknameBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v2, 0x0

    move v3, v2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x7

    move v3, v2

    return-object v0
.end method

.method public getTime()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->time_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->time_:Ljava/lang/Object;

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0
.end method

.method public getTimeBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->time_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->time_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object v0
.end method

.method public getTotalPrice()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->totalPrice_:Ljava/lang/Object;

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0
.end method

.method public getTotalPriceBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    return-object v0
.end method

.method public getUserRole()I
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->userRole_:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    return v0
.end method

.method public getVipLevelId()I
    .locals 3

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->vipLevelId_:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public hasAnchorId()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    and-int/lit8 v0, v0, 0x10

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public hasArea()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public hasGiftAmount()Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x2

    move v2, v1

    const/4 v3, 0x1

    and-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    return v1
.end method

.method public hasGiftId()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    and-int/lit8 v0, v0, 0x40

    const/4 v2, 0x0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public hasGiftInfo()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    and-int/lit16 v0, v0, 0x2000

    const/4 v2, 0x7

    const/4 v1, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public hasGiftNumber()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    and-int/lit16 v0, v0, 0x1000

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method public hasGiftRank()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public hasImgUrl()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    and-int/lit8 v0, v0, 0x20

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public hasMemberId()Z
    .locals 3

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    and-int/lit16 v0, v0, 0x800

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public hasNickname()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    and-int/lit16 v0, v0, 0x100

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public hasTime()Z
    .locals 3

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    and-int/lit16 v0, v0, 0x200

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public hasTotalPrice()Z
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    and-int/lit8 v0, v0, 0x8

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public hasUserRole()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    and-int/lit16 v0, v0, 0x400

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    move v2, v1

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    return v0
.end method

.method public hasVipLevelId()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    and-int/lit16 v0, v0, 0x80

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x0

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto;->access$1100()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    const/4 v4, 0x5

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x2

    return v0
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p1
.end method

.method public mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v0, 0x0

    :cond_0
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-nez v0, :cond_1

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readTag()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v2, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    sparse-switch v1, :sswitch_data_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-super {p0, p1, p2, v1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->parseUnknownField(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;I)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto/16 :goto_2

    :sswitch_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->getGiftInfoFieldBuilder()Lcom/google/protobuf/SingleFieldBuilderV3;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1}, Lcom/google/protobuf/SingleFieldBuilderV3;->getBuilder()Lcom/google/protobuf/AbstractMessage$Builder;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p1, v1, p2}, Lcom/google/protobuf/CodedInputStream;->readMessage(Lcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    or-int/lit16 v1, v1, 0x2000

    const/4 v4, 0x3

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :sswitch_1
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt32()I

    move-result v1

    const/4 v3, 0x6

    shl-int/2addr v4, v3

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftNumber_:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    or-int/lit16 v1, v1, 0x1000

    const/4 v4, 0x6

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_0

    :sswitch_2
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    or-int/lit16 v1, v1, 0x800

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto :goto_0

    :sswitch_3
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt32()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->userRole_:I

    const/4 v3, 0x0

    shl-int/2addr v4, v3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    or-int/lit16 v1, v1, 0x400

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto/16 :goto_0

    :sswitch_4
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->time_:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    or-int/lit16 v1, v1, 0x200

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    goto/16 :goto_0

    :sswitch_5
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v4, 0x5

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    or-int/lit16 v1, v1, 0x100

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto/16 :goto_0

    :sswitch_6
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readInt32()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->vipLevelId_:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x7

    or-int/lit16 v1, v1, 0x80

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    goto/16 :goto_0

    :sswitch_7
    const/4 v4, 0x7

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftId_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    or-int/lit8 v1, v1, 0x40

    const/4 v4, 0x2

    const/4 v3, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto/16 :goto_0

    :sswitch_8
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    or-int/lit8 v1, v1, 0x20

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto/16 :goto_0

    :sswitch_9
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    or-int/lit8 v1, v1, 0x10

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    goto/16 :goto_0

    :sswitch_a
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    or-int/lit8 v1, v1, 0x8

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x1

    goto/16 :goto_0

    :sswitch_b
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt32()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftRank_:I

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    or-int/lit8 v1, v1, 0x4

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    goto/16 :goto_0

    :sswitch_c
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->area_:Ljava/lang/Object;

    const/4 v4, 0x6

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    or-int/lit8 v1, v1, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    goto/16 :goto_0

    :sswitch_d
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v4, 0x6

    or-int/2addr v1, v2

    const/4 v4, 0x6

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I
    :try_end_0
    .catch Lcom/google/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    goto/16 :goto_0

    :goto_1
    :sswitch_e
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    move v0, v2

    move v0, v2

    move v0, v2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto/16 :goto_0

    :goto_2
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-nez v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_3

    :catch_0
    move-exception p1

    :try_start_1
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/InvalidProtocolBufferException;->unwrapIOException()Ljava/io/IOException;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_3
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    throw p1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-object p0

    :sswitch_data_0
    .sparse-switch
        0x0 -> :sswitch_e
        0xa -> :sswitch_d
        0x12 -> :sswitch_c
        0x18 -> :sswitch_b
        0x22 -> :sswitch_a
        0x2a -> :sswitch_9
        0x32 -> :sswitch_8
        0x3a -> :sswitch_7
        0x40 -> :sswitch_6
        0x4a -> :sswitch_5
        0x52 -> :sswitch_4
        0x58 -> :sswitch_3
        0x62 -> :sswitch_2
        0x68 -> :sswitch_1
        0x72 -> :sswitch_0
    .end sparse-switch
.end method

.method public mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    instance-of v0, p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    const/4 v1, 0x0

    move v2, v1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public mergeFrom(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-ne p1, v0, :cond_0

    const/4 v1, 0x4

    xor-int/2addr v2, v1

    return-object p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->hasGiftAmount()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$1600(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    or-int/2addr v2, v1

    or-int/lit8 v0, v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->hasArea()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    if-eqz v0, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$1700(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->area_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    or-int/lit8 v0, v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->hasGiftRank()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getGiftRank()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->setGiftRank(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    :cond_3
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->hasTotalPrice()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_4

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$1900(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    or-int/lit8 v0, v0, 0x8

    const/4 v2, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_4
    const/4 v2, 0x5

    const/4 v1, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->hasAnchorId()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_5

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2000(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    or-int/lit8 v0, v0, 0x10

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_5
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->hasImgUrl()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_6

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2100(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    or-int/lit8 v0, v0, 0x20

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_6
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->hasGiftId()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_7

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2200(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftId_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    or-int/lit8 v0, v0, 0x40

    const/4 v2, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_7
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->hasVipLevelId()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_8

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getVipLevelId()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->setVipLevelId(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    :cond_8
    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->hasNickname()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_9

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2400(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    or-int/lit16 v0, v0, 0x100

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_9
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->hasTime()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_a

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2500(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->time_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    or-int/lit16 v0, v0, 0x200

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_a
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->hasUserRole()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_b

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getUserRole()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->setUserRole(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    :cond_b
    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->hasMemberId()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_c

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$2700(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    or-int/lit16 v0, v0, 0x800

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_c
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->hasGiftNumber()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    if-eqz v0, :cond_d

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getGiftNumber()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->setGiftNumber(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    :cond_d
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->hasGiftInfo()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_e

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->getGiftInfo()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->mergeGiftInfo(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    :cond_e
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p0
.end method

.method public mergeGiftInfo(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfoBuilder_:Lcom/google/protobuf/SingleFieldBuilderV3;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    and-int/lit16 v0, v0, 0x2000

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfo_:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eq v0, v1, :cond_0

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->getGiftInfoBuilder()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo$Builder;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo$Builder;

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfo_:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    invoke-virtual {v0, p1}, Lcom/google/protobuf/SingleFieldBuilderV3;->mergeFrom(Lcom/google/protobuf/AbstractMessage;)Lcom/google/protobuf/SingleFieldBuilderV3;

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfo_:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz p1, :cond_2

    const/4 v2, 0x5

    move v3, v2

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    or-int/lit16 p1, p1, 0x2000

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object p0
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p1
.end method

.method public final mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p1
.end method

.method public setAnchorId(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    or-int/lit8 p1, p1, 0x10

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    return-object p0
.end method

.method public setAnchorIdBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x4

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$3400(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    or-int/lit8 p1, p1, 0x10

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method public setArea(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->area_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v0, 0x2

    move v1, v0

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v0, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method public setAreaBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$3200(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->area_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p1
.end method

.method public setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p1
.end method

.method public setGiftAmount(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v1, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method public setGiftAmountBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$3100(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method public setGiftId(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftId_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    or-int/lit8 p1, p1, 0x40

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method public setGiftIdBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$3600(Lcom/google/protobuf/ByteString;)V

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftId_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    or-int/lit8 p1, p1, 0x40

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v0, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method public setGiftInfo(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo$Builder;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builderForValue"
        }
    .end annotation

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfoBuilder_:Lcom/google/protobuf/SingleFieldBuilderV3;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfo_:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-virtual {v0, p1}, Lcom/google/protobuf/SingleFieldBuilderV3;->setMessage(Lcom/google/protobuf/AbstractMessage;)Lcom/google/protobuf/SingleFieldBuilderV3;

    :goto_0
    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    or-int/lit16 p1, p1, 0x2000

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0
.end method

.method public setGiftInfo(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfoBuilder_:Lcom/google/protobuf/SingleFieldBuilderV3;

    const/4 v1, 0x1

    const/4 v1, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftInfo_:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$GiftInfo;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/protobuf/SingleFieldBuilderV3;->setMessage(Lcom/google/protobuf/AbstractMessage;)Lcom/google/protobuf/SingleFieldBuilderV3;

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    or-int/lit16 p1, p1, 0x2000

    const/4 v2, 0x1

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0
.end method

.method public setGiftNumber(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftNumber_:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    or-int/lit16 p1, p1, 0x1000

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    return-object p0
.end method

.method public setGiftRank(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->giftRank_:I

    const/4 v0, 0x1

    move v1, v0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    or-int/lit8 p1, p1, 0x4

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p0
.end method

.method public setImgUrl(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    or-int/lit8 p1, p1, 0x20

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v0, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method

.method public setImgUrlBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$3500(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    or-int/lit8 p1, p1, 0x20

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p0
.end method

.method public setMemberId(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    or-int/lit16 p1, p1, 0x800

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method public setMemberIdBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x5

    move v1, v0

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$3900(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    or-int/lit16 p1, p1, 0x800

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v0, 0x7

    xor-int/2addr v1, v0

    return-object p0
.end method

.method public setNickname(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    or-int/lit16 p1, p1, 0x100

    const/4 v0, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    return-object p0
.end method

.method public setNicknameBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$3700(Lcom/google/protobuf/ByteString;)V

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    or-int/lit16 p1, p1, 0x100

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p1
.end method

.method public setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-super {p0, p1, p2, p3}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p1
.end method

.method public setTime(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->time_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    or-int/lit16 p1, p1, 0x200

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method public setTimeBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$3800(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->time_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    or-int/lit16 p1, p1, 0x200

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method public setTotalPrice(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    or-int/lit8 p1, p1, 0x8

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method public setTotalPriceBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult;->access$3300(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    or-int/lit8 p1, p1, 0x8

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v0, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v0, 0x7

    move v1, v0

    return-object p0
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p1
.end method

.method public final setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p1
.end method

.method public setUserRole(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->userRole_:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    or-int/lit16 p1, p1, 0x400

    const/4 v1, 0x7

    const/4 v0, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p0
.end method

.method public setVipLevelId(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->vipLevelId_:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    or-int/lit16 p1, p1, 0x80

    const/4 v0, 0x3

    move v1, v0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$SendGiftResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method
