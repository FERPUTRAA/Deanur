.class public final Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;
.super Lcom/google/protobuf/GeneratedMessageV3;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResultOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "CallingPlayerListResult"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

.field private static final PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;",
            ">;"
        }
    .end annotation
.end field

.field public static final USERLIST_FIELD_NUMBER:I = 0x1

.field private static final serialVersionUID:J


# instance fields
.field private memoizedIsInitialized:B

.field private userList_:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerList;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    sput-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$1;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$1;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    sput-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v0, -0x1

    move v2, v0

    const/4 v1, 0x5

    const/4 v1, 0x3

    iput-byte v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->memoizedIsInitialized:B

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->userList_:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    const/4 p1, -0x1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-byte p1, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->memoizedIsInitialized:B

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$1;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic access$8900(Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;)Ljava/util/List;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->userList_:Ljava/util/List;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic access$8902(Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;Ljava/util/List;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->userList_:Ljava/util/List;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p1
.end method

.method static synthetic access$9000()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    sget-boolean v0, Lcom/google/protobuf/GeneratedMessageV3;->alwaysUseFieldBuilders:Z

    const/4 v1, 0x1

    shr-int/2addr v2, v1

    return v0
.end method

.method public static getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto;->access$8400()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public static newBuilder()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public static newBuilder(Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "prototype"
        }
    .end annotation

    const/4 v2, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x7

    const/4 v1, 0x7

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom([B)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom([B)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-ne p1, p0, :cond_0

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    return v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    instance-of v1, p1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v3, 0x6

    move v4, v3

    if-nez v1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    return p1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->getUserListList()Ljava/util/List;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->getUserListList()Ljava/util/List;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-interface {v1, v2}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    if-nez v1, :cond_2

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    return v2

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1, p1}, Lcom/google/protobuf/UnknownFieldSet;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez p1, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    return v2

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public getParserForType()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v1, 0x2

    move v2, v1

    return-object v0
.end method

.method public getSerializedSize()I
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v1, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eq v0, v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    return v0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x3

    move v1, v0

    move v1, v0

    const/4 v5, 0x3

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v5, 0x5

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->userList_:Ljava/util/List;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v4, 0x0

    move v5, v4

    if-ge v0, v2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->userList_:Ljava/util/List;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    check-cast v2, Lcom/google/protobuf/MessageLite;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v3, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x7

    invoke-static {v3, v2}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    add-int/2addr v1, v2

    const/4 v5, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->getSerializedSize()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    add-int/2addr v1, v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    iput v1, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    return v1
.end method

.method public getUserList(I)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerList;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->userList_:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerList;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p1
.end method

.method public getUserListCount()I
    .locals 3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->userList_:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public getUserListList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerList;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->userList_:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public getUserListOrBuilder(I)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListOrBuilder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->userList_:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListOrBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p1
.end method

.method public getUserListOrBuilderList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListOrBuilder;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->userList_:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/16 v1, 0x30b

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    add-int/2addr v1, v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->getUserListCount()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-lez v0, :cond_1

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->getUserListList()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/List;->hashCode()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    add-int/2addr v1, v0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x1d

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->hashCode()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    add-int/2addr v1, v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput v1, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    return v1
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto;->access$8500()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    const/4 v4, 0x4

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-byte v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->memoizedIsInitialized:B

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    return v1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    return v0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-byte v1, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->memoizedIsInitialized:B

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    return v1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method protected bridge synthetic newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->newBuilder()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    return-object v0
.end method

.method protected newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v0, p1, v1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$1;)V

    const/4 v2, 0x4

    move v3, v2

    return-object v0
.end method

.method protected newInstance(Lcom/google/protobuf/GeneratedMessageV3$UnusedPrivateParameter;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unused"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    new-instance p1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public toBuilder()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;
    .locals 4

    const/4 v3, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-ne p0, v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;-><init>(Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$1;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;-><init>(Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$1;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult$Builder;

    move-result-object v0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0
.end method

.method public writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->userList_:Ljava/util/List;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    if-ge v0, v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$CallingPlayerListResult;->userList_:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    check-cast v1, Lcom/google/protobuf/MessageLite;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1, v2, v1}, Lcom/google/protobuf/CodedOutputStream;->writeMessage(ILcom/google/protobuf/MessageLite;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Lcom/google/protobuf/UnknownFieldSet;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-void
.end method
