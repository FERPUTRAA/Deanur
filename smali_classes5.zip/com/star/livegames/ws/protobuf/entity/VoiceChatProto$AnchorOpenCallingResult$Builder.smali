.class public final Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;
.super Lcom/google/protobuf/GeneratedMessageV3$Builder;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResultOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
        "Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;",
        ">;",
        "Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResultOrBuilder;"
    }
.end annotation


# instance fields
.field private bitField0_:I

.field private succeed_:Z


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$1;)V
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method synthetic constructor <init>(Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$1;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method private buildPartial0(Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "result"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " 1s@nb@~@-~t v~bol~ @~ b~/ ~~@c MKfo@r@@f~~m~~~o@d@~  .4  ~ i  ~@@~aiS/@o@y~@~@s ~~u@@il  o@o@ t"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->bitField0_:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    and-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-boolean v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->succeed_:Z

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p1, v0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;->access$16002(Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;Z)Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;->access$16176(Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;I)I

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto;->access$15500()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method public addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic build()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic build()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public build()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;->isInitialized()Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/protobuf/AbstractMessage$Builder;->newUninitializedMessageException(Lcom/google/protobuf/Message;)Lcom/google/protobuf/UninitializedMessageException;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    throw v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    move-result-object v0

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public buildPartial()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x4

    and-int/2addr v2, v1

    const/4 v3, 0x7

    invoke-direct {v0, p0, v1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$1;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->buildPartial0(Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onBuilt()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public clear()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-boolean v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->succeed_:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p1
.end method

.method public clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    const/4 v1, 0x6

    const/4 v0, 0x2

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p1
.end method

.method public clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x2

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    const/4 v1, 0x1

    const/4 v0, 0x3

    return-object p1
.end method

.method public clearSucceed()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    and-int/lit8 v0, v0, -0x2

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-boolean v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->succeed_:Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public clone()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast v0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public getDescriptorForType()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto;->access$15500()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public getSucceed()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->succeed_:Z

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method

.method public hasSucceed()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    and-int/2addr v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    return v1
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto;->access$15600()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    const/4 v4, 0x1

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    const/4 v4, 0x4

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p1
.end method

.method public mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v5, 0x2

    const/4 v0, 0x3

    const/4 v5, 0x7

    const/4 v0, 0x0

    :cond_0
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-nez v0, :cond_3

    :try_start_0
    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readTag()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/16 v3, 0x8

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eq v1, v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-super {p0, p1, p2, v1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->parseUnknownField(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;I)Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez v1, :cond_0

    const/4 v5, 0x3

    goto :goto_1

    :cond_1
    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readBool()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    iput-boolean v1, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->succeed_:Z

    const/4 v4, 0x6

    move v5, v4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->bitField0_:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    or-int/2addr v1, v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->bitField0_:I
    :try_end_0
    .catch Lcom/google/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v4, 0x2

    const/4 v5, 0x0

    move v0, v2

    const/4 v5, 0x4

    move v0, v2

    move v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    goto :goto_2

    :catch_0
    move-exception p1

    :try_start_1
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/InvalidProtocolBufferException;->unwrapIOException()Ljava/io/IOException;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_2
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    throw p1

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-object p0
.end method

.method public mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    instance-of v0, p1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p1

    :cond_0
    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;

    return-object p0
.end method

.method public mergeFrom(Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-ne p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;->hasSucceed()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult;->getSucceed()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->setSucceed(Z)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    const/4 v2, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p1
.end method

.method public final mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p1
.end method

.method public setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p1
.end method

.method public setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-super {p0, p1, p2, p3}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p1
.end method

.method public setSucceed(Z)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    iput-boolean p1, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->succeed_:Z

    const/4 v1, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v0, 0x6

    shr-int/2addr v1, v0

    return-object p0
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p1
.end method

.method public final setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/VoiceChatProto$AnchorOpenCallingResult$Builder;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p1
.end method
