.class public final Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;
.super Lcom/google/protobuf/GeneratedMessageV3;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToyOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/NoticeProto;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "CurrentToy"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;
    }
.end annotation


# static fields
.field public static final ANCHORID_FIELD_NUMBER:I = 0x1

.field public static final AREA_FIELD_NUMBER:I = 0x2

.field public static final BAUBLEGRADE_FIELD_NUMBER:I = 0x3

.field public static final BAUBLETIME_FIELD_NUMBER:I = 0x4

.field private static final DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

.field public static final IMGURL_FIELD_NUMBER:I = 0x5

.field public static final MEMBERID_FIELD_NUMBER:I = 0x6

.field public static final NICKNAME_FIELD_NUMBER:I = 0x7

.field private static final PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;",
            ">;"
        }
    .end annotation
.end field

.field public static final TIME_FIELD_NUMBER:I = 0x8

.field public static final TOTALPRICE_FIELD_NUMBER:I = 0x9

.field public static final TOYAMOUNT_FIELD_NUMBER:I = 0xa

.field public static final TOYID_FIELD_NUMBER:I = 0xb

.field public static final TOYNUM_FIELD_NUMBER:I = 0xc

.field public static final USERROLE_FIELD_NUMBER:I = 0xd

.field public static final VIPLEVELID_FIELD_NUMBER:I = 0xe

.field private static final serialVersionUID:J


# instance fields
.field private volatile anchorId_:Ljava/lang/Object;

.field private volatile area_:Ljava/lang/Object;

.field private baubleGrade_:I

.field private volatile baubleTime_:Ljava/lang/Object;

.field private bitField0_:I

.field private volatile imgUrl_:Ljava/lang/Object;

.field private volatile memberId_:Ljava/lang/Object;

.field private memoizedIsInitialized:B

.field private volatile nickname_:Ljava/lang/Object;

.field private volatile time_:Ljava/lang/Object;

.field private volatile totalPrice_:Ljava/lang/Object;

.field private volatile toyAmount_:Ljava/lang/Object;

.field private volatile toyId_:Ljava/lang/Object;

.field private toyNum_:I

.field private userRole_:I

.field private vipLevelId_:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    sput-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$1;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$1;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    sput-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->area_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleGrade_:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleTime_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->time_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->totalPrice_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyAmount_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyId_:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyNum_:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->userRole_:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->vipLevelId_:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v1, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-byte v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->memoizedIsInitialized:B

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->area_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleTime_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->time_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->totalPrice_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyAmount_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyId_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
            "*>;)V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x0

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->anchorId_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->area_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleGrade_:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleTime_:Ljava/lang/Object;

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->imgUrl_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->memberId_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->nickname_:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->time_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->totalPrice_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyAmount_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyId_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyNum_:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->userRole_:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->vipLevelId_:I

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 p1, -0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-byte p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->memoizedIsInitialized:B

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic access$19500(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s@~~@~ul@@.y@ ofS~d~~   ~~r@@ @@@@o c~v~ao@~t   K  b@ ~~  /i ~@@1tf/~o obiMb~@~~mn@~l~s~o i-@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->anchorId_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic access$19502(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->anchorId_:Ljava/lang/Object;

    const/4 v1, 0x2

    return-object p1
.end method

.method static synthetic access$19600(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->area_:Ljava/lang/Object;

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$19602(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->area_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x2

    return-object p1
.end method

.method static synthetic access$19702(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;I)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleGrade_:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return p1
.end method

.method static synthetic access$19800(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleTime_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic access$19802(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleTime_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p1
.end method

.method static synthetic access$19900(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->imgUrl_:Ljava/lang/Object;

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic access$19902(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->imgUrl_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method static synthetic access$20000(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->memberId_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic access$20002(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->memberId_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p1
.end method

.method static synthetic access$20100(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->nickname_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x3

    return-object p0
.end method

.method static synthetic access$20102(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->nickname_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p1
.end method

.method static synthetic access$20200(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->time_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic access$20202(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->time_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p1
.end method

.method static synthetic access$20300(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->totalPrice_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$20302(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->totalPrice_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic access$20400(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyAmount_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic access$20402(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyAmount_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic access$20500(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyId_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic access$20502(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyId_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p1
.end method

.method static synthetic access$20602(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;I)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyNum_:I

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    return p1
.end method

.method static synthetic access$20702(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->userRole_:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    return p1
.end method

.method static synthetic access$20802(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;I)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->vipLevelId_:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return p1
.end method

.method static synthetic access$20976(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;I)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    or-int/2addr p1, v0

    const/4 v1, 0x4

    move v2, v1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    return p1
.end method

.method static synthetic access$21000(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic access$21100(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic access$21200(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    return-void
.end method

.method static synthetic access$21300(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic access$21400(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic access$21500(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic access$21600(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v0, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic access$21700(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic access$21800(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic access$21900(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public static getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v1, 0x2

    xor-int/2addr v2, v1

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto;->access$19000()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public static newBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public static newBuilder(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "prototype"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v1, 0x0

    move v2, v1

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v1, 0x1

    move v2, v1

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom([B)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom([B)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v5, 0x1

    move v4, v0

    move v4, v0

    const/4 v5, 0x6

    if-ne p1, p0, :cond_0

    const/4 v5, 0x7

    return v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    instance-of v1, p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-nez v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    return p1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v5, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasAnchorId()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasAnchorId()Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eq v1, v2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    return v3

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasAnchorId()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz v1, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getAnchorId()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getAnchorId()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez v1, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    return v3

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasArea()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasArea()Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eq v1, v2, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    return v3

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasArea()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz v1, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getArea()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getArea()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-nez v1, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    return v3

    :cond_5
    const/4 v5, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasBaubleGrade()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasBaubleGrade()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eq v1, v2, :cond_6

    const/4 v4, 0x0

    move v5, v4

    return v3

    :cond_6
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasBaubleGrade()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz v1, :cond_7

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getBaubleGrade()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getBaubleGrade()I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eq v1, v2, :cond_7

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    return v3

    :cond_7
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasBaubleTime()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasBaubleTime()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eq v1, v2, :cond_8

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    return v3

    :cond_8
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasBaubleTime()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v1, :cond_9

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getBaubleTime()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getBaubleTime()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-nez v1, :cond_9

    const/4 v5, 0x6

    const/4 v4, 0x3

    return v3

    :cond_9
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasImgUrl()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasImgUrl()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eq v1, v2, :cond_a

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    return v3

    :cond_a
    const/4 v4, 0x5

    move v5, v4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasImgUrl()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v1, :cond_b

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getImgUrl()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getImgUrl()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    if-nez v1, :cond_b

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    return v3

    :cond_b
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasMemberId()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasMemberId()Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eq v1, v2, :cond_c

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v3

    :cond_c
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasMemberId()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v1, :cond_d

    const/4 v4, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getMemberId()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getMemberId()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-nez v1, :cond_d

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    return v3

    :cond_d
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasNickname()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasNickname()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-eq v1, v2, :cond_e

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    return v3

    :cond_e
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasNickname()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v1, :cond_f

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getNickname()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getNickname()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-nez v1, :cond_f

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    return v3

    :cond_f
    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasTime()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasTime()Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eq v1, v2, :cond_10

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    return v3

    :cond_10
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasTime()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v1, :cond_11

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getTime()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getTime()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-nez v1, :cond_11

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    return v3

    :cond_11
    const/4 v5, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasTotalPrice()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasTotalPrice()Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eq v1, v2, :cond_12

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    return v3

    :cond_12
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasTotalPrice()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v1, :cond_13

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getTotalPrice()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getTotalPrice()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    if-nez v1, :cond_13

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    return v3

    :cond_13
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasToyAmount()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasToyAmount()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eq v1, v2, :cond_14

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    return v3

    :cond_14
    const/4 v5, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasToyAmount()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz v1, :cond_15

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getToyAmount()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getToyAmount()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-nez v1, :cond_15

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    return v3

    :cond_15
    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasToyId()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasToyId()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eq v1, v2, :cond_16

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    return v3

    :cond_16
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasToyId()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v1, :cond_17

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getToyId()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getToyId()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-nez v1, :cond_17

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    return v3

    :cond_17
    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasToyNum()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasToyNum()Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eq v1, v2, :cond_18

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    return v3

    :cond_18
    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasToyNum()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v1, :cond_19

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getToyNum()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getToyNum()I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eq v1, v2, :cond_19

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    return v3

    :cond_19
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasUserRole()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasUserRole()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eq v1, v2, :cond_1a

    const/4 v5, 0x1

    const/4 v4, 0x4

    return v3

    :cond_1a
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasUserRole()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz v1, :cond_1b

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getUserRole()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getUserRole()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eq v1, v2, :cond_1b

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    return v3

    :cond_1b
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasVipLevelId()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasVipLevelId()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eq v1, v2, :cond_1c

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    return v3

    :cond_1c
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasVipLevelId()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eqz v1, :cond_1d

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getVipLevelId()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getVipLevelId()I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eq v1, v2, :cond_1d

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    return v3

    :cond_1d
    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1, p1}, Lcom/google/protobuf/UnknownFieldSet;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-nez p1, :cond_1e

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    return v3

    :cond_1e
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    return v0
.end method

.method public getAnchorId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->anchorId_:Ljava/lang/Object;

    const/4 v2, 0x4

    move v3, v2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method

.method public getAnchorIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0
.end method

.method public getArea()Ljava/lang/String;
    .locals 4

    const/4 v2, 0x6

    move v3, v2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->area_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->area_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0
.end method

.method public getAreaBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->area_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->area_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    return-object v0
.end method

.method public getBaubleGrade()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleGrade_:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public getBaubleTime()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleTime_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleTime_:Ljava/lang/Object;

    const/4 v3, 0x1

    return-object v0
.end method

.method public getBaubleTimeBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v2, 0x3

    move v3, v2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleTime_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    if-eqz v1, :cond_0

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleTime_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public getImgUrl()Ljava/lang/String;
    .locals 4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0
.end method

.method public getImgUrlBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->imgUrl_:Ljava/lang/Object;

    const/4 v2, 0x2

    move v3, v2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0

    :cond_0
    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method public getMemberId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0
.end method

.method public getMemberIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object v0
.end method

.method public getNickname()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0
.end method

.method public getNicknameBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    return-object v0
.end method

.method public getParserForType()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x2

    move v2, v1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v1, 0x5

    move v2, v1

    return-object v0
.end method

.method public getSerializedSize()I
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v1, -0x1

    const/4 v4, 0x0

    move v5, v4

    if-eq v0, v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    return v0

    :cond_0
    const/4 v4, 0x3

    const/4 v5, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v5, 0x0

    const/4 v1, 0x7

    const/4 v5, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    and-int/2addr v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->anchorId_:Ljava/lang/Object;

    const/4 v5, 0x1

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    add-int/2addr v2, v0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v1, 0x2

    and-int/2addr v5, v1

    const/4 v4, 0x2

    xor-int/2addr v5, v4

    and-int/2addr v0, v1

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->area_:Ljava/lang/Object;

    const/4 v5, 0x7

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    add-int/2addr v2, v0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v1, 0x4

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    and-int/2addr v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v0, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v0, 0x3

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget v3, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleGrade_:I

    const/4 v4, 0x3

    shr-int/2addr v5, v4

    invoke-static {v0, v3}, Lcom/google/protobuf/CodedOutputStream;->computeUInt32Size(II)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    add-int/2addr v2, v0

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/16 v3, 0x8

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    and-int/2addr v0, v3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleTime_:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    add-int/2addr v2, v0

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    and-int/lit8 v0, v0, 0x10

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v0, :cond_5

    const/4 v5, 0x5

    const/4 v0, 0x5

    const/4 v5, 0x3

    const/4 v0, 0x5

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->imgUrl_:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    add-int/2addr v2, v0

    :cond_5
    const/4 v5, 0x7

    const/4 v4, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v5, 0x4

    and-int/lit8 v0, v0, 0x20

    const/4 v5, 0x0

    if-eqz v0, :cond_6

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v0, 0x6

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->memberId_:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    add-int/2addr v2, v0

    :cond_6
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    and-int/lit8 v0, v0, 0x40

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz v0, :cond_7

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v0, 0x7

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->nickname_:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    add-int/2addr v2, v0

    :cond_7
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    and-int/lit16 v0, v0, 0x80

    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz v0, :cond_8

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->time_:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {v3, v0}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    add-int/2addr v2, v0

    :cond_8
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    and-int/lit16 v0, v0, 0x100

    const/4 v5, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_9

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/16 v0, 0x9

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->totalPrice_:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    add-int/2addr v2, v0

    :cond_9
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    and-int/lit16 v0, v0, 0x200

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v0, :cond_a

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/16 v0, 0xa

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyAmount_:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x7

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    add-int/2addr v2, v0

    :cond_a
    const/4 v5, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v5, 0x1

    const/4 v4, 0x7

    and-int/lit16 v0, v0, 0x400

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v0, :cond_b

    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/16 v0, 0xb

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyId_:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    add-int/2addr v2, v0

    :cond_b
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v5, 0x1

    and-int/lit16 v0, v0, 0x800

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz v0, :cond_c

    const/4 v4, 0x1

    move v5, v4

    const/16 v0, 0xc

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyNum_:I

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeUInt32Size(II)I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    add-int/2addr v2, v0

    :cond_c
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    and-int/lit16 v0, v0, 0x1000

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v0, :cond_d

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/16 v0, 0xd

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->userRole_:I

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeUInt32Size(II)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    add-int/2addr v2, v0

    :cond_d
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    and-int/lit16 v0, v0, 0x2000

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v0, :cond_e

    const/4 v5, 0x1

    const/16 v0, 0xe

    const/4 v4, 0x6

    or-int/2addr v5, v4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->vipLevelId_:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeInt32Size(II)I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    add-int/2addr v2, v0

    :cond_e
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->getSerializedSize()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    add-int/2addr v2, v0

    const/4 v5, 0x0

    iput v2, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    return v2
.end method

.method public getTime()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->time_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x3

    move v3, v2

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->time_:Ljava/lang/Object;

    const/4 v3, 0x4

    return-object v0
.end method

.method public getTimeBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->time_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->time_:Ljava/lang/Object;

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0
.end method

.method public getTotalPrice()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->totalPrice_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->totalPrice_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0
.end method

.method public getTotalPriceBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->totalPrice_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v2, 0x4

    or-int/2addr v3, v2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->totalPrice_:Ljava/lang/Object;

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0
.end method

.method public getToyAmount()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyAmount_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x7

    and-int/2addr v3, v2

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyAmount_:Ljava/lang/Object;

    const/4 v2, 0x6

    return-object v0
.end method

.method public getToyAmountBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyAmount_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyAmount_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    return-object v0
.end method

.method public getToyId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyId_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyId_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v0
.end method

.method public getToyIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyId_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyId_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0
.end method

.method public getToyNum()I
    .locals 3

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyNum_:I

    const/4 v2, 0x4

    return v0
.end method

.method public getUserRole()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->userRole_:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public getVipLevelId()I
    .locals 3

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->vipLevelId_:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method public hasAnchorId()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    and-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    return v1
.end method

.method public hasArea()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    return v0
.end method

.method public hasBaubleGrade()Z
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method public hasBaubleTime()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    and-int/lit8 v0, v0, 0x8

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method public hasImgUrl()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    and-int/lit8 v0, v0, 0x10

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    move v2, v1

    const/4 v0, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public hasMemberId()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    and-int/lit8 v0, v0, 0x20

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    return v0
.end method

.method public hasNickname()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    and-int/lit8 v0, v0, 0x40

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x6

    move v1, v0

    move v1, v0

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    return v0
.end method

.method public hasTime()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v2, 0x2

    and-int/lit16 v0, v0, 0x80

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x4

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v2, 0x4

    return v0
.end method

.method public hasTotalPrice()Z
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v2, 0x7

    and-int/lit16 v0, v0, 0x100

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x0

    move v2, v0

    :goto_0
    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public hasToyAmount()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    and-int/lit16 v0, v0, 0x200

    const/4 v2, 0x0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public hasToyId()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    and-int/lit16 v0, v0, 0x400

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x4

    xor-int/2addr v1, v0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    return v0
.end method

.method public hasToyNum()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    and-int/lit16 v0, v0, 0x800

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public hasUserRole()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    and-int/lit16 v0, v0, 0x1000

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public hasVipLevelId()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    and-int/lit16 v0, v0, 0x2000

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    move v2, v1

    const/4 v0, 0x1

    shl-int/2addr v2, v0

    const/4 v1, 0x7

    and-int/2addr v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    return v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/16 v1, 0x30b

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    add-int/2addr v1, v0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasAnchorId()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x6

    mul-int/lit8 v1, v1, 0x35

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getAnchorId()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    add-int/2addr v1, v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasArea()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    add-int/lit8 v1, v1, 0x2

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    mul-int/lit8 v1, v1, 0x35

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getArea()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    add-int/2addr v1, v0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasBaubleGrade()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x5

    add-int/lit8 v1, v1, 0x3

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getBaubleGrade()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    add-int/2addr v1, v0

    :cond_3
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasBaubleTime()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    add-int/lit8 v1, v1, 0x4

    const/4 v2, 0x6

    and-int/2addr v3, v2

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getBaubleTime()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_4
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasImgUrl()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x25

    const/4 v2, 0x3

    or-int/2addr v3, v2

    add-int/lit8 v1, v1, 0x5

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getImgUrl()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    add-int/2addr v1, v0

    :cond_5
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasMemberId()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_6

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x25

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x6

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getMemberId()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    add-int/2addr v1, v0

    :cond_6
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasNickname()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz v0, :cond_7

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    add-int/lit8 v1, v1, 0x7

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getNickname()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_7
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasTime()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v0, :cond_8

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x25

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    add-int/lit8 v1, v1, 0x8

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getTime()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    add-int/2addr v1, v0

    :cond_8
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasTotalPrice()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_9

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x4

    add-int/lit8 v1, v1, 0x9

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getTotalPrice()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    add-int/2addr v1, v0

    :cond_9
    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasToyAmount()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_a

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x2

    const/4 v2, 0x0

    add-int/lit8 v1, v1, 0xa

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x35

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getToyAmount()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    add-int/2addr v1, v0

    :cond_a
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasToyId()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_b

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    add-int/lit8 v1, v1, 0xb

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getToyId()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    add-int/2addr v1, v0

    :cond_b
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasToyNum()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz v0, :cond_c

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    add-int/lit8 v1, v1, 0xc

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getToyNum()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    add-int/2addr v1, v0

    :cond_c
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasUserRole()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_d

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0xd

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getUserRole()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    add-int/2addr v1, v0

    :cond_d
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->hasVipLevelId()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_e

    const/4 v3, 0x3

    const/4 v2, 0x0

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    add-int/lit8 v1, v1, 0xe

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->getVipLevelId()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    add-int/2addr v1, v0

    :cond_e
    const/4 v2, 0x1

    move v3, v2

    mul-int/lit8 v1, v1, 0x1d

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->hashCode()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    add-int/2addr v1, v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput v1, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    return v1
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto;->access$19100()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v4, 0x6

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    const/4 v4, 0x5

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 4

    const/4 v2, 0x6

    move v3, v2

    iget-byte v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->memoizedIsInitialized:B

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    shr-int/2addr v3, v2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    return v1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x2

    move v3, v2

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x2

    move v3, v2

    return v0

    :cond_1
    const/4 v2, 0x3

    move v3, v2

    iput-byte v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->memoizedIsInitialized:B

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    return v1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method protected bridge synthetic newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    return-object v0
.end method

.method public newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;
    .locals 3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->newBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method protected newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v0, p1, v1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0
.end method

.method protected newInstance(Lcom/google/protobuf/GeneratedMessageV3$UnusedPrivateParameter;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unused"
        }
    .end annotation

    const/4 v0, 0x1

    move v1, v0

    new-instance p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public toBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;
    .locals 4

    const/4 v3, 0x2

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    const/4 v1, 0x0

    or-int/2addr v3, v1

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-ne p0, v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;-><init>(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;-><init>(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy$Builder;

    move-result-object v0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x4

    move v4, v3

    and-int/2addr v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->anchorId_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p1, v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v1, 0x2

    const/4 v3, 0x6

    move v4, v3

    and-int/2addr v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->area_:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {p1, v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x4

    move v4, v1

    const/4 v3, 0x7

    const/4 v3, 0x0

    and-int/2addr v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v3, 0x4

    move v4, v3

    const/4 v0, 0x3

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleGrade_:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v2}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32(II)V

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/16 v2, 0x8

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    and-int/2addr v0, v2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v0, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->baubleTime_:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p1, v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v3, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    and-int/lit8 v0, v0, 0x10

    const/4 v3, 0x7

    and-int/2addr v4, v3

    if-eqz v0, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v0, 0x5

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->imgUrl_:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    and-int/lit8 v0, v0, 0x20

    const/4 v3, 0x0

    or-int/2addr v4, v3

    if-eqz v0, :cond_5

    const/4 v4, 0x7

    const/4 v0, 0x6

    const/4 v4, 0x5

    move v3, v0

    move v3, v0

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->memberId_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_5
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    and-int/lit8 v0, v0, 0x40

    const/4 v3, 0x5

    and-int/2addr v4, v3

    if-eqz v0, :cond_6

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v0, 0x7

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->nickname_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_6
    const/4 v3, 0x4

    const/4 v4, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    and-int/lit16 v0, v0, 0x80

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v0, :cond_7

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->time_:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {p1, v2, v0}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_7
    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    and-int/lit16 v0, v0, 0x100

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v0, :cond_8

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/16 v0, 0x9

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->totalPrice_:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_8
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v3, 0x0

    const/4 v3, 0x6

    and-int/lit16 v0, v0, 0x200

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v0, :cond_9

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/16 v0, 0xa

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyAmount_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_9
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    and-int/lit16 v0, v0, 0x400

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v0, :cond_a

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/16 v0, 0xb

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyId_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_a
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    and-int/lit16 v0, v0, 0x800

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v0, :cond_b

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/16 v0, 0xc

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->toyNum_:I

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32(II)V

    :cond_b
    const/4 v3, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    and-int/lit16 v0, v0, 0x1000

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v0, :cond_c

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/16 v0, 0xd

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->userRole_:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32(II)V

    :cond_c
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->bitField0_:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    and-int/lit16 v0, v0, 0x2000

    const/4 v4, 0x0

    if-eqz v0, :cond_d

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/16 v0, 0xe

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$CurrentToy;->vipLevelId_:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeInt32(II)V

    :cond_d
    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Lcom/google/protobuf/UnknownFieldSet;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void
.end method
