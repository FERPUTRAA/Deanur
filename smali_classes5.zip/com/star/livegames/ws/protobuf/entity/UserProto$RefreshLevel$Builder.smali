.class public final Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
.super Lcom/google/protobuf/GeneratedMessageV3$Builder;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevelOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
        "Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;",
        ">;",
        "Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevelOrBuilder;"
    }
.end annotation


# instance fields
.field private bitField0_:I

.field private charge_:Ljava/lang/Object;

.field private currentLevel_:Ljava/lang/Object;

.field private nextLevel_:Ljava/lang/Object;

.field private vipLevelId_:I


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->currentLevel_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->charge_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->nextLevel_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x4

    const-string p1, ""

    const/4 v1, 0x3

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->currentLevel_:Ljava/lang/Object;

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->charge_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->nextLevel_:Ljava/lang/Object;

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/UserProto$1;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method synthetic constructor <init>(Lcom/star/livegames/ws/protobuf/entity/UserProto$1;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method private buildPartial0(Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "result"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "i@s oS o  ~~~u~l~o @f@~1t~~o.o@~@~M@@n~yv@~ b@Kalfi@ ~@@~ ~/di@ors~ c~~ @b~@ ~~ 4@b@@ @ mt  @/- "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v3, 0x4

    move v4, v3

    and-int/lit8 v1, v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->currentLevel_:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->access$1902(Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v1, 0x4

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    and-int/lit8 v2, v0, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->vipLevelId_:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->access$2002(Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;I)I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    or-int/lit8 v1, v1, 0x2

    :cond_1
    const/4 v4, 0x4

    and-int/lit8 v2, v0, 0x4

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v2, :cond_2

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->charge_:Ljava/lang/Object;

    const/4 v4, 0x5

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->access$2102(Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    or-int/lit8 v1, v1, 0x4

    :cond_2
    const/4 v3, 0x6

    move v4, v3

    and-int/lit8 v0, v0, 0x8

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz v0, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->nextLevel_:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p1, v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->access$2202(Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    or-int/lit8 v1, v1, 0x8

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->access$2376(Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;I)I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto;->access$1400()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    return-object v0
.end method


# virtual methods
.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p1
.end method

.method public addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    const/4 v1, 0x3

    const/4 v0, 0x5

    return-object p1
.end method

.method public bridge synthetic build()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic build()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public build()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->isInitialized()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/protobuf/AbstractMessage$Builder;->newUninitializedMessageException(Lcom/google/protobuf/Message;)Lcom/google/protobuf/UninitializedMessageException;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    throw v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public buildPartial()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-direct {v0, p0, v1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/UserProto$1;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->buildPartial0(Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;)V

    :cond_0
    const/4 v2, 0x4

    move v3, v2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onBuilt()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    return-object v0
.end method

.method public clear()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    move v3, v2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x4

    const-string v1, ""

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->currentLevel_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->vipLevelId_:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->charge_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->nextLevel_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p0
.end method

.method public clearCharge()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->getCharge()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->charge_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    and-int/lit8 v0, v0, -0x5

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x1

    move v2, v1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p0
.end method

.method public clearCurrentLevel()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->getCurrentLevel()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->currentLevel_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    and-int/lit8 v0, v0, -0x2

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p0
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-object p1
.end method

.method public clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p1
.end method

.method public clearNextLevel()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->getNextLevel()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->nextLevel_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    and-int/lit8 v0, v0, -0x9

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v0, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p1
.end method

.method public clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p1
.end method

.method public clearVipLevelId()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    and-int/lit8 v0, v0, -0x3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->vipLevelId_:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method public clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    check-cast v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public getCharge()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->charge_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->charge_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0
.end method

.method public getChargeBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->charge_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->charge_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v0
.end method

.method public getCurrentLevel()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->currentLevel_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v2, 0x4

    move v3, v2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->currentLevel_:Ljava/lang/Object;

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0
.end method

.method public getCurrentLevelBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->currentLevel_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->currentLevel_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-object v0
.end method

.method public getDescriptorForType()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto;->access$1400()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public getNextLevel()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->nextLevel_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->nextLevel_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0
.end method

.method public getNextLevelBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->nextLevel_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->nextLevel_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method public getVipLevelId()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->vipLevelId_:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public hasCharge()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public hasCurrentLevel()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    and-int/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    return v1
.end method

.method public hasNextLevel()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    and-int/lit8 v0, v0, 0x8

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v0, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method public hasVipLevelId()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v2, 0x5

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto;->access$1500()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    const/4 v4, 0x3

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    const/4 v4, 0x7

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p1
.end method

.method public mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v0, 0x0

    :cond_0
    :goto_0
    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez v0, :cond_6

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readTag()I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v1, :cond_5

    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/16 v3, 0xa

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eq v1, v3, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/16 v3, 0x10

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eq v1, v3, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/16 v3, 0x1a

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eq v1, v3, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/16 v3, 0x22

    const/4 v5, 0x0

    const/4 v4, 0x2

    if-eq v1, v3, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-super {p0, p1, p2, v1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->parseUnknownField(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;I)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_1

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->nextLevel_:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v5, 0x5

    const/4 v4, 0x7

    or-int/lit8 v1, v1, 0x8

    const/4 v5, 0x7

    const/4 v4, 0x3

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->charge_:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    or-int/lit8 v1, v1, 0x4

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto/16 :goto_0

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readInt32()I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->vipLevelId_:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    or-int/lit8 v1, v1, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->currentLevel_:Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    or-int/2addr v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I
    :try_end_0
    .catch Lcom/google/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v5, 0x5

    goto/16 :goto_0

    :cond_5
    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    move v0, v2

    move v0, v2

    const/4 v5, 0x7

    move v0, v2

    move v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    goto/16 :goto_0

    :catchall_0
    move-exception p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_2

    :catch_0
    move-exception p1

    :try_start_1
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/InvalidProtocolBufferException;->unwrapIOException()Ljava/io/IOException;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_2
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    throw p1

    :cond_6
    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v4, 0x3

    move v5, v4

    return-object p0
.end method

.method public mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    instance-of v0, p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p1

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;

    const/4 v2, 0x5

    return-object p0
.end method

.method public mergeFrom(Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-ne p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0

    :cond_0
    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->hasCurrentLevel()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->access$1900(Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->currentLevel_:Ljava/lang/Object;

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    or-int/lit8 v0, v0, 0x1

    const/4 v2, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->hasVipLevelId()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->getVipLevelId()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->setVipLevelId(I)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->hasCharge()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz v0, :cond_3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->access$2100(Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->charge_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    or-int/lit8 v0, v0, 0x4

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_3
    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->hasNextLevel()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_4

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->access$2200(Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->nextLevel_:Ljava/lang/Object;

    const/4 v1, 0x6

    move v2, v1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    or-int/lit8 v0, v0, 0x8

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_4
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p1
.end method

.method public final mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x3

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p1
.end method

.method public setCharge(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->charge_:Ljava/lang/Object;

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    or-int/lit8 p1, p1, 0x4

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p0
.end method

.method public setChargeBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->access$2500(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->charge_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x0

    or-int/lit8 p1, p1, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    return-object p0
.end method

.method public setCurrentLevel(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->currentLevel_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method

.method public setCurrentLevelBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->access$2400(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->currentLevel_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p0
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1
.end method

.method public setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p1
.end method

.method public setNextLevel(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->nextLevel_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    or-int/lit8 p1, p1, 0x8

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p0
.end method

.method public setNextLevelBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel;->access$2600(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->nextLevel_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    or-int/lit8 p1, p1, 0x8

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p0
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    return-object p1
.end method

.method public setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-super {p0, p1, p2, p3}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    return-object p1
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    return-object p1
.end method

.method public final setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method public setVipLevelId(I)Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->vipLevelId_:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$RefreshLevel$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method
