.class public final Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
.super Lcom/google/protobuf/GeneratedMessageV3$Builder;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResultOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
        "Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;",
        ">;",
        "Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResultOrBuilder;"
    }
.end annotation


# instance fields
.field private anchorId_:Ljava/lang/Object;

.field private area_:Ljava/lang/Object;

.field private baubleGrade_:I

.field private baubleTime_:Ljava/lang/Object;

.field private bitField0_:I

.field private giftAmount_:Ljava/lang/Object;

.field private imgUrl_:Ljava/lang/Object;

.field private memberId_:Ljava/lang/Object;

.field private nickname_:Ljava/lang/Object;

.field private time_:Ljava/lang/Object;

.field private totalPrice_:Ljava/lang/Object;

.field private toyAmount_:Ljava/lang/Object;

.field private toyId_:Ljava/lang/Object;

.field private userRole_:I

.field private vipLevelId_:I


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v0, ""

    const/4 v2, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->area_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyAmount_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleTime_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyId_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->time_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v0, 0x7

    move v1, v0

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x5

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->area_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyAmount_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleTime_:Ljava/lang/Object;

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyId_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->time_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x3

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    return-void
.end method

.method synthetic constructor <init>(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method private buildPartial0(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "result"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "tosfbs@M t@~S4 ~oyb   ~~~ c~@o@ i ~a~@b@~l ~@-/r K~~u @~@.@@@@ ~~/f@~~o id~v@@ ~@ m~o o@~ n~@1l@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    move v4, v3

    and-int/lit8 v1, v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->area_:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$13802(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    and-int/lit8 v2, v0, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleGrade_:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$13902(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;I)I

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    or-int/lit8 v1, v1, 0x2

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    and-int/lit8 v2, v0, 0x4

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v2, :cond_2

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyAmount_:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14002(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    or-int/lit8 v1, v1, 0x4

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    and-int/lit8 v2, v0, 0x8

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v2, :cond_3

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14102(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    or-int/lit8 v1, v1, 0x8

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    and-int/lit8 v2, v0, 0x10

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v2, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleTime_:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14202(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    or-int/lit8 v1, v1, 0x10

    :cond_4
    const/4 v4, 0x1

    const/4 v3, 0x5

    and-int/lit8 v2, v0, 0x20

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v2, :cond_5

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14302(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    or-int/lit8 v1, v1, 0x20

    :cond_5
    const/4 v4, 0x6

    and-int/lit8 v2, v0, 0x40

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz v2, :cond_6

    const/4 v4, 0x5

    const/4 v3, 0x3

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyId_:Ljava/lang/Object;

    const/4 v4, 0x4

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14402(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    or-int/lit8 v1, v1, 0x40

    :cond_6
    const/4 v4, 0x6

    const/4 v3, 0x0

    and-int/lit16 v2, v0, 0x80

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz v2, :cond_7

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v4, 0x5

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14502(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    or-int/lit16 v1, v1, 0x80

    :cond_7
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    and-int/lit16 v2, v0, 0x100

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v2, :cond_8

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->vipLevelId_:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14602(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;I)I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    or-int/lit16 v1, v1, 0x100

    :cond_8
    const/4 v4, 0x1

    const/4 v3, 0x3

    and-int/lit16 v2, v0, 0x200

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v2, :cond_9

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14702(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    or-int/lit16 v1, v1, 0x200

    :cond_9
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    and-int/lit16 v2, v0, 0x400

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v2, :cond_a

    const/4 v4, 0x3

    const/4 v3, 0x7

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->time_:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14802(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    or-int/lit16 v1, v1, 0x400

    :cond_a
    const/4 v4, 0x1

    const/4 v3, 0x5

    and-int/lit16 v2, v0, 0x800

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz v2, :cond_b

    const/4 v4, 0x6

    const/4 v3, 0x0

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->userRole_:I

    const/4 v4, 0x5

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14902(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;I)I

    const/4 v4, 0x7

    or-int/lit16 v1, v1, 0x800

    :cond_b
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    and-int/lit16 v2, v0, 0x1000

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz v2, :cond_c

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$15002(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    or-int/lit16 v1, v1, 0x1000

    :cond_c
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    and-int/lit16 v0, v0, 0x2000

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v0, :cond_d

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p1, v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$15102(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    or-int/lit16 v1, v1, 0x2000

    :cond_d
    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$15276(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;I)I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-void
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto;->access$13300()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p1
.end method

.method public addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic build()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic build()Lcom/google/protobuf/MessageLite;
    .locals 3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public build()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;
    .locals 4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->isInitialized()Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/protobuf/AbstractMessage$Builder;->newUninitializedMessageException(Lcom/google/protobuf/Message;)Lcom/google/protobuf/UninitializedMessageException;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    throw v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method public buildPartial()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;
    .locals 4

    const/4 v3, 0x3

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-direct {v0, p0, v1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->buildPartial0(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onBuilt()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public clear()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 4

    const/4 v2, 0x4

    move v3, v2

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    const/4 v2, 0x6

    move v3, v2

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->area_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleGrade_:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyAmount_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleTime_:Ljava/lang/Object;

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->vipLevelId_:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->time_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->userRole_:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object p0
.end method

.method public clearAnchorId()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getAnchorId()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    and-int/lit8 v0, v0, -0x21

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    return-object p0
.end method

.method public clearArea()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getArea()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->area_:Ljava/lang/Object;

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    or-int/2addr v2, v1

    and-int/lit8 v0, v0, -0x2

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public clearBaubleGrade()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    and-int/lit8 v0, v0, -0x3

    const/4 v2, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleGrade_:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p0
.end method

.method public clearBaubleTime()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getBaubleTime()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleTime_:Ljava/lang/Object;

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    and-int/lit8 v0, v0, -0x11

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p1
.end method

.method public clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method public clearGiftAmount()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getGiftAmount()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    and-int/lit16 v0, v0, -0x2001

    const/4 v1, 0x7

    move v2, v1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p0
.end method

.method public clearImgUrl()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getImgUrl()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    and-int/lit16 v0, v0, -0x81

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p0
.end method

.method public clearMemberId()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getMemberId()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    and-int/lit16 v0, v0, -0x1001

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p0
.end method

.method public clearNickname()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getNickname()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    and-int/lit16 v0, v0, -0x201

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p1
.end method

.method public clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    const/4 v1, 0x2

    return-object p1
.end method

.method public clearTime()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getTime()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->time_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    and-int/lit16 v0, v0, -0x401

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public clearTotalPrice()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getTotalPrice()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    and-int/lit8 v0, v0, -0x9

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public clearToyAmount()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getToyAmount()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyAmount_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    and-int/lit8 v0, v0, -0x5

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0
.end method

.method public clearToyId()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getToyId()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyId_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    and-int/lit8 v0, v0, -0x41

    const/4 v2, 0x0

    const/4 v1, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public clearUserRole()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    and-int/lit16 v0, v0, -0x801

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->userRole_:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0
.end method

.method public clearVipLevelId()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    and-int/lit16 v0, v0, -0x101

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->vipLevelId_:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public clone()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    check-cast v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public getAnchorId()Ljava/lang/String;
    .locals 4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0
.end method

.method public getAnchorIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0
.end method

.method public getArea()Ljava/lang/String;
    .locals 4

    const/4 v2, 0x5

    move v3, v2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->area_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->area_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public getAreaBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->area_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->area_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0
.end method

.method public getBaubleGrade()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleGrade_:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public getBaubleTime()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleTime_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleTime_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method

.method public getBaubleTimeBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleTime_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleTime_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public getDescriptorForType()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto;->access$13300()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public getGiftAmount()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0
.end method

.method public getGiftAmountBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0
.end method

.method public getImgUrl()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0
.end method

.method public getImgUrlBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0
.end method

.method public getMemberId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0
.end method

.method public getMemberIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v0
.end method

.method public getNickname()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x0

    move v3, v2

    if-nez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    return-object v0
.end method

.method public getNicknameBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0
.end method

.method public getTime()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->time_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->time_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0
.end method

.method public getTimeBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->time_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->time_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0
.end method

.method public getTotalPrice()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v0
.end method

.method public getTotalPriceBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0
.end method

.method public getToyAmount()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyAmount_:Ljava/lang/Object;

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x4

    move v3, v2

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyAmount_:Ljava/lang/Object;

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0
.end method

.method public getToyAmountBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v2, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyAmount_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyAmount_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0
.end method

.method public getToyId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyId_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v2, 0x3

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public getToyIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyId_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x1

    or-int/2addr v3, v2

    return-object v0
.end method

.method public getUserRole()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->userRole_:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public getVipLevelId()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->vipLevelId_:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0
.end method

.method public hasAnchorId()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    and-int/lit8 v0, v0, 0x20

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public hasArea()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    and-int/2addr v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    return v1
.end method

.method public hasBaubleGrade()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v2, 0x0

    return v0
.end method

.method public hasBaubleTime()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    and-int/lit8 v0, v0, 0x10

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public hasGiftAmount()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    and-int/lit16 v0, v0, 0x2000

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public hasImgUrl()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    and-int/lit16 v0, v0, 0x80

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v0, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v0, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method public hasMemberId()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    and-int/lit16 v0, v0, 0x1000

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    and-int/2addr v2, v1

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    return v0
.end method

.method public hasNickname()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    and-int/lit16 v0, v0, 0x200

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public hasTime()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    and-int/lit16 v0, v0, 0x400

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    return v0
.end method

.method public hasTotalPrice()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    and-int/lit8 v0, v0, 0x8

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public hasToyAmount()Z
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    xor-int/2addr v2, v1

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public hasToyId()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    and-int/lit8 v0, v0, 0x40

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    return v0
.end method

.method public hasUserRole()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    and-int/lit16 v0, v0, 0x800

    const/4 v2, 0x2

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x1

    or-int/2addr v2, v0

    const/4 v1, 0x0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v0, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public hasVipLevelId()Z
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    and-int/lit16 v0, v0, 0x100

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto;->access$13400()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    const/4 v4, 0x4

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    const/4 v4, 0x1

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p1
.end method

.method public mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v0, 0x0

    :cond_0
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez v0, :cond_1

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readTag()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    sparse-switch v1, :sswitch_data_0

    const/4 v4, 0x7

    invoke-super {p0, p1, p2, v1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->parseUnknownField(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;I)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto/16 :goto_2

    :sswitch_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->giftAmount_:Ljava/lang/Object;

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    or-int/lit16 v1, v1, 0x2000

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto :goto_0

    :sswitch_1
    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    or-int/lit16 v1, v1, 0x1000

    const/4 v4, 0x3

    const/4 v3, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto :goto_0

    :sswitch_2
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt32()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->userRole_:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    or-int/lit16 v1, v1, 0x800

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_0

    :sswitch_3
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->time_:Ljava/lang/Object;

    const/4 v3, 0x6

    move v4, v3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    or-int/lit16 v1, v1, 0x400

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto/16 :goto_0

    :sswitch_4
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    or-int/lit16 v1, v1, 0x200

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto/16 :goto_0

    :sswitch_5
    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readInt32()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->vipLevelId_:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    or-int/lit16 v1, v1, 0x100

    const/4 v4, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x7

    goto/16 :goto_0

    :sswitch_6
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    or-int/lit16 v1, v1, 0x80

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto/16 :goto_0

    :sswitch_7
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyId_:Ljava/lang/Object;

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    move v4, v3

    or-int/lit8 v1, v1, 0x40

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    goto/16 :goto_0

    :sswitch_8
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    or-int/lit8 v1, v1, 0x20

    const/4 v4, 0x6

    const/4 v3, 0x4

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    goto/16 :goto_0

    :sswitch_9
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleTime_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    or-int/lit8 v1, v1, 0x10

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v3, 0x0

    move v4, v3

    goto/16 :goto_0

    :sswitch_a
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    or-int/lit8 v1, v1, 0x8

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto/16 :goto_0

    :sswitch_b
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyAmount_:Ljava/lang/Object;

    const/4 v4, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    or-int/lit8 v1, v1, 0x4

    const/4 v4, 0x2

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    goto/16 :goto_0

    :sswitch_c
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt32()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleGrade_:I

    const/4 v4, 0x5

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    or-int/lit8 v1, v1, 0x2

    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto/16 :goto_0

    :sswitch_d
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->area_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    or-int/2addr v1, v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I
    :try_end_0
    .catch Lcom/google/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto/16 :goto_0

    :goto_1
    :sswitch_e
    const/4 v4, 0x6

    const/4 v3, 0x4

    move v0, v2

    const/4 v4, 0x0

    move v0, v2

    move v0, v2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto/16 :goto_0

    :goto_2
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-nez v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    goto :goto_3

    :catch_0
    move-exception p1

    :try_start_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/InvalidProtocolBufferException;->unwrapIOException()Ljava/io/IOException;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_3
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    throw p1

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object p0

    :sswitch_data_0
    .sparse-switch
        0x0 -> :sswitch_e
        0xa -> :sswitch_d
        0x10 -> :sswitch_c
        0x1a -> :sswitch_b
        0x22 -> :sswitch_a
        0x2a -> :sswitch_9
        0x32 -> :sswitch_8
        0x3a -> :sswitch_7
        0x42 -> :sswitch_6
        0x48 -> :sswitch_5
        0x52 -> :sswitch_4
        0x5a -> :sswitch_3
        0x60 -> :sswitch_2
        0x6a -> :sswitch_1
        0x72 -> :sswitch_0
    .end sparse-switch
.end method

.method public mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    instance-of v0, p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p0
.end method

.method public mergeFrom(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-ne p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object p0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->hasArea()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$13800(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->area_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    or-int/lit8 v0, v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->hasBaubleGrade()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getBaubleGrade()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->setBaubleGrade(I)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    :cond_2
    const/4 v1, 0x5

    const/4 v1, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->hasToyAmount()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14000(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyAmount_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    or-int/lit8 v0, v0, 0x4

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_3
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->hasTotalPrice()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_4

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14100(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    or-int/lit8 v0, v0, 0x8

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_4
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->hasBaubleTime()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_5

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14200(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleTime_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    or-int/lit8 v0, v0, 0x10

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_5
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->hasAnchorId()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_6

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14300(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    or-int/lit8 v0, v0, 0x20

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_6
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->hasToyId()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_7

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14400(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyId_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    or-int/lit8 v0, v0, 0x40

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_7
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->hasImgUrl()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_8

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14500(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    or-int/lit16 v0, v0, 0x80

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_8
    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->hasVipLevelId()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_9

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getVipLevelId()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->setVipLevelId(I)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    :cond_9
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->hasNickname()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_a

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14700(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    or-int/lit16 v0, v0, 0x200

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_a
    const/4 v2, 0x5

    const/4 v1, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->hasTime()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_b

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$14800(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->time_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    or-int/lit16 v0, v0, 0x400

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_b
    const/4 v2, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->hasUserRole()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_c

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->getUserRole()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->setUserRole(I)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    :cond_c
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->hasMemberId()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    if-eqz v0, :cond_d

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$15000(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    or-int/lit16 v0, v0, 0x1000

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_d
    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->hasGiftAmount()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_e

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$15100(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    or-int/lit16 v0, v0, 0x2000

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_e
    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p0
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p1
.end method

.method public final mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p1
.end method

.method public setAnchorId(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v1, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    or-int/lit8 p1, p1, 0x20

    const/4 v1, 0x0

    const/4 v0, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v0, 0x7

    move v1, v0

    return-object p0
.end method

.method public setAnchorIdBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x1

    move v1, v0

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$15700(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->anchorId_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v0, 0x4

    const/4 v1, 0x1

    or-int/lit8 p1, p1, 0x20

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method

.method public setArea(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->area_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method public setAreaBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$15300(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->area_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    return-object p0
.end method

.method public setBaubleGrade(I)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleGrade_:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v0, 0x1

    const/4 v0, 0x5

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x6

    const/4 v0, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p0
.end method

.method public setBaubleTime(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleTime_:Ljava/lang/Object;

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    or-int/lit8 p1, p1, 0x10

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method

.method public setBaubleTimeBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$15600(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->baubleTime_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    or-int/lit8 p1, p1, 0x10

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p1
.end method

.method public setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p1
.end method

.method public setGiftAmount(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    or-int/lit16 p1, p1, 0x2000

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method public setGiftAmountBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$16300(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    or-int/lit16 p1, p1, 0x2000

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p0
.end method

.method public setImgUrl(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    or-int/lit16 p1, p1, 0x80

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p0
.end method

.method public setImgUrlBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$15900(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    or-int/lit16 p1, p1, 0x80

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p0
.end method

.method public setMemberId(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    or-int/lit16 p1, p1, 0x1000

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p0
.end method

.method public setMemberIdBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$16200(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->memberId_:Ljava/lang/Object;

    const/4 v1, 0x2

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    or-int/lit16 p1, p1, 0x1000

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    return-object p0
.end method

.method public setNickname(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    or-int/lit16 p1, p1, 0x200

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method public setNicknameBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$16000(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->nickname_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    or-int/lit16 p1, p1, 0x200

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    return-object p0
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p1
.end method

.method public setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-super {p0, p1, p2, p3}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p1
.end method

.method public setTime(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->time_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    or-int/lit16 p1, p1, 0x400

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x5

    return-object p0
.end method

.method public setTimeBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$16100(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->time_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v0, 0x5

    shl-int/2addr v1, v0

    or-int/lit16 p1, p1, 0x400

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v0, 0x7

    move v1, v0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p0
.end method

.method public setTotalPrice(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    or-int/lit8 p1, p1, 0x8

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p0
.end method

.method public setTotalPriceBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$15500(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->totalPrice_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    or-int/lit8 p1, p1, 0x8

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method public setToyAmount(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyAmount_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    or-int/lit8 p1, p1, 0x4

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    return-object p0
.end method

.method public setToyAmountBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$15400(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyAmount_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x1

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    or-int/lit8 p1, p1, 0x4

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method public setToyId(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyId_:Ljava/lang/Object;

    const/4 v0, 0x1

    or-int/2addr v1, v0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    or-int/lit8 p1, p1, 0x40

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    return-object p0
.end method

.method public setToyIdBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult;->access$15800(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->toyId_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    or-int/lit8 p1, p1, 0x40

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x7

    return-object p0
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p1
.end method

.method public final setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p1
.end method

.method public setUserRole(I)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->userRole_:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    or-int/lit16 p1, p1, 0x800

    const/4 v1, 0x7

    const/4 v0, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method public setVipLevelId(I)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->vipLevelId_:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    or-int/lit16 p1, p1, 0x100

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ToyResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x6

    return-object p0
.end method
