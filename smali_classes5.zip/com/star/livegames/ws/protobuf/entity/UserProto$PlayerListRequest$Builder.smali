.class public final Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
.super Lcom/google/protobuf/GeneratedMessageV3$Builder;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequestOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
        "Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;",
        ">;",
        "Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequestOrBuilder;"
    }
.end annotation


# instance fields
.field private bitField0_:I

.field private page_:I

.field private size_:I


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/UserProto$1;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method synthetic constructor <init>(Lcom/star/livegames/ws/protobuf/entity/UserProto$1;)V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    return-void
.end method

.method private buildPartial0(Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "result"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~s @ ~@@S o-a ~ li~ ob@ f@@o  oK@~bt ~ @@@o~cMl~y@bim~@u~tf ~d1@/ ~i~@n/  v@@@~~~~4. @s~@~~r~@o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    and-int/lit8 v1, v0, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->page_:I

    const/4 v2, 0x4

    move v3, v2

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;->access$3202(Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;I)I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    and-int/lit8 v0, v0, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->size_:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p1, v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;->access$3302(Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;I)I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    or-int/lit8 v1, v1, 0x2

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;->access$3476(Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;I)I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto;->access$2700()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p1
.end method

.method public addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    const/4 v0, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic build()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic build()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public build()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;->isInitialized()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/google/protobuf/AbstractMessage$Builder;->newUninitializedMessageException(Lcom/google/protobuf/Message;)Lcom/google/protobuf/UninitializedMessageException;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    throw v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public buildPartial()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;
    .locals 4

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {v0, p0, v1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/UserProto$1;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->buildPartial0(Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;)V

    :cond_0
    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onBuilt()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public clear()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->page_:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->size_:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p0
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v0, 0x6

    move v1, v0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p1
.end method

.method public clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p1
.end method

.method public clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p1
.end method

.method public clearPage()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    and-int/lit8 v0, v0, -0x2

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v0, 0x5

    const/4 v0, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->page_:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0
.end method

.method public clearSize()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v1, 0x3

    move v2, v1

    and-int/lit8 v0, v0, -0x3

    const/4 v2, 0x6

    const/4 v1, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->size_:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    check-cast v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public getDescriptorForType()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x0

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto;->access$2700()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public getPage()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->page_:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public getSize()I
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->size_:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public hasPage()Z
    .locals 4

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    and-int/2addr v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    return v1
.end method

.method public hasSize()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto;->access$2800()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    const/4 v4, 0x0

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    const/4 v4, 0x0

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p1
.end method

.method public mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v0, 0x0

    :cond_0
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez v0, :cond_4

    :try_start_0
    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readTag()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz v1, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/16 v3, 0x8

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eq v1, v3, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/16 v3, 0x10

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eq v1, v3, :cond_1

    const/4 v5, 0x5

    invoke-super {p0, p1, p2, v1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->parseUnknownField(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;I)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-nez v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt32()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->size_:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    or-int/lit8 v1, v1, 0x2

    const/4 v4, 0x3

    move v5, v4

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_0

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt32()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->page_:I

    const/4 v5, 0x7

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    or-int/2addr v1, v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I
    :try_end_0
    .catch Lcom/google/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    goto :goto_0

    :cond_3
    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    move v0, v2

    move v0, v2

    const/4 v5, 0x1

    move v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_2

    :catch_0
    move-exception p1

    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/InvalidProtocolBufferException;->unwrapIOException()Ljava/io/IOException;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_2
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    throw p1

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-object p0
.end method

.method public mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    instance-of v0, p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    const/4 v1, 0x0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public mergeFrom(Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    if-ne p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0

    :cond_0
    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;->hasPage()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;->getPage()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->setPage(I)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;->hasSize()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_2

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest;->getSize()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->setSize(I)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p0
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p1
.end method

.method public final mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    return-object p1
.end method

.method public setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p1
.end method

.method public setPage(I)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->page_:I

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p0
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p1
.end method

.method public setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-super {p0, p1, p2, p3}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    const/4 v1, 0x5

    const/4 v0, 0x4

    return-object p1
.end method

.method public setSize(I)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->size_:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v0, 0x1

    and-int/2addr v1, v0

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    return-object p0
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p1
.end method

.method public final setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListRequest$Builder;

    const/4 v1, 0x7

    return-object p1
.end method
