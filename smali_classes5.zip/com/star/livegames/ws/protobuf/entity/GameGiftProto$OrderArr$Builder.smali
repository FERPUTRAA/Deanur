.class public final Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
.super Lcom/google/protobuf/GeneratedMessageV3$Builder;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArrOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
        "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;",
        ">;",
        "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArrOrBuilder;"
    }
.end annotation


# instance fields
.field private betTypeContent_:Ljava/lang/Object;

.field private betTypeGroupId_:Ljava/lang/Object;

.field private bitField0_:I

.field private byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/RepeatedFieldBuilderV3<",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeListOrBuilder;",
            ">;"
        }
    .end annotation
.end field

.field private byteTypeList_:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;",
            ">;"
        }
    .end annotation
.end field

.field private gameId_:Ljava/lang/Object;

.field private gameIssue_:Ljava/lang/Object;

.field private gameName_:Ljava/lang/Object;

.field private multiple_:I

.field private totalMoney_:Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeGroupId_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameIssue_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->totalMoney_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeContent_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x4

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x6

    move v2, v1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeGroupId_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameId_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameIssue_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameName_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->totalMoney_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeContent_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$1;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method synthetic constructor <init>(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$1;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method private buildPartial0(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "result"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    and-int/lit8 v1, v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeGroupId_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10302(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    and-int/lit8 v2, v0, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameId_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10402(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    or-int/lit8 v1, v1, 0x2

    :cond_1
    const/4 v4, 0x1

    and-int/lit8 v2, v0, 0x8

    const/4 v3, 0x7

    const/4 v3, 0x2

    if-eqz v2, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameIssue_:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10502(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    or-int/lit8 v1, v1, 0x4

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    and-int/lit8 v2, v0, 0x10

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz v2, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameName_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10602(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    or-int/lit8 v1, v1, 0x8

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    and-int/lit8 v2, v0, 0x20

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v2, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->multiple_:I

    const/4 v4, 0x1

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10702(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;I)I

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    or-int/lit8 v1, v1, 0x10

    :cond_4
    const/4 v4, 0x0

    and-int/lit8 v2, v0, 0x40

    const/4 v4, 0x5

    const/4 v3, 0x5

    if-eqz v2, :cond_5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->totalMoney_:Ljava/lang/Object;

    const/4 v4, 0x1

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10802(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    or-int/lit8 v1, v1, 0x20

    :cond_5
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    and-int/lit16 v0, v0, 0x80

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v0, :cond_6

    const/4 v3, 0x5

    move v4, v3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeContent_:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {p1, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10902(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    or-int/lit8 v1, v1, 0x40

    :cond_6
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$11076(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;I)I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-void
.end method

.method private buildPartialRepeatedFields(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "result"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    and-int/lit8 v0, v0, -0x3

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p1, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10202(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;Ljava/util/List;)Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_0

    :cond_1
    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->build()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10202(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;Ljava/util/List;)Ljava/util/List;

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method private ensureByteTypeListIsMutable()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    or-int/lit8 v0, v0, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    :cond_0
    const/4 v3, 0x5

    return-void
.end method

.method private getByteTypeListFieldBuilder()Lcom/google/protobuf/RepeatedFieldBuilderV3;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/RepeatedFieldBuilderV3<",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeListOrBuilder;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-nez v0, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x1

    new-instance v0, Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v5, 0x2

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    and-int/lit8 v2, v2, 0x2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-eqz v2, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 v2, 0x1

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->getParentForChildren()Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->isClean()Z

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/google/protobuf/RepeatedFieldBuilderV3;-><init>(Ljava/util/List;ZLcom/google/protobuf/AbstractMessage$BuilderParent;Z)V

    const/4 v6, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v6, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v6, 0x7

    const/4 v5, 0x3

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto;->access$9700()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public addAllByteTypeList(Ljava/lang/Iterable;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "values"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;",
            ">;)",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v1, 0x4

    move v2, v1

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->ensureByteTypeListIsMutable()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite$Builder;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->addAllMessages(Ljava/lang/Iterable;)Lcom/google/protobuf/RepeatedFieldBuilderV3;

    :goto_0
    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method

.method public addByteTypeList(ILcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "builderForValue"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->ensureByteTypeListIsMutable()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {v0, p1, p2}, Ljava/util/List;->add(ILjava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->addMessage(ILcom/google/protobuf/AbstractMessage;)Lcom/google/protobuf/RepeatedFieldBuilderV3;

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0
.end method

.method public addByteTypeList(ILcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "value"
        }
    .end annotation

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->ensureByteTypeListIsMutable()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {v0, p1, p2}, Ljava/util/List;->add(ILjava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->addMessage(ILcom/google/protobuf/AbstractMessage;)Lcom/google/protobuf/RepeatedFieldBuilderV3;

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method

.method public addByteTypeList(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builderForValue"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v1, 0x6

    or-int/2addr v2, v1

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->ensureByteTypeListIsMutable()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x5

    or-int/2addr v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->addMessage(Lcom/google/protobuf/AbstractMessage;)Lcom/google/protobuf/RepeatedFieldBuilderV3;

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p0
.end method

.method public addByteTypeList(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->ensureByteTypeListIsMutable()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->addMessage(Lcom/google/protobuf/AbstractMessage;)Lcom/google/protobuf/RepeatedFieldBuilderV3;

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0
.end method

.method public addByteTypeListBuilder()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->getByteTypeListFieldBuilder()Lcom/google/protobuf/RepeatedFieldBuilderV3;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->addBuilder(Lcom/google/protobuf/AbstractMessage;)Lcom/google/protobuf/AbstractMessage$Builder;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    check-cast v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v0
.end method

.method public addByteTypeListBuilder(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->getByteTypeListFieldBuilder()Lcom/google/protobuf/RepeatedFieldBuilderV3;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, p1, v1}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->addBuilder(ILcom/google/protobuf/AbstractMessage;)Lcom/google/protobuf/AbstractMessage$Builder;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p1
.end method

.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p1
.end method

.method public addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    const/4 v1, 0x3

    const/4 v0, 0x1

    return-object p1
.end method

.method public bridge synthetic build()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic build()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->isInitialized()Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/protobuf/AbstractMessage$Builder;->newUninitializedMessageException(Lcom/google/protobuf/Message;)Lcom/google/protobuf/UninitializedMessageException;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    throw v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public buildPartial()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    const/4 v3, 0x1

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0, p0, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$1;)V

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->buildPartialRepeatedFields(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->buildPartial0(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onBuilt()V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    return-object v0
.end method

.method public clear()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x4

    xor-int/2addr v5, v4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeGroupId_:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v5, 0x4

    const/4 v4, 0x7

    if-nez v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    iput-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x3

    iput-object v3, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v2}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->clear()V

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    and-int/lit8 v2, v2, -0x3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    iput v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v5, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameId_:Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameIssue_:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameName_:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->multiple_:I

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->totalMoney_:Ljava/lang/Object;

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeContent_:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-object p0
.end method

.method public clearBetTypeContent()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->getBetTypeContent()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeContent_:Ljava/lang/Object;

    const/4 v1, 0x1

    and-int/2addr v2, v1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    and-int/lit16 v0, v0, -0x81

    const/4 v2, 0x1

    const/4 v1, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method

.method public clearBetTypeGroupId()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->getBetTypeGroupId()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeGroupId_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    and-int/lit8 v0, v0, -0x2

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method public clearByteTypeList()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    and-int/lit8 v0, v0, -0x3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->clear()V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    return-object p1
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v0, 0x5

    move v1, v0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p1
.end method

.method public clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p1
.end method

.method public clearGameId()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->getGameId()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameId_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    and-int/lit8 v0, v0, -0x5

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0
.end method

.method public clearGameIssue()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->getGameIssue()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameIssue_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    and-int/lit8 v0, v0, -0x9

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0
.end method

.method public clearGameName()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->getGameName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameName_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    and-int/lit8 v0, v0, -0x11

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p0
.end method

.method public clearMultiple()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    and-int/lit8 v0, v0, -0x21

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->multiple_:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x5

    return-object p0
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p1
.end method

.method public clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p1
.end method

.method public clearTotalMoney()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->getTotalMoney()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->totalMoney_:Ljava/lang/Object;

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    and-int/lit8 v0, v0, -0x41

    const/4 v2, 0x3

    const/4 v1, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    check-cast v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public getBetTypeContent()Ljava/lang/String;
    .locals 4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeContent_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeContent_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0
.end method

.method public getBetTypeContentBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeContent_:Ljava/lang/Object;

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeContent_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0
.end method

.method public getBetTypeGroupId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeGroupId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeGroupId_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public getBetTypeGroupIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeGroupId_:Ljava/lang/Object;

    const/4 v2, 0x0

    and-int/2addr v3, v2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeGroupId_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0
.end method

.method public getByteTypeList(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->getMessage(I)Lcom/google/protobuf/AbstractMessage;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x0

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p1
.end method

.method public getByteTypeListBuilder(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->getByteTypeListFieldBuilder()Lcom/google/protobuf/RepeatedFieldBuilderV3;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->getBuilder(I)Lcom/google/protobuf/AbstractMessage$Builder;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p1
.end method

.method public getByteTypeListBuilderList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->getByteTypeListFieldBuilder()Lcom/google/protobuf/RepeatedFieldBuilderV3;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->getBuilderList()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    return-object v0
.end method

.method public getByteTypeListCount()I
    .locals 3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0

    :cond_0
    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->getCount()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public getByteTypeListList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0

    :cond_0
    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {v0}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->getMessageList()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-object v0
.end method

.method public getByteTypeListOrBuilder(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeListOrBuilder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeListOrBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->getMessageOrBuilder(I)Lcom/google/protobuf/MessageOrBuilder;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeListOrBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p1
.end method

.method public getByteTypeListOrBuilderList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeListOrBuilder;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v2, 0x3

    const/4 v1, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->getMessageOrBuilderList()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public getDescriptorForType()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto;->access$9700()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public getGameId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameId_:Ljava/lang/Object;

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0
.end method

.method public getGameIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0
.end method

.method public getGameIssue()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameIssue_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameIssue_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    return-object v0
.end method

.method public getGameIssueBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameIssue_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameIssue_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0
.end method

.method public getGameName()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v2, 0x0

    move v3, v2

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0
.end method

.method public getGameNameBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v0
.end method

.method public getMultiple()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->multiple_:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public getTotalMoney()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->totalMoney_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->totalMoney_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object v0
.end method

.method public getTotalMoneyBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->totalMoney_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->totalMoney_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public hasBetTypeContent()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    and-int/lit16 v0, v0, 0x80

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    move v2, v1

    const/4 v0, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method

.method public hasBetTypeGroupId()Z
    .locals 4

    const/4 v3, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x5

    and-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    return v1
.end method

.method public hasGameId()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    return v0
.end method

.method public hasGameIssue()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    and-int/lit8 v0, v0, 0x8

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    return v0
.end method

.method public hasGameName()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    and-int/lit8 v0, v0, 0x10

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public hasMultiple()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x6

    move v2, v1

    and-int/lit8 v0, v0, 0x20

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public hasTotalMoney()Z
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v2, 0x2

    and-int/lit8 v0, v0, 0x40

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto;->access$9800()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    const/4 v4, 0x2

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    const/4 v4, 0x6

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p1
.end method

.method public mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v0, 0x0

    :cond_0
    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez v0, :cond_b

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readTag()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz v1, :cond_a

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/16 v3, 0xa

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eq v1, v3, :cond_9

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/16 v3, 0x12

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eq v1, v3, :cond_7

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/16 v3, 0x1a

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eq v1, v3, :cond_6

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/16 v3, 0x22

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eq v1, v3, :cond_5

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/16 v3, 0x2a

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eq v1, v3, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/16 v3, 0x30

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eq v1, v3, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/16 v3, 0x3a

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eq v1, v3, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/16 v3, 0x42

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eq v1, v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-super {p0, p1, p2, v1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->parseUnknownField(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;I)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-nez v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto/16 :goto_1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeContent_:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    or-int/lit16 v1, v1, 0x80

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v4, 0x7

    or-int/2addr v5, v4

    goto/16 :goto_0

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->totalMoney_:Ljava/lang/Object;

    const/4 v4, 0x5

    move v5, v4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    or-int/lit8 v1, v1, 0x40

    const/4 v5, 0x4

    const/4 v4, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v5, 0x6

    const/4 v4, 0x1

    goto/16 :goto_0

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt32()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->multiple_:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v4, 0x0

    shr-int/2addr v5, v4

    or-int/lit8 v1, v1, 0x20

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    goto/16 :goto_0

    :cond_4
    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameName_:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    or-int/lit8 v1, v1, 0x10

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto/16 :goto_0

    :cond_5
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameIssue_:Ljava/lang/Object;

    const/4 v5, 0x6

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v5, 0x5

    or-int/lit8 v1, v1, 0x8

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    goto/16 :goto_0

    :cond_6
    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameId_:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    or-int/lit8 v1, v1, 0x4

    const/4 v4, 0x1

    move v5, v4

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto/16 :goto_0

    :cond_7
    const/4 v4, 0x3

    move v5, v4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;->parser()Lcom/google/protobuf/Parser;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p1, v1, p2}, Lcom/google/protobuf/CodedInputStream;->readMessage(Lcom/google/protobuf/Parser;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    check-cast v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-nez v2, :cond_8

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->ensureByteTypeListIsMutable()V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto/16 :goto_0

    :cond_8
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v2, v1}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->addMessage(Lcom/google/protobuf/AbstractMessage;)Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto/16 :goto_0

    :cond_9
    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeGroupId_:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x2

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    or-int/2addr v1, v2

    const/4 v5, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I
    :try_end_0
    .catch Lcom/google/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto/16 :goto_0

    :cond_a
    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x0

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto/16 :goto_0

    :catchall_0
    move-exception p1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto :goto_2

    :catch_0
    move-exception p1

    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/InvalidProtocolBufferException;->unwrapIOException()Ljava/io/IOException;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_2
    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    throw p1

    :cond_b
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object p0
.end method

.method public mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x7

    instance-of v0, p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;

    const/4 v1, 0x1

    const/4 v1, 0x3

    return-object p0
.end method

.method public mergeFrom(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v2, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-ne p1, v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->hasBetTypeGroupId()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10300(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeGroupId_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    or-int/lit8 v0, v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_1
    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v0, :cond_3

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10200(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez v0, :cond_6

    const/4 v3, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10200(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    and-int/lit8 v0, v0, -0x3

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->ensureByteTypeListIsMutable()V

    const/4 v2, 0x7

    move v3, v2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10200(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)Ljava/util/List;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    goto :goto_1

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10200(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-nez v0, :cond_6

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->isEmpty()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_5

    const/4 v3, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->dispose()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10200(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)Ljava/util/List;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    and-int/lit8 v1, v1, -0x3

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$11100()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->getByteTypeListFieldBuilder()Lcom/google/protobuf/RepeatedFieldBuilderV3;

    move-result-object v0

    :cond_4
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_1

    :cond_5
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10200(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)Ljava/util/List;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->addAllMessages(Ljava/lang/Iterable;)Lcom/google/protobuf/RepeatedFieldBuilderV3;

    :cond_6
    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->hasGameId()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_7

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10400(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    or-int/lit8 v0, v0, 0x4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_7
    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->hasGameIssue()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_8

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10500(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameIssue_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    or-int/lit8 v0, v0, 0x8

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_8
    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->hasGameName()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_9

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10600(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    or-int/lit8 v0, v0, 0x10

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_9
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->hasMultiple()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_a

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->getMultiple()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->setMultiple(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    :cond_a
    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->hasTotalMoney()Z

    move-result v0

    const/4 v3, 0x2

    if-eqz v0, :cond_b

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10800(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->totalMoney_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    or-int/lit8 v0, v0, 0x40

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_b
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->hasBetTypeContent()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_c

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$10900(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeContent_:Ljava/lang/Object;

    const/4 v3, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    or-int/lit16 v0, v0, 0x80

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_c
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object p0
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p1
.end method

.method public final mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v0, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v0, 0x0

    or-int/2addr v1, v0

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p1
.end method

.method public removeByteTypeList(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v2, 0x6

    const/4 v1, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->ensureByteTypeListIsMutable()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->remove(I)V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public setBetTypeContent(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeContent_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    or-int/lit16 p1, p1, 0x80

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p0
.end method

.method public setBetTypeContentBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$11700(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeContent_:Ljava/lang/Object;

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    or-int/lit16 p1, p1, 0x80

    const/4 v1, 0x3

    const/4 v0, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    return-object p0
.end method

.method public setBetTypeGroupId(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeGroupId_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p0
.end method

.method public setBetTypeGroupIdBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$11200(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->betTypeGroupId_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method

.method public setByteTypeList(ILcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "builderForValue"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->ensureByteTypeListIsMutable()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x0

    invoke-virtual {p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-interface {v0, p1, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->setMessage(ILcom/google/protobuf/AbstractMessage;)Lcom/google/protobuf/RepeatedFieldBuilderV3;

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0
.end method

.method public setByteTypeList(ILcom/star/livegames/ws/protobuf/entity/GameGiftProto$ByteTypeList;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "value"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeListBuilder_:Lcom/google/protobuf/RepeatedFieldBuilderV3;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->ensureByteTypeListIsMutable()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->byteTypeList_:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-interface {v0, p1, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/RepeatedFieldBuilderV3;->setMessage(ILcom/google/protobuf/AbstractMessage;)Lcom/google/protobuf/RepeatedFieldBuilderV3;

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p0
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p1
.end method

.method public setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-object p1
.end method

.method public setGameId(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameId_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x4

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p0
.end method

.method public setGameIdBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$11300(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameId_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    or-int/lit8 p1, p1, 0x4

    const/4 v0, 0x1

    xor-int/2addr v1, v0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p0
.end method

.method public setGameIssue(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameIssue_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x0

    or-int/lit8 p1, p1, 0x8

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method public setGameIssueBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x6

    move v1, v0

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$11400(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameIssue_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    or-int/lit8 p1, p1, 0x8

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p0
.end method

.method public setGameName(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameName_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x7

    or-int/lit8 p1, p1, 0x10

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p0
.end method

.method public setGameNameBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$11500(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->gameName_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x10

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method public setMultiple(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->multiple_:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    or-int/lit8 p1, p1, 0x20

    const/4 v1, 0x1

    const/4 v0, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p0
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p1
.end method

.method public setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    invoke-super {p0, p1, p2, p3}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method

.method public setTotalMoney(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->totalMoney_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    or-int/lit8 p1, p1, 0x40

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p0
.end method

.method public setTotalMoneyBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr;->access$11600(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->totalMoney_:Ljava/lang/Object;

    const/4 v0, 0x3

    shr-int/2addr v1, v0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    or-int/lit8 p1, p1, 0x40

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p1
.end method

.method public final setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OrderArr$Builder;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p1
.end method
