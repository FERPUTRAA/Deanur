.class public final Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;
.super Lcom/google/protobuf/GeneratedMessageV3;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResultOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/PKProto;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "PKResult"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;,
        Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$PkInfoReplyDefaultEntryHolder;
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

.field private static final PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;",
            ">;"
        }
    .end annotation
.end field

.field public static final PKINFOREPLY_FIELD_NUMBER:I = 0x1

.field private static final serialVersionUID:J


# instance fields
.field private memoizedIsInitialized:B

.field private pkInfoReply_:Lcom/google/protobuf/MapField;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/MapField<",
            "Ljava/lang/String;",
            "Lcom/star/livegames/ws/protobuf/entity/PKProto$PKDataList;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    sput-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$1;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {v0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$1;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    sput-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-byte v0, p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->memoizedIsInitialized:B

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    const/4 p1, -0x1

    const/4 v1, 0x6

    const/4 v0, 0x6

    iput-byte p1, p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->memoizedIsInitialized:B

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/PKProto$1;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic access$7002(Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;Lcom/google/protobuf/MapField;)Lcom/google/protobuf/MapField;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@vs tyit@b @mas@~/ @~@~~ob@@ l@ ~@~@~/ iu~f1 Mf~ b@  o4 ro@@@K .~~~ -~~n icS ~~o~~@ @~~l@~@ o~@d"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->pkInfoReply_:Lcom/google/protobuf/MapField;

    const/4 v1, 0x5

    return-object p1
.end method

.method static synthetic access$7100(Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;)Lcom/google/protobuf/MapField;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->internalGetPkInfoReply()Lcom/google/protobuf/MapField;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method public static getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/PKProto;->access$6400()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    return-object v0
.end method

.method private internalGetPkInfoReply()Lcom/google/protobuf/MapField;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/MapField<",
            "Ljava/lang/String;",
            "Lcom/star/livegames/ws/protobuf/entity/PKProto$PKDataList;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->pkInfoReply_:Lcom/google/protobuf/MapField;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$PkInfoReplyDefaultEntryHolder;->defaultEntry:Lcom/google/protobuf/MapEntry;

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/protobuf/MapField;->emptyMapField(Lcom/google/protobuf/MapEntry;)Lcom/google/protobuf/MapField;

    move-result-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public static newBuilder()Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public static newBuilder(Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "prototype"
        }
    .end annotation

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v1, 0x2

    move v2, v1

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom([B)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom([B)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x7

    const/4 v1, 0x6

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method public containsPkInfoReply(Ljava/lang/String;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->internalGetPkInfoReply()Lcom/google/protobuf/MapField;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/MapField;->getMap()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string v0, " pkmsya"

    const-string v0, "kpsyae "

    const/4 v2, 0x1

    const-string v0, "akmyop "

    const-string v0, "map key"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    throw p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-ne p1, p0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    return v0

    :cond_0
    const/4 v3, 0x0

    move v4, v3

    instance-of v1, p1, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    return p1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->internalGetPkInfoReply()Lcom/google/protobuf/MapField;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {p1}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->internalGetPkInfoReply()Lcom/google/protobuf/MapField;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-virtual {v1, v2}, Lcom/google/protobuf/MapField;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez v1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    return v2

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Lcom/google/protobuf/UnknownFieldSet;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-nez p1, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    return v2

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    return v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public getParserForType()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public getPkInfoReply()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/star/livegames/ws/protobuf/entity/PKProto$PKDataList;",
            ">;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->getPkInfoReplyMap()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public getPkInfoReplyCount()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->internalGetPkInfoReply()Lcom/google/protobuf/MapField;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/MapField;->getMap()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public getPkInfoReplyMap()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/star/livegames/ws/protobuf/entity/PKProto$PKDataList;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->internalGetPkInfoReply()Lcom/google/protobuf/MapField;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/MapField;->getMap()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public getPkInfoReplyOrDefault(Ljava/lang/String;Lcom/star/livegames/ws/protobuf/entity/PKProto$PKDataList;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKDataList;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "defaultValue"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->internalGetPkInfoReply()Lcom/google/protobuf/MapField;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/MapField;->getMap()Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v2, 0x6

    move v3, v2

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    check-cast p2, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKDataList;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    return-object p2

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string p2, " amkmbe"

    const-string p2, "maemp k"

    const/4 v3, 0x3

    const-string p2, "eapkm u"

    const-string p2, "map key"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    throw p1
.end method

.method public getPkInfoReplyOrThrow(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKDataList;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->internalGetPkInfoReply()Lcom/google/protobuf/MapField;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/MapField;->getMap()Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKDataList;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object p1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    throw p1

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string v0, "pam eyo"

    const-string v0, "k meoya"

    const/4 v3, 0x3

    const-string v0, "eqp amy"

    const-string v0, "map key"

    const/4 v3, 0x5

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    throw p1
.end method

.method public getSerializedSize()I
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/4 v1, -0x1

    const/4 v5, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eq v0, v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    return v0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->internalGetPkInfoReply()Lcom/google/protobuf/MapField;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/MapField;->getMap()Ljava/util/Map;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz v2, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x6

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    sget-object v3, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$PkInfoReplyDefaultEntryHolder;->defaultEntry:Lcom/google/protobuf/MapEntry;

    const/4 v6, 0x5

    invoke-virtual {v3}, Lcom/google/protobuf/MapEntry;->newBuilderForType()Lcom/google/protobuf/MapEntry$Builder;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    check-cast v4, Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v3, v4}, Lcom/google/protobuf/MapEntry$Builder;->setKey(Ljava/lang/Object;)Lcom/google/protobuf/MapEntry$Builder;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    check-cast v2, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKDataList;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v3, v2}, Lcom/google/protobuf/MapEntry$Builder;->setValue(Ljava/lang/Object;)Lcom/google/protobuf/MapEntry$Builder;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/google/protobuf/MapEntry$Builder;->build()Lcom/google/protobuf/MapEntry;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v3, 0x1

    move v6, v3

    const/4 v5, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v3, v2}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    add-int/2addr v1, v2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->getSerializedSize()I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    add-int/2addr v1, v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    iput v1, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    return v1
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget v0, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    return v0

    :cond_0
    const/4 v2, 0x2

    move v3, v2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/16 v1, 0x30b

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    add-int/2addr v1, v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->internalGetPkInfoReply()Lcom/google/protobuf/MapField;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/MapField;->getMap()Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    add-int/lit8 v1, v1, 0x1

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->internalGetPkInfoReply()Lcom/google/protobuf/MapField;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/MapField;->hashCode()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    add-int/2addr v1, v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x1d

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->hashCode()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    add-int/2addr v1, v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput v1, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    return v1
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/PKProto;->access$6500()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v4, 0x7

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v4, 0x1

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    const/4 v4, 0x7

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object v0
.end method

.method protected internalGetMapFieldReflection(I)Lcom/google/protobuf/MapFieldReflectionAccessor;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "number"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-ne p1, v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->internalGetPkInfoReply()Lcom/google/protobuf/MapField;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-object p1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string v2, "n sdem av:dal Ifnrbim biel"

    const-string v2, "  aIebfinam uidreb lnd:lvm"

    const/4 v4, 0x6

    const-string v2, "Invalid map field number: "

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    throw v0
.end method

.method public final isInitialized()Z
    .locals 4

    const/4 v2, 0x4

    move v3, v2

    iget-byte v0, p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->memoizedIsInitialized:B

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    return v1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x0

    or-int/2addr v3, v0

    return v0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-byte v1, p0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->memoizedIsInitialized:B

    const/4 v2, 0x0

    shl-int/2addr v3, v2

    return v1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    move-result-object v0

    const/4 v1, 0x5

    move v2, v1

    return-object v0
.end method

.method protected bridge synthetic newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v0, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method public newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->newBuilder()Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method protected newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0, p1, v1}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/PKProto$1;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object v0
.end method

.method protected newInstance(Lcom/google/protobuf/GeneratedMessageV3$UnusedPrivateParameter;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unused"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    new-instance p1, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p1}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-object v0
.end method

.method public toBuilder()Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-ne p0, v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;-><init>(Lcom/star/livegames/ws/protobuf/entity/PKProto$1;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;-><init>(Lcom/star/livegames/ws/protobuf/entity/PKProto$1;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;)Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$Builder;

    move-result-object v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0
.end method

.method public writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult;->internalGetPkInfoReply()Lcom/google/protobuf/MapField;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    sget-object v1, Lcom/star/livegames/ws/protobuf/entity/PKProto$PKResult$PkInfoReplyDefaultEntryHolder;->defaultEntry:Lcom/google/protobuf/MapEntry;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {p1, v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3;->serializeStringMapTo(Lcom/google/protobuf/CodedOutputStream;Lcom/google/protobuf/MapField;Lcom/google/protobuf/MapEntry;I)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Lcom/google/protobuf/UnknownFieldSet;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void
.end method
