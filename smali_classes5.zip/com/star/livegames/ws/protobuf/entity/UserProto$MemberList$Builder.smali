.class public final Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
.super Lcom/google/protobuf/GeneratedMessageV3$Builder;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberListOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
        "Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;",
        ">;",
        "Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberListOrBuilder;"
    }
.end annotation


# instance fields
.field private bitField0_:I

.field private giftAmount_:Ljava/lang/Object;

.field private imgUrl_:Ljava/lang/Object;

.field private memberId_:Ljava/lang/Object;

.field private nickname_:Ljava/lang/Object;

.field private roomManager_:I

.field private sysTime_:Ljava/lang/Object;

.field private username_:Ljava/lang/Object;

.field private vipLevelId_:I


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->nickname_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->memberId_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->username_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->sysTime_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x7

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->nickname_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->memberId_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->username_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->sysTime_:Ljava/lang/Object;

    const/4 v0, 0x7

    shr-int/2addr v1, v0

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/UserProto$1;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method synthetic constructor <init>(Lcom/star/livegames/ws/protobuf/entity/UserProto$1;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method private buildPartial0(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "result"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "o@s .~ @~ir~@  ~~ @~Kb~@@~~oM @i@o~y~~ u @b@o~~t~c@ i~v@nl4 /~@~1l@o@ ~mf /S @~d-o@~~@a  b  fst@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v4, 0x3

    and-int/lit8 v1, v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x1

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$4902(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    and-int/lit8 v2, v0, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->nickname_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$5002(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    or-int/lit8 v1, v1, 0x2

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x4

    and-int/lit8 v2, v0, 0x4

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->memberId_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$5102(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    or-int/lit8 v1, v1, 0x4

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    and-int/lit8 v2, v0, 0x8

    const/4 v4, 0x2

    const/4 v3, 0x0

    if-eqz v2, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->username_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$5202(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    or-int/lit8 v1, v1, 0x8

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    and-int/lit8 v2, v0, 0x10

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v2, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$5302(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    or-int/lit8 v1, v1, 0x10

    :cond_4
    const/4 v4, 0x3

    and-int/lit8 v2, v0, 0x20

    const/4 v4, 0x6

    if-eqz v2, :cond_5

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->vipLevelId_:I

    const/4 v4, 0x2

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$5402(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;I)I

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    or-int/lit8 v1, v1, 0x20

    :cond_5
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    and-int/lit8 v2, v0, 0x40

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz v2, :cond_6

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->roomManager_:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$5502(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;I)I

    const/4 v4, 0x3

    or-int/lit8 v1, v1, 0x40

    :cond_6
    const/4 v4, 0x4

    and-int/lit16 v0, v0, 0x80

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v0, :cond_7

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->sysTime_:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p1, v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$5602(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    or-int/lit16 v1, v1, 0x80

    :cond_7
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$5776(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;I)I

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto;->access$4400()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p1
.end method

.method public addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic build()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic build()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public build()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;
    .locals 4

    const/4 v2, 0x6

    move v3, v2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->isInitialized()Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/protobuf/AbstractMessage$Builder;->newUninitializedMessageException(Lcom/google/protobuf/Message;)Lcom/google/protobuf/UninitializedMessageException;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    throw v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public buildPartial()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x5

    invoke-direct {v0, p0, v1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/UserProto$1;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->buildPartial0(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onBuilt()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    return-object v0
.end method

.method public clear()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 4

    const/4 v3, 0x7

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->username_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->vipLevelId_:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->roomManager_:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->sysTime_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x6

    return-object p0
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    return-object p1
.end method

.method public clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    const/4 v1, 0x7

    return-object p1
.end method

.method public clearGiftAmount()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getGiftAmount()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    and-int/lit8 v0, v0, -0x11

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p0
.end method

.method public clearImgUrl()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getImgUrl()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    and-int/lit8 v0, v0, -0x2

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    return-object p0
.end method

.method public clearMemberId()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getMemberId()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->memberId_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    and-int/lit8 v0, v0, -0x5

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public clearNickname()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getNickname()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->nickname_:Ljava/lang/Object;

    const/4 v1, 0x1

    move v2, v1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    and-int/lit8 v0, v0, -0x3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p1
.end method

.method public clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p1
.end method

.method public clearRoomManager()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    and-int/lit8 v0, v0, -0x41

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->roomManager_:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method

.method public clearSysTime()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getSysTime()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->sysTime_:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    and-int/lit16 v0, v0, -0x81

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public clearUsername()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getUsername()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->username_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    and-int/lit8 v0, v0, -0x9

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0
.end method

.method public clearVipLevelId()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    and-int/lit8 v0, v0, -0x21

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->vipLevelId_:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x1

    return-object p0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object v0

    const/4 v1, 0x1

    move v2, v1

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    check-cast v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public getDescriptorForType()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto;->access$4400()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    return-object v0
.end method

.method public getGiftAmount()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v2, 0x3

    move v3, v2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0
.end method

.method public getGiftAmountBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0
.end method

.method public getImgUrl()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v0
.end method

.method public getImgUrlBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0
.end method

.method public getMemberId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public getMemberIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->memberId_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->memberId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0
.end method

.method public getNickname()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    return-object v0
.end method

.method public getNicknameBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x3

    move v3, v2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->nickname_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v0
.end method

.method public getRoomManager()I
    .locals 3

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->roomManager_:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public getSysTime()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->sysTime_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->sysTime_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0
.end method

.method public getSysTimeBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->sysTime_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->sysTime_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0
.end method

.method public getUsername()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->username_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->username_:Ljava/lang/Object;

    const/4 v2, 0x4

    move v3, v2

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0
.end method

.method public getUsernameBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->username_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->username_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v2, 0x4

    move v3, v2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0
.end method

.method public getVipLevelId()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->vipLevelId_:I

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public hasGiftAmount()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x0

    and-int/lit8 v0, v0, 0x10

    const/4 v1, 0x3

    move v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x0

    and-int/2addr v1, v0

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x3

    const/4 v1, 0x1

    return v0
.end method

.method public hasImgUrl()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    and-int/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    return v1
.end method

.method public hasMemberId()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x1

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public hasNickname()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x1

    move v2, v1

    return v0
.end method

.method public hasRoomManager()Z
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    and-int/lit8 v0, v0, 0x40

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public hasSysTime()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    and-int/lit16 v0, v0, 0x80

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    move v2, v1

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public hasUsername()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    and-int/lit8 v0, v0, 0x8

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public hasVipLevelId()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    and-int/lit8 v0, v0, 0x20

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    return v0
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto;->access$4500()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    const/4 v4, 0x4

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    const/4 v4, 0x3

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method

.method public mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v0, 0x0

    :cond_0
    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez v0, :cond_a

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readTag()I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v1, :cond_9

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/16 v3, 0xa

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eq v1, v3, :cond_8

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/16 v3, 0x12

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eq v1, v3, :cond_7

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/16 v3, 0x1a

    const/4 v5, 0x7

    const/4 v4, 0x5

    if-eq v1, v3, :cond_6

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/16 v3, 0x22

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eq v1, v3, :cond_5

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/16 v3, 0x2a

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eq v1, v3, :cond_4

    const/4 v5, 0x6

    const/16 v3, 0x30

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eq v1, v3, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/16 v3, 0x38

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eq v1, v3, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/16 v3, 0x42

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eq v1, v3, :cond_1

    const/4 v4, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-super {p0, p1, p2, v1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->parseUnknownField(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;I)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    if-nez v1, :cond_0

    const/4 v5, 0x3

    goto/16 :goto_1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->sysTime_:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    or-int/lit16 v1, v1, 0x80

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    goto/16 :goto_0

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt32()I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->roomManager_:I

    const/4 v5, 0x1

    const/4 v4, 0x7

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    or-int/lit8 v1, v1, 0x40

    const/4 v4, 0x0

    const/4 v5, 0x4

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v5, 0x6

    goto/16 :goto_0

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readInt32()I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->vipLevelId_:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    or-int/lit8 v1, v1, 0x20

    const/4 v5, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v5, 0x1

    goto/16 :goto_0

    :cond_4
    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v5, 0x5

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    or-int/lit8 v1, v1, 0x10

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_5
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->username_:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v5, 0x2

    or-int/lit8 v1, v1, 0x8

    const/4 v5, 0x3

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto/16 :goto_0

    :cond_6
    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->memberId_:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    or-int/lit8 v1, v1, 0x4

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_7
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->nickname_:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    or-int/lit8 v1, v1, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    goto/16 :goto_0

    :cond_8
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    or-int/2addr v1, v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I
    :try_end_0
    .catch Lcom/google/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    move v5, v4

    goto/16 :goto_0

    :cond_9
    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    move v0, v2

    move v0, v2

    const/4 v5, 0x3

    move v0, v2

    move v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    goto/16 :goto_0

    :catchall_0
    move-exception p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    goto :goto_2

    :catch_0
    move-exception p1

    :try_start_1
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/InvalidProtocolBufferException;->unwrapIOException()Ljava/io/IOException;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_2
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v5, 0x7

    throw p1

    :cond_a
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object p0
.end method

.method public mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    instance-of v0, p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public mergeFrom(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    if-ne p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p0

    :cond_0
    const/4 v2, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->hasImgUrl()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$4900(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    or-int/lit8 v0, v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->hasNickname()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$5000(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->nickname_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    or-int/lit8 v0, v0, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->hasMemberId()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_3

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$5100(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;)Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x5

    const/4 v1, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->memberId_:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    or-int/lit8 v0, v0, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_3
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->hasUsername()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    if-eqz v0, :cond_4

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$5200(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->username_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x0

    xor-int/2addr v2, v1

    or-int/lit8 v0, v0, 0x8

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_4
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->hasGiftAmount()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_5

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$5300(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    or-int/lit8 v0, v0, 0x10

    const/4 v2, 0x3

    const/4 v1, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_5
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->hasVipLevelId()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_6

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getVipLevelId()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->setVipLevelId(I)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    :cond_6
    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->hasRoomManager()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_7

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->getRoomManager()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->setRoomManager(I)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    :cond_7
    const/4 v2, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->hasSysTime()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_8

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$5600(Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->sysTime_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    or-int/lit16 v0, v0, 0x80

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x7

    and-int/2addr v2, v1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_8
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x1

    return-object p0
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p1
.end method

.method public final mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p1
.end method

.method public setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p1
.end method

.method public setGiftAmount(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x1

    or-int/lit8 p1, p1, 0x10

    const/4 v1, 0x5

    const/4 v0, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v0, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0
.end method

.method public setGiftAmountBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$6200(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->giftAmount_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    or-int/lit8 p1, p1, 0x10

    const/4 v1, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method public setImgUrl(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    return-object p0
.end method

.method public setImgUrlBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$5800(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->imgUrl_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method public setMemberId(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->memberId_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    or-int/lit8 p1, p1, 0x4

    const/4 v0, 0x1

    move v1, v0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p0
.end method

.method public setMemberIdBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$6000(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->memberId_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    or-int/lit8 p1, p1, 0x4

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method public setNickname(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->nickname_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p0
.end method

.method public setNicknameBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v0, 0x2

    move v1, v0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x3

    shl-int/2addr v1, v0

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$5900(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->nickname_:Ljava/lang/Object;

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    or-int/lit8 p1, p1, 0x2

    const/4 v0, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p1
.end method

.method public setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-super {p0, p1, p2, p3}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    const/4 v0, 0x6

    move v1, v0

    return-object p1
.end method

.method public setRoomManager(I)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->roomManager_:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    or-int/lit8 p1, p1, 0x40

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method

.method public setSysTime(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->sysTime_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    or-int/lit16 p1, p1, 0x80

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-object p0
.end method

.method public setSysTimeBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$6300(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->sysTime_:Ljava/lang/Object;

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    or-int/lit16 p1, p1, 0x80

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p1
.end method

.method public final setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p1
.end method

.method public setUsername(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->username_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    or-int/lit8 p1, p1, 0x8

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p0
.end method

.method public setUsernameBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;->access$6100(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->username_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    or-int/lit8 p1, p1, 0x8

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method public setVipLevelId(I)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->vipLevelId_:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x20

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p0
.end method
