.class public final Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
.super Lcom/google/protobuf/GeneratedMessageV3$Builder;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResultOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
        "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;",
        ">;",
        "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResultOrBuilder;"
    }
.end annotation


# instance fields
.field private amountBig_:Ljava/lang/Object;

.field private amount_:J

.field private bitField0_:I

.field private endTime_:J

.field private issue_:Ljava/lang/Object;

.field private limitAmountBig_:Ljava/lang/Object;

.field private limitAmount_:J

.field private limitPeople_:I

.field private nextIssueTime_:J

.field private now_:J

.field private people_:I

.field private si_:Ljava/lang/Object;

.field private startTime_:J


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->issue_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amountBig_:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmountBig_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->si_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x4

    const-string p1, ""

    const-string p1, ""

    const/4 v0, 0x4

    or-int/2addr v1, v0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->issue_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amountBig_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmountBig_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->si_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$1;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method synthetic constructor <init>(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$1;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method private buildPartial0(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "result"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "r/si b@@  o~tf@~~- @  ~~~/ci ~~@~ o~a@ @ ~@Mf~mo~~yvb~~~ dl4 l@ @i@~bn@o@ ~K~ @o@1 ~@@.o@s~@uS t"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    and-int/lit8 v1, v0, 0x1

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->issue_:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x7

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$44002(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    and-int/lit8 v2, v0, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v2, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-wide v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->endTime_:J

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {p1, v2, v3}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$44102(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;J)J

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    or-int/lit8 v1, v1, 0x2

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    and-int/lit8 v2, v0, 0x4

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz v2, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-wide v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->startTime_:J

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p1, v2, v3}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$44202(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;J)J

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    or-int/lit8 v1, v1, 0x4

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x6

    and-int/lit8 v2, v0, 0x8

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v2, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-wide v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amount_:J

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p1, v2, v3}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$44302(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;J)J

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    or-int/lit8 v1, v1, 0x8

    :cond_3
    const/4 v4, 0x1

    const/4 v5, 0x5

    and-int/lit8 v2, v0, 0x10

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v2, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amountBig_:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$44402(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x4

    or-int/lit8 v1, v1, 0x10

    :cond_4
    const/4 v4, 0x4

    const/4 v5, 0x6

    and-int/lit8 v2, v0, 0x20

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v2, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-wide v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmount_:J

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {p1, v2, v3}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$44502(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;J)J

    const/4 v4, 0x5

    xor-int/2addr v5, v4

    or-int/lit8 v1, v1, 0x20

    :cond_5
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    and-int/lit8 v2, v0, 0x40

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v2, :cond_6

    const/4 v4, 0x2

    shl-int/2addr v5, v4

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmountBig_:Ljava/lang/Object;

    const/4 v4, 0x5

    and-int/2addr v5, v4

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$44602(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    or-int/lit8 v1, v1, 0x40

    :cond_6
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    and-int/lit16 v2, v0, 0x80

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v2, :cond_7

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->people_:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$44702(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;I)I

    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    or-int/lit16 v1, v1, 0x80

    :cond_7
    const/4 v5, 0x3

    const/4 v4, 0x7

    and-int/lit16 v2, v0, 0x100

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v2, :cond_8

    const/4 v4, 0x4

    move v5, v4

    iget v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitPeople_:I

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-static {p1, v2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$44802(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;I)I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    or-int/lit16 v1, v1, 0x100

    :cond_8
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    and-int/lit16 v2, v0, 0x200

    const/4 v4, 0x3

    xor-int/2addr v5, v4

    if-eqz v2, :cond_9

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-wide v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->now_:J

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p1, v2, v3}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$44902(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;J)J

    const/4 v5, 0x6

    const/4 v4, 0x1

    or-int/lit16 v1, v1, 0x200

    :cond_9
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    and-int/lit16 v2, v0, 0x400

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v2, :cond_a

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-wide v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->nextIssueTime_:J

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {p1, v2, v3}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$45002(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;J)J

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    or-int/lit16 v1, v1, 0x400

    :cond_a
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    and-int/lit16 v0, v0, 0x800

    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v0, :cond_b

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->si_:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p1, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$45102(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x2

    or-int/lit16 v1, v1, 0x800

    :cond_b
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {p1, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$45276(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;I)I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    return-void
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto;->access$43500()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    return-object v0
.end method


# virtual methods
.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p1
.end method

.method public addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->addRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    const/4 v0, 0x7

    or-int/2addr v1, v0

    return-object p1
.end method

.method public bridge synthetic build()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic build()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method public build()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->isInitialized()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/protobuf/AbstractMessage$Builder;->newUninitializedMessageException(Lcom/google/protobuf/Message;)Lcom/google/protobuf/UninitializedMessageException;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    throw v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic buildPartial()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->buildPartial()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public buildPartial()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0, p0, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$1;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->buildPartial0(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onBuilt()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic clear()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->clear()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object v0

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public clear()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clear()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->issue_:Ljava/lang/Object;

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput-wide v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->endTime_:J

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    iput-wide v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->startTime_:J

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    iput-wide v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amount_:J

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amountBig_:Ljava/lang/Object;

    const/4 v4, 0x6

    shr-int/2addr v5, v4

    iput-wide v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmount_:J

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmountBig_:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->people_:I

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitPeople_:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    iput-wide v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->now_:J

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput-wide v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->nextIssueTime_:J

    const/4 v5, 0x1

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->si_:Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-object p0
.end method

.method public clearAmount()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 4

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    and-int/lit8 v0, v0, -0x9

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amount_:J

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object p0
.end method

.method public clearAmountBig()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getAmountBig()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amountBig_:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    and-int/lit8 v0, v0, -0x11

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x3

    return-object p0
.end method

.method public clearEndTime()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    and-int/lit8 v0, v0, -0x3

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-wide v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->endTime_:J

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object p0
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    return-object p1
.end method

.method public clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p1
.end method

.method public clearIssue()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getIssue()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->issue_:Ljava/lang/Object;

    const/4 v1, 0x4

    move v2, v1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    and-int/lit8 v0, v0, -0x2

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    move v2, v1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p0
.end method

.method public clearLimitAmount()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    and-int/lit8 v0, v0, -0x21

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    iput-wide v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmount_:J

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p0
.end method

.method public clearLimitAmountBig()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getLimitAmountBig()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmountBig_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    and-int/lit8 v0, v0, -0x41

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public clearLimitPeople()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    and-int/lit16 v0, v0, -0x101

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitPeople_:I

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0
.end method

.method public clearNextIssueTime()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    and-int/lit16 v0, v0, -0x401

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput-wide v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->nextIssueTime_:J

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p0
.end method

.method public clearNow()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 4

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    and-int/lit16 v0, v0, -0x201

    const/4 v3, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->now_:J

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p0
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p1
.end method

.method public clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v0, 0x3

    move v1, v0

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clearOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method

.method public clearPeople()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 3

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    and-int/lit16 v0, v0, -0x81

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->people_:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0
.end method

.method public clearSi()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getSi()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->si_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    and-int/lit16 v0, v0, -0x801

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public clearStartTime()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    and-int/lit8 v0, v0, -0x5

    const/4 v3, 0x6

    const/4 v2, 0x0

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->startTime_:J

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-super {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->clone()Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    check-cast v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    const/4 v2, 0x6

    const/4 v1, 0x3

    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->clone()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public getAmount()J
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amount_:J

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-wide v0
.end method

.method public getAmountBig()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amountBig_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x7

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amountBig_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0
.end method

.method public getAmountBigBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amountBig_:Ljava/lang/Object;

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amountBig_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public getDescriptorForType()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto;->access$43500()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public getEndTime()J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->endTime_:J

    const/4 v3, 0x6

    return-wide v0
.end method

.method public getIssue()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->issue_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->issue_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x5

    move v3, v2

    return-object v0
.end method

.method public getIssueBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->issue_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->issue_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0
.end method

.method public getLimitAmount()J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-wide v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmount_:J

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-wide v0
.end method

.method public getLimitAmountBig()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmountBig_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmountBig_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0
.end method

.method public getLimitAmountBigBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmountBig_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x4

    move v3, v2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmountBig_:Ljava/lang/Object;

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    return-object v0
.end method

.method public getLimitPeople()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitPeople_:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public getNextIssueTime()J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-wide v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->nextIssueTime_:J

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-wide v0
.end method

.method public getNow()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->now_:J

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-wide v0
.end method

.method public getPeople()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->people_:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method public getSi()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->si_:Ljava/lang/Object;

    const/4 v2, 0x6

    move v3, v2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->si_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v0
.end method

.method public getSiBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->si_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x4

    move v3, v2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->si_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object v0
.end method

.method public getStartTime()J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->startTime_:J

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-wide v0
.end method

.method public hasAmount()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    and-int/lit8 v0, v0, 0x8

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v1, 0x2

    move v2, v1

    const/4 v0, 0x1

    move v2, v0

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public hasAmountBig()Z
    .locals 3

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    and-int/lit8 v0, v0, 0x10

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v0, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public hasEndTime()Z
    .locals 3

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public hasIssue()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    and-int/2addr v0, v1

    const/4 v2, 0x1

    move v3, v2

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    return v1
.end method

.method public hasLimitAmount()Z
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    and-int/lit8 v0, v0, 0x20

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    return v0
.end method

.method public hasLimitAmountBig()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    and-int/lit8 v0, v0, 0x40

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public hasLimitPeople()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    move v2, v1

    and-int/lit16 v0, v0, 0x100

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public hasNextIssueTime()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    and-int/lit16 v0, v0, 0x400

    const/4 v2, 0x7

    const/4 v1, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public hasNow()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    and-int/lit16 v0, v0, 0x200

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v0, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    return v0
.end method

.method public hasPeople()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x4

    and-int/lit16 v0, v0, 0x80

    const/4 v1, 0x3

    shl-int/2addr v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public hasSi()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    and-int/lit16 v0, v0, 0x800

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public hasStartTime()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto;->access$43600()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    const/4 v4, 0x5

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    const/4 v4, 0x5

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    const/4 v4, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p1
.end method

.method public mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v0, 0x0

    :cond_0
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-nez v0, :cond_1

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readTag()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v2, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    sparse-switch v1, :sswitch_data_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-super {p0, p1, p2, v1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->parseUnknownField(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;I)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto/16 :goto_2

    :sswitch_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->si_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    or-int/lit16 v1, v1, 0x800

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    goto :goto_0

    :sswitch_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt64()J

    move-result-wide v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput-wide v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->nextIssueTime_:J

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    or-int/lit16 v1, v1, 0x400

    const/4 v3, 0x3

    move v4, v3

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    goto :goto_0

    :sswitch_2
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt64()J

    move-result-wide v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-wide v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->now_:J

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    or-int/lit16 v1, v1, 0x200

    const/4 v4, 0x2

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_0

    :sswitch_3
    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt32()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitPeople_:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    or-int/lit16 v1, v1, 0x100

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto/16 :goto_0

    :sswitch_4
    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt32()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->people_:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    or-int/lit16 v1, v1, 0x80

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto/16 :goto_0

    :sswitch_5
    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmountBig_:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    or-int/lit8 v1, v1, 0x40

    const/4 v4, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto/16 :goto_0

    :sswitch_6
    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt64()J

    move-result-wide v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-wide v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmount_:J

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    and-int/2addr v4, v3

    or-int/lit8 v1, v1, 0x20

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto/16 :goto_0

    :sswitch_7
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amountBig_:Ljava/lang/Object;

    const/4 v4, 0x7

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    or-int/lit8 v1, v1, 0x10

    const/4 v4, 0x3

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto/16 :goto_0

    :sswitch_8
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt64()J

    move-result-wide v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput-wide v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amount_:J

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    or-int/lit8 v1, v1, 0x8

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    goto/16 :goto_0

    :sswitch_9
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt64()J

    move-result-wide v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput-wide v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->startTime_:J

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    or-int/lit8 v1, v1, 0x4

    const/4 v4, 0x7

    const/4 v3, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto/16 :goto_0

    :sswitch_a
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readUInt64()J

    move-result-wide v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput-wide v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->endTime_:J

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x5

    or-int/lit8 v1, v1, 0x2

    const/4 v4, 0x7

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    goto/16 :goto_0

    :sswitch_b
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/CodedInputStream;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->issue_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    or-int/2addr v1, v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I
    :try_end_0
    .catch Lcom/google/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto/16 :goto_0

    :goto_1
    :sswitch_c
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    move v0, v2

    move v0, v2

    const/4 v4, 0x2

    move v0, v2

    move v0, v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    goto/16 :goto_0

    :goto_2
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-nez v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto :goto_3

    :catch_0
    move-exception p1

    :try_start_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/InvalidProtocolBufferException;->unwrapIOException()Ljava/io/IOException;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_3
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    throw p1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object p0

    nop

    :sswitch_data_0
    .sparse-switch
        0x0 -> :sswitch_c
        0xa -> :sswitch_b
        0x10 -> :sswitch_a
        0x18 -> :sswitch_9
        0x20 -> :sswitch_8
        0x2a -> :sswitch_7
        0x30 -> :sswitch_6
        0x3a -> :sswitch_5
        0x40 -> :sswitch_4
        0x48 -> :sswitch_3
        0x50 -> :sswitch_2
        0x58 -> :sswitch_1
        0x62 -> :sswitch_0
    .end sparse-switch
.end method

.method public mergeFrom(Lcom/google/protobuf/Message;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x6

    instance-of v0, p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0
.end method

.method public mergeFrom(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v3, 0x1

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-ne p1, v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->hasIssue()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$44000(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->issue_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x5

    or-int/lit8 v0, v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->hasEndTime()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getEndTime()J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, v0, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->setEndTime(J)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->hasStartTime()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_3

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getStartTime()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0, v0, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->setStartTime(J)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    :cond_3
    const/4 v2, 0x1

    move v3, v2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->hasAmount()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getAmount()J

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, v0, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->setAmount(J)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    :cond_4
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->hasAmountBig()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v0, :cond_5

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$44400(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amountBig_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    or-int/lit8 v0, v0, 0x10

    const/4 v2, 0x1

    move v3, v2

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_5
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->hasLimitAmount()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_6

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getLimitAmount()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, v0, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->setLimitAmount(J)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    :cond_6
    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->hasLimitAmountBig()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz v0, :cond_7

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$44600(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmountBig_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    or-int/lit8 v0, v0, 0x40

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_7
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->hasPeople()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz v0, :cond_8

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getPeople()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->setPeople(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    :cond_8
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->hasLimitPeople()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_9

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getLimitPeople()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->setLimitPeople(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    :cond_9
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->hasNow()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_a

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getNow()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0, v0, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->setNow(J)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    :cond_a
    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->hasNextIssueTime()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_b

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->getNextIssueTime()J

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0, v0, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->setNextIssueTime(J)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    :cond_b
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->hasSi()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v0, :cond_c

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$45100(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->si_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x0

    or-int/lit16 v0, v0, 0x800

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    :cond_c
    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object p0
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/AbstractMessage$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    return-object p1
.end method

.method public bridge synthetic mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    return-object p1
.end method

.method public final mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->mergeUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p1
.end method

.method public setAmount(J)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-wide p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amount_:J

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    or-int/lit8 p1, p1, 0x8

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    return-object p0
.end method

.method public setAmountBig(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amountBig_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    or-int/lit8 p1, p1, 0x10

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method public setAmountBigBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$45400(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->amountBig_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    or-int/lit8 p1, p1, 0x10

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    return-object p0
.end method

.method public setEndTime(J)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-wide p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->endTime_:J

    const/4 v1, 0x0

    const/4 v0, 0x6

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x6

    const/4 v0, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p1
.end method

.method public setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "field",
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-super {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setField(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method

.method public setIssue(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->issue_:Ljava/lang/Object;

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x4

    return-object p0
.end method

.method public setIssueBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$45300(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->issue_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method

.method public setLimitAmount(J)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-wide p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmount_:J

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    or-int/lit8 p1, p1, 0x20

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v0, 0x5

    const/4 v0, 0x2

    return-object p0
.end method

.method public setLimitAmountBig(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmountBig_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x40

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0
.end method

.method public setLimitAmountBigBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x6

    const/4 v0, 0x7

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$45500(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitAmountBig_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    or-int/lit8 p1, p1, 0x40

    const/4 v1, 0x3

    const/4 v0, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    return-object p0
.end method

.method public setLimitPeople(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->limitPeople_:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    or-int/lit16 p1, p1, 0x100

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p0
.end method

.method public setNextIssueTime(J)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-wide p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->nextIssueTime_:J

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    or-int/lit16 p1, p1, 0x400

    const/4 v1, 0x4

    const/4 v0, 0x2

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v0, 0x3

    move v1, v0

    return-object p0
.end method

.method public setNow(J)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-wide p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->now_:J

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    or-int/lit16 p1, p1, 0x200

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method

.method public setPeople(I)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->people_:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    or-int/lit16 p1, p1, 0x80

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2, p3}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p1
.end method

.method public setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "field",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-super {p0, p1, p2, p3}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setRepeatedField(Lcom/google/protobuf/Descriptors$FieldDescriptor;ILjava/lang/Object;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p1
.end method

.method public setSi(Ljava/lang/String;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->si_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    or-int/lit16 p1, p1, 0x800

    const/4 v1, 0x1

    const/4 v0, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    return-object p0
.end method

.method public setSiBytes(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult;->access$45600(Lcom/google/protobuf/ByteString;)V

    const/4 v0, 0x0

    move v1, v0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->si_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v0, 0x1

    move v1, v0

    or-int/lit16 p1, p1, 0x800

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p0
.end method

.method public setStartTime(J)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-wide p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->startTime_:J

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    iget p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    or-int/lit8 p1, p1, 0x4

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->bitField0_:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->onChanged()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    return-object p0
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p1
.end method

.method public final setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "unknownFields"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-super {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$Builder;->setUnknownFields(Lcom/google/protobuf/UnknownFieldSet;)Lcom/google/protobuf/GeneratedMessageV3$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$OneToWinGameInfoResult$Builder;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p1
.end method
