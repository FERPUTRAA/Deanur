.class public final Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;
.super Lcom/google/protobuf/GeneratedMessageV3;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequestOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/NoticeProto;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "ChangeInviteCodeRequest"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

.field public static final INVITECODE_FIELD_NUMBER:I = 0x1

.field private static final PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;",
            ">;"
        }
    .end annotation
.end field

.field private static final serialVersionUID:J


# instance fields
.field private bitField0_:I

.field private volatile inviteCode_:Ljava/lang/Object;

.field private memoizedIsInitialized:B


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    sput-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$1;

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-direct {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$1;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    sput-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3;-><init>()V

    const/4 v2, 0x3

    move v3, v2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->inviteCode_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-byte v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->memoizedIsInitialized:B

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->inviteCode_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x7

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->inviteCode_:Ljava/lang/Object;

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    const/4 p1, -0x1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-byte p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->memoizedIsInitialized:B

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v0, 0x7

    move v1, v0

    return-void
.end method

.method static synthetic access$500(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "s s@i~-@@o~v~@4@ m c@b/@ n~o@~@@a@~o~~@~ ~ ~/~o~r t@~ @ @i b1@ob~Ktofl@~S f~~u l di  ~M ~~. @~y@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->inviteCode_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic access$502(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->inviteCode_:Ljava/lang/Object;

    const/4 v0, 0x0

    const/4 v0, 0x4

    return-object p1
.end method

.method static synthetic access$676(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;I)I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->bitField0_:I

    const/4 v1, 0x6

    const/4 v1, 0x3

    or-int/2addr p1, v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return p1
.end method

.method static synthetic access$700(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public static getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto;->access$000()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public static newBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public static newBuilder(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "prototype"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parseFrom([B)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom([B)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-ne p1, p0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    return v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    instance-of v1, p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-nez v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    return p1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->hasInviteCode()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->hasInviteCode()Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v4, 0x7

    if-eq v1, v2, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    return v3

    :cond_2
    const/4 v4, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->hasInviteCode()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz v1, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->getInviteCode()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    move v5, v4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->getInviteCode()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-nez v1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    return v3

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v1, p1}, Lcom/google/protobuf/UnknownFieldSet;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez p1, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    return v3

    :cond_4
    const/4 v4, 0x6

    move v5, v4

    return v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public getInviteCode()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->inviteCode_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->inviteCode_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0
.end method

.method public getInviteCodeBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->inviteCode_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->inviteCode_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0
.end method

.method public getParserForType()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public getSerializedSize()I
    .locals 5

    const/4 v3, 0x0

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v4, 0x7

    const/4 v1, -0x1

    const/4 v4, 0x7

    or-int/2addr v3, v1

    if-eq v0, v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    return v0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->bitField0_:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    and-int/2addr v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->inviteCode_:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    add-int/2addr v2, v0

    :cond_1
    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->getSerializedSize()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    add-int/2addr v2, v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput v2, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v4, 0x4

    return v2
.end method

.method public hasInviteCode()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    and-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    return v1
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v3, 0x2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/16 v1, 0x30b

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    add-int/2addr v1, v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->hasInviteCode()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->getInviteCode()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    add-int/2addr v1, v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x1d

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->hashCode()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    add-int/2addr v1, v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput v1, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    return v1
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto;->access$100()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v4, 0x4

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v4, 0x5

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    const/4 v4, 0x7

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-byte v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->memoizedIsInitialized:B

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x7

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return v1

    :cond_0
    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x7

    const/4 v0, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    return v0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-byte v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->memoizedIsInitialized:B

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    return v1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method protected bridge synthetic newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->newBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    return-object v0
.end method

.method protected newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0, p1, v1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0
.end method

.method protected newInstance(Lcom/google/protobuf/GeneratedMessageV3$UnusedPrivateParameter;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unused"
        }
    .end annotation

    new-instance p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public toBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-ne p0, v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;-><init>(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;-><init>(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest$Builder;

    move-result-object v0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0
.end method

.method public writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    and-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$ChangeInviteCodeRequest;->inviteCode_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1, v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lcom/google/protobuf/UnknownFieldSet;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method
