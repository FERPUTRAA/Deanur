.class public final Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;
.super Lcom/google/protobuf/GeneratedMessageV3;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResultOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/UserProto;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "PlayerListResult"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

.field public static final MEMBERLIST_FIELD_NUMBER:I = 0x2

.field public static final MEMBERNUMBER_FIELD_NUMBER:I = 0x1

.field private static final PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;",
            ">;"
        }
    .end annotation
.end field

.field private static final serialVersionUID:J


# instance fields
.field private bitField0_:I

.field private memberList_:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;",
            ">;"
        }
    .end annotation
.end field

.field private memberNumber_:I

.field private memoizedIsInitialized:B


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    sput-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$1;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$1;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    sput-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3;-><init>()V

    const/4 v2, 0x5

    const/4 v0, 0x7

    const/4 v0, 0x0

    xor-int/2addr v2, v0

    const/4 v1, 0x0

    move v2, v1

    iput v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberNumber_:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-byte v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memoizedIsInitialized:B

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberList_:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberNumber_:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 p1, -0x1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-byte p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memoizedIsInitialized:B

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/UserProto$1;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic access$4000(Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;)Ljava/util/List;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s@~ m@l -4~~@fM~ b @@~1 ~@ii fo~@i y~@oorb / @~lo @~~~t~~ ~s @u@v@.o @~@n @S@ ~@tKabo /~~~~d c"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberList_:Ljava/util/List;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic access$4002(Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;Ljava/util/List;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberList_:Ljava/util/List;

    const/4 v0, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p1
.end method

.method static synthetic access$4102(Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;I)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberNumber_:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return p1
.end method

.method static synthetic access$4276(Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;I)I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->bitField0_:I

    const/4 v2, 0x7

    or-int/2addr p1, v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return p1
.end method

.method static synthetic access$4300()Z
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-boolean v0, Lcom/google/protobuf/GeneratedMessageV3;->alwaysUseFieldBuilders:Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public static getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto;->access$3500()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public static newBuilder()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public static newBuilder(Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "prototype"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x0

    const/4 v1, 0x3

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-object p0
.end method

.method public static parseFrom([B)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom([B)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v0, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ne p1, p0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    return v0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    instance-of v1, p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v5, 0x5

    const/4 v4, 0x0

    if-nez v1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    return p1

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->hasMemberNumber()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->hasMemberNumber()Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eq v1, v2, :cond_2

    const/4 v5, 0x5

    return v3

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->hasMemberNumber()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->getMemberNumber()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->getMemberNumber()I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eq v1, v2, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    return v3

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->getMemberListList()Ljava/util/List;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->getMemberListList()Ljava/util/List;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {v1, v2}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-nez v1, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    return v3

    :cond_4
    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1, p1}, Lcom/google/protobuf/UnknownFieldSet;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-nez p1, :cond_5

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    return v3

    :cond_5
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    return v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v1, 0x7

    shl-int/2addr v2, v1

    return-object v0
.end method

.method public getMemberList(I)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberList_:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p1
.end method

.method public getMemberListCount()I
    .locals 3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberList_:Ljava/util/List;

    const/4 v1, 0x1

    move v2, v1

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    return v0
.end method

.method public getMemberListList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberList;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberList_:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public getMemberListOrBuilder(I)Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberListOrBuilder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberList_:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberListOrBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p1
.end method

.method public getMemberListOrBuilderList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/star/livegames/ws/protobuf/entity/UserProto$MemberListOrBuilder;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberList_:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method public getMemberNumber()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberNumber_:I

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public getParserForType()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public getSerializedSize()I
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v1, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eq v0, v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    return v0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->bitField0_:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x6

    move v5, v4

    and-int/2addr v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberNumber_:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->computeUInt32Size(II)I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    add-int/2addr v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    move v0, v2

    move v0, v2

    const/4 v5, 0x0

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberList_:Ljava/util/List;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-ge v2, v1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberList_:Ljava/util/List;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    check-cast v1, Lcom/google/protobuf/MessageLite;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v3, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-static {v3, v1}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    add-int/2addr v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    goto :goto_0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v1}, Lcom/google/protobuf/UnknownFieldSet;->getSerializedSize()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    add-int/2addr v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    iput v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x2

    return v0
.end method

.method public hasMemberNumber()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->bitField0_:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    and-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return v1
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    return v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v1, 0x30b

    const/4 v3, 0x1

    const/4 v2, 0x3

    add-int/2addr v1, v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->hasMemberNumber()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->getMemberNumber()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->getMemberListCount()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-lez v0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->getMemberListList()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/List;->hashCode()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    add-int/2addr v1, v0

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x1d

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->hashCode()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-int/2addr v1, v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput v1, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    return v1
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto;->access$3600()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v4, 0x7

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v3, 0x2

    and-int/2addr v4, v3

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 4

    const/4 v3, 0x3

    iget-byte v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memoizedIsInitialized:B

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    return v1

    :cond_0
    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x4

    const/4 v2, 0x1

    return v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-byte v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memoizedIsInitialized:B

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    return v1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method protected bridge synthetic newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->newBuilder()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method protected newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v3, 0x4

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x4

    invoke-direct {v0, p1, v1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/UserProto$1;)V

    const/4 v3, 0x7

    return-object v0
.end method

.method protected newInstance(Lcom/google/protobuf/GeneratedMessageV3$UnusedPrivateParameter;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unused"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    new-instance p1, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method public toBuilder()Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-ne p0, v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;-><init>(Lcom/star/livegames/ws/protobuf/entity/UserProto$1;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;-><init>(Lcom/star/livegames/ws/protobuf/entity/UserProto$1;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;)Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult$Builder;

    move-result-object v0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0
.end method

.method public writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->bitField0_:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    and-int/2addr v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberNumber_:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1, v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32(II)V

    :cond_0
    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x2

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberList_:Ljava/util/List;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-ge v0, v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/UserProto$PlayerListResult;->memberList_:Ljava/util/List;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    check-cast v1, Lcom/google/protobuf/MessageLite;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1, v2, v1}, Lcom/google/protobuf/CodedOutputStream;->writeMessage(ILcom/google/protobuf/MessageLite;)V

    const/4 v4, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Lcom/google/protobuf/UnknownFieldSet;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method
