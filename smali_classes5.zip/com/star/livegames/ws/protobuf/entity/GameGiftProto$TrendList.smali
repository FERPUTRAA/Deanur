.class public final Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;
.super Lcom/google/protobuf/GeneratedMessageV3;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendListOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/GameGiftProto;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "TrendList"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

.field public static final DS_FIELD_NUMBER:I = 0x1

.field public static final DX_FIELD_NUMBER:I = 0x2

.field public static final EW_FIELD_NUMBER:I = 0x3

.field public static final GYJ_FIELD_NUMBER:I = 0x4

.field public static final HDS_FIELD_NUMBER:I = 0x5

.field public static final HDX_FIELD_NUMBER:I = 0x6

.field public static final ISSUE_FIELD_NUMBER:I = 0x7

.field public static final LH_FIELD_NUMBER:I = 0x8

.field private static final PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;",
            ">;"
        }
    .end annotation
.end field

.field public static final SANW_FIELD_NUMBER:I = 0x9

.field public static final SW_FIELD_NUMBER:I = 0xa

.field public static final TS_FIELD_NUMBER:I = 0xb

.field public static final WINNUMBER_FIELD_NUMBER:I = 0xc

.field public static final XIAN_FIELD_NUMBER:I = 0xd

.field public static final ZHUANG_FIELD_NUMBER:I = 0xf

.field public static final ZH_FIELD_NUMBER:I = 0xe

.field private static final serialVersionUID:J


# instance fields
.field private bitField0_:I

.field private volatile ds_:Ljava/lang/Object;

.field private volatile dx_:Ljava/lang/Object;

.field private volatile ew_:Ljava/lang/Object;

.field private volatile gyj_:Ljava/lang/Object;

.field private volatile hds_:Ljava/lang/Object;

.field private volatile hdx_:Ljava/lang/Object;

.field private volatile issue_:Ljava/lang/Object;

.field private volatile lh_:Ljava/lang/Object;

.field private memoizedIsInitialized:B

.field private volatile sanw_:Ljava/lang/Object;

.field private volatile sw_:Ljava/lang/Object;

.field private volatile ts_:Ljava/lang/Object;

.field private volatile winNumber_:Ljava/lang/Object;

.field private volatile xian_:Ljava/lang/Object;

.field private volatile zh_:Ljava/lang/Object;

.field private volatile zhuang_:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    sput-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$1;

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-direct {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$1;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    sput-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3;-><init>()V

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ds_:Ljava/lang/Object;

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->dx_:Ljava/lang/Object;

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ew_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->gyj_:Ljava/lang/Object;

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hds_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hdx_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->issue_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->lh_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sanw_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sw_:Ljava/lang/Object;

    const/4 v2, 0x3

    move v3, v2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ts_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->winNumber_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->xian_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zh_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zhuang_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-byte v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->memoizedIsInitialized:B

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ds_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->dx_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ew_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->gyj_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hds_:Ljava/lang/Object;

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hdx_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->issue_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->lh_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sanw_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sw_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ts_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->winNumber_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->xian_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zh_:Ljava/lang/Object;

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zhuang_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v0, 0x6

    and-int/2addr v1, v0

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x3

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ds_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->dx_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ew_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->gyj_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hds_:Ljava/lang/Object;

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hdx_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->issue_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->lh_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sanw_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sw_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ts_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->winNumber_:Ljava/lang/Object;

    const/4 v0, 0x2

    move v1, v0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->xian_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zh_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zhuang_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 p1, -0x1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-byte p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->memoizedIsInitialized:B

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$1;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic access$29200(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "K~s@y / v~~1~~u-i~o@o @~~a@ ~ b~4rf@ c~m@~~l  @ l@@@@@~d~bMt@ @~ o.~ not@S~  ~~@@ is~io  o/~@b@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ds_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic access$29202(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ds_:Ljava/lang/Object;

    const/4 v1, 0x0

    return-object p1
.end method

.method static synthetic access$29300(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->dx_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic access$29302(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->dx_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p1
.end method

.method static synthetic access$29400(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ew_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic access$29402(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ew_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p1
.end method

.method static synthetic access$29500(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->gyj_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic access$29502(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->gyj_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p1
.end method

.method static synthetic access$29600(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hds_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic access$29602(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hds_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic access$29700(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hdx_:Ljava/lang/Object;

    const/4 v0, 0x1

    and-int/2addr v1, v0

    return-object p0
.end method

.method static synthetic access$29702(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hdx_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x5

    return-object p1
.end method

.method static synthetic access$29800(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->issue_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic access$29802(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->issue_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p1
.end method

.method static synthetic access$29900(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->lh_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic access$29902(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->lh_:Ljava/lang/Object;

    return-object p1
.end method

.method static synthetic access$30000(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sanw_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic access$30002(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sanw_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p1
.end method

.method static synthetic access$30100(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sw_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic access$30102(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sw_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method

.method static synthetic access$30200(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ts_:Ljava/lang/Object;

    const/4 v0, 0x0

    return-object p0
.end method

.method static synthetic access$30202(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ts_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p1
.end method

.method static synthetic access$30300(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->winNumber_:Ljava/lang/Object;

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic access$30302(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->winNumber_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p1
.end method

.method static synthetic access$30400(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->xian_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$30402(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->xian_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method

.method static synthetic access$30500(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zh_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$30502(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zh_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p1
.end method

.method static synthetic access$30600(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zhuang_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x1

    return-object p0
.end method

.method static synthetic access$30602(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zhuang_:Ljava/lang/Object;

    const/4 v1, 0x0

    return-object p1
.end method

.method static synthetic access$30776(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;I)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v2, 0x2

    or-int/2addr p1, v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return p1
.end method

.method static synthetic access$30800(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic access$30900(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    return-void
.end method

.method static synthetic access$31000(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic access$31100(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic access$31200(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic access$31300(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic access$31400(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v0, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic access$31500(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic access$31600(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic access$31700(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic access$31800(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic access$31900(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic access$32000(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic access$32100(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic access$32200(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public static getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto;->access$28700()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public static newBuilder()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public static newBuilder(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "prototype"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x7

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom([B)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom([B)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v0, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-ne p1, p0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    return v0

    :cond_0
    const/4 v5, 0x5

    instance-of v1, p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-nez v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    return p1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasDs()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasDs()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eq v1, v2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    return v3

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasDs()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getDs()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getDs()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-nez v1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    return v3

    :cond_3
    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasDx()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasDx()Z

    move-result v2

    const/4 v5, 0x0

    if-eq v1, v2, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    return v3

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasDx()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v1, :cond_5

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getDx()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getDx()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    if-nez v1, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    return v3

    :cond_5
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasEw()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasEw()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eq v1, v2, :cond_6

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    return v3

    :cond_6
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasEw()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v1, :cond_7

    const/4 v4, 0x3

    or-int/2addr v5, v4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getEw()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getEw()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez v1, :cond_7

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    return v3

    :cond_7
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasGyj()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasGyj()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eq v1, v2, :cond_8

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v3

    :cond_8
    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasGyj()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v1, :cond_9

    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getGyj()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getGyj()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    if-nez v1, :cond_9

    const/4 v4, 0x6

    move v5, v4

    return v3

    :cond_9
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasHds()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasHds()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eq v1, v2, :cond_a

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    return v3

    :cond_a
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasHds()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v1, :cond_b

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getHds()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getHds()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-nez v1, :cond_b

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    return v3

    :cond_b
    const/4 v4, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasHdx()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasHdx()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eq v1, v2, :cond_c

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    return v3

    :cond_c
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasHdx()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v1, :cond_d

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getHdx()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getHdx()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-nez v1, :cond_d

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    return v3

    :cond_d
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasIssue()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasIssue()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eq v1, v2, :cond_e

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    return v3

    :cond_e
    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasIssue()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v1, :cond_f

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getIssue()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getIssue()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-nez v1, :cond_f

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    return v3

    :cond_f
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasLh()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasLh()Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eq v1, v2, :cond_10

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    return v3

    :cond_10
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasLh()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v1, :cond_11

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getLh()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getLh()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-nez v1, :cond_11

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v3

    :cond_11
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasSanw()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasSanw()Z

    move-result v2

    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eq v1, v2, :cond_12

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    return v3

    :cond_12
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasSanw()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    if-eqz v1, :cond_13

    const/4 v4, 0x0

    move v5, v4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getSanw()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getSanw()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    if-nez v1, :cond_13

    const/4 v4, 0x4

    or-int/2addr v5, v4

    return v3

    :cond_13
    const/4 v4, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasSw()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasSw()Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eq v1, v2, :cond_14

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    return v3

    :cond_14
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasSw()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v1, :cond_15

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getSw()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getSw()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-nez v1, :cond_15

    const/4 v5, 0x0

    const/4 v4, 0x0

    return v3

    :cond_15
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasTs()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasTs()Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eq v1, v2, :cond_16

    const/4 v4, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    return v3

    :cond_16
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasTs()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v1, :cond_17

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getTs()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getTs()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-nez v1, :cond_17

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    return v3

    :cond_17
    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasWinNumber()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasWinNumber()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eq v1, v2, :cond_18

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    return v3

    :cond_18
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasWinNumber()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz v1, :cond_19

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getWinNumber()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getWinNumber()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez v1, :cond_19

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    return v3

    :cond_19
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasXian()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasXian()Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eq v1, v2, :cond_1a

    const/4 v4, 0x1

    const/4 v5, 0x1

    return v3

    :cond_1a
    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasXian()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v1, :cond_1b

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getXian()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getXian()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-nez v1, :cond_1b

    const/4 v5, 0x4

    const/4 v4, 0x2

    return v3

    :cond_1b
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasZh()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasZh()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eq v1, v2, :cond_1c

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    return v3

    :cond_1c
    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasZh()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v1, :cond_1d

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getZh()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getZh()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez v1, :cond_1d

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    return v3

    :cond_1d
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasZhuang()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasZhuang()Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eq v1, v2, :cond_1e

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v3

    :cond_1e
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasZhuang()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v1, :cond_1f

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getZhuang()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getZhuang()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-nez v1, :cond_1f

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    return v3

    :cond_1f
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v1, p1}, Lcom/google/protobuf/UnknownFieldSet;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-nez p1, :cond_20

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    return v3

    :cond_20
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    return v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public getDs()Ljava/lang/String;
    .locals 4

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ds_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ds_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0
.end method

.method public getDsBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ds_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ds_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0
.end method

.method public getDx()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->dx_:Ljava/lang/Object;

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x2

    move v3, v2

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->dx_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0
.end method

.method public getDxBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->dx_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->dx_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0
.end method

.method public getEw()Ljava/lang/String;
    .locals 4

    const/4 v2, 0x3

    move v3, v2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ew_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ew_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0
.end method

.method public getEwBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ew_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x4

    or-int/2addr v3, v2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ew_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0
.end method

.method public getGyj()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->gyj_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->gyj_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0
.end method

.method public getGyjBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->gyj_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x5

    move v3, v2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->gyj_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0
.end method

.method public getHds()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hds_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hds_:Ljava/lang/Object;

    const/4 v3, 0x6

    return-object v0
.end method

.method public getHdsBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hds_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hds_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method

.method public getHdx()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hdx_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hdx_:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0
.end method

.method public getHdxBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v2, 0x3

    move v3, v2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hdx_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hdx_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0
.end method

.method public getIssue()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->issue_:Ljava/lang/Object;

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x0

    and-int/2addr v3, v2

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x4

    move v3, v2

    return-object v0

    :cond_0
    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->issue_:Ljava/lang/Object;

    const/4 v3, 0x5

    return-object v0
.end method

.method public getIssueBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->issue_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->issue_:Ljava/lang/Object;

    const/4 v2, 0x4

    move v3, v2

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0
.end method

.method public getLh()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->lh_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->lh_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v0
.end method

.method public getLhBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->lh_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->lh_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method

.method public getParserForType()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public getSanw()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sanw_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sanw_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0
.end method

.method public getSanwBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sanw_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sanw_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0
.end method

.method public getSerializedSize()I
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v1, -0x1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eq v0, v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    return v0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    and-int/2addr v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ds_:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    add-int/2addr v2, v0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v1, 0x2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    and-int/2addr v0, v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->dx_:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    add-int/2addr v2, v0

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v1, 0x4

    const/4 v5, 0x4

    const/4 v4, 0x4

    and-int/2addr v0, v1

    const/4 v4, 0x7

    shl-int/2addr v5, v4

    if-eqz v0, :cond_3

    const/4 v5, 0x3

    const/4 v0, 0x3

    const/4 v5, 0x6

    or-int/2addr v4, v0

    const/4 v5, 0x1

    iget-object v3, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ew_:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v0, v3}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    add-int/2addr v2, v0

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v5, 0x5

    const/16 v3, 0x8

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    and-int/2addr v0, v3

    const/4 v5, 0x4

    if-eqz v0, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->gyj_:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    add-int/2addr v2, v0

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    and-int/lit8 v0, v0, 0x10

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v0, :cond_5

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v0, 0x5

    const/4 v4, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hds_:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    add-int/2addr v2, v0

    :cond_5
    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    and-int/lit8 v0, v0, 0x20

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v0, :cond_6

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v0, 0x6

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hdx_:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    add-int/2addr v2, v0

    :cond_6
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    and-int/lit8 v0, v0, 0x40

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v0, :cond_7

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v0, 0x7

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->issue_:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    add-int/2addr v2, v0

    :cond_7
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    and-int/lit16 v0, v0, 0x80

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v0, :cond_8

    const/4 v4, 0x6

    move v5, v4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->lh_:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v3, v0}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    add-int/2addr v2, v0

    :cond_8
    const/4 v5, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    and-int/lit16 v0, v0, 0x100

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v0, :cond_9

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/16 v0, 0x9

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sanw_:Ljava/lang/Object;

    const/4 v5, 0x2

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    add-int/2addr v2, v0

    :cond_9
    const/4 v4, 0x2

    const/4 v5, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    and-int/lit16 v0, v0, 0x200

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v0, :cond_a

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/16 v0, 0xa

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sw_:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    add-int/2addr v2, v0

    :cond_a
    const/4 v5, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v5, 0x7

    and-int/lit16 v0, v0, 0x400

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v0, :cond_b

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/16 v0, 0xb

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ts_:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    add-int/2addr v2, v0

    :cond_b
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    and-int/lit16 v0, v0, 0x800

    const/4 v5, 0x5

    const/4 v4, 0x5

    if-eqz v0, :cond_c

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/16 v0, 0xc

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->winNumber_:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    add-int/2addr v2, v0

    :cond_c
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    and-int/lit16 v0, v0, 0x1000

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v0, :cond_d

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/16 v0, 0xd

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->xian_:Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    add-int/2addr v2, v0

    :cond_d
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    and-int/lit16 v0, v0, 0x2000

    const/4 v4, 0x7

    shr-int/2addr v5, v4

    if-eqz v0, :cond_e

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/16 v0, 0xe

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zh_:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    add-int/2addr v2, v0

    :cond_e
    const/4 v5, 0x3

    const/4 v4, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    and-int/lit16 v0, v0, 0x4000

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz v0, :cond_f

    const/4 v5, 0x3

    const/16 v0, 0xf

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zhuang_:Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    add-int/2addr v2, v0

    :cond_f
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->getSerializedSize()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    add-int/2addr v2, v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    iput v2, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v2
.end method

.method public getSw()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sw_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sw_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public getSwBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sw_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sw_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    return-object v0
.end method

.method public getTs()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ts_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ts_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method public getTsBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ts_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ts_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0
.end method

.method public getWinNumber()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->winNumber_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->winNumber_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0
.end method

.method public getWinNumberBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->winNumber_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->winNumber_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    return-object v0
.end method

.method public getXian()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->xian_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->xian_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0
.end method

.method public getXianBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->xian_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->xian_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0
.end method

.method public getZh()Ljava/lang/String;
    .locals 4

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zh_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zh_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method public getZhBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zh_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zh_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public getZhuang()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zhuang_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zhuang_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public getZhuangBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zhuang_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zhuang_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0
.end method

.method public hasDs()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    and-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    return v1
.end method

.method public hasDx()Z
    .locals 3

    const/4 v2, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v0, 0x6

    xor-int/2addr v2, v0

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public hasEw()Z
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v2, 0x4

    return v0
.end method

.method public hasGyj()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v1, 0x7

    move v2, v1

    and-int/lit8 v0, v0, 0x8

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public hasHds()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    and-int/lit8 v0, v0, 0x10

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public hasHdx()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    and-int/lit8 v0, v0, 0x20

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public hasIssue()Z
    .locals 3

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    and-int/lit8 v0, v0, 0x40

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method public hasLh()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    and-int/lit16 v0, v0, 0x80

    const/4 v2, 0x7

    const/4 v1, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    return v0
.end method

.method public hasSanw()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v2, 0x2

    and-int/lit16 v0, v0, 0x100

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public hasSw()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    and-int/lit16 v0, v0, 0x200

    const/4 v2, 0x6

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public hasTs()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    and-int/lit16 v0, v0, 0x400

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public hasWinNumber()Z
    .locals 3

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    and-int/lit16 v0, v0, 0x800

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public hasXian()Z
    .locals 3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    and-int/lit16 v0, v0, 0x1000

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    return v0
.end method

.method public hasZh()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    and-int/lit16 v0, v0, 0x2000

    const/4 v2, 0x5

    const/4 v1, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public hasZhuang()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v2, 0x3

    and-int/lit16 v0, v0, 0x4000

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    return v0
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    return v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/16 v1, 0x30b

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    add-int/2addr v1, v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasDs()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getDs()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasDx()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    add-int/lit8 v1, v1, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getDx()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasEw()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_3

    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    add-int/lit8 v1, v1, 0x3

    const/4 v3, 0x7

    const/4 v2, 0x7

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getEw()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    add-int/2addr v1, v0

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasGyj()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_4

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    add-int/lit8 v1, v1, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getGyj()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    add-int/2addr v1, v0

    :cond_4
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasHds()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_5

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    add-int/lit8 v1, v1, 0x5

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getHds()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    add-int/2addr v1, v0

    :cond_5
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasHdx()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_6

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    add-int/lit8 v1, v1, 0x6

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getHdx()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    add-int/2addr v1, v0

    :cond_6
    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasIssue()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_7

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x2

    add-int/lit8 v1, v1, 0x7

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getIssue()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    add-int/2addr v1, v0

    :cond_7
    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasLh()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v0, :cond_8

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x25

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    add-int/lit8 v1, v1, 0x8

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getLh()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    add-int/2addr v1, v0

    :cond_8
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasSanw()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_9

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    add-int/lit8 v1, v1, 0x9

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getSanw()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    add-int/2addr v1, v0

    :cond_9
    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasSw()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_a

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    add-int/lit8 v1, v1, 0xa

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getSw()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    add-int/2addr v1, v0

    :cond_a
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasTs()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_b

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    add-int/lit8 v1, v1, 0xb

    const/4 v2, 0x4

    move v3, v2

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getTs()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_b
    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasWinNumber()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_c

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    add-int/lit8 v1, v1, 0xc

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getWinNumber()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    add-int/2addr v1, v0

    :cond_c
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasXian()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_d

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    add-int/lit8 v1, v1, 0xd

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getXian()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    add-int/2addr v1, v0

    :cond_d
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasZh()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_e

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0xe

    const/4 v3, 0x5

    const/4 v2, 0x6

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getZh()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_e
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hasZhuang()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_f

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    add-int/lit8 v1, v1, 0xf

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->getZhuang()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    add-int/2addr v1, v0

    :cond_f
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x1d

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->hashCode()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    add-int/2addr v1, v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput v1, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    return v1
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto;->access$28800()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v4, 0x4

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    const/4 v4, 0x3

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-byte v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->memoizedIsInitialized:B

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    return v1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    return v0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-byte v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->memoizedIsInitialized:B

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    return v1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method protected bridge synthetic newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->newBuilder()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method protected newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x4

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x1

    move v2, v1

    move v2, v1

    invoke-direct {v0, p1, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$1;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0
.end method

.method protected newInstance(Lcom/google/protobuf/GeneratedMessageV3$UnusedPrivateParameter;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unused"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    new-instance p1, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v1, 0x1

    invoke-direct {p1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public toBuilder()Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-ne p0, v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;-><init>(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$1;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;-><init>(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$1;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;)Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList$Builder;

    move-result-object v0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object v0
.end method

.method public writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    and-int/2addr v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ds_:Ljava/lang/Object;

    const/4 v4, 0x2

    invoke-static {p1, v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v1, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    and-int/2addr v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->dx_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p1, v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v1, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    and-int/2addr v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v0, 0x3

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ew_:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p1, v0, v2}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v3, 0x1

    move v4, v3

    const/16 v2, 0x8

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    and-int/2addr v0, v2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v0, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->gyj_:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {p1, v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    and-int/lit8 v0, v0, 0x10

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v0, 0x5

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hds_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    and-int/lit8 v0, v0, 0x20

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_5

    const/4 v4, 0x6

    const/4 v0, 0x6

    const/4 v4, 0x5

    xor-int/2addr v3, v0

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->hdx_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_5
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    and-int/lit8 v0, v0, 0x40

    const/4 v4, 0x3

    if-eqz v0, :cond_6

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v0, 0x7

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->issue_:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_6
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    and-int/lit16 v0, v0, 0x80

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v0, :cond_7

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->lh_:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1, v2, v0}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_7
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    and-int/lit16 v0, v0, 0x100

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_8

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/16 v0, 0x9

    const/4 v4, 0x2

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sanw_:Ljava/lang/Object;

    const/4 v3, 0x6

    shr-int/2addr v4, v3

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_8
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    and-int/lit16 v0, v0, 0x200

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_9

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/16 v0, 0xa

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->sw_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_9
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    and-int/lit16 v0, v0, 0x400

    const/4 v4, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_a

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/16 v0, 0xb

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->ts_:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_a
    const/4 v4, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    and-int/lit16 v0, v0, 0x800

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v0, :cond_b

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/16 v0, 0xc

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->winNumber_:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_b
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    and-int/lit16 v0, v0, 0x1000

    const/4 v3, 0x4

    move v4, v3

    if-eqz v0, :cond_c

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/16 v0, 0xd

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->xian_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_c
    const/4 v3, 0x7

    move v4, v3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    and-int/lit16 v0, v0, 0x2000

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v0, :cond_d

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/16 v0, 0xe

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zh_:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_d
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    and-int/lit16 v0, v0, 0x4000

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v0, :cond_e

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/16 v0, 0xf

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/GameGiftProto$TrendList;->zhuang_:Ljava/lang/Object;

    const/4 v3, 0x1

    move v4, v3

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_e
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Lcom/google/protobuf/UnknownFieldSet;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void
.end method
