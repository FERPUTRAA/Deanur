.class public final Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;
.super Lcom/google/protobuf/GeneratedMessageV3;

# interfaces
.implements Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResultOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/star/livegames/ws/protobuf/entity/NoticeProto;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "AnchorRewardResult"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;
    }
.end annotation


# static fields
.field public static final ANCHORID_FIELD_NUMBER:I = 0x2

.field private static final DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

.field public static final GAMEID_FIELD_NUMBER:I = 0x3

.field public static final GAMENAME_FIELD_NUMBER:I = 0x4

.field public static final ISSUE_FIELD_NUMBER:I = 0x5

.field public static final LIST_FIELD_NUMBER:I = 0x1

.field public static final MONEY_FIELD_NUMBER:I = 0x6

.field private static final PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;",
            ">;"
        }
    .end annotation
.end field

.field private static final serialVersionUID:J


# instance fields
.field private volatile anchorId_:Ljava/lang/Object;

.field private bitField0_:I

.field private volatile gameId_:Ljava/lang/Object;

.field private volatile gameName_:Ljava/lang/Object;

.field private volatile issue_:Ljava/lang/Object;

.field private list_:Lcom/google/protobuf/LazyStringArrayList;

.field private memoizedIsInitialized:B

.field private volatile money_:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    sput-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$1;

    const/4 v1, 0x1

    shl-int/2addr v2, v1

    invoke-direct {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$1;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    sput-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/protobuf/LazyStringArrayList;->emptyList()Lcom/google/protobuf/LazyStringArrayList;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->list_:Lcom/google/protobuf/LazyStringArrayList;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->issue_:Ljava/lang/Object;

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->money_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v1, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-byte v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->memoizedIsInitialized:B

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/protobuf/LazyStringArrayList;->emptyList()Lcom/google/protobuf/LazyStringArrayList;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->list_:Lcom/google/protobuf/LazyStringArrayList;

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->anchorId_:Ljava/lang/Object;

    const/4 v2, 0x6

    move v3, v2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->issue_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->money_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-static {}, Lcom/google/protobuf/LazyStringArrayList;->emptyList()Lcom/google/protobuf/LazyStringArrayList;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->list_:Lcom/google/protobuf/LazyStringArrayList;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x0

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->anchorId_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameId_:Ljava/lang/Object;

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameName_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->issue_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->money_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    const/4 p1, -0x1

    const/4 v0, 0x7

    move v1, v0

    iput-byte p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->memoizedIsInitialized:B

    const/4 v1, 0x6

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic access$7500(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;)Lcom/google/protobuf/LazyStringArrayList;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " Ks@S @ i1c@~@~@ @~ b~ii@o@@rbmu  @@@d @~@v@~~ n@~ ty~  t/ @ ~@~~o~s~~oM f-o~ 4ol~/~~l~f~ob@a~ ."

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->list_:Lcom/google/protobuf/LazyStringArrayList;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic access$7502(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;Lcom/google/protobuf/LazyStringArrayList;)Lcom/google/protobuf/LazyStringArrayList;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->list_:Lcom/google/protobuf/LazyStringArrayList;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p1
.end method

.method static synthetic access$7600(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->anchorId_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic access$7602(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->anchorId_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x4

    return-object p1
.end method

.method static synthetic access$7700(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameId_:Ljava/lang/Object;

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic access$7702(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameId_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic access$7800(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameName_:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic access$7802(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameName_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method

.method static synthetic access$7900(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->issue_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic access$7902(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->issue_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x0

    return-object p1
.end method

.method static synthetic access$8000(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->money_:Ljava/lang/Object;

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic access$8002(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->money_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p1
.end method

.method static synthetic access$8176(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;I)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    or-int/2addr p1, v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    iput p1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return p1
.end method

.method static synthetic access$8200(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    return-void
.end method

.method static synthetic access$8300(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic access$8400(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic access$8500(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic access$8600(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic access$8700(Lcom/google/protobuf/ByteString;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/protobuf/AbstractMessageLite;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public static getDefaultInstance()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto;->access$7000()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public static newBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;
    .locals 3

    const/4 v2, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public static newBuilder(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "prototype"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x3

    const/4 v1, 0x7

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom([B)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom([B)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v1, 0x6

    shl-int/2addr v2, v1

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v0, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-ne p1, p0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    return v0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    instance-of v1, p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x7

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    return p1

    :cond_1
    const/4 v4, 0x7

    move v5, v4

    check-cast p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getListList()Lcom/google/protobuf/ProtocolStringList;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getListList()Lcom/google/protobuf/ProtocolStringList;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-nez v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    return v2

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasAnchorId()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasAnchorId()Z

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eq v1, v3, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    return v2

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasAnchorId()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v1, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getAnchorId()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getAnchorId()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-nez v1, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    return v2

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasGameId()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasGameId()Z

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x5

    if-eq v1, v3, :cond_5

    const/4 v5, 0x7

    return v2

    :cond_5
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasGameId()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v1, :cond_6

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getGameId()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getGameId()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-nez v1, :cond_6

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    return v2

    :cond_6
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasGameName()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasGameName()Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eq v1, v3, :cond_7

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    return v2

    :cond_7
    const/4 v5, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasGameName()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    if-eqz v1, :cond_8

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getGameName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getGameName()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez v1, :cond_8

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    return v2

    :cond_8
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasIssue()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasIssue()Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eq v1, v3, :cond_9

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    return v2

    :cond_9
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasIssue()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v1, :cond_a

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getIssue()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getIssue()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-nez v1, :cond_a

    const/4 v4, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v2

    :cond_a
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasMoney()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasMoney()Z

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eq v1, v3, :cond_b

    const/4 v5, 0x1

    return v2

    :cond_b
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasMoney()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v1, :cond_c

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getMoney()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getMoney()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-nez v1, :cond_c

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    return v2

    :cond_c
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Lcom/google/protobuf/UnknownFieldSet;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-nez p1, :cond_d

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    return v2

    :cond_d
    const/4 v5, 0x5

    return v0
.end method

.method public getAnchorId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0
.end method

.method public getAnchorIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->anchorId_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public getDefaultInstanceForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public getGameId()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object v0
.end method

.method public getGameIdBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameId_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0
.end method

.method public getGameName()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public getGameNameBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameName_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x3

    move v3, v2

    return-object v0
.end method

.method public getIssue()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->issue_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0

    :cond_0
    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->issue_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0
.end method

.method public getIssueBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v2, 0x5

    move v3, v2

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->issue_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x1

    and-int/2addr v3, v2

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x6

    move v3, v2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->issue_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0
.end method

.method public getList(I)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->list_:Lcom/google/protobuf/LazyStringArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-virtual {v0, p1}, Lcom/google/protobuf/LazyStringArrayList;->get(I)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p1
.end method

.method public getListBytes(I)Lcom/google/protobuf/ByteString;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->list_:Lcom/google/protobuf/LazyStringArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/protobuf/LazyStringArrayList;->getByteString(I)Lcom/google/protobuf/ByteString;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p1
.end method

.method public getListCount()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->list_:Lcom/google/protobuf/LazyStringArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/LazyStringArrayList;->size()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public getListList()Lcom/google/protobuf/ProtocolStringList;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->list_:Lcom/google/protobuf/LazyStringArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic getListList()Ljava/util/List;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getListList()Lcom/google/protobuf/ProtocolStringList;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    return-object v0
.end method

.method public getMoney()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->money_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->money_:Ljava/lang/Object;

    const/4 v3, 0x7

    return-object v0
.end method

.method public getMoneyBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->money_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->money_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public getParserForType()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    return-object v0
.end method

.method public getSerializedSize()I
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v1, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eq v0, v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    return v0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    move v1, v0

    move v1, v0

    const/4 v5, 0x1

    move v1, v0

    move v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    move v2, v1

    move v2, v1

    const/4 v5, 0x3

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    iget-object v3, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->list_:Lcom/google/protobuf/LazyStringArrayList;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v3}, Lcom/google/protobuf/LazyStringArrayList;->size()I

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-ge v1, v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v3, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->list_:Lcom/google/protobuf/LazyStringArrayList;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v3, v1}, Lcom/google/protobuf/LazyStringArrayList;->getRaw(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSizeNoTag(Ljava/lang/Object;)I

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    add-int/2addr v2, v3

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    add-int/2addr v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getListList()Lcom/google/protobuf/ProtocolStringList;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    mul-int/lit8 v1, v1, 0x1

    const/4 v4, 0x1

    move v5, v4

    add-int/2addr v0, v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    and-int/lit8 v1, v1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v2, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->anchorId_:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v2, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    add-int/2addr v0, v1

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v5, 0x6

    and-int/2addr v1, v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v1, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v1, 0x3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameId_:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x1

    invoke-static {v1, v2}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    add-int/2addr v0, v1

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v2, 0x4

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    and-int/2addr v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x2

    if-eqz v1, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameName_:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v2, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    add-int/2addr v0, v1

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    and-int/lit8 v1, v1, 0x8

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v1, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v1, 0x5

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->issue_:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v1, v2}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    add-int/2addr v0, v1

    :cond_5
    const/4 v5, 0x2

    iget v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    and-int/lit8 v1, v1, 0x10

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz v1, :cond_6

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v1, 0x6

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->money_:Ljava/lang/Object;

    const/4 v4, 0x0

    move v5, v4

    invoke-static {v1, v2}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    add-int/2addr v0, v1

    :cond_6
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v1}, Lcom/google/protobuf/UnknownFieldSet;->getSerializedSize()I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    add-int/2addr v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iput v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x4

    return v0
.end method

.method public hasAnchorId()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    and-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return v1
.end method

.method public hasGameId()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x0

    or-int/2addr v1, v0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public hasGameName()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public hasIssue()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v1, 0x2

    xor-int/2addr v2, v1

    and-int/lit8 v0, v0, 0x8

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public hasMoney()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v2, 0x1

    and-int/lit8 v0, v0, 0x10

    const/4 v2, 0x3

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    move v2, v1

    const/4 v0, 0x0

    move v2, v0

    :goto_0
    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget v0, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    return v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/16 v1, 0x30b

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    add-int/2addr v1, v0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getListCount()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-lez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x5

    const/4 v2, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getListList()Lcom/google/protobuf/ProtocolStringList;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    add-int/2addr v1, v0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasAnchorId()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x25

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    add-int/lit8 v1, v1, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getAnchorId()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasGameId()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    add-int/lit8 v1, v1, 0x3

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getGameId()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    add-int/2addr v1, v0

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasGameName()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_4

    const/4 v3, 0x7

    const/4 v2, 0x6

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    add-int/lit8 v1, v1, 0x4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getGameName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    add-int/2addr v1, v0

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasIssue()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_5

    const/4 v2, 0x6

    move v3, v2

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    add-int/lit8 v1, v1, 0x5

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getIssue()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    add-int/2addr v1, v0

    :cond_5
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->hasMoney()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_6

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    add-int/lit8 v1, v1, 0x6

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->getMoney()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_6
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x1d

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->hashCode()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    add-int/2addr v1, v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput v1, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    return v1
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x7

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto;->access$7100()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v4, 0x2

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const-class v1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    const-class v2, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 4

    iget-byte v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->memoizedIsInitialized:B

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x3

    move v2, v1

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    return v1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    return v0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-byte v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->memoizedIsInitialized:B

    const/4 v2, 0x0

    const/4 v3, 0x1

    return v1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method protected bridge synthetic newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    return-object v0
.end method

.method public newBuilderForType()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-static {}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->newBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method protected newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v0, p1, v1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V

    const/4 v3, 0x0

    return-object v0
.end method

.method protected newInstance(Lcom/google/protobuf/GeneratedMessageV3$UnusedPrivateParameter;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unused"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    new-instance p1, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->toBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public toBuilder()Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->DEFAULT_INSTANCE:Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-ne p0, v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;-><init>(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance v0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;-><init>(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$1;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;->mergeFrom(Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;)Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult$Builder;

    move-result-object v0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0
.end method

.method public writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->list_:Lcom/google/protobuf/LazyStringArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v1}, Lcom/google/protobuf/LazyStringArrayList;->size()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-ge v0, v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->list_:Lcom/google/protobuf/LazyStringArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1, v0}, Lcom/google/protobuf/LazyStringArrayList;->getRaw(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p1, v2, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    const/4 v3, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    and-int/2addr v0, v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v1, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->anchorId_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {p1, v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v4, 0x6

    and-int/2addr v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v0, 0x3

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameId_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v1, 0x4

    const/4 v4, 0x2

    and-int/2addr v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz v0, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->gameName_:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-static {p1, v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_3
    const/4 v3, 0x1

    move v4, v3

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    and-int/lit8 v0, v0, 0x8

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz v0, :cond_4

    const/4 v4, 0x3

    const/4 v0, 0x6

    const/4 v4, 0x7

    const/4 v0, 0x5

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->issue_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget v0, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    and-int/lit8 v0, v0, 0x10

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v0, :cond_5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v0, 0x6

    const/4 v4, 0x1

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/star/livegames/ws/protobuf/entity/NoticeProto$AnchorRewardResult;->money_:Ljava/lang/Object;

    const/4 v3, 0x0

    move v4, v3

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_5
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Lcom/google/protobuf/UnknownFieldSet;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void
.end method
