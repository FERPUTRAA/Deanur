.class public final Lcom/google/protobuf/DescriptorProtos$FieldOptions;
.super Lcom/google/protobuf/GeneratedMessageV3$ExtendableMessage;

# interfaces
.implements Lcom/google/protobuf/DescriptorProtos$FieldOptionsOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/DescriptorProtos;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "FieldOptions"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;,
        Lcom/google/protobuf/DescriptorProtos$FieldOptions$EditionDefault;,
        Lcom/google/protobuf/DescriptorProtos$FieldOptions$EditionDefaultOrBuilder;,
        Lcom/google/protobuf/DescriptorProtos$FieldOptions$OptionTargetType;,
        Lcom/google/protobuf/DescriptorProtos$FieldOptions$OptionRetention;,
        Lcom/google/protobuf/DescriptorProtos$FieldOptions$JSType;,
        Lcom/google/protobuf/DescriptorProtos$FieldOptions$CType;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageV3$ExtendableMessage<",
        "Lcom/google/protobuf/DescriptorProtos$FieldOptions;",
        ">;",
        "Lcom/google/protobuf/DescriptorProtos$FieldOptionsOrBuilder;"
    }
.end annotation


# static fields
.field public static final CTYPE_FIELD_NUMBER:I = 0x1

.field public static final DEBUG_REDACT_FIELD_NUMBER:I = 0x10

.field private static final DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FieldOptions;

.field public static final DEPRECATED_FIELD_NUMBER:I = 0x3

.field public static final EDITION_DEFAULTS_FIELD_NUMBER:I = 0x14

.field public static final FEATURES_FIELD_NUMBER:I = 0x15

.field public static final JSTYPE_FIELD_NUMBER:I = 0x6

.field public static final LAZY_FIELD_NUMBER:I = 0x5

.field public static final PACKED_FIELD_NUMBER:I = 0x2

.field public static final PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/DescriptorProtos$FieldOptions;",
            ">;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final RETENTION_FIELD_NUMBER:I = 0x11

.field public static final TARGETS_FIELD_NUMBER:I = 0x13

.field public static final UNINTERPRETED_OPTION_FIELD_NUMBER:I = 0x3e7

.field public static final UNVERIFIED_LAZY_FIELD_NUMBER:I = 0xf

.field public static final WEAK_FIELD_NUMBER:I = 0xa

.field private static final serialVersionUID:J

.field private static final targets_converter_:Lcom/google/protobuf/Internal$ListAdapter$Converter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ListAdapter$Converter<",
            "Ljava/lang/Integer;",
            "Lcom/google/protobuf/DescriptorProtos$FieldOptions$OptionTargetType;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private bitField0_:I

.field private ctype_:I

.field private debugRedact_:Z

.field private deprecated_:Z

.field private editionDefaults_:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/protobuf/DescriptorProtos$FieldOptions$EditionDefault;",
            ">;"
        }
    .end annotation
.end field

.field private features_:Lcom/google/protobuf/DescriptorProtos$FeatureSet;

.field private jstype_:I

.field private lazy_:Z

.field private memoizedIsInitialized:B

.field private packed_:Z

.field private retention_:I

.field private targets_:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private uninterpretedOption_:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/protobuf/DescriptorProtos$UninterpretedOption;",
            ">;"
        }
    .end annotation
.end field

.field private unverifiedLazy_:Z

.field private weak_:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions$1;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions$1;-><init>()V

    const/4 v2, 0x0

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_converter_:Lcom/google/protobuf/Internal$ListAdapter$Converter;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;-><init>()V

    const/4 v2, 0x7

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v1, 0x6

    move v2, v1

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions$2;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions$2;-><init>()V

    const/4 v1, 0x1

    or-int/2addr v2, v1

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3$ExtendableMessage;-><init>()V

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-boolean v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->packed_:Z

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-boolean v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->lazy_:Z

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-boolean v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->unverifiedLazy_:Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-boolean v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->deprecated_:Z

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-boolean v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->weak_:Z

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-boolean v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->debugRedact_:Z

    const/4 v3, 0x6

    const/4 v1, -0x1

    const/4 v3, 0x3

    or-int/2addr v2, v1

    const/4 v3, 0x3

    iput-byte v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->memoizedIsInitialized:B

    const/4 v2, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->ctype_:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->jstype_:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->retention_:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_:Ljava/util/List;

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->editionDefaults_:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->uninterpretedOption_:Ljava/util/List;

    const/4 v2, 0x3

    move v3, v2

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$ExtendableBuilder;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/GeneratedMessageV3$ExtendableBuilder<",
            "Lcom/google/protobuf/DescriptorProtos$FieldOptions;",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3$ExtendableMessage;-><init>(Lcom/google/protobuf/GeneratedMessageV3$ExtendableBuilder;)V

    const/4 v1, 0x1

    const/4 p1, 0x7

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->ctype_:I

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->packed_:Z

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->jstype_:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->lazy_:Z

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->unverifiedLazy_:Z

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->deprecated_:Z

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-boolean p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->weak_:Z

    const/4 v0, 0x3

    move v1, v0

    iput-boolean p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->debugRedact_:Z

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->retention_:I

    const/4 v1, 0x5

    const/4 p1, -0x1

    const/4 v1, 0x6

    xor-int/2addr v0, p1

    const/4 v1, 0x3

    iput-byte p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->memoizedIsInitialized:B

    const/4 v0, 0x2

    shl-int/2addr v1, v0

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$ExtendableBuilder;Lcom/google/protobuf/DescriptorProtos$1;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;-><init>(Lcom/google/protobuf/GeneratedMessageV3$ExtendableBuilder;)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic access$20700(Lcom/google/protobuf/DescriptorProtos$FieldOptions;)Ljava/util/List;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "bbs ~c@.ou~@~o~o to@@f~@ ~toav@oS  @i@ il~@~-@ @ / @ @~@/dsi~  y@~@~lbmM @ ~f~@~@K4 1n@ ~~~~~ ~r"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_:Ljava/util/List;

    return-object p0
.end method

.method static synthetic access$20702(Lcom/google/protobuf/DescriptorProtos$FieldOptions;Ljava/util/List;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_:Ljava/util/List;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p1
.end method

.method static synthetic access$20800(Lcom/google/protobuf/DescriptorProtos$FieldOptions;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->editionDefaults_:Ljava/util/List;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic access$20802(Lcom/google/protobuf/DescriptorProtos$FieldOptions;Ljava/util/List;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->editionDefaults_:Ljava/util/List;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p1
.end method

.method static synthetic access$20900(Lcom/google/protobuf/DescriptorProtos$FieldOptions;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->uninterpretedOption_:Ljava/util/List;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$20902(Lcom/google/protobuf/DescriptorProtos$FieldOptions;Ljava/util/List;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->uninterpretedOption_:Ljava/util/List;

    return-object p1
.end method

.method static synthetic access$21002(Lcom/google/protobuf/DescriptorProtos$FieldOptions;I)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->ctype_:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    return p1
.end method

.method static synthetic access$21102(Lcom/google/protobuf/DescriptorProtos$FieldOptions;Z)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    iput-boolean p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->packed_:Z

    const/4 v0, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    return p1
.end method

.method static synthetic access$21202(Lcom/google/protobuf/DescriptorProtos$FieldOptions;I)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->jstype_:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    return p1
.end method

.method static synthetic access$21302(Lcom/google/protobuf/DescriptorProtos$FieldOptions;Z)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-boolean p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->lazy_:Z

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return p1
.end method

.method static synthetic access$21402(Lcom/google/protobuf/DescriptorProtos$FieldOptions;Z)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->unverifiedLazy_:Z

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    return p1
.end method

.method static synthetic access$21502(Lcom/google/protobuf/DescriptorProtos$FieldOptions;Z)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->deprecated_:Z

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p1
.end method

.method static synthetic access$21602(Lcom/google/protobuf/DescriptorProtos$FieldOptions;Z)Z
    .locals 2

    const/4 v0, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->weak_:Z

    const/4 v1, 0x2

    const/4 v0, 0x1

    return p1
.end method

.method static synthetic access$21702(Lcom/google/protobuf/DescriptorProtos$FieldOptions;Z)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-boolean p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->debugRedact_:Z

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return p1
.end method

.method static synthetic access$21802(Lcom/google/protobuf/DescriptorProtos$FieldOptions;I)I
    .locals 2

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->retention_:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    return p1
.end method

.method static synthetic access$21902(Lcom/google/protobuf/DescriptorProtos$FieldOptions;Lcom/google/protobuf/DescriptorProtos$FeatureSet;)Lcom/google/protobuf/DescriptorProtos$FeatureSet;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->features_:Lcom/google/protobuf/DescriptorProtos$FeatureSet;

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic access$22076(Lcom/google/protobuf/DescriptorProtos$FieldOptions;I)I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    or-int/2addr p1, v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return p1
.end method

.method static synthetic access$22100()Lcom/google/protobuf/Internal$ListAdapter$Converter;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_converter_:Lcom/google/protobuf/Internal$ListAdapter$Converter;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public static getDefaultInstance()Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos;->access$19400()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public static newBuilder()Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x1

    const/4 v1, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->toBuilder()Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public static newBuilder(Lcom/google/protobuf/DescriptorProtos$FieldOptions;)Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "prototype"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->toBuilder()Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;->mergeFrom(Lcom/google/protobuf/DescriptorProtos$FieldOptions;)Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x3

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0
.end method

.method public static parseFrom([B)Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom([B)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->PARSER:Lcom/google/protobuf/Parser;

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/DescriptorProtos$FieldOptions;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-ne p1, p0, :cond_0

    const/4 v5, 0x6

    return v0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    instance-of v1, p1, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v5, 0x2

    if-nez v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x2

    return p1

    :cond_1
    const/4 v4, 0x4

    move v5, v4

    check-cast p1, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasCtype()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasCtype()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x3

    if-eq v1, v2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    return v3

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasCtype()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v1, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->ctype_:I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget v2, p1, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->ctype_:I

    const/4 v5, 0x7

    if-eq v1, v2, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    return v3

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasPacked()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasPacked()Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eq v1, v2, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    return v3

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasPacked()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz v1, :cond_5

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getPacked()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getPacked()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eq v1, v2, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    return v3

    :cond_5
    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasJstype()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasJstype()Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eq v1, v2, :cond_6

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    return v3

    :cond_6
    const/4 v4, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasJstype()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v1, :cond_7

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->jstype_:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget v2, p1, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->jstype_:I

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eq v1, v2, :cond_7

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    return v3

    :cond_7
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasLazy()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasLazy()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eq v1, v2, :cond_8

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    return v3

    :cond_8
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasLazy()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v1, :cond_9

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getLazy()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getLazy()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eq v1, v2, :cond_9

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    return v3

    :cond_9
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasUnverifiedLazy()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasUnverifiedLazy()Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eq v1, v2, :cond_a

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    return v3

    :cond_a
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasUnverifiedLazy()Z

    move-result v1

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v1, :cond_b

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getUnverifiedLazy()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getUnverifiedLazy()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    if-eq v1, v2, :cond_b

    const/4 v5, 0x6

    const/4 v4, 0x4

    return v3

    :cond_b
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasDeprecated()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasDeprecated()Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eq v1, v2, :cond_c

    const/4 v5, 0x5

    const/4 v4, 0x2

    return v3

    :cond_c
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasDeprecated()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz v1, :cond_d

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getDeprecated()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getDeprecated()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eq v1, v2, :cond_d

    const/4 v5, 0x3

    return v3

    :cond_d
    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasWeak()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasWeak()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-eq v1, v2, :cond_e

    const/4 v5, 0x0

    const/4 v4, 0x6

    return v3

    :cond_e
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasWeak()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v1, :cond_f

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getWeak()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getWeak()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eq v1, v2, :cond_f

    const/4 v5, 0x5

    const/4 v4, 0x3

    return v3

    :cond_f
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasDebugRedact()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasDebugRedact()Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eq v1, v2, :cond_10

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    return v3

    :cond_10
    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasDebugRedact()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v1, :cond_11

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getDebugRedact()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getDebugRedact()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    if-eq v1, v2, :cond_11

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    return v3

    :cond_11
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasRetention()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasRetention()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eq v1, v2, :cond_12

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    return v3

    :cond_12
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasRetention()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v1, :cond_13

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->retention_:I

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget v2, p1, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->retention_:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eq v1, v2, :cond_13

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    return v3

    :cond_13
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v4, 0x7

    iget-object v2, p1, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_:Ljava/util/List;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v1, v2}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v1, :cond_14

    const/4 v5, 0x6

    return v3

    :cond_14
    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getEditionDefaultsList()Ljava/util/List;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getEditionDefaultsList()Ljava/util/List;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-interface {v1, v2}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-nez v1, :cond_15

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    return v3

    :cond_15
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasFeatures()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasFeatures()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eq v1, v2, :cond_16

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    return v3

    :cond_16
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasFeatures()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v1, :cond_17

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getFeatures()Lcom/google/protobuf/DescriptorProtos$FeatureSet;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getFeatures()Lcom/google/protobuf/DescriptorProtos$FeatureSet;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Lcom/google/protobuf/DescriptorProtos$FeatureSet;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    if-nez v1, :cond_17

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    return v3

    :cond_17
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getUninterpretedOptionList()Ljava/util/List;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getUninterpretedOptionList()Ljava/util/List;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-interface {v1, v2}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-nez v1, :cond_18

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    return v3

    :cond_18
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Lcom/google/protobuf/UnknownFieldSet;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-nez v1, :cond_19

    const/4 v5, 0x4

    return v3

    :cond_19
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$ExtendableMessage;->getExtensionFields()Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3$ExtendableMessage;->getExtensionFields()Ljava/util/Map;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {v1, p1}, Ljava/util/Map;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-nez p1, :cond_1a

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    return v3

    :cond_1a
    const/4 v5, 0x3

    return v0
.end method

.method public getCtype()Lcom/google/protobuf/DescriptorProtos$FieldOptions$CType;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->ctype_:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    invoke-static {v0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions$CType;->forNumber(I)Lcom/google/protobuf/DescriptorProtos$FieldOptions$CType;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions$CType;->STRING:Lcom/google/protobuf/DescriptorProtos$FieldOptions$CType;

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public getDebugRedact()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->debugRedact_:Z

    const/4 v2, 0x4

    return v0
.end method

.method public getDefaultInstanceForType()Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getDefaultInstanceForType()Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getDefaultInstanceForType()Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public getDeprecated()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->deprecated_:Z

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public getEditionDefaults(I)Lcom/google/protobuf/DescriptorProtos$FieldOptions$EditionDefault;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->editionDefaults_:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    check-cast p1, Lcom/google/protobuf/DescriptorProtos$FieldOptions$EditionDefault;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p1
.end method

.method public getEditionDefaultsCount()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->editionDefaults_:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public getEditionDefaultsList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/DescriptorProtos$FieldOptions$EditionDefault;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->editionDefaults_:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public getEditionDefaultsOrBuilder(I)Lcom/google/protobuf/DescriptorProtos$FieldOptions$EditionDefaultOrBuilder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->editionDefaults_:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    check-cast p1, Lcom/google/protobuf/DescriptorProtos$FieldOptions$EditionDefaultOrBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p1
.end method

.method public getEditionDefaultsOrBuilderList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/google/protobuf/DescriptorProtos$FieldOptions$EditionDefaultOrBuilder;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->editionDefaults_:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public getFeatures()Lcom/google/protobuf/DescriptorProtos$FeatureSet;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->features_:Lcom/google/protobuf/DescriptorProtos$FeatureSet;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FeatureSet;->getDefaultInstance()Lcom/google/protobuf/DescriptorProtos$FeatureSet;

    move-result-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public getFeaturesOrBuilder()Lcom/google/protobuf/DescriptorProtos$FeatureSetOrBuilder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->features_:Lcom/google/protobuf/DescriptorProtos$FeatureSet;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FeatureSet;->getDefaultInstance()Lcom/google/protobuf/DescriptorProtos$FeatureSet;

    move-result-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public getJstype()Lcom/google/protobuf/DescriptorProtos$FieldOptions$JSType;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->jstype_:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions$JSType;->forNumber(I)Lcom/google/protobuf/DescriptorProtos$FieldOptions$JSType;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions$JSType;->JS_NORMAL:Lcom/google/protobuf/DescriptorProtos$FieldOptions$JSType;

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public getLazy()Z
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->lazy_:Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public getPacked()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->packed_:Z

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public getParserForType()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/DescriptorProtos$FieldOptions;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    return-object v0
.end method

.method public getRetention()Lcom/google/protobuf/DescriptorProtos$FieldOptions$OptionRetention;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->retention_:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions$OptionRetention;->forNumber(I)Lcom/google/protobuf/DescriptorProtos$FieldOptions$OptionRetention;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions$OptionRetention;->RETENTION_UNKNOWN:Lcom/google/protobuf/DescriptorProtos$FieldOptions$OptionRetention;

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public getSerializedSize()I
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/4 v1, -0x1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-eq v0, v1, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    return v0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    and-int/2addr v0, v1

    const/4 v7, 0x3

    const/4 v2, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz v0, :cond_1

    const/4 v7, 0x2

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->ctype_:I

    const/4 v7, 0x2

    const/4 v6, 0x4

    invoke-static {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->computeEnumSize(II)I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    add-int/2addr v0, v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto :goto_0

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v3, 0x2

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    and-int/2addr v1, v3

    const/4 v7, 0x6

    const/4 v6, 0x7

    if-eqz v1, :cond_2

    const/4 v6, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-boolean v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->packed_:Z

    const/4 v7, 0x7

    const/4 v6, 0x7

    invoke-static {v3, v1}, Lcom/google/protobuf/CodedOutputStream;->computeBoolSize(IZ)I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    add-int/2addr v0, v1

    :cond_2
    const/4 v6, 0x1

    const/4 v7, 0x3

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    and-int/lit8 v1, v1, 0x20

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-eqz v1, :cond_3

    const/4 v7, 0x7

    const/4 v1, 0x3

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-boolean v4, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->deprecated_:Z

    const/4 v7, 0x4

    invoke-static {v1, v4}, Lcom/google/protobuf/CodedOutputStream;->computeBoolSize(IZ)I

    move-result v1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    add-int/2addr v0, v1

    :cond_3
    const/4 v7, 0x4

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    and-int/lit8 v1, v1, 0x8

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-eqz v1, :cond_4

    const/4 v6, 0x5

    move v7, v6

    const/4 v1, 0x5

    move v7, v1

    const/4 v6, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-boolean v4, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->lazy_:Z

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {v1, v4}, Lcom/google/protobuf/CodedOutputStream;->computeBoolSize(IZ)I

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    add-int/2addr v0, v1

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x6

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    and-int/lit8 v1, v1, 0x4

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz v1, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    const/4 v1, 0x6

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget v4, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->jstype_:I

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {v1, v4}, Lcom/google/protobuf/CodedOutputStream;->computeEnumSize(II)I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    add-int/2addr v0, v1

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x4

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    and-int/lit8 v1, v1, 0x40

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v1, :cond_6

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/16 v1, 0xa

    const/4 v6, 0x2

    move v7, v6

    iget-boolean v4, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->weak_:Z

    const/4 v7, 0x1

    invoke-static {v1, v4}, Lcom/google/protobuf/CodedOutputStream;->computeBoolSize(IZ)I

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    add-int/2addr v0, v1

    :cond_6
    const/4 v7, 0x5

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/16 v4, 0x10

    const/4 v7, 0x5

    const/4 v6, 0x1

    and-int/2addr v1, v4

    const/4 v7, 0x4

    const/4 v6, 0x5

    if-eqz v1, :cond_7

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/16 v1, 0xf

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-boolean v5, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->unverifiedLazy_:Z

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {v1, v5}, Lcom/google/protobuf/CodedOutputStream;->computeBoolSize(IZ)I

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    add-int/2addr v0, v1

    :cond_7
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    and-int/lit16 v1, v1, 0x80

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz v1, :cond_8

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-boolean v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->debugRedact_:Z

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {v4, v1}, Lcom/google/protobuf/CodedOutputStream;->computeBoolSize(IZ)I

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    add-int/2addr v0, v1

    :cond_8
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    and-int/lit16 v1, v1, 0x100

    const/4 v7, 0x5

    const/4 v6, 0x2

    if-eqz v1, :cond_9

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/16 v1, 0x11

    const/4 v7, 0x1

    iget v4, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->retention_:I

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {v1, v4}, Lcom/google/protobuf/CodedOutputStream;->computeEnumSize(II)I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    add-int/2addr v0, v1

    :cond_9
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    move v1, v2

    move v1, v2

    move v1, v2

    move v1, v2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    move v4, v1

    move v4, v1

    const/4 v7, 0x2

    move v4, v1

    move v4, v1

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-object v5, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_:Ljava/util/List;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-ge v1, v5, :cond_a

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v5, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_:Ljava/util/List;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-interface {v5, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    check-cast v5, Ljava/lang/Integer;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {v5}, Lcom/google/protobuf/CodedOutputStream;->computeEnumSizeNoTag(I)I

    move-result v5

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    add-int/2addr v4, v5

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    goto :goto_1

    :cond_a
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    add-int/2addr v0, v4

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_:Ljava/util/List;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    mul-int/2addr v1, v3

    const/4 v7, 0x1

    add-int/2addr v0, v1

    const/4 v7, 0x4

    const/4 v6, 0x5

    move v1, v2

    move v1, v2

    const/4 v7, 0x0

    move v1, v2

    move v1, v2

    :goto_2
    const/4 v7, 0x0

    iget-object v3, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->editionDefaults_:Ljava/util/List;

    const/4 v7, 0x1

    const/4 v6, 0x1

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-ge v1, v3, :cond_b

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v3, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->editionDefaults_:Ljava/util/List;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-interface {v3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    check-cast v3, Lcom/google/protobuf/MessageLite;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/16 v4, 0x14

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v4, v3}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    add-int/2addr v0, v3

    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    goto :goto_2

    :cond_b
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    and-int/lit16 v1, v1, 0x200

    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-eqz v1, :cond_c

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    const/16 v1, 0x15

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getFeatures()Lcom/google/protobuf/DescriptorProtos$FeatureSet;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x6

    invoke-static {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    add-int/2addr v0, v1

    :cond_c
    :goto_3
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->uninterpretedOption_:Ljava/util/List;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-ge v2, v1, :cond_d

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->uninterpretedOption_:Ljava/util/List;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x2

    check-cast v1, Lcom/google/protobuf/MessageLite;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/16 v3, 0x3e7

    const/4 v7, 0x3

    invoke-static {v3, v1}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    add-int/2addr v0, v1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    goto :goto_3

    :cond_d
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$ExtendableMessage;->extensionsSerializedSize()I

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    add-int/2addr v0, v1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v1}, Lcom/google/protobuf/UnknownFieldSet;->getSerializedSize()I

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    add-int/2addr v0, v1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    iput v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    return v0
.end method

.method public getTargets(I)Lcom/google/protobuf/DescriptorProtos$FieldOptions$OptionTargetType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_converter_:Lcom/google/protobuf/Internal$ListAdapter$Converter;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_:Ljava/util/List;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    check-cast p1, Ljava/lang/Integer;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ListAdapter$Converter;->convert(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    check-cast p1, Lcom/google/protobuf/DescriptorProtos$FieldOptions$OptionTargetType;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object p1
.end method

.method public getTargetsCount()I
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    return v0
.end method

.method public getTargetsList()Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/DescriptorProtos$FieldOptions$OptionTargetType;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v0, Lcom/google/protobuf/Internal$ListAdapter;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_:Ljava/util/List;

    const/4 v4, 0x4

    sget-object v2, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_converter_:Lcom/google/protobuf/Internal$ListAdapter$Converter;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v0, v1, v2}, Lcom/google/protobuf/Internal$ListAdapter;-><init>(Ljava/util/List;Lcom/google/protobuf/Internal$ListAdapter$Converter;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-object v0
.end method

.method public getUninterpretedOption(I)Lcom/google/protobuf/DescriptorProtos$UninterpretedOption;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->uninterpretedOption_:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    check-cast p1, Lcom/google/protobuf/DescriptorProtos$UninterpretedOption;

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p1
.end method

.method public getUninterpretedOptionCount()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->uninterpretedOption_:Ljava/util/List;

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public getUninterpretedOptionList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/DescriptorProtos$UninterpretedOption;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x5

    move v2, v1

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->uninterpretedOption_:Ljava/util/List;

    return-object v0
.end method

.method public getUninterpretedOptionOrBuilder(I)Lcom/google/protobuf/DescriptorProtos$UninterpretedOptionOrBuilder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->uninterpretedOption_:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    check-cast p1, Lcom/google/protobuf/DescriptorProtos$UninterpretedOptionOrBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p1
.end method

.method public getUninterpretedOptionOrBuilderList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/google/protobuf/DescriptorProtos$UninterpretedOptionOrBuilder;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->uninterpretedOption_:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public getUnverifiedLazy()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->unverifiedLazy_:Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public getWeak()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->weak_:Z

    const/4 v1, 0x0

    and-int/2addr v2, v1

    return v0
.end method

.method public hasCtype()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x4

    and-int/2addr v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    return v1
.end method

.method public hasDebugRedact()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    and-int/lit16 v0, v0, 0x80

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x2

    move v1, v0

    move v1, v0

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public hasDeprecated()Z
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    and-int/lit8 v0, v0, 0x20

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v1, 0x3

    shl-int/2addr v2, v1

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x6

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public hasFeatures()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    and-int/lit16 v0, v0, 0x200

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public hasJstype()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public hasLazy()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    and-int/lit8 v0, v0, 0x8

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x4

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public hasPacked()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v0, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public hasRetention()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    and-int/lit16 v0, v0, 0x100

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public hasUnverifiedLazy()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    and-int/lit8 v0, v0, 0x10

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public hasWeak()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    and-int/lit8 v0, v0, 0x40

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v0, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    return v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/16 v1, 0x30b

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    add-int/2addr v1, v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasCtype()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->ctype_:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    add-int/2addr v1, v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasPacked()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getPacked()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/protobuf/Internal;->hashBoolean(Z)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    add-int/2addr v1, v0

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasJstype()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x1

    add-int/lit8 v1, v1, 0x6

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->jstype_:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    add-int/2addr v1, v0

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasLazy()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    add-int/lit8 v1, v1, 0x5

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x35

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getLazy()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/protobuf/Internal;->hashBoolean(Z)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    add-int/2addr v1, v0

    :cond_4
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasUnverifiedLazy()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x4

    add-int/lit8 v1, v1, 0xf

    const/4 v3, 0x2

    const/4 v2, 0x7

    mul-int/lit8 v1, v1, 0x35

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getUnverifiedLazy()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/protobuf/Internal;->hashBoolean(Z)I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    add-int/2addr v1, v0

    :cond_5
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasDeprecated()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_6

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    add-int/lit8 v1, v1, 0x3

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getDeprecated()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/protobuf/Internal;->hashBoolean(Z)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    add-int/2addr v1, v0

    :cond_6
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasWeak()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_7

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    add-int/lit8 v1, v1, 0xa

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getWeak()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/protobuf/Internal;->hashBoolean(Z)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_7
    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasDebugRedact()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_8

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    add-int/lit8 v1, v1, 0x10

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getDebugRedact()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/protobuf/Internal;->hashBoolean(Z)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    add-int/2addr v1, v0

    :cond_8
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasRetention()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v0, :cond_9

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    add-int/lit8 v1, v1, 0x11

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->retention_:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_9
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getTargetsCount()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-lez v0, :cond_a

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x25

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x13

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/List;->hashCode()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    add-int/2addr v1, v0

    :cond_a
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getEditionDefaultsCount()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-lez v0, :cond_b

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    add-int/lit8 v1, v1, 0x14

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getEditionDefaultsList()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/List;->hashCode()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    add-int/2addr v1, v0

    :cond_b
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasFeatures()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v0, :cond_c

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x5

    const/4 v2, 0x1

    add-int/lit8 v1, v1, 0x15

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getFeatures()Lcom/google/protobuf/DescriptorProtos$FeatureSet;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FeatureSet;->hashCode()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    add-int/2addr v1, v0

    :cond_c
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getUninterpretedOptionCount()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-lez v0, :cond_d

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    add-int/lit16 v1, v1, 0x3e7

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getUninterpretedOptionList()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/List;->hashCode()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    add-int/2addr v1, v0

    :cond_d
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$ExtendableMessage;->getExtensionFields()Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/google/protobuf/AbstractMessage;->hashFields(ILjava/util/Map;)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    mul-int/lit8 v0, v0, 0x1d

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v1}, Lcom/google/protobuf/UnknownFieldSet;->hashCode()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    add-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput v0, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    return v0
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos;->access$19500()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-class v1, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const-class v1, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-class v2, Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    const-class v2, Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    const/4 v4, 0x3

    const-class v2, Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    const-class v2, Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-byte v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->memoizedIsInitialized:B

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v5, 0x4

    move v4, v1

    move v4, v1

    const/4 v5, 0x1

    if-ne v0, v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    return v1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-nez v0, :cond_1

    const/4 v5, 0x7

    return v2

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasFeatures()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v0, :cond_2

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getFeatures()Lcom/google/protobuf/DescriptorProtos$FeatureSet;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FeatureSet;->isInitialized()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    iput-byte v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->memoizedIsInitialized:B

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    return v2

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    move v0, v2

    move v0, v2

    const/4 v5, 0x4

    move v0, v2

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getUninterpretedOptionCount()I

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-ge v0, v3, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p0, v0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getUninterpretedOption(I)Lcom/google/protobuf/DescriptorProtos$UninterpretedOption;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v3}, Lcom/google/protobuf/DescriptorProtos$UninterpretedOption;->isInitialized()Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-nez v3, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x1

    iput-byte v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->memoizedIsInitialized:B

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    return v2

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_0

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$ExtendableMessage;->extensionsAreInitialized()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-nez v0, :cond_5

    const/4 v5, 0x1

    iput-byte v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->memoizedIsInitialized:B

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    return v2

    :cond_5
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput-byte v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->memoizedIsInitialized:B

    const/4 v4, 0x1

    shr-int/2addr v5, v4

    return v1
.end method

.method public newBuilderForType()Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->newBuilder()Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method protected newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v0, p1, v1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/google/protobuf/DescriptorProtos$1;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v0
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->newBuilderForType()Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method protected bridge synthetic newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->newBuilderForType()Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method protected newInstance(Lcom/google/protobuf/GeneratedMessageV3$UnusedPrivateParameter;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unused"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    new-instance p1, Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p1
.end method

.method public toBuilder()Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x5

    xor-int/2addr v3, v2

    const/4 v1, 0x0

    xor-int/2addr v3, v1

    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-ne p0, v0, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;-><init>(Lcom/google/protobuf/DescriptorProtos$1;)V

    const/4 v2, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;-><init>(Lcom/google/protobuf/DescriptorProtos$1;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;->mergeFrom(Lcom/google/protobuf/DescriptorProtos$FieldOptions;)Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    move-result-object v0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/Message$Builder;
    .locals 3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->toBuilder()Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->toBuilder()Lcom/google/protobuf/DescriptorProtos$FieldOptions$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3$ExtendableMessage;->newExtensionWriter()Lcom/google/protobuf/GeneratedMessageV3$ExtendableMessage$ExtensionWriter;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    and-int/2addr v1, v2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->ctype_:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p1, v2, v1}, Lcom/google/protobuf/CodedOutputStream;->writeEnum(II)V

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v2, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    and-int/2addr v1, v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-boolean v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->packed_:Z

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p1, v2, v1}, Lcom/google/protobuf/CodedOutputStream;->writeBool(IZ)V

    :cond_1
    const/4 v5, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v6, 0x4

    const/4 v5, 0x3

    and-int/lit8 v1, v1, 0x20

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v1, 0x3

    const/4 v5, 0x1

    move v6, v5

    iget-boolean v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->deprecated_:Z

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p1, v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeBool(IZ)V

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    and-int/lit8 v1, v1, 0x8

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eqz v1, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v1, 0x5

    const/4 v6, 0x7

    iget-boolean v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->lazy_:Z

    const/4 v5, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p1, v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeBool(IZ)V

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    and-int/lit8 v1, v1, 0x4

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz v1, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 v1, 0x6

    const/4 v6, 0x3

    const/4 v5, 0x0

    iget v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->jstype_:I

    const/4 v6, 0x5

    const/4 v5, 0x2

    invoke-virtual {p1, v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeEnum(II)V

    :cond_4
    const/4 v6, 0x6

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    and-int/lit8 v1, v1, 0x40

    const/4 v6, 0x5

    if-eqz v1, :cond_5

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/16 v1, 0xa

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-boolean v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->weak_:Z

    const/4 v6, 0x5

    invoke-virtual {p1, v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeBool(IZ)V

    :cond_5
    const/4 v6, 0x1

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/16 v2, 0x10

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    and-int/2addr v1, v2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-eqz v1, :cond_6

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/16 v1, 0xf

    const/4 v6, 0x1

    iget-boolean v3, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->unverifiedLazy_:Z

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1, v1, v3}, Lcom/google/protobuf/CodedOutputStream;->writeBool(IZ)V

    :cond_6
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v6, 0x2

    and-int/lit16 v1, v1, 0x80

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v1, :cond_7

    const/4 v5, 0x1

    move v6, v5

    iget-boolean v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->debugRedact_:Z

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p1, v2, v1}, Lcom/google/protobuf/CodedOutputStream;->writeBool(IZ)V

    :cond_7
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    and-int/lit16 v1, v1, 0x100

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-eqz v1, :cond_8

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/16 v1, 0x11

    const/4 v6, 0x1

    const/4 v5, 0x6

    iget v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->retention_:I

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p1, v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeEnum(II)V

    :cond_8
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    move v2, v1

    move v2, v1

    const/4 v6, 0x5

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v3, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_:Ljava/util/List;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-ge v2, v3, :cond_9

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->targets_:Ljava/util/List;

    const/4 v6, 0x1

    const/4 v5, 0x5

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    check-cast v3, Ljava/lang/Integer;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/16 v4, 0x13

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p1, v4, v3}, Lcom/google/protobuf/CodedOutputStream;->writeEnum(II)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x5

    goto :goto_0

    :cond_9
    const/4 v6, 0x0

    const/4 v5, 0x4

    move v2, v1

    move v2, v1

    const/4 v6, 0x6

    move v2, v1

    move v2, v1

    :goto_1
    const/4 v6, 0x1

    iget-object v3, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->editionDefaults_:Ljava/util/List;

    const/4 v5, 0x4

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-ge v2, v3, :cond_a

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->editionDefaults_:Ljava/util/List;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    check-cast v3, Lcom/google/protobuf/MessageLite;

    const/4 v6, 0x2

    const/16 v4, 0x14

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p1, v4, v3}, Lcom/google/protobuf/CodedOutputStream;->writeMessage(ILcom/google/protobuf/MessageLite;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    goto :goto_1

    :cond_a
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->bitField0_:I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    and-int/lit16 v2, v2, 0x200

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-eqz v2, :cond_b

    const/16 v2, 0x15

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getFeatures()Lcom/google/protobuf/DescriptorProtos$FeatureSet;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-virtual {p1, v2, v3}, Lcom/google/protobuf/CodedOutputStream;->writeMessage(ILcom/google/protobuf/MessageLite;)V

    :cond_b
    :goto_2
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->uninterpretedOption_:Ljava/util/List;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-ge v1, v2, :cond_c

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->uninterpretedOption_:Ljava/util/List;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    check-cast v2, Lcom/google/protobuf/MessageLite;

    const/4 v6, 0x0

    const/16 v3, 0x3e7

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p1, v3, v2}, Lcom/google/protobuf/CodedOutputStream;->writeMessage(ILcom/google/protobuf/MessageLite;)V

    const/4 v5, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    goto :goto_2

    :cond_c
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/high16 v1, 0x20000000

    const/4 v6, 0x3

    invoke-virtual {v0, v1, p1}, Lcom/google/protobuf/GeneratedMessageV3$ExtendableMessage$ExtensionWriter;->writeUntil(ILcom/google/protobuf/CodedOutputStream;)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0, p1}, Lcom/google/protobuf/UnknownFieldSet;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    return-void
.end method
