.class public Lcom/tencent/thumbplayer/api/TPDashFormat;
.super Ljava/lang/Object;


# instance fields
.field public audioChannels:I

.field public audioSamplingRate:I

.field public bandwidth:I

.field public codecs:Ljava/lang/String;

.field public frameRate:F

.field public height:I

.field public language:Ljava/lang/String;

.field public mimeType:Ljava/lang/String;

.field public representationId:Ljava/lang/String;

.field public width:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPDashFormat;->width:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPDashFormat;->height:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPDashFormat;->bandwidth:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPDashFormat;->audioChannels:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPDashFormat;->audioSamplingRate:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPDashFormat;->frameRate:F

    const/4 v2, 0x0

    return-void
.end method
