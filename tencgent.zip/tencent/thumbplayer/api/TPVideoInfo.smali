.class public Lcom/tencent/thumbplayer/api/TPVideoInfo;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;
    }
.end annotation


# instance fields
.field private builder:Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;

.field private definition:Ljava/lang/String;

.field private downloadParamList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;",
            ">;"
        }
    .end annotation
.end field

.field private fileID:Ljava/lang/String;

.field private height:J

.field private videoCodecId:I
    .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_VIDEO_CODEC_TYPE;
    .end annotation
.end field

.field private width:J


# direct methods
.method private constructor <init>(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    move v3, v2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo;->downloadParamList:Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->access$000(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;)J

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-wide v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo;->width:J

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->access$100(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;)J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo;->height:J

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    invoke-static {p1}, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->access$200(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo;->videoCodecId:I

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->access$300(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo;->fileID:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->access$400(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo;->definition:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->access$500(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo;->downloadParamList:Ljava/util/ArrayList;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo;->builder:Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;Lcom/tencent/thumbplayer/api/TPVideoInfo$1;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/api/TPVideoInfo;-><init>(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public getBuilder()Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~/sb ~t 1@@o~m@~o~c~@y~t~~4o ~@s~ l@ ~oru~o~@   ~ @@a f ~oM@b/b.l@d@if~~ @@v @ ~ in@~Si@@@@K~  ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo;->builder:Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;

    const/4 v1, 0x0

    and-int/2addr v2, v1

    return-object v0
.end method

.method public getDefinition()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo;->definition:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public getDownloadPraramList()Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo;->downloadParamList:Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public getHeight()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo;->height:J

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-wide v0
.end method

.method public getProxyFileID()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo;->fileID:Ljava/lang/String;

    const/4 v2, 0x4

    return-object v0
.end method

.method public getVideoCodecId()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo;->videoCodecId:I

    const/4 v2, 0x6

    return v0
.end method

.method public getWidth()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo;->width:J

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-wide v0
.end method
