.class public final Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation


# static fields
.field public static final DEFAULT_ADJUST_INTERVAL_THRESHOLD_MS:J = 0xea60L

.field public static final DEFAULT_FROZEN_THRESHOLD_MS:J = 0x320L

.field public static final DEFAULT_MAX_DECREASE_DURATION_MS:J = 0x1f40L

.field public static final DEFAULT_MIN_DECREASE_DURATION_MS:J = 0x7d0L

.field public static final DEFAULT_PER_DECREASE_DURATION_MS:J = 0x1f4L

.field public static final DEFAULT_PER_INCREASE_DURATION_MS:J = 0x3e8L


# instance fields
.field private mAdjustIntervalThresholdMs:J

.field private mFrozenThresholdMs:J

.field private mMaxIncreaseDurationMs:J

.field private mMinDecreaseDurationMs:J

.field private mPerDecreaseDurationMs:J

.field private mPerIncreaseDurationMs:J


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const-wide/16 v0, 0x7d0

    const-wide/16 v0, 0x7d0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mMinDecreaseDurationMs:J

    const/4 v3, 0x6

    const-wide/16 v0, 0x1f40

    const-wide/16 v0, 0x1f40

    const/4 v3, 0x2

    const-wide/16 v0, 0x1f40

    const-wide/16 v0, 0x1f40

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mMaxIncreaseDurationMs:J

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x5

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-wide v0, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mPerIncreaseDurationMs:J

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-wide/16 v0, 0x1f4

    const-wide/16 v0, 0x1f4

    const/4 v3, 0x0

    const-wide/16 v0, 0x1f4

    const-wide/16 v0, 0x1f4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mPerDecreaseDurationMs:J

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-wide/32 v0, 0xea60

    const/4 v3, 0x4

    const-wide/32 v0, 0xea60

    const-wide/32 v0, 0xea60

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mAdjustIntervalThresholdMs:J

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-wide/16 v0, 0x320

    const-wide/16 v0, 0x320

    iput-wide v0, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mFrozenThresholdMs:J

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public final build()Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;
    .locals 15

    const-string/jumbo v14, "sms  - ~l~io f~@oo   / d y@@ ~ rMv@~@~ @~1tK~@c@n~@   ~i@@~~~o~a ~b~~o@~ @@~4~f.b~iltS@@/~@u@o@b"

    const-string v14, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v13, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;

    const/4 v14, 0x1

    iget-wide v1, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mMinDecreaseDurationMs:J

    const/4 v14, 0x6

    iget-wide v3, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mMaxIncreaseDurationMs:J

    const/4 v14, 0x6

    iget-wide v5, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mPerIncreaseDurationMs:J

    const/4 v14, 0x4

    iget-wide v7, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mPerDecreaseDurationMs:J

    const/4 v14, 0x6

    iget-wide v9, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mAdjustIntervalThresholdMs:J

    const/4 v14, 0x2

    iget-wide v11, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mFrozenThresholdMs:J

    move-object v0, v13

    move-object v0, v13

    move-object v0, v13

    move-object v0, v13

    const/4 v14, 0x7

    invoke-direct/range {v0 .. v12}, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;-><init>(JJJJJJ)V

    const/4 v14, 0x5

    return-object v13
.end method

.method public final setAdjustIntervalThresholdMs(J)Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-wide p1, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mAdjustIntervalThresholdMs:J

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p0
.end method

.method public final setFrozenThresholdMs(J)Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-wide p1, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mFrozenThresholdMs:J

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method public final setMaxIncreaseDurationMs(J)Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-wide p1, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mMaxIncreaseDurationMs:J

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p0
.end method

.method public final setMinDecreaseDurationMs(J)Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    iput-wide p1, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mMinDecreaseDurationMs:J

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p0
.end method

.method public final setPerDecreaseDurationMs(J)Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-wide p1, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mPerDecreaseDurationMs:J

    const/4 v1, 0x7

    return-object p0
.end method

.method public final setPerIncreaseDurationMs(J)Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-wide p1, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;->mPerIncreaseDurationMs:J

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method
