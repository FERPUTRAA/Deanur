.class final Lcom/tencent/thumbplayer/api/TPPlayerMgr$1;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/common/ITPNativeLogCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/api/TPPlayerMgr;->preInitSync(Landroid/content/Context;Ljava/lang/String;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final onPrintLog(ILjava/lang/String;Ljava/lang/String;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " cs  a fM@@/~  Kr~.b~  /@~s~l~o @ @f@@~~~i@yno@ -~@@  4 ~i@d @~@@l~~~~oS ~~btv1o~~~b~@@o@o u@@tm"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    if-eqz p1, :cond_4

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eq p1, v0, :cond_3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eq p1, v0, :cond_2

    const/4 v1, 0x7

    move v2, v1

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eq p1, v0, :cond_1

    const/4 v2, 0x7

    const/4 v0, 0x4

    shl-int/2addr v1, v0

    const/4 v2, 0x6

    if-eq p1, v0, :cond_0

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p2, p3}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    return-void

    :cond_1
    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p2, p3}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    return-void

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p2, p3}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void

    :cond_3
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p2, p3}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void

    :cond_4
    const/4 v2, 0x3

    const/4 v1, 0x6

    invoke-static {p2, p3}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    return-void
.end method
