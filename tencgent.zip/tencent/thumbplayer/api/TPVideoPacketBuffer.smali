.class public Lcom/tencent/thumbplayer/api/TPVideoPacketBuffer;
.super Ljava/lang/Object;


# instance fields
.field public mData:[B

.field public mDolbyVisionInfo:Lcom/tencent/thumbplayer/api/TPSurfaceDolbyVisionInfo;

.field public mDtsMs:J

.field public mPtsMs:J

.field public mSize:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method
