.class public Lcom/tencent/thumbplayer/api/richmedia/TPRichMediaRequestExtraInfo;
.super Ljava/lang/Object;


# static fields
.field public static final TP_RICH_MEDIA_ACT_ON_OPTION_ACCOMPANY_AUDIO_CALLBACK:I = 0x2

.field public static final TP_RICH_MEDIA_ACT_ON_OPTION_ACCOMPANY_VIDEO_CALLBACK:I = 0x1

.field public static final TP_RICH_MEDIA_ACT_ON_OPTION_DIRECT_CALLBACK:I


# instance fields
.field private mActOnOption:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput v0, p0, Lcom/tencent/thumbplayer/api/richmedia/TPRichMediaRequestExtraInfo;->mActOnOption:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public getActOnOption()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "ots@~o y@~~f~~ @ @mbr~~o@~f@~ ~@~@ Mu@i~ ~. d  lKt@~/b~ b@1 oSc4 @-s~o o~~~@ v~@l  ~ai/@@@n ~@@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget v0, p0, Lcom/tencent/thumbplayer/api/richmedia/TPRichMediaRequestExtraInfo;->mActOnOption:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public setActOnOption(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/thumbplayer/api/richmedia/TPRichMediaRequestExtraInfo;->mActOnOption:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method
