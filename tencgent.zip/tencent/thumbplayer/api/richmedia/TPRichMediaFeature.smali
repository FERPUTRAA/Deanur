.class public Lcom/tencent/thumbplayer/api/richmedia/TPRichMediaFeature;
.super Ljava/lang/Object;


# instance fields
.field private final mBinding:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final mFeatureType:Ljava/lang/String;

.field private final mIsSelected:Z


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/core/richmedia/TPNativeRichMediaFeature;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/core/richmedia/TPNativeRichMediaFeature;->getFeatureType()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/richmedia/TPRichMediaFeature;->mFeatureType:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/core/richmedia/TPNativeRichMediaFeature;->getBinding()[Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/richmedia/TPRichMediaFeature;->mBinding:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/core/richmedia/TPNativeRichMediaFeature;->isSelected()Z

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-boolean p1, p0, Lcom/tencent/thumbplayer/api/richmedia/TPRichMediaFeature;->mIsSelected:Z

    return-void
.end method


# virtual methods
.method public getBinding()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~us @t b~co~S~lao~@/~ ~- @~~Koo~o~~t @@bs @  ~1lr~.@~yi~/~@ o@ b~@n@@ @ ~i  v~~4@@ d@M~@ @@fm i@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/richmedia/TPRichMediaFeature;->mBinding:Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public getFeatureType()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/richmedia/TPRichMediaFeature;->mFeatureType:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public isSelected()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/api/richmedia/TPRichMediaFeature;->mIsSelected:Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method
