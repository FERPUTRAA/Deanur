.class public Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/api/TPVideoInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Builder"
.end annotation


# instance fields
.field private definition:Ljava/lang/String;

.field private downloadParamList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;",
            ">;"
        }
    .end annotation
.end field

.field private fileID:Ljava/lang/String;

.field private height:J

.field private videoCodecId:I
    .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_VIDEO_CODEC_TYPE;
    .end annotation
.end field

.field private width:J


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic access$000(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;)J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  s~ ~@y ~@ds@t~@~n/4@aim  o~@@v~@ib~o @~/ b~o1@r @~~   @~~@~ @.-@@~i @M@ c~ooKou~ ~ll @@~ff~Sb~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->width:J

    const/4 v2, 0x1

    const/4 v2, 0x5

    return-wide v0
.end method

.method static synthetic access$100(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;)J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->height:J

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-wide v0
.end method

.method static synthetic access$200(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;)I
    .locals 2

    const/4 v1, 0x4

    iget p0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->videoCodecId:I

    const/4 v0, 0x7

    or-int/2addr v1, v0

    return p0
.end method

.method static synthetic access$300(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;)Ljava/lang/String;
    .locals 2

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->fileID:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic access$400(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;)Ljava/lang/String;
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->definition:Ljava/lang/String;

    const/4 v0, 0x2

    move v1, v0

    return-object p0
.end method

.method static synthetic access$500(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;)Ljava/util/ArrayList;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->downloadParamList:Ljava/util/ArrayList;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p0
.end method


# virtual methods
.method public build()Lcom/tencent/thumbplayer/api/TPVideoInfo;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/api/TPVideoInfo;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {v0, p0, v1}, Lcom/tencent/thumbplayer/api/TPVideoInfo;-><init>(Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;Lcom/tencent/thumbplayer/api/TPVideoInfo$1;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object v0
.end method

.method public definition(Ljava/lang/String;)Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->definition:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p0
.end method

.method public downloadParam(Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;)Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->downloadParamList:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/utils/b;->a(Ljava/util/Collection;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->downloadParamList:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->downloadParamList:Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->downloadParamList:Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x1

    return-object p0
.end method

.method public downloadParamList(Ljava/util/ArrayList;)Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;",
            ">;)",
            "Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->downloadParamList:Ljava/util/ArrayList;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p0
.end method

.method public fileId(Ljava/lang/String;)Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;
    .locals 2

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->fileID:Ljava/lang/String;

    return-object p0
.end method

.method public size(JJ)Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-wide p1, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->width:J

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-wide p3, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->height:J

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p0
.end method

.method public videoCodecId(I)Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;
    .locals 2
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_VIDEO_CODEC_TYPE;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPVideoInfo$Builder;->videoCodecId:I

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method
