.class final Lcom/tencent/thumbplayer/api/TPPlayerMgr$2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/api/TPPlayerMgr;->initAsyncWithWait()Ljava/util/concurrent/Future;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Boolean;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l~s ~o ~t@Mr@/fi cov~~u@~n@@@d@@@ i S~@~~~ 4~i-~1 foo@~@~@@bKmy /s  o @~ ~o @l. a~bb~t ~@@~ ~ @~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->access$000()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public final bridge synthetic call()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$2;->call()Ljava/lang/Boolean;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method
