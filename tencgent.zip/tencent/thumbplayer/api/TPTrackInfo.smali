.class public Lcom/tencent/thumbplayer/api/TPTrackInfo;
.super Ljava/lang/Object;


# static fields
.field public static final TP_MEDIA_CONTAINER_TYPE_DASH:I = 0x2

.field public static final TP_MEDIA_CONTAINER_TYPE_HLS:I = 0x1

.field public static final TP_MEDIA_CONTAINER_TYPE_UNKNOWN:I = 0x0

.field public static final TP_MEDIA_TRACK_TYPE_AUDIO:I = 0x2

.field public static final TP_MEDIA_TRACK_TYPE_SUBTITLE:I = 0x3

.field public static final TP_MEDIA_TRACK_TYPE_UNKNOW:I = 0x0

.field public static final TP_MEDIA_TRACK_TYPE_VIDEO:I = 0x1


# instance fields
.field public containerType:I

.field public dashFormat:Lcom/tencent/thumbplayer/api/TPDashFormat;

.field public hlsTag:Lcom/tencent/thumbplayer/api/TPHlsTag;

.field public isExclusive:Z

.field public isInternal:Z

.field public isSelected:Z

.field public name:Ljava/lang/String;

.field public trackType:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->containerType:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isExclusive:Z

    const/4 v2, 0x0

    const/4 v1, 0x2

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isInternal:Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/api/TPHlsTag;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPHlsTag;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->hlsTag:Lcom/tencent/thumbplayer/api/TPHlsTag;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance v0, Lcom/tencent/thumbplayer/api/TPDashFormat;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPDashFormat;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->dashFormat:Lcom/tencent/thumbplayer/api/TPDashFormat;

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " @s u4rK @oi-@Sbs@@~ n@~~~/  b@l @  v~ ~~o M~o~@~yfb ~@1~~@~.  ~~o@~~~ @t ~@@~@@l@tfo@m ~@daoic/"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz p1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    instance-of v1, p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-nez v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x3

    check-cast p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v2, p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget p1, p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-ne v1, p1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 p1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    return p1

    :cond_1
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    return v0
.end method

.method public getDashFormat()Lcom/tencent/thumbplayer/api/TPDashFormat;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->dashFormat:Lcom/tencent/thumbplayer/api/TPDashFormat;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public getHlsTag()Lcom/tencent/thumbplayer/api/TPHlsTag;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->hlsTag:Lcom/tencent/thumbplayer/api/TPHlsTag;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method public getName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public getTrackType()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method
