.class public Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer$TP_SUBTITLE_FRAME_FORMAT_ID;
    }
.end annotation


# static fields
.field public static final TP_PLAYER_SUBTITLE_OUTPUT_FORMAT_NONE:I = -0x1
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSubtitleFormat;
        value = -0x1
    .end annotation
.end field

.field public static final TP_PLAYER_SUBTITLE_OUTPUT_FORMAT_RGBA:I = 0x1a
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSubtitleFormat;
        value = 0x1a
    .end annotation
.end field


# instance fields
.field public data:[[B

.field public dstHeight:I

.field public dstWidth:I

.field public flags:I

.field public format:I

.field public lineSize:[I

.field public ptsMs:J

.field public rotation:I

.field public srcHeight:I

.field public srcWidth:I

.field public trackID:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public getData()[[B
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s~@Sobdi~~ @ ~o@ ~~~@~ /b u ~ ~io~ rKyt~ ~@M@m~1o@~@lb@t flis~f@-o .a@@@@~@  @o ~~c@/ v n 4@~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->data:[[B

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public getDstHeight()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->dstHeight:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public getDstWidth()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->dstWidth:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public getFlags()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->flags:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public getFormat()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->format:I

    const/4 v1, 0x3

    move v2, v1

    return v0
.end method

.method public getLineSize()[I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->lineSize:[I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public getPtsMs()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->ptsMs:J

    const/4 v3, 0x6

    return-wide v0
.end method

.method public getRotation()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->rotation:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public getSrcHeight()I
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->srcHeight:I

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public getSrcWidth()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->srcWidth:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public getTrackID()I
    .locals 3

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->trackID:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method
