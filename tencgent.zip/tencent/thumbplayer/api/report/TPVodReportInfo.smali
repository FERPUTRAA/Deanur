.class public Lcom/tencent/thumbplayer/api/report/TPVodReportInfo;
.super Lcom/tencent/thumbplayer/api/report/TPDefaultReportInfo;


# instance fields
.field public bizId:I

.field public clipCount:I

.field public currentPlayState:I

.field public hasSubtitles:Z

.field public optimizedPlay:I

.field public videoStatus:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/thumbplayer/api/report/TPDefaultReportInfo;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public getPlayType()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "a~s~ ~t@@@doi/~@v M~~~@~~ @/ o@r .s~@~ @~K@of1l~ub~ oi@c l~@@o4m@o~b t@@ b~~@~f ~~iy @~n -  S@ @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method
