.class public Lcom/tencent/thumbplayer/api/report/TPLiveReportInfo;
.super Lcom/tencent/thumbplayer/api/report/TPDefaultReportInfo;


# instance fields
.field public adPlayLength:I

.field public cdnServer:Ljava/lang/String;

.field public contentId:I

.field public isLookBack:Z

.field public isUserPay:Z

.field public liveDelay:I

.field public liveType:I

.field public playTime:I

.field public programId:I

.field public streamId:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/api/report/TPDefaultReportInfo;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public getPlayType()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @sut i@ llr @c @o ~~d@@~ ~to~@~o~@~b@.nm ~i~  1~K@ 4~v ~~ b@ o@ya~~@@ S~bf~foo@ @~@@s/ ~@i~M-@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method
