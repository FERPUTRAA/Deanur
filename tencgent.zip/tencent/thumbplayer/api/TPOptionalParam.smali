.class public Lcom/tencent/thumbplayer/api/TPOptionalParam;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;,
        Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;,
        Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;,
        Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;,
        Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;,
        Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;,
        Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;
    }
.end annotation


# static fields
.field public static final TP_OPTIONAL_PARAM_TYPE_BOOLEAN:I = 0x1

.field public static final TP_OPTIONAL_PARAM_TYPE_FLOAT:I = 0x6

.field public static final TP_OPTIONAL_PARAM_TYPE_LONG:I = 0x2

.field public static final TP_OPTIONAL_PARAM_TYPE_OBJECT:I = 0x7

.field public static final TP_OPTIONAL_PARAM_TYPE_QUEUE_INT:I = 0x4

.field public static final TP_OPTIONAL_PARAM_TYPE_QUEUE_STRING:I = 0x5

.field public static final TP_OPTIONAL_PARAM_TYPE_STRING:I = 0x3

.field public static final TP_OPTIONAL_PARAM_TYPE_UNKNOWN:I = -0x1


# instance fields
.field private key:I
    .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
    .end annotation
.end field

.field private paramBoolean:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;

.field private paramFloat:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;

.field private paramLong:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

.field private paramObject:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;

.field private paramQueueInt:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;

.field private paramQueueString:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;

.field private paramString:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;

.field private paramType:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, -0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramType:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public buildBoolean(IZ)Lcom/tencent/thumbplayer/api/TPOptionalParam;
    .locals 3
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramType:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramBoolean:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;

    const/4 v2, 0x1

    const/4 v1, 0x4

    iput-boolean p2, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;->value:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p0
.end method

.method public buildFloat(IF)Lcom/tencent/thumbplayer/api/TPOptionalParam;
    .locals 3
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x6

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramType:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramFloat:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput p2, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;->value:F

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method public buildFloat(IFFF)Lcom/tencent/thumbplayer/api/TPOptionalParam;
    .locals 3
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x6

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramType:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramFloat:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput p2, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;->value:F

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput p3, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;->param1:F

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput p4, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;->param2:F

    const/4 v2, 0x1

    return-object p0
.end method

.method public buildLong(IJ)Lcom/tencent/thumbplayer/api/TPOptionalParam;
    .locals 3
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x2

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramType:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v1, 0x5

    move v2, v1

    new-instance p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;-><init>()V

    const/4 v1, 0x7

    or-int/2addr v2, v1

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramLong:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-wide p2, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0
.end method

.method public buildLong(IJJJ)Lcom/tencent/thumbplayer/api/TPOptionalParam;
    .locals 3
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramType:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramLong:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-wide p2, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-wide p4, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->param1:J

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-wide p6, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->param2:J

    const/4 v2, 0x3

    const/4 v1, 0x7

    return-object p0
.end method

.method public buildObject(ILjava/lang/Object;)Lcom/tencent/thumbplayer/api/TPOptionalParam;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x7

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramType:I

    const/4 v2, 0x1

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramObject:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p2, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;->objectValue:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0
.end method

.method public buildQueueInt(I[I)Lcom/tencent/thumbplayer/api/TPOptionalParam;
    .locals 3
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x4

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramType:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramQueueInt:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object p2, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;->queueValue:[I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p0
.end method

.method public buildQueueString(I[Ljava/lang/String;)Lcom/tencent/thumbplayer/api/TPOptionalParam;
    .locals 3
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x5

    const/4 v2, 0x5

    const/4 v1, 0x7

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramType:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;

    const/4 v2, 0x7

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramQueueString:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-object p2, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;->queueValue:[Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p0
.end method

.method public buildString(ILjava/lang/String;)Lcom/tencent/thumbplayer/api/TPOptionalParam;
    .locals 3
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramType:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v1, 0x6

    move v2, v1

    new-instance p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramString:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object p2, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;->value:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p0
.end method

.method public buildString(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/thumbplayer/api/TPOptionalParam;
    .locals 3
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramType:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramString:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;

    const/4 v2, 0x3

    const/4 v1, 0x5

    iput-object p2, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;->value:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x0

    iput-object p3, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;->param1:Ljava/lang/String;

    iput-object p4, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;->param2:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method

.method public getKey()I
    .locals 3
    .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public getParamBoolean()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramBoolean:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public getParamFloat()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramFloat:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramLong:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public getParamObject()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramObject:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    return-object v0
.end method

.method public getParamQueueInt()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramQueueInt:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public getParamQueueString()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramQueueString:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;

    const/4 v1, 0x5

    or-int/2addr v2, v1

    return-object v0
.end method

.method public getParamString()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramString:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public getParamType()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramType:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 11

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    move v10, v9

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramType:I

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    const-string v2, ", "

    const-string v2, ", "

    const/4 v10, 0x1

    const-string v2, ", "

    const-string v2, ", "

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    const/4 v3, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    const-string v4, "eeskl,t::npsyy "

    const-string/jumbo v4, "yesy:p g,etln:k"

    const/4 v10, 0x6

    const-string/jumbo v4, "gelmneyk:o: y,p"

    const-string/jumbo v4, "type:long, key:"

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    const-string/jumbo v5, "mp2,oa:ra"

    const-string v5, ",:ammpr2a"

    const/4 v10, 0x2

    const-string v5, "2mprab,a "

    const-string v5, ", param2:"

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    const-string v6, ",mapa uo1"

    const-string v6, ":,apoma 1"

    const/4 v10, 0x5

    const-string/jumbo v6, "m, 1arap:"

    const-string v6, ", param1:"

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    const-string/jumbo v7, "qvau:e,l"

    const-string v7, ":ul,ebva"

    const/4 v10, 0x4

    const-string v7, ": slaeu,"

    const-string v7, ", value:"

    const/4 v10, 0x6

    const/4 v9, 0x7

    const-string/jumbo v8, "u mmn,e/n"

    const-string v8, "en,amnu /"

    const/4 v10, 0x4

    const-string v8, ":nmeon/, "

    const-string v8, ", \nname:"

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    packed-switch v1, :pswitch_data_0

    const/4 v9, 0x6

    shl-int/2addr v10, v9

    const-string/jumbo v1, "nky:upnpwetn"

    const/4 v10, 0x0

    const-string/jumbo v1, "euknybnn:tpw"

    const-string/jumbo v1, "type:unknown"

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    goto/16 :goto_2

    :pswitch_0
    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-string/jumbo v1, "t,:eetubkq:c yypj"

    const-string/jumbo v1, "ey jbeptqce,::ytk"

    const/4 v10, 0x4

    const-string v1, ":yyttcbp kej,o:ep"

    const-string/jumbo v1, "type:object, key:"

    const/4 v10, 0x3

    const/4 v9, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x2

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x1

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getOptionalIdName(I)Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x6

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramObject:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object v1, v1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;->objectValue:Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    goto/16 :goto_3

    :pswitch_1
    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x2

    const-string/jumbo v1, "l yyste,q:kfatpo"

    const-string v1, ":fsyleatp,:ko yt"

    const/4 v10, 0x5

    const-string v1, "::stetfpykyea,ol"

    const-string/jumbo v1, "type:float, key:"

    const/4 v9, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v9, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getOptionalIdName(I)Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramFloat:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget v1, v1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;->value:F

    const/4 v10, 0x7

    const/4 v9, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramFloat:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    iget v1, v1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;->param1:F

    const/4 v10, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x4

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramFloat:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    iget v1, v1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;->param2:F

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    move v10, v9

    goto/16 :goto_3

    :pswitch_2
    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    const-string v1, "eemmtt trn_i:siy:pu,ygn"

    const-string/jumbo v1, "p emi_,ir:gttnntey:uyks"

    const/4 v10, 0x2

    const-string v1, ":puto: e_stnkiy,etrngiq"

    const-string/jumbo v1, "type:quint_string, key:"

    const/4 v10, 0x0

    const/4 v9, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getOptionalIdName(I)Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramQueueString:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x4

    iget-object v1, v1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;->queueValue:[Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    if-eqz v1, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    array-length v4, v1

    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    if-ge v3, v4, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    aget-object v5, v1, v3

    const/4 v10, 0x7

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    goto :goto_0

    :pswitch_3
    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    const-string/jumbo v1, "q:piibyeten_t,tk :on"

    const-string v1, ",_tpoqtenkiinyu :te:"

    const/4 v10, 0x0

    const-string v1, "::_ttpuknyu q,ieyeit"

    const-string/jumbo v1, "type:quint_int, key:"

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v9, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getOptionalIdName(I)Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramQueueInt:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget-object v1, v1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;->queueValue:[I

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-eqz v1, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x3

    array-length v4, v1

    :goto_1
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-ge v3, v4, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    aget v5, v1, v3

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    goto :goto_1

    :pswitch_4
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    const-string/jumbo v1, "rbk:geeptspy,yi:n"

    const-string/jumbo v1, "ky,erbgesi ptny::"

    const/4 v10, 0x2

    const-string v1, "eriyy stqt:pgk,n:"

    const-string/jumbo v1, "type:string, key:"

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v9, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getOptionalIdName(I)Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramString:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    iget-object v1, v1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;->value:Ljava/lang/String;

    const/4 v10, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramString:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    iget-object v1, v1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;->param1:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramString:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget-object v1, v1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;->param2:Ljava/lang/String;

    :goto_2
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    goto/16 :goto_3

    :pswitch_5
    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v10, 0x7

    const/4 v9, 0x6

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getOptionalIdName(I)Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramLong:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x3

    iget-wide v1, v1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramLong:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    iget-wide v1, v1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->param1:J

    const/4 v10, 0x5

    const/4 v9, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramLong:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget-wide v1, v1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->param2:J

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    goto :goto_3

    :pswitch_6
    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->key:I

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getOptionalIdName(I)Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPOptionalParam;->paramBoolean:Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    iget-boolean v1, v1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;->value:Z

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    :cond_0
    :goto_3
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
