.class public interface abstract Lcom/tencent/thumbplayer/api/ITPModuleLoader;
.super Ljava/lang/Object;


# virtual methods
.method public abstract loadLibrary(Ljava/lang/String;Ljava/lang/String;)V
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method
