.class public Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/api/TPJitterBufferConfig$Builder;
    }
.end annotation


# instance fields
.field private mAdjustIntervalThresholdMs:J

.field private mFrozenThresholdMs:J

.field private mMaxIncreaseDurationMs:J

.field private mMinDecreaseDurationMs:J

.field private mPerDecreaseDurationMs:J

.field private mPerIncreaseDurationMs:J


# direct methods
.method protected constructor <init>(JJJJJJ)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-wide p1, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->mMinDecreaseDurationMs:J

    const/4 v1, 0x2

    iput-wide p3, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->mMaxIncreaseDurationMs:J

    const/4 v1, 0x4

    iput-wide p5, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->mPerIncreaseDurationMs:J

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-wide p7, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->mPerDecreaseDurationMs:J

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-wide p9, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->mAdjustIntervalThresholdMs:J

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-wide p11, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->mFrozenThresholdMs:J

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public getAdjustIntervalThresholdMs()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  s ob~d/ m@n4 @ustc@@iS~~1@ly~o@@@ /~~~i-f oo~~ @~@@~Mar~   @~@~   K@v@@~t~o@ i~o~ @bf@b@~l~~~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->mAdjustIntervalThresholdMs:J

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-wide v0
.end method

.method public getFrozenThresholdMs()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->mFrozenThresholdMs:J

    const/4 v3, 0x3

    const/4 v2, 0x0

    return-wide v0
.end method

.method public getMaxIncreaseDurationMs()J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->mMaxIncreaseDurationMs:J

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-wide v0
.end method

.method public getMinDecreaseDurationMs()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->mMinDecreaseDurationMs:J

    const/4 v3, 0x4

    return-wide v0
.end method

.method public getPerDecreaseDurationMs()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->mPerDecreaseDurationMs:J

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-wide v0
.end method

.method public getPerIncreaseDurationMs()J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->mPerIncreaseDurationMs:J

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-wide v0
.end method
