.class public Lcom/tencent/thumbplayer/api/proxy/TPP2PProxyFactory;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public static createPreloadManager(Landroid/content/Context;I)Lcom/tencent/thumbplayer/api/proxy/ITPPreloadProxy;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "bdso~ @o@Km .~@to~~-oo/~~ i /~~@  s@@~@~if@~ ~~~@ ~ua@ @o@r@y~ @ lft@@li@S@1@M~ b~~ bnv~  ~@ 4c~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/c/g;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {v0, p0, p1}, Lcom/tencent/thumbplayer/c/g;-><init>(Landroid/content/Context;I)V

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method
