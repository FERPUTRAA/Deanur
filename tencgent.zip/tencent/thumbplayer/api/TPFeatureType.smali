.class public Lcom/tencent/thumbplayer/api/TPFeatureType;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/api/TPFeatureType$TP_FEATURE_TYPE;
    }
.end annotation


# static fields
.field public static final TP_FEATURE_NONE:I = -0x1
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapFeatureType;
        value = -0x1
    .end annotation
.end field

.field public static final TP_SUBTITLE_RGBA_OUTPUT:I
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapFeatureType;
        value = 0x0
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method
