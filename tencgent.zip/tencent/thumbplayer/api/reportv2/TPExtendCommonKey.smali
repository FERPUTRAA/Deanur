.class public Lcom/tencent/thumbplayer/api/reportv2/TPExtendCommonKey;
.super Ljava/lang/Object;


# static fields
.field public static final APP_GUID:Ljava/lang/String; = "reserved_ext_guid"

.field public static final LIVE_PERIOD_CDN_DELAY_MS:Ljava/lang/String; = "reserved_ext_livecdndelayms"

.field public static final LIVE_PERIOD_ENCODE_DELAY_MS:Ljava/lang/String; = "reserved_ext_liveencodedelayms"

.field public static final LIVE_PERIOD_TOTAL_DELAY_MS:Ljava/lang/String; = "reserved_ext_livetotaldelayms"

.field public static final SCENE_ID:Ljava/lang/String; = "reserved_ext_scenesid"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method
