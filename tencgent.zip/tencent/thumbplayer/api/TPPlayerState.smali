.class public Lcom/tencent/thumbplayer/api/TPPlayerState;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/api/TPPlayerState$STATE;
    }
.end annotation


# static fields
.field public static final COMPLETE:I = 0x7

.field public static final ERROR:I = 0xa

.field public static final IDLE:I = 0x1

.field public static final INDEX:I = 0x0

.field public static final INITIALIZED:I = 0x2

.field private static final NS_STATES:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final PAUSE:I = 0x6

.field public static final PREPARED:I = 0x4

.field public static final PREPARING:I = 0x3

.field public static final RELEASED:I = 0xb

.field public static final START:I = 0x5

.field public static final STOPPED:I = 0x9

.field public static final STOPPING:I = 0x8


# instance fields
.field private mCurState:I

.field private mInnerPlayState:I

.field private mLastState:I

.field private mPreState:I

.field private mStateChangeListener:Lcom/tencent/thumbplayer/adapter/a/c$k;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v0, Landroid/util/SparseArray;

    const/4 v4, 0x7

    const/4 v3, 0x0

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    sput-object v0, Lcom/tencent/thumbplayer/api/TPPlayerState;->NS_STATES:Landroid/util/SparseArray;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v2, "LEID"

    const-string v2, "LEDI"

    const/4 v4, 0x7

    const-string v2, "IELD"

    const-string v2, "IDLE"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string v2, "IDsINETsILA"

    const-string v2, "AEsTZIINDIL"

    const/4 v4, 0x6

    const-string v2, "LIEmNITADIZ"

    const-string v2, "INITIALIZED"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v4, 0x1

    move v3, v1

    move v3, v1

    const/4 v4, 0x0

    const-string v2, "RmIGoPEAN"

    const-string v2, "INRmEGRAP"

    const-string v2, "APRERbGNP"

    const-string v2, "PREPARING"

    const/4 v4, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x4

    move v4, v1

    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo v2, "oARPERuD"

    const-string v2, "PRREoDAE"

    const-string v2, "EREPRDPp"

    const-string v2, "PREPARED"

    const/4 v3, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v1, 0x5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string v2, "AbTqS"

    const-string v2, "bATTS"

    const/4 v4, 0x2

    const-string v2, "TAsRT"

    const-string v2, "START"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v1, 0x6

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string/jumbo v2, "uUSmE"

    const-string v2, "AuSEU"

    const/4 v4, 0x0

    const-string v2, "PAUSE"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v1, 0x7

    const/4 v4, 0x1

    const-string/jumbo v2, "pEPToCEO"

    const-string v2, "TCMEOPEp"

    const/4 v4, 0x2

    const-string v2, "EEOTLbCP"

    const-string v2, "COMPLETE"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/16 v1, 0x8

    const/4 v4, 0x1

    const/4 v3, 0x5

    const-string v2, "PqPGNOuI"

    const-string/jumbo v2, "qSPPIONG"

    const/4 v4, 0x4

    const-string v2, "PSITPNGp"

    const-string v2, "STOPPING"

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v4, 0x3

    const/16 v1, 0x9

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v2, "sqSETPD"

    const-string v2, "EPsPTSD"

    const/4 v4, 0x4

    const-string v2, "TEsPDOP"

    const-string v2, "STOPPED"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/16 v1, 0xa

    const/4 v4, 0x3

    const-string/jumbo v2, "mREmR"

    const-string v2, "REOmR"

    const/4 v4, 0x7

    const-string v2, "ROERo"

    const-string v2, "ERROR"

    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/16 v1, 0xb

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string v2, "DELSoEAE"

    const/4 v4, 0x1

    const-string v2, "ELSDEbER"

    const-string v2, "RELEASED"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mCurState:I

    const/4 v2, 0x1

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mPreState:I

    const/4 v2, 0x4

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mLastState:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mInnerPlayState:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public declared-synchronized changeState(I)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " r@s/tu @@~@K@~@~l@@~i@.~4o@  d~~bob @1oov u~~ o @y a t b~~ @i~  f~~n@-~~~@loi~@~M@S~~/m~@ @c@ f"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mCurState:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eq v0, p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mPreState:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mCurState:I

    const/4 v2, 0x1

    move v3, v2

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mStateChangeListener:Lcom/tencent/thumbplayer/adapter/a/c$k;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {v1, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/c$k;->b(II)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    monitor-exit p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    monitor-exit p0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    throw p1
.end method

.method public declared-synchronized innerPlayState()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mInnerPlayState:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x6

    return v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    throw v0
.end method

.method public declared-synchronized is(I)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mCurState:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v2, 0x3

    if-ne v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v1, 0x3

    move v2, v1

    throw p1
.end method

.method public declared-synchronized lastState()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mLastState:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    throw v0
.end method

.method public declared-synchronized preState()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mPreState:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    throw v0
.end method

.method public declared-synchronized setInnerPlayStateState(I)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mInnerPlayState:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eq v0, p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mInnerPlayState:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    throw p1
.end method

.method public declared-synchronized setLastState(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mLastState:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eq v0, p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mLastState:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    throw p1
.end method

.method public setOnPlayerStateChangeListener(Lcom/tencent/thumbplayer/adapter/a/c$k;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mStateChangeListener:Lcom/tencent/thumbplayer/adapter/a/c$k;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public declared-synchronized state()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mCurState:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    monitor-exit p0

    return v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    throw v0
.end method

.method public declared-synchronized toString()Ljava/lang/String;
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x2

    sget-object v0, Lcom/tencent/thumbplayer/api/TPPlayerState;->NS_STATES:Landroid/util/SparseArray;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mCurState:I

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    check-cast v1, Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget v2, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mPreState:I

    const/4 v7, 0x7

    invoke-virtual {v0, v2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    check-cast v2, Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget v3, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mLastState:I

    const/4 v6, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v0, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    check-cast v3, Ljava/lang/String;

    const/4 v7, 0x6

    iget v4, p0, Lcom/tencent/thumbplayer/api/TPPlayerState;->mInnerPlayState:I

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0, v4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string v5, "[ubtec p: ar "

    const-string/jumbo v5, "eua rb [:cs t"

    const/4 v7, 0x0

    const-string v5, ":rst e[cq  ut"

    const-string/jumbo v5, "state[ cur : "

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string v1, ": ser p ,"

    const-string/jumbo v1, "r: p, u e"

    const/4 v7, 0x0

    const-string v1, "  pme  r,"

    const-string v1, " , pre : "

    const/4 v7, 0x5

    const/4 v6, 0x4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-string v1, "as: ot p, "

    const-string v1, " , a  tp:s"

    const/4 v7, 0x1

    const-string v1, ", sl:ba t "

    const-string v1, " , last : "

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-string/jumbo v1, "pnl :,ur iayqe  "

    const-string v1, " ea:  ,lqin r yp"

    const/4 v7, 0x5

    const-string v1, "e  a n,p:y pri l"

    const-string v1, " , inner play : "

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string v0, " ]"

    const-string v0, " ]"

    const/4 v7, 0x6

    const-string v0, "] "

    const-string v0, " ]"

    const/4 v6, 0x1

    move v7, v6

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    monitor-exit p0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    monitor-exit p0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    throw v0
.end method
