.class final Lcom/tencent/thumbplayer/api/TPPlayerMgr$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/api/TPPlayerMgr;->initAsyncWithoutWait()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "1 sb@ i@~.~~@m~t @ o @  ~ @r~~-ii~~l~~~ ~o~ /~y@@@@ @@4~tM@@~cv ua/f~~@@  b@ @~ osoS bfonK~o@~@l"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/utils/d;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-direct {v0}, Lcom/tencent/thumbplayer/utils/d;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/d;->a()V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->init()V

    const/4 v5, 0x3

    const/4 v5, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string/jumbo v2, "hisKtnia,uitcpiiK Aa WyM SyavWnsotntItee:iit, n De  tiistm"

    const/4 v6, 0x2

    const-string v2, "Init SDK, initAsyncWithoutWait  nativeKeyMap init, times: "

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/d;->c()J

    move-result-wide v2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v2, "TPymTaMmbTPrmlaga[yjPrheuPl.]ve"

    const-string/jumbo v2, "gTrmlrmyvaerbPPP]eTl.T[PMaauyhj"

    const/4 v6, 0x7

    const-string v2, "TPThumbPlayer[TPPlayerMgr.java]"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v2, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/utils/i;->a()Lcom/tencent/thumbplayer/utils/i;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->access$100()Landroid/content/Context;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v1, v3}, Lcom/tencent/thumbplayer/utils/i;->a(Landroid/content/Context;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v1, Lcom/tencent/thumbplayer/common/a/c;

    const/4 v5, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {v1}, Lcom/tencent/thumbplayer/common/a/c;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/common/a/c;->a()V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string/jumbo v3, "ncinoK, t hoslttASaamsiiIlDit yt:WenuWto i"

    const-string/jumbo v3, "n   otne,aWcahloiytWKt sD:iStminu lsiAiItt"

    const/4 v6, 0x3

    const-string/jumbo v3, "uoh:ybsKtttiinWsice, lSa  ttWiamnnIltiDi  "

    const-string v3, "Init SDK, initAsyncWithoutWait all times: "

    const/4 v6, 0x1

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/d;->d()J

    move-result-wide v3

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v1, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    shr-int/2addr v6, v5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v2, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    return-void
.end method
