.class public Lcom/tencent/thumbplayer/api/TPPropertyID;
.super Ljava/lang/Object;


# static fields
.field public static final LONG_AUDIO_BIT_RATE:I = 0x65
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0x65
    .end annotation
.end field

.field public static final LONG_AUDIO_CHANNEL_NUM:I = 0x67
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0x67
    .end annotation
.end field

.field public static final LONG_AUDIO_CODEC_ID:I = 0x64
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0x64
    .end annotation
.end field

.field public static final LONG_AUDIO_PROFILE:I = 0x66
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0x66
    .end annotation
.end field

.field public static final LONG_AUDIO_SESSION_ID:I = 0x68
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0x68
    .end annotation
.end field

.field public static final LONG_PLAYER_ADDRESS:I = 0xcf
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0x1
    .end annotation
.end field

.field public static final LONG_SUBTITLE_CODEC_ID:I = 0x12d
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0x12d
    .end annotation
.end field

.field public static final LONG_VIDEO_BIT_RATE:I = 0xca
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0xca
    .end annotation
.end field

.field public static final LONG_VIDEO_CODEC_ID:I = 0xc9
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0xc9
    .end annotation
.end field

.field public static final LONG_VIDEO_COLOR_SPACE:I = 0xd2
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0xd2
    .end annotation
.end field

.field public static final LONG_VIDEO_DECODE_FRAME_COUNT:I = 0xd0
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0xd0
    .end annotation
.end field

.field public static final LONG_VIDEO_FRAME_RATE:I = 0xce
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0xce
    .end annotation
.end field

.field public static final LONG_VIDEO_LEVEL:I = 0xcc
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0xcc
    .end annotation
.end field

.field public static final LONG_VIDEO_PROFILE:I = 0xcb
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0xcb
    .end annotation
.end field

.field public static final LONG_VIDEO_RENDER_FRAME_COUNT:I = 0xd1
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0xd1
    .end annotation
.end field

.field public static final LONG_VIDEO_ROTATION:I = 0xcd
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0xcd
    .end annotation
.end field

.field public static final STRING_MEDIA_INFO:I
    .annotation runtime Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;
        value = 0x0
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method
