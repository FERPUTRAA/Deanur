.class public Lcom/tencent/thumbplayer/api/TPHlsTag;
.super Ljava/lang/Object;


# instance fields
.field public bandwidth:J

.field public codecs:Ljava/lang/String;

.field public framerate:F

.field public groupId:Ljava/lang/String;

.field public language:Ljava/lang/String;

.field public name:Ljava/lang/String;

.field public resolution:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/tencent/thumbplayer/api/TPHlsTag;->bandwidth:J

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/high16 v0, -0x40800000    # -1.0f

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPHlsTag;->framerate:F

    const/4 v3, 0x7

    return-void
.end method


# virtual methods
.method public getBandwidth()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "bms @@b.lv s~~~@a~t~@f@   ~ @t@ @ ~-oo~ l@ ~K ro@~i~~ d@@@@Mi@i4o @~ buo@S@~ o ~~f@c~//1~~y~@~ n"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPHlsTag;->bandwidth:J

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-wide v0
.end method

.method public getCodecs()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPHlsTag;->codecs:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public getFramerate()F
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPHlsTag;->framerate:F

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public getGroupId()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPHlsTag;->groupId:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public getLanguage()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPHlsTag;->language:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public getName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPHlsTag;->name:Ljava/lang/String;

    const/4 v2, 0x6

    return-object v0
.end method

.method public getResolution()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPHlsTag;->resolution:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method
