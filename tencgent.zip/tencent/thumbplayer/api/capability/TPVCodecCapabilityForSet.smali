.class public Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;
.super Ljava/lang/Object;


# instance fields
.field private level:I

.field private lowerboundHeight:I

.field private lowerboundWidth:I

.field private profile:I

.field private upperboundHeight:I

.field private upperboundWidth:I


# direct methods
.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    shl-int/2addr v1, v0

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->upperboundWidth:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p2, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->upperboundHeight:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->lowerboundWidth:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->lowerboundHeight:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    const/4 p1, -0x1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->profile:I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->level:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(III)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->upperboundWidth:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p2, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->upperboundHeight:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    iput p3, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->profile:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->lowerboundWidth:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->lowerboundHeight:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 p1, -0x1

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->level:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>(IIIIII)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->upperboundWidth:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p2, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->upperboundHeight:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p3, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->lowerboundWidth:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput p4, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->lowerboundHeight:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p5, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->profile:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p6, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->level:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public getLevel()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "lbsi@oo~oo~~u c@~@i/~dS@M~ of~ @~~ ~@~~@ mb@a~@rv1~~b@ n@  ~@ s i~l  @  - @@ 4@K~~y@@@ ~.~t@f~t/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->level:I

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public getLowerboundHeight()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->lowerboundHeight:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public getLowerboundWidth()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->lowerboundWidth:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public getProfile()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->profile:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method public getUpperboundHeight()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->upperboundHeight:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public getUpperboundWidth()I
    .locals 3

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->upperboundWidth:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method
