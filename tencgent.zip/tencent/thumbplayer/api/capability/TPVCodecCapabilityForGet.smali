.class public Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;
.super Ljava/lang/Object;


# static fields
.field private static final MAX_FRAME_RATE_FOR_LUMA_SAMPLES_DEFAULT:I = -0x1

.field private static final MAX_LEVEL_DEFAULT:I = -0x1

.field private static final MAX_LUMA_SAMPLES_DEFAULT:I = -0x1

.field private static final MAX_PROFILE_DEFAULT:I = -0x1

.field public static final mDefaultVCodecCapability:Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;


# instance fields
.field private maxFramerateFormaxLumaSamples:I

.field private maxLevel:I

.field private maxLumaSamples:I

.field private maxProfile:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance v0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    invoke-direct {v0, v1, v1, v1, v1}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;-><init>(IIII)V

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    sput-object v0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->mDefaultVCodecCapability:Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public constructor <init>(IIII)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->maxLumaSamples:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p2, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->maxProfile:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p3, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->maxLevel:I

    const/4 v1, 0x1

    iput p4, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->maxFramerateFormaxLumaSamples:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public getMaxFramerateFormaxLumaSamples()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s~d ~@c~oa@@ s~~@K@~ob~of~b ~@   /~-b~~iy~~lu@i t@ if4t  ~@@ .v@l Mo@~@n@@@~~@  S~ oo~~ @m/~1r"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->maxFramerateFormaxLumaSamples:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public getMaxLevel()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->maxLevel:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public getMaxLumaSamples()I
    .locals 3

    const/4 v2, 0x0

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->maxLumaSamples:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public getMaxProfile()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->maxProfile:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method
