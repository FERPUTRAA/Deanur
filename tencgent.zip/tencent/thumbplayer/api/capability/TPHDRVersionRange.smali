.class public Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;
.super Ljava/lang/Object;


# instance fields
.field public lowerboundAndroidAPILevel:I

.field public lowerboundPatchVersion:I

.field public lowerboundSystemVersion:I

.field public upperboundAndroidAPILevel:I

.field public upperboundPatchVersion:I

.field public upperboundSystemVersion:I


# direct methods
.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->upperboundAndroidAPILevel:I

    const/4 v0, 0x5

    shr-int/2addr v1, v0

    iput p2, p0, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->lowerboundAndroidAPILevel:I

    const/4 v0, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public constructor <init>(IIII)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->upperboundSystemVersion:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p2, p0, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->lowerboundSystemVersion:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p3, p0, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->upperboundPatchVersion:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p4, p0, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->lowerboundPatchVersion:I

    const/4 v1, 0x3

    return-void
.end method
