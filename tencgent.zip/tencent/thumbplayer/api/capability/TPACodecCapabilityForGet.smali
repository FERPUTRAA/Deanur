.class public Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForGet;
.super Ljava/lang/Object;


# instance fields
.field private maxBitrate:I

.field private maxChannels:I

.field private maxLevel:I

.field private maxProfile:I

.field private maxSamplerate:I


# direct methods
.method public constructor <init>(IIIII)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForGet;->maxSamplerate:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p2, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForGet;->maxChannels:I

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p3, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForGet;->maxBitrate:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput p4, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForGet;->maxProfile:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p5, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForGet;->maxLevel:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public getMaxBitrate()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "f~sy ~~~ i~1K@  ~~oo~ i~ta@not~~  ~@i@/-Mb@r @@d @@@@cb~fv~m  /@~u~@@~sS4~o@~@~~ o o@ ~ll@@  .@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForGet;->maxBitrate:I

    const/4 v2, 0x6

    return v0
.end method

.method public getMaxChannels()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForGet;->maxChannels:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public getMaxLevel()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForGet;->maxLevel:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method public getMaxProfile()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForGet;->maxProfile:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public getMaxSamplerate()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForGet;->maxSamplerate:I

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method
