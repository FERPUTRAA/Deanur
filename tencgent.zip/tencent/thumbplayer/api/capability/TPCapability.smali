.class public Lcom/tencent/thumbplayer/api/capability/TPCapability;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public static addACodecBlacklist(IILcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;)Z
    .locals 12
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_AUDIO_DECODER_TYPE;
        .end annotation
    .end param
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_AUDIO_CODEC_TYPE;
        .end annotation
    .end param

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v10, "@ s  ~@oi@o@@io1~~ ~oo@ l~~@@~~nvbSu f @~t  ~b/4 is@y@~dtr o ~@ al~ f-~.~Mm~b@@ ~~@~K @~ ~@/@@@~"

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x1

    new-instance v9, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-direct {v9}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;-><init>()V

    const/4 v11, 0x5

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getUpperboundSamplerate()I

    move-result v1

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getUpperboundChannels()I

    move-result v2

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getUpperboundBitrate()I

    move-result v3

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getLowerboundSamplerate()I

    move-result v4

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getLowerboundChannels()I

    move-result v5

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getLowerboundBitrate()I

    move-result v6

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getProfileForSet()I

    move-result v7

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getLevelForSet()I

    move-result v8

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual/range {v0 .. v8}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;->set(IIIIIIII)V

    :try_start_0
    const/4 v11, 0x0

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioDecoderType;

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioDecoderType;

    const/4 v11, 0x1

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioDecoderType;

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioDecoderType;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-static {p2, p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p0

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioCodecType;

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioCodecType;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p1

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-static {p0, p1, v9}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->addACodecBlacklist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;)Z

    move-result p0
    :try_end_0
    .catch Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    return p0

    :catch_0
    move-exception p0

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    new-instance p1, Lcom/tencent/thumbplayer/api/TPNativeException;

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-direct {p1, p0}, Lcom/tencent/thumbplayer/api/TPNativeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v11, 0x0

    const/4 v10, 0x0

    throw p1
.end method

.method public static addACodecWhitelist(IILcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;)Z
    .locals 12
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_AUDIO_DECODER_TYPE;
        .end annotation
    .end param
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_AUDIO_CODEC_TYPE;
        .end annotation
    .end param

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    new-instance v9, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-direct {v9}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;-><init>()V

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getUpperboundSamplerate()I

    move-result v1

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getUpperboundChannels()I

    move-result v2

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getUpperboundBitrate()I

    move-result v3

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getLowerboundSamplerate()I

    move-result v4

    const/4 v11, 0x4

    const/4 v10, 0x0

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getLowerboundChannels()I

    move-result v5

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getLowerboundBitrate()I

    move-result v6

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getProfileForSet()I

    move-result v7

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->getLevelForSet()I

    move-result v8

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual/range {v0 .. v8}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;->set(IIIIIIII)V

    :try_start_0
    const/4 v11, 0x3

    const/4 v10, 0x0

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioDecoderType;

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioDecoderType;

    const/4 v11, 0x6

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioDecoderType;

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioDecoderType;

    const/4 v11, 0x5

    invoke-static {p2, p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p0

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x6

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioCodecType;

    const/4 v11, 0x4

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioCodecType;

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioCodecType;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p1

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-static {p0, p1, v9}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->addACodecWhitelist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;)Z

    move-result p0
    :try_end_0
    .catch Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    return p0

    :catch_0
    move-exception p0

    const/4 v11, 0x4

    const/4 v10, 0x5

    new-instance p1, Lcom/tencent/thumbplayer/api/TPNativeException;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-direct {p1, p0}, Lcom/tencent/thumbplayer/api/TPNativeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x6

    throw p1
.end method

.method public static addDRMLevel1Blacklist(I)Z
    .locals 2
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_DRM_TYPE;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->addDRMLevel1Blacklist(I)Z

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return p0
.end method

.method public static addHDRBlackList(ILcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;)Z
    .locals 6
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_HDR_TYPE;
        .end annotation
    .end param

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget v1, p1, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->upperboundSystemVersion:I

    const/4 v5, 0x1

    iget v2, p1, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->lowerboundSystemVersion:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget v3, p1, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->upperboundPatchVersion:I

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget p1, p1, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->lowerboundPatchVersion:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {v0, v1, v2, v3, p1}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapHdrType;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapHdrType;

    const/4 v5, 0x0

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapHdrType;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapHdrType;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {p1, p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {p0, v0}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->addHDRBlackList(ILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;)Z

    move-result p0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    return p0
.end method

.method public static addHDRVideoDecoderTypeWhiteList(IILcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;)Z
    .locals 6
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_HDR_TYPE;
        .end annotation
    .end param
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_VIDEO_DECODER_TYPE;
        .end annotation
    .end param
    .param p2    # Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v5, 0x5

    iget v1, p2, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->upperboundSystemVersion:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget v2, p2, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->lowerboundSystemVersion:I

    iget v3, p2, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->upperboundPatchVersion:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget p2, p2, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->lowerboundPatchVersion:I

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {v0, v1, v2, v3, p2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 p2, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    iput p2, v0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->lowerboundAndroidAPILevel:I

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/16 p2, 0x3e7

    const/4 v5, 0x6

    const/4 v4, 0x6

    iput p2, v0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->upperboundAndroidAPILevel:I

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapHdrType;

    const/4 v5, 0x0

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapHdrType;

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapHdrType;

    const/4 v5, 0x4

    invoke-static {p2, p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const/4 v5, 0x2

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {p0, p1, v0}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->addHDRVideoDecoderTypeWhiteList(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;)Z

    move-result p0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    return p0
.end method

.method public static addHDRWhiteList(ILcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;)Z
    .locals 6
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_HDR_TYPE;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget v1, p1, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->upperboundSystemVersion:I

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget v2, p1, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->lowerboundSystemVersion:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget v3, p1, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->upperboundPatchVersion:I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget p1, p1, Lcom/tencent/thumbplayer/api/capability/TPHDRVersionRange;->lowerboundPatchVersion:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {v0, v1, v2, v3, p1}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapHdrType;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapHdrType;

    const/4 v5, 0x2

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapHdrType;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapHdrType;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p1, p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {p0, v0}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->addHDRWhiteList(ILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;)Z

    move-result p0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    return p0
.end method

.method public static addVCodecBlacklist(IILcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;)Z
    .locals 10
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_VIDEO_DECODER_TYPE;
        .end annotation
    .end param
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_VIDEO_CODEC_TYPE;
        .end annotation
    .end param

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    new-instance v7, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-direct {v7}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->getUpperboundWidth()I

    move-result v1

    const/4 v9, 0x1

    const/4 v8, 0x5

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->getUpperboundHeight()I

    move-result v2

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->getLowerboundWidth()I

    move-result v3

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->getLowerboundHeight()I

    move-result v4

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->getProfile()I

    move-result v5

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->getLevel()I

    move-result v6

    move-object v0, v7

    move-object v0, v7

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual/range {v0 .. v6}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;->set(IIIIII)V

    :try_start_0
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const/4 v9, 0x5

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {p2, p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const/4 v9, 0x7

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const/4 v9, 0x4

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-static {p0, p1, v7}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->addVCodecBlacklist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;)Z

    move-result p0
    :try_end_0
    .catch Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    return p0

    :catch_0
    move-exception p0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    new-instance p1, Lcom/tencent/thumbplayer/api/TPNativeException;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-direct {p1, p0}, Lcom/tencent/thumbplayer/api/TPNativeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v8, 0x4

    const/4 v9, 0x4

    throw p1
.end method

.method public static addVCodecWhitelist(IILcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;)Z
    .locals 10
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_VIDEO_DECODER_TYPE;
        .end annotation
    .end param
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_VIDEO_CODEC_TYPE;
        .end annotation
    .end param

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x3

    new-instance v7, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-direct {v7}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x7

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->getUpperboundWidth()I

    move-result v1

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->getUpperboundHeight()I

    move-result v2

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->getLowerboundWidth()I

    move-result v3

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->getLowerboundHeight()I

    move-result v4

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->getProfile()I

    move-result v5

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForSet;->getLevel()I

    move-result v6

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual/range {v0 .. v6}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;->set(IIIIII)V

    :try_start_0
    const/4 v9, 0x6

    const/4 v8, 0x5

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const/4 v9, 0x7

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-static {p2, p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const/4 v9, 0x7

    const-class p2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const/4 v9, 0x6

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {p0, p1, v7}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->addVCodecWhitelist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;)Z

    move-result p0
    :try_end_0
    .catch Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    return p0

    :catch_0
    move-exception p0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    new-instance p1, Lcom/tencent/thumbplayer/api/TPNativeException;

    const/4 v9, 0x7

    const/4 v8, 0x0

    invoke-direct {p1, p0}, Lcom/tencent/thumbplayer/api/TPNativeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v8, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    throw p1
.end method

.method public static getDRMCapabilities()[I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/a/b/a;->a()[I

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public static getThumbPlayerVCodecMaxCapability(I)Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;
    .locals 6
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_VIDEO_CODEC_TYPE;
        .end annotation
    .end param

    const/4 v5, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->isThumbPlayerEnable()Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    sget-object p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->mDefaultVCodecCapability:Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-object p0

    :cond_0
    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const/4 v5, 0x3

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->getVCodecMaxCapability(I)Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    move-result-object p0
    :try_end_0
    .catch Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-nez p0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x3

    sget-object p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->mDefaultVCodecCapability:Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    const/4 v5, 0x3

    const/4 v4, 0x1

    return-object p0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance v0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    const/4 v5, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLumaSamples:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget v2, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxProfile:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget v3, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLevel:I

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget p0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxFramerateFormaxLumaSamples:I

    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2, v3, p0}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;-><init>(IIII)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-object v0

    :catch_0
    move-exception p0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    new-instance v0, Lcom/tencent/thumbplayer/api/TPNativeException;

    const/4 v4, 0x7

    xor-int/2addr v5, v4

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/api/TPNativeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    throw v0
.end method

.method public static getThumbPlayerVCodecTypeMaxCapability(II)Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;
    .locals 5
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_VIDEO_CODEC_TYPE;
        .end annotation
    .end param
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_VIDEO_DECODER_TYPE;
        .end annotation
    .end param

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->isLibLoaded()Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    sget-object p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->mDefaultVCodecCapability:Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-object p0

    :cond_0
    :try_start_0
    const/4 v4, 0x3

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->getVCodecDecoderMaxCapabilityMap(I)Ljava/util/HashMap;

    move-result-object p1
    :try_end_0
    .catch Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const/4 v4, 0x5

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz p1, :cond_3

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/util/HashMap;->isEmpty()Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    check-cast p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-nez p0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->mDefaultVCodecCapability:Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object p0

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance p1, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLumaSamples:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxProfile:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget v2, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLevel:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    iget p0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxFramerateFormaxLumaSamples:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-direct {p1, v0, v1, v2, p0}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;-><init>(IIII)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-object p1

    :cond_3
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    sget-object p0, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->mDefaultVCodecCapability:Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-object p0

    :catch_0
    move-exception p0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance p1, Lcom/tencent/thumbplayer/api/TPNativeException;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {p1, p0}, Lcom/tencent/thumbplayer/api/TPNativeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    throw p1
.end method

.method public static isACodecCapabilityCanSupport(IIIIII)Z
    .locals 3
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_AUDIO_CODEC_TYPE;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->isThumbPlayerEnable()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 p0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    return p0

    :cond_0
    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-static/range {p0 .. p5}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->isACodecCapabilityCanSupport(IIIIII)Z

    move-result p0
    :try_end_0
    .catch Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return p0

    :catch_0
    move-exception p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance p1, Lcom/tencent/thumbplayer/api/TPNativeException;

    const/4 v2, 0x3

    invoke-direct {p1, p0}, Lcom/tencent/thumbplayer/api/TPNativeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    throw p1
.end method

.method public static isDDPlusSupported()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->isThumbPlayerEnable()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->isDDPlusSupported()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public static isDDSupported()Z
    .locals 3

    const/4 v2, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->isThumbPlayerEnable()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->isDDSupported()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public static isDRMsupport(I)Z
    .locals 2
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_DRM_TYPE;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/tencent/thumbplayer/adapter/a/b/a;->a(I)Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    return p0
.end method

.method public static isDolbyDSSupported()Z
    .locals 3

    const/4 v2, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->isThumbPlayerEnable()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    or-int/2addr v2, v1

    return v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->isDolbyDSSupported()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public static isDolbyVisionSupported()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public static isFeatureSupport(I)Z
    .locals 3
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$InnerFeatureType;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->isThumbPlayerEnable()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 p0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return p0

    :cond_0
    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapFeatureType;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapFeatureType;

    const/4 v2, 0x4

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapFeatureType;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapFeatureType;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->isFeatureSupport(I)Z

    move-result p0
    :try_end_0
    .catch Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return p0

    :catch_0
    move-exception p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/api/TPNativeException;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/api/TPNativeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    throw v0
.end method

.method public static isHDRsupport(III)Z
    .locals 3
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_HDR_TYPE;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->isThumbPlayerEnable()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    if-nez v0, :cond_0

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 p0, 0x0

    const/4 v1, 0x7

    const/4 v1, 0x2

    return p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapHdrType;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapHdrType;

    const/4 v2, 0x5

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapHdrType;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p0, p1, p2}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->isHDRsupport(III)Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return p0
.end method

.method public static isVCodecCapabilityCanSupport(IIIIII)Z
    .locals 8
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_VIDEO_CODEC_TYPE;
        .end annotation
    .end param

    const/4 v7, 0x6

    const/4 v6, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->isThumbPlayerEnable()Z

    move-result p3

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-nez p3, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 p0, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    return p0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    const/4 v3, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    const/4 v4, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    move v0, p0

    const/4 v7, 0x3

    move v0, p0

    move v0, p0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    move v1, p1

    move v1, p1

    const/4 v7, 0x7

    move v1, p1

    move v1, p1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    move v2, p2

    move v2, p2

    const/4 v7, 0x0

    move v2, p2

    move v2, p2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    move v5, p5

    move v5, p5

    const/4 v7, 0x3

    move v5, p5

    move v5, p5

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static/range {v0 .. v5}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->isVCodecCapabilityCanSupport(IIIIII)Z

    move-result p0
    :try_end_0
    .catch Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    return p0

    :catch_0
    move-exception p0

    const/4 v7, 0x1

    const/4 v6, 0x6

    new-instance p1, Lcom/tencent/thumbplayer/api/TPNativeException;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {p1, p0}, Lcom/tencent/thumbplayer/api/TPNativeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v6, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    throw p1
.end method

.method public static isVCodecCapabilityCanSupport(IIIIIII)Z
    .locals 8
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_VIDEO_CODEC_TYPE;
        .end annotation
    .end param

    const/4 v7, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->isThumbPlayerEnable()Z

    move-result p4

    const/4 v7, 0x3

    if-nez p4, :cond_0

    const/4 v7, 0x4

    const/4 p0, 0x0

    const/4 v7, 0x0

    return p0

    :cond_0
    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v7, 0x4

    const/4 v5, 0x0

    const/4 v7, 0x4

    move v0, p1

    move v0, p1

    const/4 v7, 0x0

    move v1, p0

    move v1, p0

    move v1, p0

    const/4 v7, 0x6

    move v2, p2

    move v2, p2

    move v2, p2

    move v2, p2

    const/4 v7, 0x1

    move v3, p3

    move v3, p3

    move v3, p3

    move v3, p3

    const/4 v7, 0x5

    move v6, p6

    move v6, p6

    move v6, p6

    :try_start_0
    const/4 v7, 0x0

    invoke-static/range {v0 .. v6}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->isVCodecCapabilitySupport(IIIIIII)Z

    move-result p0
    :try_end_0
    .catch Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x7

    return p0

    :catch_0
    move-exception p0

    const/4 v7, 0x6

    new-instance p1, Lcom/tencent/thumbplayer/api/TPNativeException;

    const/4 v7, 0x7

    invoke-direct {p1, p0}, Lcom/tencent/thumbplayer/api/TPNativeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v7, 0x6

    throw p1
.end method

.method public static setMediaCodecPreferredSoftwareComponent(Z)V
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->isThumbPlayerEnable()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->setMediaCodecPreferredSoftwareComponent(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method
