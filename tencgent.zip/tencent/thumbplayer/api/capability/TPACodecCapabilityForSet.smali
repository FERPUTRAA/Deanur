.class public Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;
.super Ljava/lang/Object;


# instance fields
.field private level:I

.field private lowerboundBitrate:I

.field private lowerboundChannels:I

.field private lowerboundSamplerate:I

.field private profile:I

.field private upperboundBitrate:I

.field private upperboundChannels:I

.field private upperboundSamplerate:I


# direct methods
.method public constructor <init>(III)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->upperboundSamplerate:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p2, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->upperboundChannels:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p3, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->upperboundBitrate:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x4

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->lowerboundSamplerate:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->lowerboundChannels:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->lowerboundBitrate:I

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->profile:I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->level:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>(IIIIIIII)V
    .locals 2

    const/4 v0, 0x4

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->upperboundSamplerate:I

    const/4 v1, 0x7

    const/4 v0, 0x1

    iput p2, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->upperboundChannels:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p3, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->upperboundBitrate:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p4, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->lowerboundSamplerate:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p5, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->lowerboundChannels:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p6, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->lowerboundBitrate:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p7, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->profile:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p8, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->level:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public getLevelForSet()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ smdr  -~~bo@@ @ ~~~i~a~o s~~oy~o@ ~ t ~ @ ~/~@~c~t@ l@@@b4@@Mif ~lf1o @v~K~ @bo@@@Si/@n @~u .@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->level:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public getLowerboundBitrate()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->lowerboundBitrate:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public getLowerboundChannels()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->lowerboundChannels:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    return v0
.end method

.method public getLowerboundSamplerate()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->lowerboundSamplerate:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    return v0
.end method

.method public getProfileForSet()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->profile:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public getUpperboundBitrate()I
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->upperboundBitrate:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public getUpperboundChannels()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->upperboundChannels:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public getUpperboundSamplerate()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget v0, p0, Lcom/tencent/thumbplayer/api/capability/TPACodecCapabilityForSet;->upperboundSamplerate:I

    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method
