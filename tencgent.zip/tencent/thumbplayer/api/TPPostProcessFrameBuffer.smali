.class public Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;
.super Ljava/lang/Object;


# static fields
.field public static final EVENT_EOS:I = 0x1

.field public static final EVENT_FLUSH:I = 0x2


# instance fields
.field public channelLayout:J

.field public channels:I

.field public data:[[B

.field public eventFlag:I

.field public format:I

.field public height:I

.field public mediaType:I

.field public nbSamples:I

.field public perfData:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field public ptsMs:J

.field public rotation:I

.field public sampleAspectRatioDen:I

.field public sampleAspectRatioNum:I

.field public sampleRate:I

.field public size:[I

.field public width:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public getChannelLayout()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "n@sb ~ o / ~@o@ ~Mf~@@~ oS @om @@~@t1@ i ~@c@~r@~db~i~u@~l~f~v @b ~~il~@~t soao~~/~@y@  K@.@ ~-4"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->channelLayout:J

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-wide v0
.end method

.method public getData()[[B
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->data:[[B

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public getFormat()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->format:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public getPtsMs()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->ptsMs:J

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-wide v0
.end method

.method public getSampleRate()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->sampleRate:I

    return v0
.end method

.method public getSize()[I
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->size:[I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method
