.class public Lcom/tencent/thumbplayer/api/TPInitParams$Builder;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/api/TPInitParams;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Builder"
.end annotation


# instance fields
.field private mDeviceName:Ljava/lang/String;

.field private mGuid:Ljava/lang/String;

.field private mPlatform:I


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/TPInitParams$Builder;->mGuid:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput v1, p0, Lcom/tencent/thumbplayer/api/TPInitParams$Builder;->mPlatform:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/TPInitParams$Builder;->mDeviceName:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public build()Lcom/tencent/thumbplayer/api/TPInitParams;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "fvs@~ ~~o@~  ~@o@ o~u@~/ @br~ bi al~f@  l  ~.~S@~on1~ @~@@@om@~o4K~@~  @t@ ~Mscb@~yd- @i~/@ @~~t"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/api/TPInitParams;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lcom/tencent/thumbplayer/api/TPInitParams;-><init>(Lcom/tencent/thumbplayer/api/TPInitParams$1;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPInitParams$Builder;->mPlatform:I

    const/4 v2, 0x5

    move v3, v2

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/api/TPInitParams;->access$102(Lcom/tencent/thumbplayer/api/TPInitParams;I)I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPInitParams$Builder;->mGuid:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/api/TPInitParams;->access$202(Lcom/tencent/thumbplayer/api/TPInitParams;Ljava/lang/String;)Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPInitParams$Builder;->mDeviceName:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/api/TPInitParams;->access$302(Lcom/tencent/thumbplayer/api/TPInitParams;Ljava/lang/String;)Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object v0
.end method

.method public setDeviceName(Ljava/lang/String;)Lcom/tencent/thumbplayer/api/TPInitParams$Builder;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPInitParams$Builder;->mDeviceName:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method public setGuid(Ljava/lang/String;)Lcom/tencent/thumbplayer/api/TPInitParams$Builder;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPInitParams$Builder;->mGuid:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method public setPlatform(I)Lcom/tencent/thumbplayer/api/TPInitParams$Builder;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPInitParams$Builder;->mPlatform:I

    const/4 v1, 0x5

    return-object p0
.end method
