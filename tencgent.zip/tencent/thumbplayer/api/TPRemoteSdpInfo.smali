.class public Lcom/tencent/thumbplayer/api/TPRemoteSdpInfo;
.super Ljava/lang/Object;


# instance fields
.field public isSuccess:Z

.field public remoteSdp:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method
