.class public Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "TPVideoCropInfo"
.end annotation


# instance fields
.field public cropBottom:I

.field public cropLeft:I

.field public cropRight:I

.field public cropTop:I

.field public height:I

.field public width:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v0, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->width:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->height:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->cropLeft:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->cropRight:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->cropTop:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->cropBottom:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~4s io~@~~~@o/~o@o~~ t~ sKf@~dv @ i~~@~ ~l@f@Sob @M .  @ @yb@mci~u ~  tnl@@~@~@  aob r~~@~@-@~@/"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v1, ":dstwh"

    const/4 v3, 0x4

    const-string v1, "d:wmit"

    const-string/jumbo v1, "width:"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->width:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    or-int/2addr v3, v2

    const-string/jumbo v1, "hmghoit ,"

    const-string/jumbo v1, "gitmhh ,:"

    const/4 v3, 0x7

    const-string v1, ":t g,bhie"

    const-string v1, ", height:"

    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->height:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const-string/jumbo v1, "f,oectup :L"

    const-string v1, "cLtrofe:p ,"

    const/4 v3, 0x6

    const-string/jumbo v1, "otr fcep,p:"

    const-string v1, ", cropLeft:"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->cropLeft:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const-string v1, ",cbgoRi:qr p"

    const-string/jumbo v1, "otRc,b rip:g"

    const/4 v3, 0x0

    const-string/jumbo v1, "grsip hoRct:"

    const-string v1, ", cropRight:"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    and-int/2addr v3, v2

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->cropRight:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v1, "c ompur:pT"

    const-string v1, " p,:ocupTr"

    const/4 v3, 0x4

    const-string v1, "Trc,o p:op"

    const-string v1, ", cropTop:"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    move v3, v2

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->cropTop:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo v1, "m,o:pbtpoto r"

    const-string v1, " mBtr:opot,op"

    const/4 v3, 0x6

    const-string/jumbo v1, "pBor:cumt ,to"

    const-string v1, ", cropBottom:"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->cropBottom:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0
.end method
