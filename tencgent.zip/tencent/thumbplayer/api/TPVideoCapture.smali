.class public Lcom/tencent/thumbplayer/api/TPVideoCapture;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/imagegenerator/ITPImageGeneratorCallback;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/api/TPVideoCapture$TPVideoCaptureCallBack;
    }
.end annotation


# static fields
.field private static final TAG:Ljava/lang/String; = "TPThumbPlayer[TPVideoCapture.java]"


# instance fields
.field private mCallBackMap:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/tencent/thumbplayer/api/TPVideoCapture$TPVideoCaptureCallBack;",
            ">;"
        }
    .end annotation
.end field

.field private mHeight:I

.field private mOpaque:J

.field private mRequestedTimeMsToleranceAfter:J

.field private mRequestedTimeMsToleranceBefore:J

.field private mTpImageGenerator:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

.field private mWidth:I


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    move v3, v2

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mWidth:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput v0, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mHeight:I

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-wide v0, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mRequestedTimeMsToleranceBefore:J

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-wide v0, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mRequestedTimeMsToleranceAfter:J

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-wide v0, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mOpaque:J

    const/4 v3, 0x5

    const/4 v2, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v0, p1, p0}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;-><init>(Ljava/lang/String;Lcom/tencent/thumbplayer/core/imagegenerator/ITPImageGeneratorCallback;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mTpImageGenerator:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance p1, Ljava/util/HashMap;

    const/4 v3, 0x7

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mCallBackMap:Ljava/util/Map;

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mTpImageGenerator:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;->init()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo v1, "sisi t"

    const-string v1, " :stii"

    const/4 v3, 0x1

    const-string v1, ":inmti"

    const-string/jumbo v1, "init: "

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v0, "bplooaeTTtu.]vmmuTirdCeaaeryPhPjPa"

    const-string/jumbo v0, "lTemTvaoeaTp]jb[yaPiPrruPtm.uadChe"

    const-string v0, "doaTybVhjrPee.euatTTupPCvrlaa]bmPi"

    const-string v0, "TPThumbPlayer[TPVideoCapture.java]"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method private generateOpaqueKey(JJ)Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@@@f@uot@ ~ obi.t@i1~- cr@ ~o~uf@o@v/@ M~K ~bnd~  @  ~l@@iba~ ~@@~@~ /y~@~ ~  ~~S@~4@mo ls ~~~o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string/jumbo v1, "ppa_uoo"

    const-string v1, "_aopouq"

    const/4 v3, 0x3

    const-string/jumbo v1, "uq_oepq"

    const-string/jumbo v1, "opaque_"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo p1, "itseb"

    const-string p1, "bimte"

    const/4 v3, 0x5

    const-string p1, "e_imm"

    const-string/jumbo p1, "time_"

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, p3, p4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    return-object p1
.end method

.method private getParameters()Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/16 v1, 0x25

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput v1, v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->format:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mWidth:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput v1, v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->width:I

    const/4 v3, 0x4

    move v4, v3

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mHeight:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput v1, v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->height:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mRequestedTimeMsToleranceAfter:J

    const/4 v4, 0x3

    const/4 v3, 0x0

    iput-wide v1, v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->requestedTimeMsToleranceAfter:J

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-wide v1, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mRequestedTimeMsToleranceBefore:J

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput-wide v1, v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->requestedTimeMsToleranceBefore:J

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object v0
.end method


# virtual methods
.method public generateImageAsyncAtTime(JLcom/tencent/thumbplayer/api/TPVideoCapture$TPVideoCaptureCallBack;)V
    .locals 11

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mOpaque:J

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v10, 0x3

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x1

    add-long/2addr v0, v2

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    iput-wide v0, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mOpaque:J

    const/4 v10, 0x3

    iget-object v2, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mCallBackMap:Ljava/util/Map;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-direct {p0, v0, v1, p1, p2}, Lcom/tencent/thumbplayer/api/TPVideoCapture;->generateOpaqueKey(JJ)Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-interface {v2, v0, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :try_start_0
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    iget-object v3, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mTpImageGenerator:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    iget-wide v6, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mOpaque:J

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-direct {p0}, Lcom/tencent/thumbplayer/api/TPVideoCapture;->getParameters()Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;

    move-result-object v8

    move-wide v4, p1

    const/4 v10, 0x3

    const/4 v9, 0x3

    invoke-virtual/range {v3 .. v8}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;->generateImageAsyncAtTime(JJLcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    return-void

    :catch_0
    move-exception p1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-string/jumbo p3, "ueyTo:ArgenaAg eInmtsimaee"

    const-string p3, "ammAeeue ynnesgrTAteIic:ag"

    const/4 v10, 0x7

    const-string/jumbo p3, "generateImageAsyncAtTime: "

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-string p2, "PimyubPvje.Tebu]aaahop[TCeadlVTPtp"

    const-string p2, "eTij]uTpayteCaPamvVr.eadPp[oPlhTbu"

    const/4 v10, 0x3

    const-string p2, "TPThumbPlayer[TPVideoCapture.java]"

    const/4 v10, 0x3

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    return-void
.end method

.method public generateImagesAsyncForTimes([JLcom/tencent/thumbplayer/api/TPVideoCapture$TPVideoCaptureCallBack;)V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mOpaque:J

    const/4 v8, 0x6

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v8, 0x2

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    add-long/2addr v0, v2

    const/4 v8, 0x6

    iput-wide v0, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mOpaque:J

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    array-length v0, p1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-ge v1, v0, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    aget-wide v2, p1, v1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget-object v4, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mCallBackMap:Ljava/util/Map;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget-wide v5, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mOpaque:J

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-direct {p0, v5, v6, v2, v3}, Lcom/tencent/thumbplayer/api/TPVideoCapture;->generateOpaqueKey(JJ)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-interface {v4, v2, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    goto :goto_0

    :cond_0
    :try_start_0
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-object p2, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mTpImageGenerator:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mOpaque:J

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-direct {p0}, Lcom/tencent/thumbplayer/api/TPVideoCapture;->getParameters()Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {p2, p1, v0, v1, v2}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;->generateImagesAsyncForTimes([JJLcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x3

    const/4 v7, 0x1

    return-void

    :catch_0
    move-exception p1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string v0, "eg:oysuAnnratmT eFergimssIceq"

    const-string v0, "egAnmFeeqrnoesT smI:ctrigaesy"

    const/4 v8, 0x0

    const-string v0, "Ta tygcpmFAe:eoemngiaereInssr"

    const-string/jumbo v0, "generateImagesAsyncForTimes: "

    const/4 v8, 0x5

    const/4 v7, 0x0

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string/jumbo p2, "hpvoV[adqTuelPPCsr]jutTm.arabeiyPT"

    const-string p2, "VesjlPd[pyimuPauTCbTearohP]ertav.T"

    const/4 v8, 0x2

    const-string p2, "]tsuauhjeaPdlbVPerTpePTra[oaTymv.C"

    const-string p2, "TPThumbPlayer[TPVideoCapture.java]"

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    return-void
.end method

.method public onImageGenerationCompleted(IJJJLcom/tencent/thumbplayer/core/common/TPVideoFrame;)V
    .locals 2

    const/4 v1, 0x0

    iget-object p4, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mCallBackMap:Ljava/util/Map;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p6, p7, p2, p3}, Lcom/tencent/thumbplayer/api/TPVideoCapture;->generateOpaqueKey(JJ)Ljava/lang/String;

    move-result-object p5

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-interface {p4, p5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p4

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    check-cast p4, Lcom/tencent/thumbplayer/api/TPVideoCapture$TPVideoCaptureCallBack;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    if-eqz p4, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    if-nez p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    if-eqz p8, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p8}, Lcom/tencent/thumbplayer/a/a;->b(Lcom/tencent/thumbplayer/core/common/TPVideoFrame;)[Landroid/graphics/Bitmap;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-interface {p4, p1}, Lcom/tencent/thumbplayer/api/TPVideoCapture$TPVideoCaptureCallBack;->onCaptureSuccess([Landroid/graphics/Bitmap;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x6

    invoke-interface {p4, p1}, Lcom/tencent/thumbplayer/api/TPVideoCapture$TPVideoCaptureCallBack;->onCaptureError(I)V

    :cond_1
    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mCallBackMap:Ljava/util/Map;

    const/4 v1, 0x6

    const/4 v0, 0x3

    invoke-direct {p0, p6, p7, p2, p3}, Lcom/tencent/thumbplayer/api/TPVideoCapture;->generateOpaqueKey(JJ)Ljava/lang/String;

    move-result-object p2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-interface {p1, p2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public release()V
    .locals 5

    :try_start_0
    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mTpImageGenerator:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;->cancelAllImageGenerations()V

    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mTpImageGenerator:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v4, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;->unInit()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string v2, "eelmsam e"

    const-string v2, "alrm seee"

    const/4 v4, 0x6

    const-string v2, "e sroee:a"

    const-string/jumbo v2, "release: "

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    move v4, v3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const-string v1, "aCda.bm[TuVulePPayvaoeTiepjPr]htTr"

    const-string v1, "TPThumbPlayer[TPVideoCapture.java]"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mCallBackMap:Ljava/util/Map;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mTpImageGenerator:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method

.method public setSize(II)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-ltz p1, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    if-ltz p2, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mWidth:I

    const/4 v0, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p2, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mHeight:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void

    :cond_0
    const/4 v1, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    const-string/jumbo p2, "lzioSlule giies"

    const-string/jumbo p2, "illloSsgiezi e "

    const/4 v1, 0x3

    const-string p2, "Size is illegal"

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    throw p1
.end method

.method public setTimeMsTolerance(JJ)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    cmp-long v0, p1, p3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-gtz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-wide p1, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mRequestedTimeMsToleranceBefore:J

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-wide p3, p0, Lcom/tencent/thumbplayer/api/TPVideoCapture;->mRequestedTimeMsToleranceAfter:J

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string p2, "ela leapcoiTsr eglni"

    const-string p2, "  eTcbgnaeeoiallrlsi"

    const-string p2, "acll e lqenosrigliea"

    const-string p2, "Tolerance is illegal"

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
