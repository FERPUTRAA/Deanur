.class public Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer$TP_AUDIO_CH_LAYOUT;
    }
.end annotation


# static fields
.field public static final TP_AUDIO_CH_BACK_CENTER:J = 0x100L

.field public static final TP_AUDIO_CH_BACK_LEFT:J = 0x10L

.field public static final TP_AUDIO_CH_BACK_RIGHT:J = 0x20L

.field public static final TP_AUDIO_CH_FRONT_CENTER:J = 0x4L

.field public static final TP_AUDIO_CH_FRONT_LEFT:J = 0x1L

.field public static final TP_AUDIO_CH_FRONT_LEFT_OF_CENTER:J = 0x40L

.field public static final TP_AUDIO_CH_FRONT_RIGHT:J = 0x2L

.field public static final TP_AUDIO_CH_FRONT_RIGHT_OF_CENTER:J = 0x80L

.field public static final TP_AUDIO_CH_LAYOUT_2POINT1:J = 0xbL

.field public static final TP_AUDIO_CH_LAYOUT_2_1:J = 0x103L

.field public static final TP_AUDIO_CH_LAYOUT_2_2:J = 0x603L

.field public static final TP_AUDIO_CH_LAYOUT_3POINT1:J = 0xfL

.field public static final TP_AUDIO_CH_LAYOUT_4POINT0:J = 0x107L

.field public static final TP_AUDIO_CH_LAYOUT_4POINT1:J = 0x10fL

.field public static final TP_AUDIO_CH_LAYOUT_5POINT0:J = 0x607L

.field public static final TP_AUDIO_CH_LAYOUT_5POINT0_BACK:J = 0x37L

.field public static final TP_AUDIO_CH_LAYOUT_5POINT1:J = 0x60fL

.field public static final TP_AUDIO_CH_LAYOUT_5POINT1_BACK:J = 0x3fL

.field public static final TP_AUDIO_CH_LAYOUT_6POINT0:J = 0x707L

.field public static final TP_AUDIO_CH_LAYOUT_6POINT0_FRONT:J = 0x6c3L

.field public static final TP_AUDIO_CH_LAYOUT_6POINT1:J = 0x70fL

.field public static final TP_AUDIO_CH_LAYOUT_6POINT1_BACK:J = 0x13fL

.field public static final TP_AUDIO_CH_LAYOUT_6POINT1_FRONT:J = 0x6cbL

.field public static final TP_AUDIO_CH_LAYOUT_7POINT0:J = 0x637L

.field public static final TP_AUDIO_CH_LAYOUT_7POINT0_FRONT:J = 0x6c7L

.field public static final TP_AUDIO_CH_LAYOUT_7POINT1:J = 0x63fL

.field public static final TP_AUDIO_CH_LAYOUT_7POINT1_WIDE:J = 0x6cfL

.field public static final TP_AUDIO_CH_LAYOUT_7POINT1_WIDE_BACK:J = 0xffL

.field public static final TP_AUDIO_CH_LAYOUT_HEXAGONAL:J = 0x137L

.field public static final TP_AUDIO_CH_LAYOUT_MONO:J = 0x4L

.field public static final TP_AUDIO_CH_LAYOUT_OCTAGONAL:J = 0x737L

.field public static final TP_AUDIO_CH_LAYOUT_QUAD:J = 0x33L

.field public static final TP_AUDIO_CH_LAYOUT_STEREO:J = 0x3L

.field public static final TP_AUDIO_CH_LAYOUT_STEREO_DOWNMIX:J = 0x60000000L

.field public static final TP_AUDIO_CH_LAYOUT_SURROUND:J = 0x7L

.field public static final TP_AUDIO_CH_LOW_FREQUENCY:J = 0x8L

.field public static final TP_AUDIO_CH_SIDE_LEFT:J = 0x200L

.field public static final TP_AUDIO_CH_SIDE_RIGHT:J = 0x400L

.field public static final TP_AUDIO_CH_STEREO_LEFT:J = 0x20000000L

.field public static final TP_AUDIO_CH_STEREO_RIGHT:J = 0x40000000L

.field public static final TP_AUDIO_CH_TOP_BACK_CENTER:J = 0x10000L

.field public static final TP_AUDIO_CH_TOP_BACK_LEFT:J = 0x8000L

.field public static final TP_AUDIO_CH_TOP_BACK_RIGHT:J = 0x20000L

.field public static final TP_AUDIO_CH_TOP_CENTER:J = 0x800L

.field public static final TP_AUDIO_CH_TOP_FRONT_CENTER:J = 0x2000L

.field public static final TP_AUDIO_CH_TOP_FRONT_LEFT:J = 0x1000L

.field public static final TP_AUDIO_CH_TOP_FRONT_RIGHT:J = 0x4000L


# instance fields
.field public channelLayout:J

.field public channels:I

.field public data:[[B

.field public format:I

.field public nbSamples:I

.field public ptsMs:J

.field public sampleRate:I

.field public size:[I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public getChannelLayout()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "u@s ~  o~ @~1 ir@b~@fm-o ~ l~@ ~ @S @c@~~@@ v~b~~~@M~olb~ /i~~ @f @@y.@ o~sK~~o4 @@t/@n@@ai~d~ o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;->channelLayout:J

    const/4 v3, 0x0

    const/4 v2, 0x1

    return-wide v0
.end method

.method public getData()[[B
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;->data:[[B

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public getFormat()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;->format:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public getPtsMs()J
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;->ptsMs:J

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-wide v0
.end method

.method public getSampleRate()I
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;->sampleRate:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public getSize()[I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;->size:[I

    const/4 v2, 0x3

    return-object v0
.end method
