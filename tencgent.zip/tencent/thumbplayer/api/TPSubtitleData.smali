.class public Lcom/tencent/thumbplayer/api/TPSubtitleData;
.super Ljava/lang/Object;


# instance fields
.field public durationMs:J

.field public startPositionMs:J

.field public subtitleData:Ljava/lang/String;

.field public trackIndex:J


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public getDurationMs()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleData;->durationMs:J

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-wide v0
.end method

.method public getStartPositionMs()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleData;->startPositionMs:J

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-wide v0
.end method

.method public getSubtitleData()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleData;->subtitleData:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method public getTrackIndex()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleData;->trackIndex:J

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-wide v0
.end method
