.class public Lcom/tencent/thumbplayer/api/TPInitParams;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/api/TPInitParams$Builder;
    }
.end annotation


# instance fields
.field private mDeviceName:Ljava/lang/String;

.field private mGuid:Ljava/lang/String;

.field private mPlatform:I


# direct methods
.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/TPInitParams;->mGuid:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput v1, p0, Lcom/tencent/thumbplayer/api/TPInitParams;->mPlatform:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/TPInitParams;->mDeviceName:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/thumbplayer/api/TPInitParams$1;)V
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/api/TPInitParams;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic access$102(Lcom/tencent/thumbplayer/api/TPInitParams;I)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ s1@a@r@o@    ~~u~ ~/o~~~ @@t @o@l~ @~s ~di~b~4n~~ oo.y@~@ f f -~~M~~@@~So/Ktb@vc@~b @@ ii@@@l "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    iput p1, p0, Lcom/tencent/thumbplayer/api/TPInitParams;->mPlatform:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    return p1
.end method

.method static synthetic access$202(Lcom/tencent/thumbplayer/api/TPInitParams;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPInitParams;->mGuid:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method

.method static synthetic access$302(Lcom/tencent/thumbplayer/api/TPInitParams;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPInitParams;->mDeviceName:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x5

    return-object p1
.end method


# virtual methods
.method public getDeviceName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPInitParams;->mDeviceName:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public getGuid()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPInitParams;->mGuid:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public getPlatform()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPInitParams;->mPlatform:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method
