.class public Lcom/tencent/thumbplayer/api/TPProgramInfo;
.super Ljava/lang/Object;


# instance fields
.field public actived:Z

.field public bandwidth:J

.field public programId:I

.field public resolution:Ljava/lang/String;

.field public url:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method
