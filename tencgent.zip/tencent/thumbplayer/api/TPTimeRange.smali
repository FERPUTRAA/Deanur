.class public Lcom/tencent/thumbplayer/api/TPTimeRange;
.super Ljava/lang/Object;


# instance fields
.field private mEndTimeMs:J

.field private mStartTimeMs:J


# direct methods
.method public constructor <init>(JJ)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-wide p1, p0, Lcom/tencent/thumbplayer/api/TPTimeRange;->mStartTimeMs:J

    const/4 v0, 0x1

    move v1, v0

    iput-wide p3, p0, Lcom/tencent/thumbplayer/api/TPTimeRange;->mEndTimeMs:J

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public getEndTimeMs()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ s~b l/~i/@t~ibK@M~~@i @a  oS~fforlo@~~o@ @ ~@1~@mo ~ @~ .~ o@~n@~c@  4@ @u- y~~ b~~s@~~~d@t @v"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPTimeRange;->mEndTimeMs:J

    const/4 v3, 0x5

    return-wide v0
.end method

.method public getStartTimeMs()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPTimeRange;->mStartTimeMs:J

    const/4 v2, 0x5

    or-int/2addr v3, v2

    return-wide v0
.end method

.method public setEndTimeMs(J)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-wide p1, p0, Lcom/tencent/thumbplayer/api/TPTimeRange;->mEndTimeMs:J

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public setStartTimeMs(J)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    iput-wide p1, p0, Lcom/tencent/thumbplayer/api/TPTimeRange;->mStartTimeMs:J

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method
