.class public Lcom/tencent/thumbplayer/api/TPCaptureParams;
.super Ljava/lang/Object;


# static fields
.field public static final TP_PIX_FMT_NONE:I = -0x1

.field public static final TP_PIX_FMT_RGB565:I = 0x25

.field public static final TP_PIX_FMT_YUV420P:I


# instance fields
.field public format:I

.field public height:I

.field public requestedTimeMsToleranceAfter:J

.field public requestedTimeMsToleranceBefore:J

.field public width:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method
