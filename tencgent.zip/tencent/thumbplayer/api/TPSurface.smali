.class public final Lcom/tencent/thumbplayer/api/TPSurface;
.super Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurface;


# instance fields
.field private mITPSurfaceCallback:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerSurfaceCallback;

.field private mPlayerSurfaceListener:Lcom/tencent/thumbplayer/api/ITPSurfaceListener;


# direct methods
.method public constructor <init>(Landroid/graphics/SurfaceTexture;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurface;-><init>(Landroid/graphics/SurfaceTexture;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPSurface;->mPlayerSurfaceListener:Lcom/tencent/thumbplayer/api/ITPSurfaceListener;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    new-instance p1, Lcom/tencent/thumbplayer/api/TPSurface$1;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p1, p0}, Lcom/tencent/thumbplayer/api/TPSurface$1;-><init>(Lcom/tencent/thumbplayer/api/TPSurface;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPSurface;->mITPSurfaceCallback:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerSurfaceCallback;

    const/4 v1, 0x6

    const/4 v0, 0x4

    invoke-super {p0, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurface;->setTPSurfaceCallback(Lcom/tencent/thumbplayer/core/player/ITPNativePlayerSurfaceCallback;)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic access$000(Lcom/tencent/thumbplayer/api/TPSurface;)Lcom/tencent/thumbplayer/api/ITPSurfaceListener;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b@sf o-v~~@  b~/t~ @ K@~i @  @ib@lc@~~  @ ~@~ rM@~@S~l @~@y~@~@s~om @ on~~ou~~i4@to~  @/d@~af~1o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/tencent/thumbplayer/api/TPSurface;->mPlayerSurfaceListener:Lcom/tencent/thumbplayer/api/ITPSurfaceListener;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0
.end method


# virtual methods
.method protected final finalize()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-super {p0}, Landroid/view/Surface;->release()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-super {p0}, Landroid/view/Surface;->finalize()V

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public final setSurfaceListener(Lcom/tencent/thumbplayer/api/ITPSurfaceListener;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPSurface;->mPlayerSurfaceListener:Lcom/tencent/thumbplayer/api/ITPSurfaceListener;

    const/4 v1, 0x3

    const/4 v0, 0x3

    return-void
.end method
