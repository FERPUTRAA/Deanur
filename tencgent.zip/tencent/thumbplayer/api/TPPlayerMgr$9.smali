.class final Lcom/tencent/thumbplayer/api/TPPlayerMgr$9;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/api/TPPlayerMgr$ITPPropertyHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/api/TPPlayerMgr;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/tencent/thumbplayer/api/TPPlayerMgr$ITPPropertyHandler<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    const/4 v0, 0x1

    return-void
.end method


# virtual methods
.method public final getPropertyValue()Ljava/lang/Boolean;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~osu~@@m@/@ otK~a@o ~-c/ yrvl 4bd~@ ~@f~~b@~i@i@@@~o~ .   @~  ~ oi1M@ S~s~@~o~~ f  @@~n~b@ tl~@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getNewReportEnable()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public final bridge synthetic getPropertyValue()Ljava/lang/Object;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$9;->getPropertyValue()Ljava/lang/Boolean;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public final setPropertyValue(Ljava/lang/Boolean;)V
    .locals 4
    .param p1    # Ljava/lang/Boolean;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string v1, "baemser :srw olnepeetn t"

    const-string/jumbo v1, "rwsretno ee l:bs eatp ne"

    const/4 v3, 0x5

    const-string v1, "e r oae:ren  tpswnoltbe "

    const-string/jumbo v1, "set new report enable : "

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v1, "bPaaMbyPjgPmlhymvPr.TueT]Teara["

    const-string v1, "MP[maajTPuyh]rTyPr.maPvTagelble"

    const/4 v3, 0x4

    const-string v1, "aTgjhMuPyavreaTlrymPe.[alPbTPur"

    const-string v1, "TPThumbPlayer[TPPlayerMgr.java]"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->setNewReportEnable(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method public final bridge synthetic setPropertyValue(Ljava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    check-cast p1, Ljava/lang/Boolean;

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$9;->setPropertyValue(Ljava/lang/Boolean;)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method
