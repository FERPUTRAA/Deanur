.class public Lcom/tencent/thumbplayer/api/TPPlayerMgr;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/api/TPPlayerMgr$ITPPropertyHandler;,
        Lcom/tencent/thumbplayer/api/TPPlayerMgr$StringProperty;,
        Lcom/tencent/thumbplayer/api/TPPlayerMgr$LongProperty;,
        Lcom/tencent/thumbplayer/api/TPPlayerMgr$IntegerProperty;,
        Lcom/tencent/thumbplayer/api/TPPlayerMgr$BooleanProperty;,
        Lcom/tencent/thumbplayer/api/TPPlayerMgr$EventId;,
        Lcom/tencent/thumbplayer/api/TPPlayerMgr$OnLogListener;
    }
.end annotation


# static fields
.field public static final BEACON_LOG_HOST_KEY:Ljava/lang/String; = "beacon_log_host"

.field public static final BEACON_POLICY_HOST_KEY:Ljava/lang/String; = "beacon_policy_host"

.field public static final EVENT_ID_APP_ENTER_BACKGROUND:I = 0x186a1

.field public static final EVENT_ID_APP_ENTER_FOREGROUND:I = 0x186a2

.field public static final INVALID_SUGGEST_BITRATE:I = -0x1

.field public static final PLYAER_HOST_KEY:Ljava/lang/String; = "player_host_config"

.field public static final PROPERTY_AB_USER_ID:Ljava/lang/String; = "PROPERTY_AbUserId"

.field public static final PROPERTY_ENABLE_DATA_REPORT:Ljava/lang/String; = "PROPERTY_EnableDataReport"

.field public static final PROPERTY_ENABLE_NEW_REPORT:Ljava/lang/String; = "PROPERTY_EnableNewReport"

.field public static final PROPERTY_ENABLE_PLAYER_REPORT:Ljava/lang/String; = "PROPERTY_EnablePlayerReport"

.field public static final PROPERTY_MEDIA_DRM_REUSE_BEFORE_INIT_SDK:Ljava/lang/String; = "PROPERTY_MediaDrmReuse"

.field public static final PROPERTY_PROXY_MAX_USE_MEMORY_MB:Ljava/lang/String; = "PROPERTY_ProxyMaxUseMemoryMB"

.field public static final PROPERTY_VIDEO_MEDIACODEC_CO_EXIST_MAX_CNT:Ljava/lang/String; = "PROPERTY_VideoMediaCodecCoexistMaxCnt"

.field public static final PROPERTY_WIDEVINE_PROVISIONING_SERVER_URL_BEFORE_INIT_SDK:Ljava/lang/String; = "PROPERTY_WidevineProvisioningServerUrl"

.field public static final PROXY_HOST_KEY:Ljava/lang/String; = "httpproxy_config"

.field private static final TAG:Ljava/lang/String; = "TPThumbPlayer[TPPlayerMgr.java]"

.field public static final TP_DOWNLOAD_PROXY_MODULE_NAME:Ljava/lang/String; = "DownloadProxy"

.field public static final TP_PLAYERCORE_MODULE_NAME:Ljava/lang/String; = "TPCore"

.field private static mAppContext:Landroid/content/Context;

.field private static final mBooleanPropertyNameToPropertyHandlerTables:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Lcom/tencent/thumbplayer/api/TPPlayerMgr$ITPPropertyHandler<",
            "Ljava/lang/Boolean;",
            ">;>;"
        }
    .end annotation
.end field

.field private static mIsInit:Z

.field private static final mStringPropertyNameToPropertyHandlerTables:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Lcom/tencent/thumbplayer/api/TPPlayerMgr$ITPPropertyHandler<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x0

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v3, 0x3

    const/4 v4, 0x3

    sput-object v0, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mBooleanPropertyNameToPropertyHandlerTables:Ljava/util/HashMap;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v1, Lcom/tencent/thumbplayer/api/TPPlayerMgr$6;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {v1}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$6;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const-string v2, "RusOPRa_YMmssePTdDReir"

    const-string v2, "MOsRDsPYaduPrTemRRe_Ei"

    const/4 v4, 0x6

    const-string v2, "E_OmTidPMmRaeRsRDPeYur"

    const-string v2, "PROPERTY_MediaDrmReuse"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    move v4, v3

    new-instance v1, Lcom/tencent/thumbplayer/api/TPPlayerMgr$7;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v1}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$7;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v2, "taYToeRaD_obpRrElanEPemOR"

    const-string/jumbo v2, "pDPmoa_EYatePRraRbeRnOlTE"

    const/4 v4, 0x6

    const-string v2, "btTrpbtPonE_eDaeEPaRlaORY"

    const-string v2, "PROPERTY_EnableDataReport"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    new-instance v1, Lcom/tencent/thumbplayer/api/TPPlayerMgr$8;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {v1}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$8;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v2, "oeoPOruaEPlnerRaRbPl_TRpeYE"

    const-string/jumbo v2, "yrbRorPlPRePnOR_oTalEeYepEa"

    const/4 v4, 0x4

    const-string v2, "ReRrnYPpEa_yPPlbeOtRpTroaEl"

    const-string v2, "PROPERTY_EnablePlayerReport"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v1, Lcom/tencent/thumbplayer/api/TPPlayerMgr$9;

    const/4 v4, 0x6

    invoke-direct {v1}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$9;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v2, "EPb_PoRRqaetTENbnOelYprw"

    const-string v2, "_nwbabEtENePTrRoRROpleYP"

    const/4 v4, 0x7

    const-string v2, "OEsTe_onRbptawPeRRPNeElY"

    const-string v2, "PROPERTY_EnableNewReport"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    sput-object v0, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mStringPropertyNameToPropertyHandlerTables:Ljava/util/HashMap;

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance v1, Lcom/tencent/thumbplayer/api/TPPlayerMgr$10;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {v1}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$10;-><init>()V

    const/4 v3, 0x1

    const-string/jumbo v2, "rIYmbRTAORs_PuUEP"

    const-string v2, "TEPPI_uRUdOARYrsb"

    const/4 v4, 0x5

    const-string v2, "TsRdoOIrbAP_REeUP"

    const-string v2, "PROPERTY_AbUserId"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance v1, Lcom/tencent/thumbplayer/api/TPPlayerMgr$11;

    const/4 v3, 0x7

    and-int/2addr v4, v3

    invoke-direct {v1}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$11;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string/jumbo v2, "vrnRoirple_TnisvPEognPedeePrSUWiiriYvR"

    const/4 v4, 0x4

    const-string/jumbo v2, "rWe_vbRoreRsYdivinnUlPrgriPveiOeioSPTE"

    const-string v2, "PROPERTY_WidevineProvisioningServerUrl"

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic access$000()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~b~o~vu~~ ~~cM@@S@~4@K@~it o@ni  . os ~y@~ mlo@b ~1~@~~@@oabt~ld@ ~o /@ ~@   u @@r~  ~f/~@@-fi~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->initInAsyncThread()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic access$100()Landroid/content/Context;
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mAppContext:Landroid/content/Context;

    const/4 v2, 0x0

    const/4 v1, 0x6

    return-object v0
.end method

.method private static dumpStackTrace()V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string v0, ":t  ekup enaatqtrrscc"

    const-string v0, " teruncrqeatsck aCt :"

    const-string v0, "a  c:kc qurrtrteaenCs"

    const-string v0, "Current stack trace: "

    const/4 v5, 0x3

    xor-int/2addr v6, v5

    const-string/jumbo v1, "has.uTPyPPTayMsgPemT[bjlvler]ar"

    const-string v1, "PTsavl.MPgeyajermbTaP]rTyahlu[P"

    const/4 v6, 0x0

    const-string v1, "PrlmjmTuPPPvrTMbyayhe.[ea]raTal"

    const-string v1, "TPThumbPlayer[TPPlayerMgr.java]"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/Thread;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v0

    const/4 v5, 0x5

    move v6, v5

    array-length v2, v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v3, 0x7

    const/4 v3, 0x0

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-ge v3, v2, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    aget-object v4, v0, v3

    const/4 v5, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v4}, Ljava/lang/StackTraceElement;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v1, v4}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    return-void
.end method

.method public static getAppContext()Landroid/content/Context;
    .locals 3

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mAppContext:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public static getLibVersion(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-boolean v0, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mIsInit:Z

    const/4 v3, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo v0, "rDxyoPanmloow"

    const-string v0, "PlDmxonaydwor"

    const/4 v3, 0x0

    const-string v0, "danoPboDrwylo"

    const-string v0, "DownloadProxy"

    const/4 v2, 0x3

    and-int/2addr v3, v2

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadProxyHelper;->getNativeLibVersion()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v0, "urCeoT"

    const-string v0, "ToeCor"

    const/4 v3, 0x7

    const-string v0, "PpCToe"

    const-string v0, "TPCore"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->getLibVersion()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object p0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x4

    move v3, v2

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string/jumbo v1, "qie:Nalb"

    const-string v1, "Neil:bam"

    const/4 v3, 0x6

    const-string/jumbo v1, "lNsai:mb"

    const-string/jumbo v1, "libName:"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    throw v0

    :cond_2
    const/4 v2, 0x0

    move v3, v2

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v0, " aimyrtnzueid poleiinl"

    const-string v0, "anzeipuolytii il dtenr"

    const/4 v3, 0x1

    const-string/jumbo v0, "nli oea iatiznidtyelpo"

    const-string/jumbo v0, "player not initialized"

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    throw p0
.end method

.method public static getOfflineRecordDurationMs(Ljava/lang/String;Ljava/lang/String;)I
    .locals 2

    invoke-static {p0, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadProxyHelper;->getRecordDuration(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return p0
.end method

.method public static getOfflineRecordVinfo(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    invoke-static {p0, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadProxyHelper;->checkVideoStatus(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p0
.end method

.method public static getPropertyBoolean(Ljava/lang/String;)Z
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->getPropertyBoolean(Ljava/lang/String;Z)Z

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return p0
.end method

.method public static getPropertyBoolean(Ljava/lang/String;Z)Z
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mBooleanPropertyNameToPropertyHandlerTables:Ljava/util/HashMap;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    check-cast p0, Lcom/tencent/thumbplayer/api/TPPlayerMgr$ITPPropertyHandler;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-interface {p0}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$ITPPropertyHandler;->getPropertyValue()Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    check-cast p0, Ljava/lang/Boolean;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    return p0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    return p1
.end method

.method public static getPropertyInteger(Ljava/lang/String;)I
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->getPropertyInteger(Ljava/lang/String;I)I

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return p0
.end method

.method public static getPropertyInteger(Ljava/lang/String;I)I
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string v0, "ePxTnEPpdtoRxe_adOCMtsiVCYeieMooicadC"

    const/4 v2, 0x1

    const-string v0, "_VaCobPRPindoTeYRdctxCdtxeCioOseMaieE"

    const-string v0, "PROPERTY_VideoMediaCodecCoexistMaxCnt"

    const/4 v2, 0x2

    invoke-static {v0, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getVideoMediaCodecCoexistMaxCnt()I

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return p0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return p1
.end method

.method public static getPropertyLong(Ljava/lang/String;)J
    .locals 4
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p0, v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->getPropertyLong(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    return-wide v0
.end method

.method public static getPropertyLong(Ljava/lang/String;J)J
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string v0, "amy_RouoPOsMPyPrqxMUxEeTrYeR"

    const-string/jumbo v0, "mMOyMrroqxPesTxReYoMy_RaUPPE"

    const/4 v2, 0x2

    const-string/jumbo v0, "yT_OoMYpMoPxyRRPsUeaPmMxerrE"

    const-string v0, "PROPERTY_ProxyMaxUseMemoryMB"

    const/4 v1, 0x6

    move v2, v1

    invoke-static {v0, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz p0, :cond_0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getProxyMaxUseMemoryMB()J

    move-result-wide p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-wide p0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-wide p1
.end method

.method public static getPropertyString(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->getPropertyString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0
.end method

.method public static getPropertyString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mStringPropertyNameToPropertyHandlerTables:Ljava/util/HashMap;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast p0, Lcom/tencent/thumbplayer/api/TPPlayerMgr$ITPPropertyHandler;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {p0}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$ITPPropertyHandler;->getPropertyValue()Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast p0, Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p1
.end method

.method public static getSuggestedBitrate()I
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/c/i;->a()Lcom/tencent/thumbplayer/c/i;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getProxyServiceType()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/c/i;->a(I)Lcom/tencent/thumbplayer/c/b;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v1, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    return v1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {v0}, Lcom/tencent/thumbplayer/c/b;->a()Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-nez v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x7

    return v1

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {v0, v2}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->getNativeInfo(I)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/b;->a(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v0
.end method

.method public static getThumbPlayerVersion()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    const-string v0, "1304.21sq."

    const-string v0, "3.s1.1240."

    const/4 v2, 0x1

    const-string v0, ".1s12034.3"

    const-string v0, "2.31.0.134"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method private static initAsyncWithWait()Ljava/util/concurrent/Future;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/concurrent/Future<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/utils/o;->a()Lcom/tencent/thumbplayer/utils/o;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/o;->c()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v1, Lcom/tencent/thumbplayer/api/TPPlayerMgr$2;

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    invoke-direct {v1}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$2;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0
.end method

.method private static initAsyncWithoutWait()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/utils/o;->a()Lcom/tencent/thumbplayer/utils/o;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/o;->d()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance v1, Lcom/tencent/thumbplayer/api/TPPlayerMgr$3;

    const/4 v3, 0x7

    const/4 v2, 0x0

    invoke-direct {v1}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$3;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/4 v3, 0x5

    return-void
.end method

.method private static initInAsyncThread()V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/utils/d;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {v0}, Lcom/tencent/thumbplayer/utils/d;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/d;->a()V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mAppContext:Landroid/content/Context;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v1}, Lcom/tencent/thumbplayer/common/a/b;->a(Landroid/content/Context;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string/jumbo v2, "haWmmnryW pio  tsp,i pnttitisiioat RaecStTeeInrWDBP, c eiAiKt:nr"

    const/4 v6, 0x2

    const-string v2, " ,pmstpAi eiai   ,cnt:tW DrnyiSeWaPnhpreKmiotBrcti tITaioReisntW"

    const-string v2, "Init SDK, initAsyncWithWait  TPBeaconReportWrapper init, times: "

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/d;->e()J

    move-result-wide v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    move v6, v5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string v2, "Pa]voTrPPuge.ajmyP[MrbTryoeTaal"

    const-string v2, "bT[PogPae.ryaPTjuerPaMvTmlay]hr"

    const/4 v6, 0x7

    const-string/jumbo v2, "yaeyabl.e]rP[TTvjrPMrPhuPTmlaab"

    const-string v2, "TPThumbPlayer[TPPlayerMgr.java]"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v2, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mAppContext:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/a/b/a;->a(Landroid/content/Context;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string v3, "WthnnmuCaiiPDbiisi,W  tS  bm:let p,yiiisyn  iKTIDcrinttaAt"

    const-string/jumbo v3, "yW ,ibiyDCtiinisiitSKm n:battPITlnmD as,Wtcii ehrnp   tAia"

    const/4 v6, 0x1

    const-string v3, ":stithWpntK  rnaCtyTiiD tni ,i,PeiaDtlmiyiWA cn SIpibatmsi"

    const-string v3, "Init SDK, initAsyncWithWait  TPDrmCapability init, times: "

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/d;->e()J

    move-result-wide v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v1, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v2, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mAppContext:Landroid/content/Context;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v3, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v1, v3}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->init(Landroid/content/Context;Z)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-string v3, "DWnhubryqitp miKHl tchipe,iy aiepiaAn yran ei:atllittTSt isTPemW Cubn,Ii"

    const-string v3, ":p r iuH KniaitaiineW,lppyainuhbatemimyttC sWSTinyci sItleetbrlhTAP, iD "

    const/4 v6, 0x0

    const-string v3, "Init SDK, initAsyncWithWait  TPThumbplayerCapabilityHelper init, times: "

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/d;->e()J

    move-result-wide v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v1, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v2, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v6, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mAppContext:Landroid/content/Context;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->playerCoreNativeSetup(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x2

    goto :goto_0

    :catch_0
    move-exception v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v2, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string/jumbo v3, "hcsiit,WiKymDiltti  e At nniIsWlp sataS"

    const-string v3, "Sat t tpnaseiytiWiI,KcW:i ilh lntsmDi A"

    const/4 v6, 0x5

    const-string/jumbo v3, "nWimaiy aWtmecsi hlt,ni ntAtsi:D SiKl I"

    const-string v3, "Init SDK, initAsyncWithWait all times: "

    const/4 v5, 0x1

    or-int/2addr v6, v5

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/d;->d()J

    move-result-wide v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v1, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v2, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    return-void
.end method

.method public static initSdk(Landroid/content/Context;Lcom/tencent/thumbplayer/api/TPInitParams;)V
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPInitParams;->getDeviceName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->setDeviceName(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPInitParams;->getGuid()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPInitParams;->getPlatform()I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p0, v0, p1}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->initSdk(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public static initSdk(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->dumpStackTrace()V

    const/4 v2, 0x5

    move v3, v2

    sget-boolean v0, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mIsInit:Z

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v1, "aMrroaaquTvle]yhPPPj[aPlTgmTrye"

    const-string v1, "TrP]aarPqvjlPh[emTPygTayubleaMr"

    const/4 v3, 0x6

    const-string v1, "albmeb.jPyvharrryPTaTgMeTP[al]u"

    const-string v1, "TPThumbPlayer[TPPlayerMgr.java]"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const-string p0, "DIshk ud tn ns,iSKiiat"

    const-string/jumbo p0, "hdsiiS,aiKDn kts t nsI"

    const/4 v3, 0x3

    const-string p0, "DdnISsnpi  Kit,hita  s"

    const-string p0, "Init SDK, has init sdk"

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v1, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    sput-boolean v0, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mIsInit:Z

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/utils/d;

    const/4 v3, 0x6

    invoke-direct {v0}, Lcom/tencent/thumbplayer/utils/d;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/d;->a()V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p0, p1, p2}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->preInitSync(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->initAsyncWithWait()Ljava/util/concurrent/Future;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->initSync()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->initAsyncWithoutWait()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/d;->b()V

    :try_start_0
    const/4 v3, 0x0

    invoke-interface {p0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    check-cast p0, Ljava/lang/Boolean;

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz p0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string p1, ",nTSmyliqiS t ifnsaw Piirat ten:ythD  P, K Iecisi"

    const-string p1, "Init SDK, TPPlayer  wait initSync finish, times: "

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/d;->c()J

    move-result-wide p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v1, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_2

    :catch_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo p1, "tIsci,nSx eyPtI a:prTilS wt opi,nnmdrim uKDten ieEnrisycatte e"

    const-string/jumbo p1, "niEmweKi iems,tp xereSntytit t, PSIet:o dnin arnlapyITDP uricc"

    const/4 v3, 0x4

    const-string/jumbo p1, "pIemEinitTPesaKtitueyrin    lc tatSDom,:SPwcdn rn,eInxtp eiyit"

    const-string p1, "Init SDK, TPPlayer wait initSync InterruptedException, times: "

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    goto :goto_1

    :catch_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string/jumbo p1, "yom oTPitntixiSn,i ee nnxs: i  uor,aceEiEKStIDocPnwt atlptce"

    const-string/jumbo p1, "iy  onD tiisclt,SemoEteSP tuai ewtptnanxTKxc:yIno PEiie,r nc"

    const/4 v3, 0x1

    const-string p1, "Pis ibn:SyK einepteIie  DiimocrtS,at,wi ttc t cPlynExnxanuET"

    const-string p1, "Init SDK, TPPlayer wait initSync ExecutionException, times: "

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/d;->c()J

    move-result-wide p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v1, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_2
    const/4 v3, 0x5

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string p1, "asKblIui aPteT r lmten:iy D,lS"

    const-string/jumbo p1, "ytDP besT l,aianPtliIl rSe:K m"

    const/4 v3, 0x2

    const-string p1, "Init SDK, TPPlayer all times: "

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/d;->d()J

    move-result-wide p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto/16 :goto_0
.end method

.method private static initSync()V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v0, "[y.hrMuvljaaulagT]yTTPebaPrrPPm"

    const/4 v6, 0x3

    const-string v0, "TPThumbPlayer[TPPlayerMgr.java]"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v1, Lcom/tencent/thumbplayer/utils/d;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {v1}, Lcom/tencent/thumbplayer/utils/d;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/utils/d;->a()V

    :try_start_0
    const/4 v5, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    sget-object v2, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mAppContext:Landroid/content/Context;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->loadLibIfNeeded(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    goto :goto_0

    :catch_0
    move-exception v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v0, v2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string v3, " iKSeiap tloys ct ,opns Iin:itnSDd"

    const-string/jumbo v3, "ysnt,:ipK  l tSansi io neSc DidIot"

    const/4 v6, 0x1

    const-string v3, "Init SDK, initSync so load times: "

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/utils/d;->d()J

    move-result-wide v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    return-void
.end method

.method public static isProxyEnable()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->isUseP2P()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadProxyHelper;->isReadyForPlay()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public static isThumbPlayerEnable()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->isLibLoaded()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    return v0
.end method

.method public static postEvent(IIILjava/lang/Object;)V
    .locals 2

    const/4 v0, 0x7

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/thumbplayer/utils/f;->a(IIILjava/lang/Object;)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method private static preInitSync(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/utils/d;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {v0}, Lcom/tencent/thumbplayer/utils/d;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/d;->a()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    sput-object p0, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mAppContext:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->setGuid(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p2}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->setPlatform(I)V

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance p0, Lcom/tencent/thumbplayer/api/TPPlayerMgr$1;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$1;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->setLogCallback(Lcom/tencent/thumbplayer/core/common/ITPNativeLogCallback;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string p1, "aIlynl mqisertc  SIDKetSpinqt: ,n"

    const-string/jumbo p1, "nnDyl,itq In Stcp:eatr miieK IsSl"

    const/4 v2, 0x4

    const-string/jumbo p1, "lnsieitI:npintst S  yem,aKI r lDS"

    const-string p1, "Init SDK, preInitSync all times: "

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/d;->d()J

    move-result-wide p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string/jumbo p1, "meamsPraarPyMaueTj.rThby[PgTl]P"

    const-string/jumbo p1, "jas[l.PyvgT]rhyTeuPamaerMPaPrTb"

    const/4 v2, 0x3

    const-string p1, "erTuo]P[rjylbPeTgPhaarMvm.lTaay"

    const-string p1, "TPThumbPlayer[TPPlayerMgr.java]"

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-static {p1, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public static setDebugEnable(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->setDebugEnable(Z)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public static setHost(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->parseHostConfig(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public static setLibLoader(Lcom/tencent/thumbplayer/api/ITPModuleLoader;)V
    .locals 3

    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-boolean v0, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mIsInit:Z

    const/4 v2, 0x6

    const/4 v1, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    new-instance v0, Lcom/tencent/thumbplayer/api/TPPlayerMgr$4;

    const/4 v1, 0x5

    and-int/2addr v2, v1

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$4;-><init>(Lcom/tencent/thumbplayer/api/ITPModuleLoader;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->setLibLoader(Lcom/tencent/thumbplayer/core/common/ITPNativeLibraryExternalLoader;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/api/TPPlayerMgr$5;

    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$5;-><init>(Lcom/tencent/thumbplayer/api/ITPModuleLoader;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadProxyHelper;->setNativeLibLoader(Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDLProxyNativeLibLoader;)V

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const-string v0, " l aybprtmesiai"

    const-string/jumbo v0, "tpsmi laa riney"

    const/4 v2, 0x3

    const-string v0, "entiayuas ril p"

    const-string/jumbo v0, "player has init"

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    throw p0
.end method

.method public static setOnLogListener(Lcom/tencent/thumbplayer/api/TPPlayerMgr$OnLogListener;)V
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->setOnLogListener(Lcom/tencent/thumbplayer/api/TPPlayerMgr$OnLogListener;)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public static setOutNetIP(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    invoke-static {p0}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->setOutNetIp(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public static setPropertyBool(Ljava/lang/String;Z)V
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mBooleanPropertyNameToPropertyHandlerTables:Ljava/util/HashMap;

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    check-cast p0, Lcom/tencent/thumbplayer/api/TPPlayerMgr$ITPPropertyHandler;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-interface {p0, p1}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$ITPPropertyHandler;->setPropertyValue(Ljava/lang/Object;)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public static setPropertyInteger(Ljava/lang/String;I)V
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const-string v0, "EdMtteOpnxVYCiRaeosTxCPediid_oRaMCPeo"

    const-string v0, "PROPERTY_VideoMediaCodecCoexistMaxCnt"

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {v0, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->setVideoMediaCodecCoexistMaxCnt(I)V

    :cond_0
    const/4 v2, 0x7

    return-void
.end method

.method public static setPropertyLong(Ljava/lang/String;J)V
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string/jumbo v0, "sPexyMmoqExRO_ToPeYaryMUBRrP"

    const-string/jumbo v0, "xPByoMeRRarysOPxYEm_UToMeMrP"

    const/4 v2, 0x0

    const-string v0, "MosPOYyRxaBTxPrr_yeeEoPMRmMs"

    const-string v0, "PROPERTY_ProxyMaxUseMemoryMB"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->setProxyMaxUseMemoryMB(J)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/c/i;->a()Lcom/tencent/thumbplayer/c/i;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/tencent/thumbplayer/c/i;->b(J)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public static setPropertyString(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    sget-object v0, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->mStringPropertyNameToPropertyHandlerTables:Ljava/util/HashMap;

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    check-cast p0, Lcom/tencent/thumbplayer/api/TPPlayerMgr$ITPPropertyHandler;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {p0, p1}, Lcom/tencent/thumbplayer/api/TPPlayerMgr$ITPPropertyHandler;->setPropertyValue(Ljava/lang/Object;)V

    :cond_0
    return-void
.end method

.method public static setProxyEnable(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p0}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->setP2PEnable(Z)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public static setProxyMaxStorageSizeMB(J)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo v1, "zermSixetxytbgrSaaeoM:Ps"

    const-string/jumbo v1, "x sePbtMrSee:ztiyaSxroag"

    const/4 v3, 0x0

    const-string/jumbo v1, "setProxyMaxStorageSize: "

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v1, ". MB"

    const-string v1, ". MB"

    const/4 v3, 0x5

    const-string v1, "B M."

    const-string v1, " MB."

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo v1, "lbTmoPyrMjr[yTavaPluhere.TaPuaP"

    const-string v1, "aaajP[uamvlPerTMr]TlbePTh.yyuPr"

    const/4 v3, 0x0

    const-string v1, "TPThumbPlayer[TPPlayerMgr.java]"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-static {p0, p1}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->setProxyMaxStorageSizeMB(J)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/c/i;->a()Lcom/tencent/thumbplayer/c/i;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, p0, p1}, Lcom/tencent/thumbplayer/c/i;->a(J)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method public static setProxyServiceType(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->setProxyServiceType(I)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public static setTPProxyAdapter(Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPProxyAdapter;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadProxyHelper;->setTPProxyAdapter(Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPProxyAdapter;)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public static setUpcInfo(Ljava/lang/String;I)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p0}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->setUserUpc(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->setUserUpcState(I)V

    const/4 v3, 0x6

    const v0, 0x186a3

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0, p1, v1, p0}, Lcom/tencent/thumbplayer/utils/f;->a(IIILjava/lang/Object;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method public static setUserInfo(Ljava/lang/String;Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->setUserUin(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->setUserIsVip(Z)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method
