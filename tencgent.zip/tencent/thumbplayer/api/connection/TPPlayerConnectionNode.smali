.class public Lcom/tencent/thumbplayer/api/connection/TPPlayerConnectionNode;
.super Ljava/lang/Object;


# instance fields
.field private nativeNode:Lcom/tencent/thumbplayer/core/connection/TPNativePlayerConnectionNode;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/core/connection/TPNativePlayerConnectionNode;

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/connection/TPNativePlayerConnectionNode;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/api/connection/TPPlayerConnectionNode;->nativeNode:Lcom/tencent/thumbplayer/core/connection/TPNativePlayerConnectionNode;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public addAction(I)Z
    .locals 4
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/connection/TPPlayerConnectionConstant$Action;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ sS~@r@@@~@tiob s o  fay@ K~~Mbl ~~@@o   ~~~~1~ 4oc@/@d@m~o@i~~~lo@ ~f~/v@t@b@~@ ~ -~@~ i  nu@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/connection/TPPlayerConnectionNode;->nativeNode:Lcom/tencent/thumbplayer/core/connection/TPNativePlayerConnectionNode;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionAction;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionAction;

    const/4 v3, 0x3

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionAction;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionAction;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v1, p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/core/connection/TPNativePlayerConnectionNode;->addAction(I)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    return p1
.end method

.method public getNativeNode()Lcom/tencent/thumbplayer/core/connection/TPNativePlayerConnectionNode;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/connection/TPPlayerConnectionNode;->nativeNode:Lcom/tencent/thumbplayer/core/connection/TPNativePlayerConnectionNode;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public removeAction(I)V
    .locals 4
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/connection/TPPlayerConnectionConstant$Action;
        .end annotation
    .end param

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/connection/TPPlayerConnectionNode;->nativeNode:Lcom/tencent/thumbplayer/core/connection/TPNativePlayerConnectionNode;

    const/4 v2, 0x4

    const/4 v2, 0x5

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionAction;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionAction;

    const/4 v3, 0x1

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionAction;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionAction;

    const/4 v3, 0x6

    invoke-static {v1, p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/core/connection/TPNativePlayerConnectionNode;->removeAction(I)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public setLongActionConfig(IIJ)Z
    .locals 4
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/connection/TPPlayerConnectionConstant$Action;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/connection/TPPlayerConnectionNode;->nativeNode:Lcom/tencent/thumbplayer/core/connection/TPNativePlayerConnectionNode;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionAction;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionAction;

    const/4 v3, 0x7

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionAction;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionAction;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v1, p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionConfig;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionConfig;

    const/4 v3, 0x7

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionConfig;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapConnectionConfig;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v1, p2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/core/connection/TPNativePlayerConnectionNode;->setLongActionConfig(IIJ)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    return p1
.end method
