.class final Lcom/tencent/thumbplayer/api/TPPlayerMgr$5;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDLProxyNativeLibLoader;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/api/TPPlayerMgr;->setLibLoader(Lcom/tencent/thumbplayer/api/ITPModuleLoader;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# instance fields
.field final synthetic val$loader:Lcom/tencent/thumbplayer/api/ITPModuleLoader;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/api/ITPModuleLoader;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPPlayerMgr$5;->val$loader:Lcom/tencent/thumbplayer/api/ITPModuleLoader;

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final loadLib(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "4os~l@ f /@~ ~~i  ~o  o~  ~i@@o @f~i@v @@~t~o.~m~@ yK~@~b~da/ @l @1@r@ tu M@~~~ bn-~s@@@~So~c@@b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPPlayerMgr$5;->val$loader:Lcom/tencent/thumbplayer/api/ITPModuleLoader;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/api/ITPModuleLoader;->loadLibrary(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 p1, 0x1

    const/4 v2, 0x3

    return p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string/jumbo p2, "jabmPvTTTarur[mPe]aglyPelsaP.yM"

    const-string/jumbo p2, "uesTlMae.Tl]mPvPaTjyaPabhry[gPr"

    const/4 v2, 0x3

    const-string p2, "aeryoThauleTmyPr[a]MgTPvrPlP.ja"

    const-string p2, "TPThumbPlayer[TPPlayerMgr.java]"

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    const/4 v1, 0x6

    move v2, v1

    const/4 p1, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return p1
.end method
