.class public Lcom/tencent/thumbplayer/api/TPSurfaceDolbyVisionInfo;
.super Ljava/lang/Object;


# instance fields
.field public mBlSignalCompatibilityId:I

.field public mLevel:I

.field public mProfile:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method
