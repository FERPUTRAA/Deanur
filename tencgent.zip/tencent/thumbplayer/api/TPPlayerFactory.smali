.class public Lcom/tencent/thumbplayer/api/TPPlayerFactory;
.super Ljava/lang/Object;


# static fields
.field private static final LOG_TAG:Ljava/lang/String; = "TPPlayerFactory"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public static createRichMediaASyncRequester(Landroid/content/Context;)Lcom/tencent/thumbplayer/api/richmedia/ITPRichMediaAsyncRequester;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ s~ i  ~@s~ ~~@-c  @o~@ol ~@S@~o~ob@4iu~@oab @ @@~~/~ r~1~t/o   ~i@d~ ~@bff~M@~ @l @.v@ty~mK@@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/f/a/a;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/f/a/a;-><init>(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object v0

    :catch_0
    move-exception p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v1, " lFmar aoieedacresqnysrua seem tid tehtc:e c"

    const-string/jumbo v1, "nesciFy ru alemes aaioqt eieae :dtdr hercsct"

    const-string v1, "esrmoidtt ee rdF:acntqe y e uaachlarierocies"

    const-string v1, "Failed to create rich media async requester:"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string v0, "PrroPbmtTaFlayy"

    const-string v0, "aacmlrTtPyorFPy"

    const/4 v3, 0x5

    const-string/jumbo v0, "tPaoePurryFlcay"

    const-string v0, "TPPlayerFactory"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 p0, 0x3

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object p0
.end method

.method public static createRichMediaSynchronizer(Landroid/content/Context;)Lcom/tencent/thumbplayer/api/richmedia/ITPRichMediaSynchronizer;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/f/b;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/f/b;-><init>(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0

    :catch_0
    move-exception p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const-string/jumbo v1, "iettcc po mdreFhn:erz   iioihodraycesrena"

    const-string v1, "crntortrzyo ahicisdFhcee: ionmieaedra  e "

    const/4 v3, 0x4

    const-string v1, "Failed to create rich media synchronizer:"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v0, "aeaoyryFqTtPcrl"

    const-string v0, "TPPlayerFactory"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p0
.end method

.method public static createTPPlayer(Landroid/content/Context;)Lcom/tencent/thumbplayer/api/ITPPlayer;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance v0, Lcom/tencent/thumbplayer/tplayer/b;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/tplayer/b;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-instance p0, Lcom/tencent/thumbplayer/tplayer/d;

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/tplayer/d;-><init>(Lcom/tencent/thumbplayer/tplayer/b;)V

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/tplayer/d;->a()Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    check-cast p0, Lcom/tencent/thumbplayer/api/ITPPlayer;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0
.end method

.method public static createTPPlayer(Landroid/content/Context;Landroid/os/Looper;)Lcom/tencent/thumbplayer/api/ITPPlayer;
    .locals 3

    const/4 v2, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/tplayer/b;

    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-direct {v0, p0, p1}, Lcom/tencent/thumbplayer/tplayer/b;-><init>(Landroid/content/Context;Landroid/os/Looper;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    new-instance p0, Lcom/tencent/thumbplayer/tplayer/d;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/tplayer/d;-><init>(Lcom/tencent/thumbplayer/tplayer/b;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/tplayer/d;->a()Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    check-cast p0, Lcom/tencent/thumbplayer/api/ITPPlayer;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p0
.end method

.method public static createTPPlayer(Landroid/content/Context;Landroid/os/Looper;Landroid/os/Looper;)Lcom/tencent/thumbplayer/api/ITPPlayer;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/tplayer/b;

    const/4 v2, 0x3

    invoke-direct {v0, p0, p1, p2}, Lcom/tencent/thumbplayer/tplayer/b;-><init>(Landroid/content/Context;Landroid/os/Looper;Landroid/os/Looper;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance p0, Lcom/tencent/thumbplayer/tplayer/d;

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/tplayer/d;-><init>(Lcom/tencent/thumbplayer/tplayer/b;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/tplayer/d;->a()Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast p0, Lcom/tencent/thumbplayer/api/ITPPlayer;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p0
.end method

.method public static createTPPlayer(Landroid/content/Context;Landroid/os/Looper;Landroid/os/Looper;Lcom/tencent/thumbplayer/e/b;)Lcom/tencent/thumbplayer/api/ITPPlayer;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/tplayer/b;

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/tencent/thumbplayer/tplayer/b;-><init>(Landroid/content/Context;Landroid/os/Looper;Landroid/os/Looper;Lcom/tencent/thumbplayer/e/b;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance p0, Lcom/tencent/thumbplayer/tplayer/d;

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/tplayer/d;-><init>(Lcom/tencent/thumbplayer/tplayer/b;)V

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/tplayer/d;->a()Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast p0, Lcom/tencent/thumbplayer/api/ITPPlayer;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0
.end method

.method public static createTPPlayer(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)Lcom/tencent/thumbplayer/api/ITPPlayer;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/tplayer/b;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v0, p0, v1, v1, p1}, Lcom/tencent/thumbplayer/tplayer/b;-><init>(Landroid/content/Context;Landroid/os/Looper;Landroid/os/Looper;Lcom/tencent/thumbplayer/e/b;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance p0, Lcom/tencent/thumbplayer/tplayer/d;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/tplayer/d;-><init>(Lcom/tencent/thumbplayer/tplayer/b;)V

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/tplayer/d;->a()Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast p0, Lcom/tencent/thumbplayer/api/ITPPlayer;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object p0
.end method

.method public static createTPSurface(Landroid/graphics/SurfaceTexture;)Lcom/tencent/thumbplayer/api/TPSurface;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/api/TPSurface;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/api/TPSurface;-><init>(Landroid/graphics/SurfaceTexture;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method
