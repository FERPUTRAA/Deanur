.class Lcom/tencent/thumbplayer/api/TPSurface$1;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/player/ITPNativePlayerSurfaceCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/api/TPSurface;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/tencent/thumbplayer/api/TPSurface;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/api/TPSurface;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPSurface$1;->this$0:Lcom/tencent/thumbplayer/api/TPSurface;

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onFlush()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "ofs@~-@fb@o ~ ~ ~@onuv~ts@lo~@K ~~ @o@~@@@ o~Sl~it  @~M@bc/~ b @ / a ~~ ~~@4~@i~1@~@ ~@ .m@~iyrd"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPSurface$1;->this$0:Lcom/tencent/thumbplayer/api/TPSurface;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/tencent/thumbplayer/api/TPSurface;->access$000(Lcom/tencent/thumbplayer/api/TPSurface;)Lcom/tencent/thumbplayer/api/ITPSurfaceListener;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {v0}, Lcom/tencent/thumbplayer/api/ITPSurfaceListener;->onFlush()V

    :cond_0
    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public onRenderInfo(Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceRenderInfo;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPSurface$1;->this$0:Lcom/tencent/thumbplayer/api/TPSurface;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/api/TPSurface;->access$000(Lcom/tencent/thumbplayer/api/TPSurface;)Lcom/tencent/thumbplayer/api/ITPSurfaceListener;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceRenderInfo;)Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/api/ITPSurfaceListener;->onRenderInfo(Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public onVideoPacket(Lcom/tencent/thumbplayer/core/common/TPVideoPacket;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPSurface$1;->this$0:Lcom/tencent/thumbplayer/api/TPSurface;

    const/4 v1, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/api/TPSurface;->access$000(Lcom/tencent/thumbplayer/api/TPSurface;)Lcom/tencent/thumbplayer/api/ITPSurfaceListener;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/core/common/TPVideoPacket;)Lcom/tencent/thumbplayer/api/TPVideoPacketBuffer;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/api/ITPSurfaceListener;->onVideoPacket(Lcom/tencent/thumbplayer/api/TPVideoPacketBuffer;)V

    :cond_0
    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method
