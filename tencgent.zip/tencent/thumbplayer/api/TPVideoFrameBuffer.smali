.class public Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;
.super Ljava/lang/Object;


# instance fields
.field public data:[[B

.field public dstHeight:I

.field public dstWidth:I

.field public flags:I

.field public format:I

.field public lineSize:[I

.field public ptsMs:J

.field public rotation:I

.field public srcHeight:I

.field public srcWidth:I

.field public trackID:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public getData()[[B
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~Ss~lt4m~l~f@@i@o o  t yn ~i@ ~ uaf@ oKo@~@~/d~@ . @@/-~ ~@b~o ~~~ @s ~~@r@@~ @ @b@o~M@~b1 ~i@vc"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->data:[[B

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public getDstHeight()I
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->dstHeight:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public getDstWidth()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->dstWidth:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    return v0
.end method

.method public getFlags()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->flags:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public getFormat()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->format:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public getLineSize()[I
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->lineSize:[I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public getPtsMs()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->ptsMs:J

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-wide v0
.end method

.method public getRotation()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->rotation:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public getSrcHeight()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->srcHeight:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    return v0
.end method

.method public getSrcWidth()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->srcWidth:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public getTrackID()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget v0, p0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->trackID:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    return v0
.end method
