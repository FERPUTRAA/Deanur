.class public Lcom/tencent/thumbplayer/api/composition/TPMediaCompositionFactory;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public static createEmptyTrackClip(IJJ)Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ sl~~~@@~@i@  K~@s ~~r~b~@o@b~~@4@vS@t@ ~@~@o.@niiM@f~~  -/~o fc~m@oo/u1a ~b@ y  ~  d~@ l~ot@  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    new-instance v0, Lcom/tencent/thumbplayer/b/a;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/b/a;-><init>(I)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/b/a;->setCutTimeRange(JJ)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public static createMediaAssetExtraParam()Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetExtraParam;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/b/b;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/tencent/thumbplayer/b/b;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public static createMediaAssetOrderedMap()Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetOrderedMap;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Lcom/tencent/thumbplayer/b/c;

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/tencent/thumbplayer/b/c;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public static createMediaComposition()Lcom/tencent/thumbplayer/api/composition/ITPMediaComposition;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/b/e;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/tencent/thumbplayer/b/e;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public static createMediaDRMAsset(ILjava/lang/String;)Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;
    .locals 3
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_DRM_TYPE;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/b/j;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0, p0, p1}, Lcom/tencent/thumbplayer/b/j;-><init>(ILjava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public static createMediaRTCAsset(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/b/k;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {v0, p0, p1}, Lcom/tencent/thumbplayer/b/k;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    return-object v0
.end method

.method public static createMediaRTCAsset(Ljava/lang/String;Ljava/lang/String;I)Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/b/k;

    const/4 v1, 0x5

    move v2, v1

    invoke-direct {v0, p0, p1, p2}, Lcom/tencent/thumbplayer/b/k;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public static createMediaTrack(I)Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/b/g;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/b/g;-><init>(I)V

    const/4 v2, 0x4

    return-object v0
.end method

.method public static createMediaTrack(ILjava/util/List;)Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;",
            ">;)",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/b/g;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/b/g;-><init>(I)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    check-cast p1, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/b/g;->addTrackClip(Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;)I

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public static varargs createMediaTrack(I[Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;)Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v0, Lcom/tencent/thumbplayer/b/g;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/b/g;-><init>(I)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    array-length p0, p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-ge v1, p0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    aget-object v2, p1, v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Lcom/tencent/thumbplayer/b/g;->addTrackClip(Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;)I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-object v0
.end method

.method public static createMediaTrackClip(Ljava/lang/String;I)Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    new-instance v0, Lcom/tencent/thumbplayer/b/h;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {v0, p0, p1}, Lcom/tencent/thumbplayer/b/h;-><init>(Ljava/lang/String;I)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public static createMediaTrackClip(Ljava/lang/String;IJJ)Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;
    .locals 9

    const/4 v8, 0x7

    new-instance v7, Lcom/tencent/thumbplayer/b/h;

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v8, 0x6

    move v2, p1

    move v2, p1

    move v2, p1

    move v2, p1

    move-wide v3, p2

    move-wide v5, p4

    const/4 v8, 0x5

    invoke-direct/range {v0 .. v6}, Lcom/tencent/thumbplayer/b/h;-><init>(Ljava/lang/String;IJJ)V

    const/4 v8, 0x1

    return-object v7
.end method

.method public static createMediaUrlAsset(Ljava/lang/String;)Lcom/tencent/thumbplayer/api/composition/ITPMediaUrlAsset;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/b/l;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/b/l;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method
