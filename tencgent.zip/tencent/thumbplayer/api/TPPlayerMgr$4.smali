.class final Lcom/tencent/thumbplayer/api/TPPlayerMgr$4;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/common/ITPNativeLibraryExternalLoader;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/api/TPPlayerMgr;->setLibLoader(Lcom/tencent/thumbplayer/api/ITPModuleLoader;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# instance fields
.field final synthetic val$loader:Lcom/tencent/thumbplayer/api/ITPModuleLoader;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/api/ITPModuleLoader;)V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/api/TPPlayerMgr$4;->val$loader:Lcom/tencent/thumbplayer/api/ITPModuleLoader;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final loadLib(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s~lb@@~y ~~ f @o1@nb~@@f@~S oail  K@@/   /~ cd~v~su@ ~oio@@@4 -i  ~@~m@t@r @~~@~.~ @~~b@~o~ Mt"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/api/TPPlayerMgr$4;->val$loader:Lcom/tencent/thumbplayer/api/ITPModuleLoader;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/api/ITPModuleLoader;->loadLibrary(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string/jumbo p2, "ylmmPhgPsTTPMerrub[.Pvajeaal]Ta"

    const-string p2, "aPshPjel]lPuTaT[ervbPgyyTam.rMa"

    const/4 v2, 0x6

    const-string p2, ".beuoyaPrPgTrhPyPvma]jelMaTrT[a"

    const-string p2, "TPThumbPlayer[TPPlayerMgr.java]"

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 p1, 0x0

    move v2, p1

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    return p1
.end method
