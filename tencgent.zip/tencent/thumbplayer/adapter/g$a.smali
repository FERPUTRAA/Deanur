.class Lcom/tencent/thumbplayer/adapter/g$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/adapter/a/c$a;
.implements Lcom/tencent/thumbplayer/adapter/a/c$b;
.implements Lcom/tencent/thumbplayer/adapter/a/c$c;
.implements Lcom/tencent/thumbplayer/adapter/a/c$d;
.implements Lcom/tencent/thumbplayer/adapter/a/c$e;
.implements Lcom/tencent/thumbplayer/adapter/a/c$f;
.implements Lcom/tencent/thumbplayer/adapter/a/c$g;
.implements Lcom/tencent/thumbplayer/adapter/a/c$h;
.implements Lcom/tencent/thumbplayer/adapter/a/c$i;
.implements Lcom/tencent/thumbplayer/adapter/a/c$j;
.implements Lcom/tencent/thumbplayer/adapter/a/c$k;
.implements Lcom/tencent/thumbplayer/adapter/a/c$l;
.implements Lcom/tencent/thumbplayer/adapter/a/c$m;
.implements Lcom/tencent/thumbplayer/adapter/a/c$n;
.implements Lcom/tencent/thumbplayer/adapter/a/c$o;
.implements Lcom/tencent/thumbplayer/adapter/a/c$p;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/adapter/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# instance fields
.field private a:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/g$a;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~os n@~t ~@ r4f~~~y@@ ~od Ml~a .1@@~l@~~ob~~bo~~@f@im-S   c~ b@~o~t@o~ v@ @@/@/ u@@  ~@@s@ i~~ K"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p1
.end method


# virtual methods
.method public a(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string v0, "be mse,oerotemmPOF suVndefasyye c liro  rstaeinot ,sit"

    const-string/jumbo v0, "ioseoPer uno,eny ssVi mie ,tsafrobde  tsFcOeenarty ltm"

    const/4 v2, 0x3

    const-string v0, " ouoo i an ry,PtptVeec sssaoyeteeimsmoin n Fr,rbeOfdle"

    const-string v0, " empty base listener , notify , onVideoProcessFrameOut"

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p1
.end method

.method public a(Ljava/lang/String;I)Lcom/tencent/thumbplayer/api/TPRemoteSdpInfo;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    const-string/jumbo p2, "opeSebmonbidn t,etnt  ygeipfaayx,cshmr   enl "

    const-string/jumbo p2, "i,omnpne,acnthosepfnm isl e ba rgedSt  yetyx "

    const-string/jumbo p2, "ex d cuEnegalnoesehoti tr nm y ysnfSp,pbt,i a"

    const-string p2, " empty base listener , notify , onSdpExchange"

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p1
.end method

.method public a()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const-string/jumbo v1, "p ris rptm,b,rso  Pe any eey elnoteodpfain"

    const-string/jumbo v1, "eyneosreo,edPnepbo alpsi  ytt rfn,ai   rtm"

    const/4 v3, 0x5

    const-string/jumbo v1, "meppir rqft,oe  rto sedePnntes,nya  lbei a"

    const-string v1, " empty base listener , notify , onPrepared"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public a(IIJJ)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v1, 0x5

    const-string/jumbo p2, "yssep nref  nrs,,broet aybt ol inEremo "

    const-string/jumbo p2, "o  ntb  msar eret,,ioernbnoiplsrfeyE y "

    const-string/jumbo p2, "ne mrftobty, m  nrEoyplesoi s e,itrne r"

    const-string p2, " empty base listener , notify , onError"

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public a(IJJLjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    const-string p2, ", fyoonm Iaeletenpn y i soi  t,robtefn"

    const-string/jumbo p2, "yeI, tu lnnane s mtrebifoy t poo ief,n"

    const/4 v1, 0x7

    const-string p2, "bni nbtnfyrpi yot   eofes,m s alnteIe,"

    const-string p2, " empty base listener , notify , onInfo"

    const/4 v1, 0x4

    const/4 v0, 0x0

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public a(JJ)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    const-string p2, "efVtyiuea teietby nnas  C ogdp,Se dnniir hopleemoz"

    const-string p2, "e ezifop iSy  eon  ognaeb,Cidne ytlpihntadeetsVsmr"

    const/4 v1, 0x0

    const-string/jumbo p2, "stfyi aphe t,osgd niptbCVdenynSle o  ,arzine oeiee"

    const-string p2, " empty base listener , notify , onVideoSizeChanged"

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v0, " fp ottOqeimAee n euryaFybettniriol,qd nusmo s "

    const-string/jumbo v0, "tomtFe tqeu pAtyrse m edln ,o isyin Ofrnuaibaoe"

    const/4 v2, 0x7

    const-string v0, "b s s oedmtltreaAuonnis fiOaeteto yrpi,yem,F nu"

    const-string v0, " empty base listener , notify , onAudioFrameOut"

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x3

    or-int/2addr v2, v1

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPDrmInfo;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    const-string/jumbo v0, "yvs snrsneee, r  doibfamElny  epe ,ttcoteonit"

    const/4 v2, 0x7

    const-string v0, ",iemnoco dt vEnebsaietof, eRentemprs yrn ytl "

    const-string v0, " empty base listener , notify , onEventRecord"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPPlayerDetailInfo;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string/jumbo v0, "s  ,oe  myDetnf,rlaeeyapnnIi fomtlt nitoseio"

    const-string/jumbo v0, "lotm nI iieirennm pa,,fs  ayoleyesntD f etto"

    const/4 v2, 0x2

    const-string v0, " lo eb eltm oi sey nnbIrneo tanftiat,psy,Dfe"

    const-string v0, " empty base listener , notify , onDetailInfo"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPSubtitleData;)V
    .locals 3

    const/4 v1, 0x6

    move v2, v1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string v0, "et  nouoi  e,asaey u ftnlbst,irbna eDltmyteipS"

    const-string v0, "berooiit  a tu yt,oinnyalnameelS  seseptfbD,t "

    const/4 v2, 0x0

    const-string/jumbo v0, "t,t Datpsna,epi lbyyoitrf  iobnmSetsnela   eue"

    const-string v0, " empty base listener , notify , onSubtitleData"

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v2, 0x6

    const-string/jumbo v0, "fmsl uFbqyleei Pmp tfye,Ba obneint,etra sTfrttuS eire"

    const-string v0, " empty base listener , notify , TPSubtitleFrameBuffer"

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string v0, "FrsebnpO e  o etmye,e, ttbtiaasonnfrd siyViu le"

    const-string/jumbo v0, "srtbnbVeeynreto eaains uomp ,  yoitOfe ,Fde ilt"

    const/4 v2, 0x5

    const-string/jumbo v0, "op,mtlbetro nm  fe,ts e nOayiyismneeFaiV todre "

    const-string v0, " empty base listener , notify , onVideoFrameOut"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    return-void
.end method

.method public b(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const-string v0, "e esos,yo l nreaie onsdooiOmrrabuPt  yfA ipetmeuFu,tcn"

    const-string/jumbo v0, "rf eFcue bonond eol mi uyytmsis,OansAPeriuap stteero ,"

    const/4 v2, 0x4

    const-string v0, " eaarbFtylei  ,t dfiteuyprnsmo s iOrePsb nmoAuscot,eoe"

    const-string v0, " empty base listener , notify , onAudioProcessFrameOut"

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x0

    move v2, p1

    move v1, p1

    move v1, p1

    const/4 v2, 0x1

    return-object p1
.end method

.method public b()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string/jumbo v1, "m,l omueiep arstpio p tt,inlsneoeoen yb ftn "

    const-string v1, "eeitiryp absem ofetnm lop  no Coenltp, ,sint"

    const/4 v3, 0x7

    const-string v1, " o nysfpittbiyn, reeooepen Cop  tnmaetsm ll,"

    const-string v1, " empty base listener , notify , onCompletion"

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void
.end method

.method public b(II)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    const-string p2, ",nimft lq ae hpyi ttraqeng CsSe,santy e nboee"

    const-string/jumbo p2, "ys enn,eqit nerg eSa pt stol Cofnemtahieya,b "

    const/4 v1, 0x2

    const-string/jumbo p2, "h ssyi tCeyap e s,inrabt t ogmne,eetaflt eonn"

    const-string p2, " empty base listener , notify , onStateChange"

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x3

    move v1, v0

    return-void
.end method

.method public c()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g$a;->a:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string/jumbo v1, "pmsenttle tkipeS bs o n ,tieore yymClofe aes,n"

    const/4 v3, 0x2

    const-string v1, "enfmt slemspCntreS,yekoni am yie op eo  e,telt"

    const-string v1, " empty base listener , notify , onSeekComplete"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void
.end method
