.class public Lcom/tencent/thumbplayer/adapter/f;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/reflect/InvocationHandler;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/adapter/f$a;
    }
.end annotation


# static fields
.field private static final f:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Class;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private a:Lcom/tencent/thumbplayer/adapter/d;

.field private b:Lcom/tencent/thumbplayer/tplayer/a;

.field private c:Lcom/tencent/thumbplayer/adapter/g;

.field private d:Lcom/tencent/thumbplayer/adapter/f$a;

.field private e:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v3, 0x7

    move v4, v3

    sput-object v0, Lcom/tencent/thumbplayer/adapter/f;->f:Ljava/util/Map;

    const/4 v3, 0x7

    or-int/2addr v4, v3

    const-string v1, "eOserirpsetsnedPsrnat"

    const-string v1, "epsesOrrdPttinernease"

    const/4 v4, 0x3

    const-string/jumbo v1, "nrrmtneeLdspaiPeeOesr"

    const-string/jumbo v1, "setOnPreparedListener"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$i;

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$i;

    const/4 v4, 0x3

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$i;

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$i;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo v1, "ntemifLseInOsrnte"

    const/4 v4, 0x5

    const-string/jumbo v1, "tesLotienensnrIOf"

    const-string/jumbo v1, "setOnInfoListener"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$h;

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$h;

    const/4 v4, 0x3

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$h;

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$h;

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo v1, "nierorOotsntereELr"

    const/4 v4, 0x5

    const-string v1, "eerEebrsLnrrttsion"

    const-string/jumbo v1, "setOnErrorListener"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$f;

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$f;

    const/4 v4, 0x1

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$f;

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$f;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string v1, "eOnkseueLCemSbpneilsterto"

    const-string v1, "emLepberttenkCesOnlsSieoe"

    const/4 v4, 0x0

    const-string/jumbo v1, "tCLnkeSpsnemopeeOeiterlte"

    const-string/jumbo v1, "setOnSeekCompleteListener"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$j;

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$j;

    const/4 v4, 0x1

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$j;

    const-class v2, Lcom/tencent/thumbplayer/adapter/a/c$j;

    const/4 v4, 0x5

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-void
.end method

.method public constructor <init>(Lcom/tencent/thumbplayer/adapter/d;Lcom/tencent/thumbplayer/tplayer/a;)V
    .locals 4
    .param p1    # Lcom/tencent/thumbplayer/adapter/d;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/tencent/thumbplayer/tplayer/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v1, "rxdrPtalqyAeyoupPera"

    const-string/jumbo v1, "yayPpeuPltaArreoPxrd"

    const-string v1, "TPPlayerAdapterProxy"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Lcom/tencent/thumbplayer/adapter/g;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->c:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/adapter/f$a;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x7

    invoke-direct {v0, p0, v1}, Lcom/tencent/thumbplayer/adapter/f$a;-><init>(Lcom/tencent/thumbplayer/adapter/f;Lcom/tencent/thumbplayer/adapter/f$1;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->d:Lcom/tencent/thumbplayer/adapter/f$a;

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/f;->a:Lcom/tencent/thumbplayer/adapter/d;

    const/4 v2, 0x5

    move v3, v2

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/f;->b:Lcom/tencent/thumbplayer/tplayer/a;

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/adapter/d;->a(Lcom/tencent/thumbplayer/adapter/a/c$g;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/adapter/d;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~osb@S i l ~ d~@f4@@~u~@@ ~@~~m sb @o @~a~iK@/t  @ ~~o -br@~M~~~ t@  .@f@@@cl ~@o~y~o1i @~o/n~~v"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/f;->a:Lcom/tencent/thumbplayer/adapter/d;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p0
.end method

.method private static a(Ljava/lang/reflect/Method;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string v0, "anemolp"

    const-string/jumbo v0, "plnaoeo"

    const/4 v3, 0x7

    const-string/jumbo v0, "onaoobl"

    const-string v0, "boolean"

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo v0, "tni"

    const-string/jumbo v0, "int"

    const/4 v3, 0x5

    const-string/jumbo v0, "int"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    return-object p0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string/jumbo v0, "gnol"

    const-string/jumbo v0, "glon"

    const/4 v3, 0x0

    const-string/jumbo v0, "glon"

    const-string/jumbo v0, "long"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p0

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v0, "bftqa"

    const-string v0, "atoqf"

    const/4 v3, 0x4

    const-string/jumbo v0, "lufot"

    const-string/jumbo v0, "float"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz p0, :cond_3

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object p0

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object p0
.end method

.method private a(Ljava/lang/reflect/Method;[Ljava/lang/Object;)V
    .locals 4
    .param p1    # Ljava/lang/reflect/Method;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v1, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    sparse-switch v0, :sswitch_data_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto/16 :goto_0

    :sswitch_0
    const/4 v2, 0x0

    move v3, v2

    const-string/jumbo v0, "plaerse"

    const-string/jumbo v0, "lssreea"

    const/4 v3, 0x0

    const-string/jumbo v0, "rqalees"

    const-string/jumbo v0, "release"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    goto/16 :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/16 v1, 0x8

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto/16 :goto_0

    :sswitch_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string/jumbo v0, "itsaRSPdeepaomyls"

    const-string v0, "SPimloaetdpstyRea"

    const/4 v3, 0x5

    const-string v0, "adSmtyRiaosePeplt"

    const-string/jumbo v0, "setPlaySpeedRatio"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto/16 :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x7

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    goto/16 :goto_0

    :sswitch_2
    const/4 v3, 0x1

    const/4 v2, 0x2

    const-string/jumbo v0, "rcosoeeclkT"

    const-string v0, "ekleocrsaTc"

    const/4 v3, 0x6

    const-string/jumbo v0, "skcltbcTera"

    const-string/jumbo v0, "selectTrack"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez p1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    goto/16 :goto_0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x6

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto/16 :goto_0

    :sswitch_3
    const/4 v3, 0x1

    const-string/jumbo v0, "turst"

    const-string/jumbo v0, "start"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez p1, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto/16 :goto_0

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v1, 0x5

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    goto/16 :goto_0

    :sswitch_4
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string v0, "ebpst"

    const-string v0, "bstre"

    const/4 v3, 0x3

    const-string/jumbo v0, "etsqe"

    const-string/jumbo v0, "reset"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez p1, :cond_4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto/16 :goto_0

    :cond_4
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x4

    const/4 v3, 0x4

    const/4 v2, 0x5

    goto/16 :goto_0

    :sswitch_5
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string/jumbo v0, "uasps"

    const-string/jumbo v0, "pusua"

    const/4 v3, 0x1

    const-string/jumbo v0, "pause"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez p1, :cond_5

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :cond_5
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x3

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_0

    :sswitch_6
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo v0, "otsp"

    const-string/jumbo v0, "ptso"

    const/4 v3, 0x3

    const-string/jumbo v0, "ptso"

    const-string/jumbo v0, "stop"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez p1, :cond_6

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    goto :goto_0

    :cond_6
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :sswitch_7
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string/jumbo v0, "poemeT"

    const-string v0, "Tpsoee"

    const/4 v3, 0x0

    const-string/jumbo v0, "skeooe"

    const-string/jumbo v0, "seekTo"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez p1, :cond_7

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :cond_7
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    goto :goto_0

    :sswitch_8
    const/4 v3, 0x1

    const/4 v2, 0x4

    const-string v0, "cpAyabpresnr"

    const-string/jumbo v0, "nrrpyseaqcAp"

    const/4 v3, 0x7

    const-string/jumbo v0, "nrseApupceay"

    const-string/jumbo v0, "prepareAsync"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez p1, :cond_8

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :cond_8
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    packed-switch v1, :pswitch_data_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_1

    :pswitch_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {p0, p2}, Lcom/tencent/thumbplayer/adapter/f;->f([Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void

    :pswitch_1
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {p0, p2}, Lcom/tencent/thumbplayer/adapter/f;->h([Ljava/lang/Object;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void

    :pswitch_2
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p0, p2}, Lcom/tencent/thumbplayer/adapter/f;->i([Ljava/lang/Object;)V

    :goto_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void

    :pswitch_3
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p0, p2}, Lcom/tencent/thumbplayer/adapter/f;->b([Ljava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    :pswitch_4
    const/4 v2, 0x1

    const/4 v2, 0x5

    invoke-direct {p0, p2}, Lcom/tencent/thumbplayer/adapter/f;->e([Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void

    :pswitch_5
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {p0, p2}, Lcom/tencent/thumbplayer/adapter/f;->c([Ljava/lang/Object;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    return-void

    :pswitch_6
    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-direct {p0, p2}, Lcom/tencent/thumbplayer/adapter/f;->d([Ljava/lang/Object;)V

    const/4 v3, 0x3

    return-void

    :pswitch_7
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p0, p2}, Lcom/tencent/thumbplayer/adapter/f;->g([Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void

    :pswitch_8
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {p0, p2}, Lcom/tencent/thumbplayer/adapter/f;->a([Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void

    :sswitch_data_0
    .sparse-switch
        -0x7a89ee4b -> :sswitch_8
        -0x3603e4ed -> :sswitch_7
        0x360802 -> :sswitch_6
        0x65825f6 -> :sswitch_5
        0x6761d4f -> :sswitch_4
        0x68ac462 -> :sswitch_3
        0xc3b89af -> :sswitch_2
        0xd079f5a -> :sswitch_1
        0x41012807 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private a([Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/tplayer/a;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/f;->b:Lcom/tencent/thumbplayer/tplayer/a;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p0
.end method

.method private b(Ljava/lang/reflect/Method;[Ljava/lang/Object;)V
    .locals 7
    .param p1    # Ljava/lang/reflect/Method;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/adapter/f;->f:Ljava/util/Map;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-nez v1, :cond_0

    const/4 v6, 0x0

    return-void

    :cond_0
    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/f;->c:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-virtual {p1}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v3, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p1}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x0

    check-cast p1, Ljava/lang/Class;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v0, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    aput-object p1, v4, v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/f;->c:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    aget-object v3, p2, v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    aput-object v3, v2, v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p1, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/f;->d:Lcom/tencent/thumbplayer/adapter/f$a;

    aput-object p1, p2, v0
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    return-void

    :catch_0
    move-exception p1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    return-void

    :catch_1
    move-exception p1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v6, 0x7

    return-void

    :catch_2
    move-exception p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v6, 0x4

    const/4 v5, 0x1

    return-void
.end method

.method private b([Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance p1, Lcom/tencent/thumbplayer/d/b$m;

    const/4 v2, 0x2

    invoke-direct {p1}, Lcom/tencent/thumbplayer/d/b$m;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->b:Lcom/tencent/thumbplayer/tplayer/a;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method static synthetic c(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/adapter/g;
    .locals 2

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/f;->c:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v1, 0x0

    return-object p0
.end method

.method private c([Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance p1, Lcom/tencent/thumbplayer/d/b$j;

    const/4 v1, 0x7

    const/4 v1, 0x0

    invoke-direct {p1}, Lcom/tencent/thumbplayer/d/b$j;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->b:Lcom/tencent/thumbplayer/tplayer/a;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method private d([Ljava/lang/Object;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance p1, Lcom/tencent/thumbplayer/d/b$n;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {p1}, Lcom/tencent/thumbplayer/d/b$n;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->a:Lcom/tencent/thumbplayer/adapter/d;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/d;->u()Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;-><init>()V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/d/b$n;->a(Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->a:Lcom/tencent/thumbplayer/adapter/d;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/d;->c(Z)Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v0, Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;-><init>()V

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/d/b$n;->a(Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->b:Lcom/tencent/thumbplayer/tplayer/a;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method

.method private e([Ljava/lang/Object;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance p1, Lcom/tencent/thumbplayer/d/b$l;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {p1}, Lcom/tencent/thumbplayer/d/b$l;-><init>()V

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->a:Lcom/tencent/thumbplayer/adapter/d;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/d;->u()Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;-><init>()V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/d/b$l;->a(Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->a:Lcom/tencent/thumbplayer/adapter/d;

    const/4 v3, 0x5

    const/4 v1, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/d;->c(Z)Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;-><init>()V

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/d/b$l;->a(Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;)V

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->b:Lcom/tencent/thumbplayer/tplayer/a;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method

.method private f([Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance p1, Lcom/tencent/thumbplayer/d/b$k;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p1}, Lcom/tencent/thumbplayer/d/b$k;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->b:Lcom/tencent/thumbplayer/tplayer/a;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method private g([Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance p1, Lcom/tencent/thumbplayer/d/b$r;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p1}, Lcom/tencent/thumbplayer/d/b$r;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->b:Lcom/tencent/thumbplayer/tplayer/a;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method private h([Ljava/lang/Object;)V
    .locals 4

    const/4 v2, 0x3

    move v3, v2

    new-instance v0, Lcom/tencent/thumbplayer/d/b$v;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0}, Lcom/tencent/thumbplayer/d/b$v;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    aget-object p1, p1, v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    check-cast p1, Ljava/lang/Float;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/d/b$v;->a(F)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/f;->b:Lcom/tencent/thumbplayer/tplayer/a;

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method private i([Ljava/lang/Object;)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/d/b$t;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {v0}, Lcom/tencent/thumbplayer/d/b$t;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    aget-object v2, p1, v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    check-cast v2, Ljava/lang/Integer;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, v2}, Lcom/tencent/thumbplayer/d/b$t;->b(I)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    aget-object v2, p1, v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    check-cast v2, Ljava/lang/Long;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0, v2, v3}, Lcom/tencent/thumbplayer/d/b$t;->a(J)V

    const/4 v4, 0x3

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/f;->a:Lcom/tencent/thumbplayer/adapter/d;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v2}, Lcom/tencent/thumbplayer/adapter/d;->r()[Lcom/tencent/thumbplayer/api/TPTrackInfo;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    aget-object p1, p1, v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    check-cast p1, Ljava/lang/Integer;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    aget-object p1, v2, p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/d/b$t;->a(Lcom/tencent/thumbplayer/api/TPTrackInfo;)V

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/f;->b:Lcom/tencent/thumbplayer/tplayer/a;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-void
.end method


# virtual methods
.method public declared-synchronized a()Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->e:Ljava/lang/Object;

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->a:Lcom/tencent/thumbplayer/adapter/d;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/f;->a:Lcom/tencent/thumbplayer/adapter/d;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v1}, Ljava/lang/Class;->getInterfaces()[Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0, v1, p0}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->e:Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f;->e:Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    monitor-exit p0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    monitor-exit p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    throw v0
.end method

.method public invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x6

    const-string/jumbo p1, "n:pieeapxs ct osc"

    const-string/jumbo p1, "pxs: csh ecaneoti"

    const/4 v4, 0x1

    const-string p1, "cixt caoqh :nespe"

    const-string p1, " has excecption: "

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string v0, "dMsevtnmo eho"

    const-string/jumbo v0, "hkemoevdo tMn"

    const/4 v4, 0x3

    const-string/jumbo v0, "vinmk othMode"

    const-string/jumbo v0, "invokeMethod "

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo v1, "roTroxlyatdPAPpeayPr"

    const-string v1, "AoreoytPprPadPaTrxyl"

    const/4 v4, 0x0

    const-string/jumbo v1, "yPrrdbxrtoeAyaePpaPl"

    const-string v1, "TPPlayerAdapterProxy"

    :try_start_0
    const/4 v3, 0x0

    move v4, v3

    invoke-direct {p0, p2, p3}, Lcom/tencent/thumbplayer/adapter/f;->a(Ljava/lang/reflect/Method;[Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-direct {p0, p2, p3}, Lcom/tencent/thumbplayer/adapter/f;->b(Ljava/lang/reflect/Method;[Ljava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/f;->a:Lcom/tencent/thumbplayer/adapter/d;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p2, v2, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object p1

    :catchall_0
    move-exception p3

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    invoke-virtual {p3}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v1, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {p2}, Lcom/tencent/thumbplayer/adapter/f;->a(Ljava/lang/reflect/Method;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object p1

    :catch_0
    move-exception p3

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p3}, Ljava/lang/reflect/InvocationTargetException;->getTargetException()Ljava/lang/Throwable;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-nez v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p3}, Ljava/lang/reflect/InvocationTargetException;->getTargetException()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    throw p1
.end method
