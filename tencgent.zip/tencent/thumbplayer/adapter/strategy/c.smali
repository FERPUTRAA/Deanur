.class public Lcom/tencent/thumbplayer/adapter/strategy/c;
.super Lcom/tencent/thumbplayer/adapter/strategy/b;


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/adapter/strategy/a/a;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/b;-><init>(Lcom/tencent/thumbplayer/adapter/strategy/a/a;)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    return-void
.end method


# virtual methods
.method protected a(Lcom/tencent/thumbplayer/adapter/strategy/a/b;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~soo@ ~@~lof@@/~~o~m4~@ @~~ s.@i v~ @c@ @oa@1~- ub@ifni~yb~db /~~@~t  @ @lS~~ @ ~M ~@Kt @@@ ~ro"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    return p1
.end method
