.class public abstract Lcom/tencent/thumbplayer/adapter/strategy/b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/adapter/strategy/a;


# instance fields
.field protected a:Lcom/tencent/thumbplayer/adapter/strategy/a/a;


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/adapter/strategy/a/a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/strategy/b;->a:Lcom/tencent/thumbplayer/adapter/strategy/a/a;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a(Lcom/tencent/thumbplayer/adapter/b;)I
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/strategy/b;->a:Lcom/tencent/thumbplayer/adapter/strategy/a/a;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->a()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/4 v1, 0x2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v2, 0x1

    const/4 v6, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz v0, :cond_a

    const/4 v5, 0x4

    move v6, v5

    if-eq v0, v2, :cond_8

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eq v0, v1, :cond_5

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v4, 0x3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eq v0, v4, :cond_3

    const/4 v6, 0x5

    const/4 v4, 0x4

    const/4 v6, 0x4

    or-int/2addr v5, v4

    const/4 v6, 0x5

    if-eq v0, v4, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x6

    return v3

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/b;->c(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eqz p1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x6

    return v2

    :cond_1
    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPStrategyUtils;->isThumbPlayerEnable()Z

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz p1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    return v1

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    return v3

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/b;->c(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-eqz p1, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x7

    return v2

    :cond_4
    const/4 v6, 0x1

    return v3

    :cond_5
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/b;->b(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz p1, :cond_6

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    return v1

    :cond_6
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPStrategyUtils;->isSystemPlayerEnable()Z

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz p1, :cond_7

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    return v2

    :cond_7
    const/4 v6, 0x4

    return v3

    :cond_8
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/b;->b(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz p1, :cond_9

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    return v1

    :cond_9
    const/4 v6, 0x7

    const/4 v5, 0x3

    return v3

    :cond_a
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/b;->b(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz p1, :cond_b

    const/4 v5, 0x5

    const/4 v5, 0x5

    return v1

    :cond_b
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPStrategyUtils;->isSystemPlayerEnable()Z

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz p1, :cond_c

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    return v2

    :cond_c
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    return v3
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/b;Lcom/tencent/thumbplayer/adapter/strategy/a/b;)I
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/strategy/b;->a:Lcom/tencent/thumbplayer/adapter/strategy/a/a;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->a()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz p2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/adapter/strategy/a/b;->a()I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-nez v1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/b;->a(Lcom/tencent/thumbplayer/adapter/b;)I

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    return p1

    :cond_0
    const/4 v6, 0x6

    invoke-virtual {p0, p2}, Lcom/tencent/thumbplayer/adapter/strategy/b;->a(Lcom/tencent/thumbplayer/adapter/strategy/a/b;)Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v2, 0x0

    move v6, v2

    const/4 v5, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-nez v1, :cond_1

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    return v2

    :cond_1
    const/4 v5, 0x5

    move v6, v5

    const/4 v1, 0x1

    xor-int/2addr v6, v1

    const/4 v5, 0x5

    xor-int/2addr v6, v5

    const/4 v3, 0x2

    shl-int/2addr v6, v3

    const/4 v5, 0x7

    shr-int/2addr v6, v5

    if-eqz v0, :cond_6

    const/4 v6, 0x3

    if-eq v0, v3, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x4

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eq v0, v4, :cond_2

    const/4 v6, 0x6

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz p2, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/adapter/strategy/a/b;->a()I

    move-result p2

    const/4 v6, 0x0

    if-ne p2, v1, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/b;->b(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz p1, :cond_3

    const/4 v5, 0x7

    and-int/2addr v6, v5

    return v3

    :cond_3
    const/4 v6, 0x4

    return v2

    :cond_4
    const/4 v6, 0x0

    if-eqz p2, :cond_5

    const/4 v5, 0x0

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/adapter/strategy/a/b;->a()I

    move-result p2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-ne p2, v3, :cond_5

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/b;->c(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz p1, :cond_5

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    return v1

    :cond_5
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    return v2

    :cond_6
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz p2, :cond_8

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/adapter/strategy/a/b;->a()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-ne v0, v1, :cond_8

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/b;->b(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz p1, :cond_7

    const/4 v6, 0x2

    const/4 v5, 0x3

    return v3

    :cond_7
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    return v2

    :cond_8
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz p2, :cond_9

    const/4 v6, 0x4

    const/4 v5, 0x0

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/adapter/strategy/a/b;->a()I

    move-result p2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-ne p2, v3, :cond_9

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/b;->c(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz p1, :cond_9

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    return v1

    :cond_9
    :goto_0
    const/4 v5, 0x4

    const/4 v5, 0x4

    return v2
.end method

.method protected a(Lcom/tencent/thumbplayer/adapter/strategy/a/b;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return p1
.end method

.method public a()[I
    .locals 6

    const/4 v4, 0x4

    move v5, v4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/strategy/b;->a:Lcom/tencent/thumbplayer/adapter/strategy/a/a;

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->b()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/16 v1, 0x65

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/16 v2, 0x66

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v0, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v3, 0x1

    if-eq v0, v3, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v3, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x4

    if-eq v0, v3, :cond_3

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v5, 0x2

    move v4, v3

    move v4, v3

    const/4 v5, 0x0

    if-eq v0, v3, :cond_1

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v3, 0x4

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eq v0, v3, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    filled-new-array {v1, v2}, [I

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    filled-new-array {v1}, [I

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    filled-new-array {v2}, [I

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_0

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    filled-new-array {v2, v1}, [I

    move-result-object v0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-object v0
.end method

.method b(Lcom/tencent/thumbplayer/adapter/b;)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPStrategyUtils;->isTVPlatform()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPStrategyUtils;->isThumbPlayerEnable()Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPStrategyUtils;->isThumbPlayerEnable()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPStrategyUtils;->enablePlayByThumbPlayer(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    if-eqz p1, :cond_1

    const/4 v2, 0x3

    const/4 p1, 0x1

    const/4 v2, 0x4

    shl-int/2addr v1, p1

    return p1

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    return p1
.end method

.method c(Lcom/tencent/thumbplayer/adapter/b;)Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPStrategyUtils;->isTVPlatform()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    return v1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPStrategyUtils;->isSystemPlayerEnable()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPStrategyUtils;->enablePlayBySystemPlayer(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz p1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    return v1

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    return p1
.end method
