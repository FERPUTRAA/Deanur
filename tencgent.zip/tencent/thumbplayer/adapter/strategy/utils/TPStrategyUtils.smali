.class public Lcom/tencent/thumbplayer/adapter/strategy/utils/TPStrategyUtils;
.super Ljava/lang/Object;


# static fields
.field private static final TAG:Ljava/lang/String; = "TPStrategyUtils"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public static enablePlayBySystemPlayer(Lcom/tencent/thumbplayer/adapter/b;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s~@ @~/d~fm b~@~l~oo@@l~c@ s@~- ~ fro~o u~t~yS~~K v1/@o @.i@~M~i @ @@~4@ai@ b @ @o@~ n b @~~ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/b;->m()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v1, 0x0

    move v2, v1

    const/4 p0, 0x7

    const/4 p0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPStrategyUtils;->isSupportMediaCodec(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    return p0
.end method

.method public static enablePlayByThumbPlayer(Lcom/tencent/thumbplayer/adapter/b;)Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    return v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/b;->m()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    return v0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPStrategyUtils;->isSupportFFmpegCodec(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez v1, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPStrategyUtils;->isSupportMediaCodec(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz p0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_0

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    return p0

    :cond_3
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    return v0
.end method

.method public static isSupportFFmpegCodec(Lcom/tencent/thumbplayer/adapter/b;)Z
    .locals 8

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/16 v0, 0x65

    :try_start_0
    const/4 v7, 0x0

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const/4 v7, 0x4

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/b;->m()I

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/b;->a()J

    move-result-wide v2

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    long-to-int v2, v2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/b;->b()J

    move-result-wide v3

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    long-to-int v3, v3

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/b;->e()I

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/b;->g()I

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static/range {v0 .. v5}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->isVCodecCapabilitySupport(IIIIII)Z

    move-result p0
    :try_end_0
    .catch Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    return p0

    :catch_0
    move-exception p0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string/jumbo v0, "saPmtetiglytrsT"

    const-string/jumbo v0, "yastisgeSlTttPr"

    const/4 v7, 0x5

    const-string/jumbo v0, "gtTUoPlSerttsia"

    const-string v0, "TPStrategyUtils"

    const/4 v7, 0x4

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 p0, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    return p0
.end method

.method public static isSupportMediaCodec(Lcom/tencent/thumbplayer/adapter/b;)Z
    .locals 8

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/16 v0, 0x66

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const/4 v7, 0x6

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/b;->m()I

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x7

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/b;->a()J

    move-result-wide v2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    long-to-int v2, v2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/b;->b()J

    move-result-wide v3

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    long-to-int v3, v3

    const/4 v7, 0x1

    const/4 v6, 0x1

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/b;->e()I

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/b;->g()I

    move-result v5

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static/range {v0 .. v5}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->isVCodecCapabilitySupport(IIIIII)Z

    move-result p0
    :try_end_0
    .catch Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x0

    move v7, v6

    return p0

    :catch_0
    move-exception p0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-string v0, "SselPbUaimgTytt"

    const-string v0, "TrtmUigystPaelS"

    const/4 v7, 0x0

    const-string v0, "SgPiTyuatrelUst"

    const-string v0, "TPStrategyUtils"

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 p0, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    return p0
.end method

.method public static isSystemPlayerEnable()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method public static isTVPlatform()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public static isThumbPlayerEnable()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->isLibLoaded()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method
