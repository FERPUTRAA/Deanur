.class public Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;
.super Ljava/lang/Object;


# static fields
.field private static final REVERSE_MAP_NAME_SUFFIX:Ljava/lang/String; = ".reverseMap"

.field private static final TAG:Ljava/lang/String; = "TPNativeKeyMapUtil"

.field private static final sHasOptionalIdMapInit:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static final sHasThisAnnotationInitMap:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Class<",
            "*>;",
            "Ljava/util/concurrent/atomic/AtomicBoolean;",
            ">;"
        }
    .end annotation
.end field

.field private static final sNameToMap:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/Number;",
            "Ljava/lang/Number;",
            ">;>;"
        }
    .end annotation
.end field

.field private static final sOptionalIdKeyToNameMap:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final sToNativeOptionalIdMap:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Lcom/tencent/thumbplayer/adapter/a/b/c$a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    sput-object v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sNameToMap:Ljava/util/Map;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v3, 0x0

    sput-object v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sHasThisAnnotationInitMap:Ljava/util/Map;

    new-instance v0, Landroid/util/SparseArray;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    sput-object v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sToNativeOptionalIdMap:Landroid/util/SparseArray;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Landroid/util/SparseArray;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    sput-object v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sOptionalIdKeyToNameMap:Landroid/util/SparseArray;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    sput-object v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sHasOptionalIdMapInit:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    return-void
.end method

.method private static buildBiDirectionMapForAnnotation(Ljava/lang/Class;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/lang/annotation/Annotation;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " ~s b~b~c@~~ @~1 ts@@i@f~y @@~@~~l-~@mb/ ~M@~o  ~a @@@d~vu ~@@@ofK@ ~ Si  @@iolt 4/o~~~.~@ ~ rno"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    const-string/jumbo v0, "ysPmTiKaNvUeteiapl"

    const-string/jumbo v0, "ltsviPpUaiNTeKaeyM"

    const/4 v5, 0x4

    const-string/jumbo v0, "vaitopKMeTUiyatleP"

    const-string v0, "TPNativeKeyMapUtil"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string/jumbo v1, "occtib b,t=znAuoomarFponltdMinleaariBizn"

    const-string/jumbo v1, "ucimlbrozoiooBdManecnt lrFi=zAit,iptanna"

    const/4 v5, 0x5

    const-string v1, "DebaBAu,zrpnnztialo=cniidFloitManorcu ti"

    const-string v1, "buildBiDirectionMapForAnnotation, clazz="

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sHasThisAnnotationInitMap:Ljava/util/Map;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    check-cast v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v5, 0x0

    const/4 v4, 0x2

    if-nez v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    const/4 v5, 0x7

    invoke-interface {v0, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    monitor-enter v1

    :try_start_1
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string/jumbo v0, "lMTtyaipPNeopKUvae"

    const-string v0, "PpevoaKyitMNTaelUt"

    const/4 v5, 0x7

    const-string v0, "KateMUtaqviieylNTp"

    const-string v0, "TPNativeKeyMapUtil"

    const/4 v4, 0x7

    move v5, v4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo v3, "sNsea=salc"

    const-string v3, "className="

    const/4 v4, 0x3

    or-int/2addr v5, v4

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo p0, "tibmyn dl eia"

    const-string p0, "e nilbyidata "

    const/4 v5, 0x6

    const-string p0, " already init"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    monitor-exit v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-void

    :cond_1
    const/4 v5, 0x6

    invoke-static {p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->searchClassToFillMap(Ljava/lang/Class;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 p0, 0x1

    const/4 v5, 0x6

    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    monitor-exit v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void

    :catchall_0
    move-exception p0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    throw p0

    :catchall_1
    move-exception p0

    :try_start_2
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    throw p0
.end method

.method private static buildNativeInitConfigMap()V
    .locals 12

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x0

    const-string v0, "NuytotUMPaaveiiple"

    const-string/jumbo v0, "ypeTtPuviMaUliNate"

    const-string v0, "MyivebPtaeTtplKaiU"

    const-string v0, "TPNativeKeyMapUtil"

    :try_start_0
    const/4 v10, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x7

    const-class v1, Lcom/tencent/thumbplayer/api/TPOptionalID;

    const-class v1, Lcom/tencent/thumbplayer/api/TPOptionalID;

    const-class v1, Lcom/tencent/thumbplayer/api/TPOptionalID;

    const-class v1, Lcom/tencent/thumbplayer/api/TPOptionalID;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v11, 0x5

    const/4 v10, 0x7

    invoke-virtual {v1}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v2

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x0

    array-length v3, v2

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x5

    const/4 v4, 0x0

    :goto_0
    const/4 v11, 0x4

    const/4 v10, 0x3

    if-ge v4, v3, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    aget-object v5, v2, v4

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v5}, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;

    move-result-object v6

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {v6}, Ljava/lang/Class;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x6

    const-string/jumbo v7, "nti"

    const-string/jumbo v7, "nti"

    const/4 v11, 0x3

    const-string/jumbo v7, "nti"

    const-string/jumbo v7, "int"

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    if-eqz v6, :cond_1

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    const-class v6, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapInitConfig;

    const-class v6, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapInitConfig;

    const/4 v11, 0x1

    const-class v6, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapInitConfig;

    const-class v6, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapInitConfig;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-virtual {v5, v6}, Ljava/lang/reflect/Field;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v6

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x0

    check-cast v6, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapInitConfig;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x7

    if-eqz v6, :cond_1

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {v5, v1}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I

    move-result v7

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x1

    sget-object v8, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sOptionalIdKeyToNameMap:Landroid/util/SparseArray;

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-interface {v6}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapInitConfig;->keyName()Ljava/lang/String;

    move-result-object v9

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {v8, v7, v9}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-interface {v6}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapInitConfig;->value()I

    move-result v8

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x1

    const/4 v9, -0x1

    const/4 v11, 0x5

    const/4 v10, 0x5

    if-ne v8, v9, :cond_0

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x4

    sget-object v5, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sToNativeOptionalIdMap:Landroid/util/SparseArray;

    const/4 v11, 0x2

    new-instance v6, Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    const/4 v11, 0x3

    invoke-direct {v6}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;-><init>()V

    const/4 v10, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v5, v7, v6}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x0

    goto :goto_1

    :cond_0
    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x5

    const/4 v8, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-virtual {v5, v8}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    sget-object v5, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sToNativeOptionalIdMap:Landroid/util/SparseArray;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x5

    new-instance v8, Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-interface {v6}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapInitConfig;->type()I

    move-result v9

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-interface {v6}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapInitConfig;->value()I

    move-result v6

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-direct {v8, v9, v6}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;-><init>(II)V

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {v5, v7, v8}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    :goto_1
    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    add-int/lit8 v4, v4, 0x1

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x1

    goto/16 :goto_0

    :cond_2
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x0

    return-void

    :catch_0
    move-exception v1

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    return-void

    :catch_1
    move-exception v1

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v11, 0x1

    return-void
.end method

.method private static buildNativeOptionalIdToMapInternal(Ljava/lang/Class;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)V"
        }
    .end annotation

    :try_start_0
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {p0}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    array-length v1, v0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    const/4 v2, 0x0

    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    if-ge v2, v1, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    aget-object v3, v0, v2

    const/4 v9, 0x2

    const/4 v8, 0x7

    invoke-virtual {v3}, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;

    move-result-object v4

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {v4}, Ljava/lang/Class;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    const-string/jumbo v5, "nit"

    const-string/jumbo v5, "nit"

    const-string/jumbo v5, "int"

    const/4 v9, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    if-eqz v4, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-class v4, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapOptionalId;

    const/4 v9, 0x4

    const-class v4, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapOptionalId;

    const-class v4, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapOptionalId;

    const/4 v8, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/reflect/Field;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v4

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    check-cast v4, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapOptionalId;

    const/4 v9, 0x0

    if-eqz v4, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v3, p0}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I

    move-result v5

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    sget-object v6, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sOptionalIdKeyToNameMap:Landroid/util/SparseArray;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-interface {v4}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapOptionalId;->keyName()Ljava/lang/String;

    move-result-object v7

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v6, v5, v7}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-interface {v4}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapOptionalId;->value()I

    move-result v6

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 v7, -0x1

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-ne v6, v7, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x7

    sget-object v3, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sToNativeOptionalIdMap:Landroid/util/SparseArray;

    new-instance v4, Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-direct {v4}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v3, v5, v4}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v8, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    goto :goto_1

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v6, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v3, v6}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    sget-object v3, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sToNativeOptionalIdMap:Landroid/util/SparseArray;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    new-instance v6, Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-interface {v4}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapOptionalId;->type()I

    move-result v7

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-interface {v4}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapOptionalId;->value()I

    move-result v4

    const/4 v9, 0x3

    const/4 v8, 0x2

    invoke-direct {v6, v7, v4}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;-><init>(II)V

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v3, v5, v6}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    :goto_1
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    goto/16 :goto_0

    :cond_2
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    return-void

    :catch_0
    move-exception p0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    const-string/jumbo v0, "yKaitUuMvepTlPpeiN"

    const-string v0, "MTeeviypaUlKNPpita"

    const/4 v9, 0x3

    const-string v0, "MlatiePpNaipeKyTtU"

    const-string v0, "TPNativeKeyMapUtil"

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    return-void
.end method

.method private static buildOptionalIdMap()V
    .locals 5

    const/4 v3, 0x4

    const/4 v4, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sHasOptionalIdMapInit:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sToNativeOptionalIdMap:Landroid/util/SparseArray;

    const/4 v3, 0x2

    and-int/2addr v4, v3

    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->buildNativeInitConfigMap()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->buildPublicToNativeOptionalIdMap()V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->buildPrivateToNativeOptionalIdMap()V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string v2, "5umd--u/q53. a/f6328q/l 6u0nfa5d6tup /s3f1e90e.2u5oc  6btbc;/6/s7fuuk7*21e660051tcu/r6uc590a//afi1eul0a8///bpu/n/*8}6pa.7/ef4u4*euyuuu7uu5/7Mpd7{1h./fmbc5e"

    const-string v2, "/5ene/feq00huf/-bud*.u60u;5aa16{tu}7u2555pc6./602m1p7i1r/  k/cu5fMcpyms547f*et a1au88 6u1blu6-7a 23/97./t///8le366u/uo.u50buusffe/uacp7f/b//ncu9u0c3*4dd6/e"

    const/4 v4, 0x3

    const-string/jumbo v2, "u.sb/f5au-7/be/2.u*uudk}/89uu/t7a0ueylcurt0/d5m21034c1//t87/2ub6e/ ape0{ uh06u 1p61/56 a76unuae.M/5i/63uu66*9cf0sl45-cfa 1/;n5f5ceb/6.of*c7f7dup35pmu/es/fe"

    const-string/jumbo v2, "\u6784\u5efaMap\u9519\u8bef\uff0c\u8bf7\u67e5\u770b\u3010--keep class com.tencent.thumbplayer.api.** { *; }\u3011\u662f\u5426\u52a0\u5165\u53cd\u6df7\u6dc6"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    throw v1

    :catchall_0
    move-exception v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    throw v1
.end method

.method private static buildPrivateToNativeOptionalIdMap()V
    .locals 4

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-class v0, Lcom/tencent/thumbplayer/tplayer/TPOptionalIDInternal;

    const-class v0, Lcom/tencent/thumbplayer/tplayer/TPOptionalIDInternal;

    const/4 v3, 0x6

    const-class v0, Lcom/tencent/thumbplayer/tplayer/TPOptionalIDInternal;

    const-class v0, Lcom/tencent/thumbplayer/tplayer/TPOptionalIDInternal;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->buildNativeOptionalIdToMapInternal(Ljava/lang/Class;)V
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void

    :catch_0
    move-exception v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo v1, "tiymtNeMesaTalPUvK"

    const-string v1, "MisTeeyPUlaKtaNtpv"

    const/4 v3, 0x2

    const-string v1, "UMeiovatTKleptaiNP"

    const-string v1, "TPNativeKeyMapUtil"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method

.method private static buildPublicToNativeOptionalIdMap()V
    .locals 4

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-class v0, Lcom/tencent/thumbplayer/api/TPOptionalID;

    const-class v0, Lcom/tencent/thumbplayer/api/TPOptionalID;

    const/4 v3, 0x5

    const-class v0, Lcom/tencent/thumbplayer/api/TPOptionalID;

    const-class v0, Lcom/tencent/thumbplayer/api/TPOptionalID;

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->buildNativeOptionalIdToMapInternal(Ljava/lang/Class;)V
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    return-void

    :catch_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v1, "NPmyMbeTpveiaKatti"

    const-string/jumbo v1, "tMPmiavpiTKNaylete"

    const/4 v3, 0x5

    const-string/jumbo v1, "ltaMyvueaUKNipiTte"

    const-string v1, "TPNativeKeyMapUtil"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method private static checkFillMapValidity(Ljava/lang/Class;Ljava/util/Map;Ljava/util/Map;Ljava/lang/Class;Ljava/lang/Number;Ljava/lang/Number;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/lang/annotation/Annotation;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;",
            "Ljava/util/Map<",
            "Ljava/lang/Number;",
            "Ljava/lang/Number;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/Number;",
            "Ljava/lang/Number;",
            ">;",
            "Ljava/lang/Class<",
            "*>;",
            "Ljava/lang/Number;",
            "Ljava/lang/Number;",
            ")V"
        }
    .end annotation

    invoke-interface {p1, p5}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string/jumbo v0, "u6908u/p3/c5/5=u2u831/4ducf55 /1"

    const-string v0, " \u6210\u5458\u53d8\u91cf\u503c="

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez p1, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {p2, p4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string p3, "cu58/c69q6e8d07/ec4936u183e9euu69fu 9u58o8/u3/f/u/e0u/=c/60/8/4dc7/u4euu1f"

    const-string p3, "9u99o/e/3 u48//0/e876uf5fe69/8uu=5c48uuuuduec///e7/68609161/04/duc3u3ecfc8"

    const/4 v2, 0x3

    const-string p3, "c1s7=9/0f/6uu383ec 8/e69eee936fu45ud/u8/6/0u//8f/86u9uc0/ddu/u5u/c7c19e4u4"

    const-string p3, " \u914d\u7f6e\u4e86\u91cd\u590d\u7684\u6ce8\u89e3\u503c\uff0c\u6ce8\u89e3="

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    invoke-virtual {p2, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string p3, "72/mfu4 e8bu7/u/ee06/750/6ub0bue"

    const-string p3, "6ufubb ee874u/7/5u/7@bee6/0020u/"

    const/4 v2, 0x2

    const-string p3, "00/uoe0u7f4662b/eu/7/8u@ueb 74e5"

    const-string p3, " \u8bf7\u67e5\u627e\u4e00\u4e0b@"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string p0, "/30ucb/auu2)e844fcu47//155d9c9uu8/8ddueu2/0/5//c9(5e9auu"

    const-string/jumbo p0, "u3a4u5u/(/u/dd91cae575//8/40eu5e2u)ccd9/u0/2u18/c9u948fu"

    const/4 v2, 0x6

    const-string p0, "60d5e5uu//uu4c0/(//9e829duu1982/4c15duu9u5afa34/c7c/)e/8"

    const-string p0, "(\u8fd9\u4e2a\u503c)\u5728\u54ea\u91cc\u91cd\u590d\u4e86"

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    throw p1

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string/jumbo p3, "u1d9/6upcd1f70 /47ee8fuf1e2u/56u3/3ufc050u/cu6/5u8ueu=9966/c418/4//8/d84d95u/u98"

    const-string p3, "2 u/8//pu//e/d35399d=cdu/f08568c4081//f0/8u7c5eu1u9664641u/ecf5uu/4e1d9u768/uf9u"

    const-string p3, " \u914d\u7f6e\u4e86\u91cd\u590d\u7684\u6210\u5458\u53d8\u91cf\uff0c\u6ce8\u89e3="

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    move v2, v1

    invoke-virtual {p2, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string/jumbo p3, "ube626e9q5/50e6/u/a/f8402/7uuuuu 47d48/7b@///8u4/9eeee7uf8fu387f2c0u"

    const-string p3, " \u8bf7\u67e5\u627e\u4e00\u4e0b\u4f7f\u7528\u8fd9\u4e2a\u6ce8\u89e3@"

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string p0, "56su37//2uu267/ea/cu55/590ea/udu40uu/uuc/u4e/b84/78415q8f48296f134"

    const-string/jumbo p0, "ua///c25qbau7e2481465/5c70f96d072u8895u4e4u///6eu5uu4u43/3/8u/u/f1"

    const/4 v2, 0x2

    const-string p0, "/5umu8duue52782044fu/86u3a94//9uu4abe45/cu4/63u561574e0///7f/c8u/2"

    const-string/jumbo p0, "\u7684\u54ea\u4e24\u4e2a\u6210\u5458\u53d8\u91cf\u503c\u76f8\u7b49"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    throw p1
.end method

.method public static convertToNativeOptionalId(I)Lcom/tencent/thumbplayer/adapter/a/b/c$a;
    .locals 4
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v2, 0x6

    move v3, v2

    sget-object v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sToNativeOptionalIdMap:Landroid/util/SparseArray;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->buildOptionalIdMap()V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v1, Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    const/4 v3, 0x7

    invoke-direct {v1}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, p0, v1}, Landroid/util/SparseArray;->get(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast p0, Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p0
.end method

.method public static getEntrySetOfToNativeMap(Ljava/lang/Class;)Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/lang/annotation/Annotation;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)",
            "Ljava/util/Set<",
            "Ljava/util/Map$Entry<",
            "Ljava/lang/Number;",
            "Ljava/lang/Number;",
            ">;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    move v2, v1

    invoke-static {p0, v0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getMapForAnnotation(Ljava/lang/Class;Z)Ljava/util/Map;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Ljava/util/HashSet;

    const/4 v2, 0x3

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public static getEntrySetOfToTPMap(Ljava/lang/Class;)Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/lang/annotation/Annotation;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)",
            "Ljava/util/Set<",
            "Ljava/util/Map$Entry<",
            "Ljava/lang/Number;",
            "Ljava/lang/Number;",
            ">;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p0, v0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getMapForAnnotation(Ljava/lang/Class;Z)Ljava/util/Map;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance v0, Ljava/util/HashSet;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method private static getMapForAnnotation(Ljava/lang/Class;Z)Ljava/util/Map;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/lang/annotation/Annotation;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;Z)",
            "Ljava/util/Map<",
            "Ljava/lang/Number;",
            "Ljava/lang/Number;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getMapKey(Ljava/lang/Class;Z)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    sget-object v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sNameToMap:Ljava/util/Map;

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    check-cast v1, Ljava/util/Map;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {v1}, Ljava/util/Map;->size()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-nez v2, :cond_1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->buildBiDirectionMapForAnnotation(Ljava/lang/Class;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    check-cast v1, Ljava/util/Map;

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p0, p1}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    check-cast p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz p1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz v1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Map;->size()I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz p1, :cond_2

    const/4 v4, 0x3

    return-object v1

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo p0, "pbiiosolfstai e MrilBnDitu d urcnl"

    const-string p0, "ansfil  ocrbudDrtaeltis nii pBMuil"

    const/4 v4, 0x2

    const-string/jumbo p0, "ticfibeipuMi iet lonDdrB rlnasb ul"

    const-string p0, " is null after buildBiDirectionMap"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    throw p1

    :cond_3
    const/4 v4, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string p0, "anetn uoianoi hntmg SsnahtrCoco"

    const-string/jumbo p0, "f tmeaooaioncnhCin rsonh tnStag"

    const/4 v4, 0x1

    const-string/jumbo p0, "ts tot pifoehaghnornannna aCSoi"

    const-string/jumbo p0, "has not SearchConfig annotation"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    throw p1
.end method

.method private static getMapKey(Ljava/lang/Class;Z)Ljava/lang/String;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/lang/annotation/Annotation;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;Z)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p0

    :cond_0
    const/4 v0, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    const-string p0, ".Mpesrovqra"

    const-string/jumbo p0, "rMeposvr.ae"

    const/4 v1, 0x0

    const-string/jumbo p0, "vMsspeeear."

    const-string p0, ".reverseMap"

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p0
.end method

.method public static getOptionalIdName(I)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sHasOptionalIdMapInit:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->buildOptionalIdMap()V

    :cond_0
    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sOptionalIdKeyToNameMap:Landroid/util/SparseArray;

    const/4 v3, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x6

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, p0, v1}, Landroid/util/SparseArray;->get(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast p0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object p0
.end method

.method public static init()V
    .locals 10

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-class v2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap;

    const/4 v9, 0x5

    const-class v2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap;

    const-class v2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap;

    const/4 v9, 0x3

    const/4 v8, 0x0

    invoke-virtual {v2}, Ljava/lang/Class;->getDeclaredClasses()[Ljava/lang/Class;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string/jumbo v3, "vtDm iboMa &upritveipnefinor ittelB iac"

    const-string/jumbo v3, "fM inbBevctpoai i& elavtoitniputDnr eri"

    const/4 v9, 0x6

    const-string/jumbo v3, "v itovpiorlipai DefantiMe&aetitoc rnn B"

    const-string/jumbo v3, "init BiDirectionMap for tp&native value"

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string v4, "UaevtbeliiKMpyPNTa"

    const-string v4, "TPNativeKeyMapUtil"

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-static {v4, v3}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    array-length v3, v2

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    const/4 v5, 0x0

    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-ge v5, v3, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x6

    aget-object v6, v2, v5

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v6}, Ljava/lang/Class;->isAnnotation()Z

    move-result v7

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-eqz v7, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v6}, Ljava/lang/Class;->getModifiers()I

    move-result v7

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-static {v7}, Ljava/lang/reflect/Modifier;->isPublic(I)Z

    move-result v7

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    if-eqz v7, :cond_0

    const-class v7, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v6, v7}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v7

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    check-cast v7, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-eqz v7, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-static {v6}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->buildBiDirectionMapForAnnotation(Ljava/lang/Class;)V

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    add-int/lit8 v5, v5, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    goto :goto_0

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string/jumbo v6, "sttii u=em nuoi"

    const-string/jumbo v6, "ioent=u ti csim"

    const/4 v9, 0x0

    const-string/jumbo v6, "toe=ictpnsit m "

    const-string/jumbo v6, "init cost time="

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    sub-long/2addr v2, v0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v5, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    shl-int/2addr v9, v8

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-static {v4, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x6

    move v9, v8

    return-void
.end method

.method private static searchClassToFillMap(Ljava/lang/Class;)V
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/lang/annotation/Annotation;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    const-string v7, "KlytePMpqavitTUipa"

    const-string v7, "NePvMtlpKTiptUayia"

    const-string v7, "TPNativeKeyMapUtil"

    const/4 v8, 0x1

    invoke-static {v0, v8}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getMapKey(Ljava/lang/Class;Z)Ljava/lang/String;

    move-result-object v1

    sget-object v2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->sNameToMap:Ljava/util/Map;

    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map;

    const/4 v9, 0x0

    invoke-static {v0, v9}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getMapKey(Ljava/lang/Class;Z)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/Map;

    if-eqz v3, :cond_0

    if-nez v5, :cond_1

    :cond_0
    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    invoke-interface {v2, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v5, Ljava/util/HashMap;

    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    invoke-interface {v2, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    move-object v10, v3

    move-object v10, v3

    move-object v10, v3

    move-object v10, v3

    move-object v11, v5

    move-object v11, v5

    move-object v11, v5

    move-object v11, v5

    :try_start_0
    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v1

    move-object v12, v1

    move-object v12, v1

    move-object v12, v1

    move-object v12, v1

    check-cast v12, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    if-eqz v12, :cond_9

    invoke-interface {v12}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;->searchClass()Ljava/lang/Class;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v14

    array-length v15, v14

    move v6, v9

    move v6, v9

    move v6, v9

    :goto_0
    if-ge v6, v15, :cond_8

    aget-object v1, v14, v6

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    invoke-interface {v12}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;->valueClass()Ljava/lang/Class;

    move-result-object v3

    sget-object v4, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    if-ne v3, v4, :cond_2

    const-string/jumbo v2, "int"

    const-string/jumbo v2, "tin"

    const-string/jumbo v2, "nti"

    const-string/jumbo v2, "int"

    goto :goto_1

    :cond_2
    invoke-interface {v12}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;->valueClass()Ljava/lang/Class;

    move-result-object v3

    sget-object v5, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    if-ne v3, v5, :cond_3

    const-string/jumbo v2, "ognl"

    const-string/jumbo v2, "nlgo"

    const-string/jumbo v2, "logn"

    const-string/jumbo v2, "long"

    :cond_3
    :goto_1
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    const-string v5, "/6s2/640uf3q5u7/81"

    const-string/jumbo v5, "uu7/46f2q135/u0/86"

    const-string v5, "061mfu43u/7u//6856"

    const-string/jumbo v5, "\u7684\u652f\u6301"

    const-string v9, "0se6o/b/u35d47/7u0euu59/b/1uff91c3u8au/8/b"

    const-string v9, "3/s3c975ue8u/u8d/f5/7bfu/b04be68/auu0u/191"

    const-string/jumbo v9, "u1e4/b9eu8u//3f6b/370fae8uu/d/u157b/c50u9b"

    const-string/jumbo v9, "\u4ee3\u7801\u8fd8\u6ca1\u5b9e\u73b0\u5bf9"

    if-nez v3, :cond_7

    :try_start_1
    invoke-virtual {v1}, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-virtual {v1, v0}, Ljava/lang/reflect/Field;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v2

    if-eqz v2, :cond_6

    invoke-virtual {v1, v8}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const-string/jumbo v3, "uaemv"

    const-string/jumbo v3, "euvul"

    const-string/jumbo v3, "value"

    move/from16 v18, v6

    move/from16 v18, v6

    move/from16 v18, v6

    move/from16 v18, v6

    const/4 v8, 0x0

    new-array v6, v8, [Ljava/lang/Class;

    invoke-virtual {v0, v3, v6}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const/4 v8, 0x1

    invoke-virtual {v3, v8}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    invoke-interface {v12}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;->valueClass()Ljava/lang/Class;

    move-result-object v6

    if-ne v6, v4, :cond_4

    const/4 v4, 0x0

    new-array v5, v4, [Ljava/lang/Object;

    invoke-virtual {v3, v2, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v1, v13}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    const/4 v6, 0x0

    goto :goto_2

    :cond_4
    invoke-interface {v12}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;->valueClass()Ljava/lang/Class;

    move-result-object v4

    sget-object v6, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    if-ne v4, v6, :cond_5

    const/4 v6, 0x0

    new-array v4, v6, [Ljava/lang/Object;

    invoke-virtual {v3, v2, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v1, v13}, Ljava/lang/reflect/Field;->getLong(Ljava/lang/Object;)J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :goto_2
    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object v2, v10

    move-object v2, v10

    move-object v2, v10

    move-object v2, v10

    move-object v3, v11

    move-object v3, v11

    move-object v3, v11

    move-object v3, v11

    move-object/from16 v16, v4

    move-object/from16 v16, v4

    move-object/from16 v16, v4

    move-object v4, v13

    move-object v4, v13

    move-object/from16 v5, v16

    move-object/from16 v5, v16

    move-object/from16 v5, v16

    move-object/from16 v5, v16

    move/from16 v17, v18

    move/from16 v17, v18

    move/from16 v18, v6

    move/from16 v18, v6

    move/from16 v18, v6

    move/from16 v18, v6

    move-object v6, v9

    move-object v6, v9

    move-object v6, v9

    move-object v6, v9

    invoke-static/range {v1 .. v6}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->checkFillMapValidity(Ljava/lang/Class;Ljava/util/Map;Ljava/util/Map;Ljava/lang/Class;Ljava/lang/Number;Ljava/lang/Number;)V

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    invoke-interface {v10, v9, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-interface {v11, v2, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_3

    :cond_5
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-interface {v12}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;->valueClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_6
    move/from16 v17, v6

    move/from16 v17, v6

    move/from16 v17, v6

    move/from16 v17, v6

    const/16 v18, 0x0

    :goto_3
    add-int/lit8 v6, v17, 0x1

    move/from16 v9, v18

    move/from16 v9, v18

    move/from16 v9, v18

    move/from16 v9, v18

    goto/16 :goto_0

    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-interface {v12}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;->valueClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_8
    return-void

    :cond_9
    new-instance v1, Ljava/lang/IllegalArgumentException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "Snsoo aponf atnatno naehhCrtioi"

    const-string/jumbo v0, "naniotoehCSai ftc narosonnohta "

    const-string/jumbo v0, "has not SearchConfig annotation"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1
    :try_end_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/lang/NoSuchMethodException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    move-exception v0

    invoke-static {v7, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void

    :catch_1
    move-exception v0

    invoke-static {v7, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "07u0seecqcu4Xbauya6ftpra7./lM9utv.u/cN/64auuu4/u2a/942/eue74uiv995ya5dd0K/P0/eu6Xt/l.5a8na8eei403e6r26,/st//1ue7unpdbc8u.Xt/6u6cm9mu720b/690eu/tueao5u 8/drd9e2tt5e42uMeu3u1eb/yb/uu7lp9c68/T0/g.//fd0680765.011uph3"

    const-string v1, "/rKdmbltuP. ed73ucpc/tp/T8ucb/806dNeu.9u72l0uet99d/0.86t6buuupn6640syu4/77u6///4uf283//oe2uetl.500/p5rf/u/0b6Mueghu99c6ev8ue16au9tuu561uee.3m/c4Me/0u70/4,a/b5/v7atru2auucaa/1ayX6.teai79/eaauXd00yi/5219d5Xe424sne8"

    const-string/jumbo v1, "ycsMnc/ei.b0euur7uX3X885u,76e1ur48t6/0e09M77.0ua/obl8ad479/ecuca l0/u/2bu/2bcg6.d/6/d2.fuee/uu/y6t4mu/.0v04/4u5tp3vKNeep6uus53dsuP17e/muu08a//9u9a/aa5rad56e7/t8u2te9/ut6dea02te1a506/c4un9Tu/fp640.9yu9ulh162Xtp/e/"

    const-string v1, "com.tencent.thumbplayer.adapter.strategy.utils.TPNativeKeyMap\u4e0b\u6240\u6709\u5143\u7d20\u9700\u8981\u52a0\u5230\u6df7\u6dc6\u4e2d, \u5e76\u4e14\u6bcf\u4e2aMapXXX\u6ce8\u89e3\u9700\u8981\u6709value\u65b9\u6cd5"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :catch_2
    move-exception v0

    invoke-static {v7, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method

.method public static toNativeIntValue(Ljava/lang/Class;I)I
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/lang/annotation/Annotation;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;I)I"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-static {p0, v0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getMapForAnnotation(Ljava/lang/Class;Z)Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v1, "ueumplttNV,ouV valaet=a"

    const-string v1, "V= Naiuvoalupettulet,Va"

    const/4 v3, 0x3

    const-string v1, "eNVtoie=ata,alvtoupue V"

    const-string/jumbo v1, "toNativeValue, tpValue="

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string p1, " ,tvdbzrzuu ellepaaelurft c"

    const-string/jumbo p1, "tcaulrepevdeaa zrlft  l,zuu"

    const/4 v3, 0x1

    const-string/jumbo p1, "feua nuut aulrlzevc,dl atzr"

    const-string/jumbo p1, "return default value, clazz"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const-string v0, "PtUMeivpNiaKTptqye"

    const-string v0, "aNitaiteqyTeMpUvPK"

    const/4 v3, 0x0

    const-string v0, "PNaiateMqTiytpevlU"

    const-string v0, "TPNativeKeyMapUtil"

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const/4 v3, 0x6

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    check-cast p0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;->nativeDefValue()J

    move-result-wide p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    long-to-int p0, p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    return p0

    :cond_0
    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    check-cast p0, Ljava/lang/Number;

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    return p0
.end method

.method public static toNativeLongValue(Ljava/lang/Class;J)J
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/lang/annotation/Annotation;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;J)J"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p0, v0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getMapForAnnotation(Ljava/lang/Class;Z)Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const-string/jumbo v1, "tvs=seatlVNapVi,atule e"

    const-string/jumbo v1, "lesattuuVVt N=l,eevaapi"

    const/4 v3, 0x2

    const-string v1, "eNtmuaeito VeapVltaul=v"

    const-string/jumbo v1, "toNativeValue, tpValue="

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const-string p1, "dmulotce fzeleuaarlt, rnuzv"

    const-string/jumbo p1, "lreme cvarldfte a,tzuuznula"

    const/4 v3, 0x0

    const-string/jumbo p1, "zunetbfdaecuraa lrtvl eulz "

    const-string/jumbo p1, "return default value, clazz"

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string p2, "atvoMUutKPpeeiyNla"

    const-string/jumbo p2, "lieMoUtaiNptaePyvK"

    const-string p2, "NltpeayptPMvUKiTae"

    const-string p2, "TPNativeKeyMapUtil"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const/4 v3, 0x3

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x6

    check-cast p0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;->nativeDefValue()J

    move-result-wide p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-wide p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast p0, Ljava/lang/Number;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    move-result-wide p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-wide p0
.end method

.method public static toTPIntValue(Ljava/lang/Class;I)I
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/lang/annotation/Annotation;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;I)I"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    invoke-static {p0, v0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getMapForAnnotation(Ljava/lang/Class;Z)Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string/jumbo v1, "tT =,PevqVnbtoeuValiaal"

    const-string v1, "eVttvboPie aTVeaa,nul=l"

    const/4 v3, 0x0

    const-string/jumbo v1, "iasVTvuPoVatlulnea e=t,"

    const-string/jumbo v1, "toTPValue, nativeValue="

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const-string/jumbo p1, "ldrmtueavuzlaaenctrf, e uuz"

    const-string p1, " v utaurezllet,lecnaraufuzd"

    const/4 v3, 0x7

    const-string p1, "erezocuuald,anutltlar  vz f"

    const-string/jumbo p1, "return default value, clazz"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo v0, "leytebaiTKUpvMNait"

    const-string/jumbo v0, "iMUTltipyataveKeNp"

    const/4 v3, 0x7

    const-string v0, "MaevNtuaiUyPlipeTK"

    const-string v0, "TPNativeKeyMapUtil"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const/4 v3, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    check-cast p0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;->tpDefValue()J

    move-result-wide p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    long-to-int p0, p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    return p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    check-cast p0, Ljava/lang/Number;

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x2

    return p0
.end method

.method public static toTPLongValue(Ljava/lang/Class;J)J
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/lang/annotation/Annotation;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;J)J"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getMapForAnnotation(Ljava/lang/Class;Z)Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    const-string/jumbo v1, "naieVuqpauVo le,vae=lTt"

    const-string v1, "anoa=luaqePTe VtViu,lev"

    const/4 v3, 0x6

    const-string/jumbo v1, "toTPValue, nativeValue="

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const-string/jumbo p1, "nfetela qruldevs,cu utla zz"

    const-string/jumbo p1, "vlsle,zeaautdeuu al cznrft "

    const/4 v3, 0x4

    const-string/jumbo p1, "return default value, clazz"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const-string/jumbo p2, "yUsMtNaKPeelaTvipt"

    const-string p2, "TPNativeKeyMapUtil"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    check-cast p0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$SearchConfig;->tpDefValue()J

    move-result-wide p0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-wide p0

    :cond_0
    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    check-cast p0, Ljava/lang/Number;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    move-result-wide p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-wide p0
.end method
