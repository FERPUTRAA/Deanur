.class public Lcom/tencent/thumbplayer/adapter/strategy/e;
.super Ljava/lang/Object;


# direct methods
.method public static a(Lcom/tencent/thumbplayer/adapter/strategy/a/a;)Lcom/tencent/thumbplayer/adapter/strategy/a;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~sft@vo@o@@ @r @~~@@@l ~l@s~- @4~yob~ ~@  ~ cn S @~oi~K~a@@i~@. /@~ @~@~i   ~~~ obfMt@oud1m~ ~b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->d()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/adapter/strategy/d;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/adapter/strategy/d;-><init>(Lcom/tencent/thumbplayer/adapter/strategy/a/a;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0

    :cond_0
    const/4 v2, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/adapter/strategy/c;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/adapter/strategy/c;-><init>(Lcom/tencent/thumbplayer/adapter/strategy/a/a;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method
