.class public Lcom/tencent/thumbplayer/adapter/strategy/d;
.super Lcom/tencent/thumbplayer/adapter/strategy/b;


# instance fields
.field private b:I

.field private c:[I


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/adapter/strategy/a/a;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/b;-><init>(Lcom/tencent/thumbplayer/adapter/strategy/a/a;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/strategy/d;->b:I

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->c()[I

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/strategy/d;->c:[I

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    array-length p1, p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez p1, :cond_1

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    new-array p1, p1, [I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/strategy/d;->c:[I

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public a(Lcom/tencent/thumbplayer/adapter/b;)I
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/strategy/d;->c:[I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    array-length v1, v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget v2, p0, Lcom/tencent/thumbplayer/adapter/strategy/d;->b:I

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-le v1, v2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    aget v0, v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    move v0, v3

    move v0, v3

    move v0, v3

    :goto_0
    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v1, 0x2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eq v0, v1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v1, 0x3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-ne v0, v1, :cond_2

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/b;->b(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-nez p1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_1

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    move v3, v0

    move v3, v0

    const/4 v5, 0x5

    move v3, v0

    move v3, v0

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string/jumbo p1, "oOs:trretpegepsa,plyr eaysnT"

    const-string/jumbo p1, "lysrppeeeoy,rngOstt ya:aeprT"

    const/4 v5, 0x3

    const-string/jumbo p1, "strmaoe,TyaltgerrFpypnOp eey"

    const-string/jumbo p1, "strategyForOpen, playerType:"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string v0, "ETuxo]rtSejyrabPtaTeltava.g[PmTyP"

    const-string v0, "TPThumbPlayer[TPExtStrategy.java]"

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    return v3
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/b;Lcom/tencent/thumbplayer/adapter/strategy/a/b;)I
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz p2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/adapter/strategy/a/b;->a()I

    move-result p2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-nez p2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/d;->a(Lcom/tencent/thumbplayer/adapter/b;)I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    return p1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/strategy/d;->c:[I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    array-length v0, p2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget v1, p0, Lcom/tencent/thumbplayer/adapter/strategy/d;->b:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    move v4, v3

    if-le v0, v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x5

    iput v1, p0, Lcom/tencent/thumbplayer/adapter/strategy/d;->b:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    aget p2, p2, v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    move p2, v2

    move p2, v2

    const/4 v4, 0x2

    move p2, v2

    move p2, v2

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v0, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eq p2, v0, :cond_2

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v4, 0x5

    shr-int/2addr v3, v0

    const/4 v4, 0x2

    if-ne p2, v0, :cond_3

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/b;->b(Lcom/tencent/thumbplayer/adapter/b;)Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-nez p1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    goto :goto_1

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    move v2, p2

    move v2, p2

    const/4 v4, 0x4

    move v2, p2

    move v2, p2

    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo p1, "yetyeb tRl:setpapryryoFr,remT"

    const-string p1, ",rgmytstrrrpF ylRTteee:ypeyao"

    const/4 v4, 0x7

    const-string/jumbo p1, "oTatFyupleyRgrr tstre,eeyry:a"

    const-string/jumbo p1, "strategyForRetry, playerType:"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string p2, "PaPtP.mpgubtyTetjS[rvaeyxr]aThaol"

    const-string p2, "ebyeomtTjPlauaPv]aE.SThxtPrrtay[g"

    const/4 v4, 0x1

    const-string/jumbo p2, "tE.SaPhgqyatrbvxj][tTTlrTaPaPeymu"

    const-string p2, "TPThumbPlayer[TPExtStrategy.java]"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    shl-int/2addr v4, v3

    return v2
.end method

.method public a()[I
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v0, -0x1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/adapter/strategy/d;->b:I

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/strategy/d;->c:[I

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    array-length v3, v2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string/jumbo v4, "jusEaaTeSPbryltagbtTvrPPtxe.]yaTh"

    const-string v4, "]SerhbTaujPtyTPlPvyTbmaeaatExtr.g"

    const/4 v7, 0x2

    const-string v4, "ajmmrS[br.attPuyxhgTavEePT]tyealP"

    const-string v4, "TPThumbPlayer[TPExtStrategy.java]"

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/4 v5, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-lt v1, v3, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string/jumbo v2, "ycagoytDerce,udeeFrtpoTe r ors"

    const-string/jumbo v2, "ryy erusgtcdoepereTFaoDtrc er,"

    const/4 v7, 0x2

    const-string/jumbo v2, "try:rbyoore raesgeceT D,drpFtc"

    const-string/jumbo v2, "strategyForDec error, decType:"

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x1

    aget v2, v0, v5

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x4

    invoke-static {v4, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    shl-int/2addr v7, v6

    return-object v0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    aget v1, v2, v1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/4 v2, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eq v1, v2, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/4 v2, 0x2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-ne v1, v2, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    goto :goto_1

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 v2, 0x3

    const/4 v7, 0x0

    if-ne v1, v2, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    const/16 v1, 0x65

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    aput v1, v0, v5

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    goto :goto_2

    :cond_2
    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    const/16 v1, 0x66

    const/4 v7, 0x7

    const/4 v6, 0x4

    aput v1, v0, v5

    :cond_3
    :goto_2
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string/jumbo v2, "tptar:ucydrsDo,yeTg eeec"

    const-string/jumbo v2, "strategyForDec, decType:"

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    aget v2, v0, v5

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    goto :goto_0
.end method
