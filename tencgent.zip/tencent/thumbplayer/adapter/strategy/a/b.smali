.class public Lcom/tencent/thumbplayer/adapter/strategy/a/b;
.super Ljava/lang/Object;


# instance fields
.field a:I

.field private b:I

.field private c:I

.field private d:Ljava/lang/String;


# direct methods
.method public constructor <init>(IIILjava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput p3, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/b;->c:I

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p2, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/b;->b:I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/b;->a:I

    const/4 v1, 0x4

    iput-object p4, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/b;->d:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/b;->a:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    return v0
.end method
