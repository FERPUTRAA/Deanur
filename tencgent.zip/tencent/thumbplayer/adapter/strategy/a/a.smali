.class public Lcom/tencent/thumbplayer/adapter/strategy/a/a;
.super Ljava/lang/Object;


# instance fields
.field a:I

.field b:I

.field c:[I

.field d:Z


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/adapter/c;)V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->d:Z

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v0, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->a:I

    const/4 v4, 0x7

    move v5, v4

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->b:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPStrategyUtils;->isTVPlatform()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v2, 0x4

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput v2, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->b:I

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->a:I

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-nez p1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-void

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/16 v1, 0xd2

    const/4 v4, 0x7

    move v5, v4

    invoke-virtual {p1, v1}, Lcom/tencent/thumbplayer/adapter/c;->b(I)Lcom/tencent/thumbplayer/api/TPOptionalParam;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamType()I

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-ne v3, v2, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamQueueInt()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object p1, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;->queueValue:[I

    const/4 v5, 0x1

    const/4 v4, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->c:[I

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 p1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x7

    iput-boolean p1, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->d:Z

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-void

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/16 v1, 0xca

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p1, v1}, Lcom/tencent/thumbplayer/adapter/c;->b(I)Lcom/tencent/thumbplayer/api/TPOptionalParam;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v1, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamType()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-ne v2, v0, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-wide v2, v2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {p0, v2, v3}, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->a(J)Z

    move-result v2

    const/4 v4, 0x7

    xor-int/2addr v5, v4

    if-eqz v2, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-wide v1, v1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v5, 0x7

    const/4 v4, 0x4

    long-to-int v1, v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput v1, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->b:I

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/16 v1, 0xcb

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p1, v1}, Lcom/tencent/thumbplayer/adapter/c;->b(I)Lcom/tencent/thumbplayer/api/TPOptionalParam;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz p1, :cond_4

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamType()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-ne v1, v0, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-wide v0, v0, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {p0, v0, v1}, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->b(J)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v0, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-wide v0, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    long-to-int p1, v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->a:I

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget p1, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->b:I

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->a:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {p0, p1, v0}, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->a(II)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-void
.end method

.method private a(II)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "fss@@1 ~i v~d@ @~~ ~b@m.~u@cM/ @l@n~@ a~@~~@lf/~   t~@oiK~i~ ~  @ y~o ~ @~ S @b@@r@~~-@~~to4@oob"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const/4 v0, 0x3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-ne p1, v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eq p2, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x5

    const-string p2, "atemsosc i s pfltnnehy ratywts"

    const-string p2, "e sswe toar tsp iohfsyctannytl"

    const/4 v2, 0x7

    const-string p2, " wtyosfteathnoosyapc nr tsemil"

    const-string p2, "can not soft with systemplayer"

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    throw p1

    :cond_1
    :goto_0
    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method private a(J)Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    cmp-long v0, p1, v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-lez v0, :cond_0

    const/4 v3, 0x5

    const-wide/16 v0, 0x5

    const-wide/16 v0, 0x5

    const/4 v3, 0x5

    const-wide/16 v0, 0x5

    const-wide/16 v0, 0x5

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    cmp-long p1, p1, v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-gez p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 p1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    return p1

    :cond_0
    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    return p1
.end method

.method private b(J)Z
    .locals 4

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    cmp-long v0, p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-lez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const-wide/16 v0, 0x5

    const-wide/16 v0, 0x5

    const/4 v3, 0x4

    const-wide/16 v0, 0x5

    const/4 v3, 0x5

    cmp-long p1, p1, v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-gez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 p1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    return p1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x2

    return p1
.end method


# virtual methods
.method public a()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->a:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public c()[I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->c:[I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public d()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;->d:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method
