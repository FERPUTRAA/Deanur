.class public Lcom/tencent/thumbplayer/adapter/c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/adapter/c$b;,
        Lcom/tencent/thumbplayer/adapter/c$c;,
        Lcom/tencent/thumbplayer/adapter/c$a;,
        Lcom/tencent/thumbplayer/adapter/c$d;
    }
.end annotation


# instance fields
.field private a:Ljava/lang/Object;

.field private b:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/tencent/thumbplayer/adapter/c$d;",
            ">;"
        }
    .end annotation
.end field

.field private c:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/tencent/thumbplayer/adapter/c$a;",
            ">;"
        }
    .end annotation
.end field

.field private d:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/tencent/thumbplayer/adapter/c$c;",
            ">;"
        }
    .end annotation
.end field

.field private e:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Lcom/tencent/thumbplayer/api/TPOptionalParam;",
            ">;"
        }
    .end annotation
.end field

.field private f:Lcom/tencent/thumbplayer/adapter/h;

.field private g:Lcom/tencent/thumbplayer/adapter/c$b;

.field private h:Z

.field private i:F

.field private j:Ljava/lang/String;

.field private k:F

.field private l:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Lcom/tencent/thumbplayer/api/TPTrackInfo;",
            ">;"
        }
    .end annotation
.end field

.field private m:I

.field private n:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/tencent/thumbplayer/api/TPTrackInfo;",
            ">;"
        }
    .end annotation
.end field

.field private o:Lcom/tencent/thumbplayer/api/TPProgramInfo;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/c;->m:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(I)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->b:Ljava/util/Map;

    const/4 v3, 0x3

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(I)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->c:Ljava/util/Map;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/adapter/h;

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/tencent/thumbplayer/adapter/h;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->f:Lcom/tencent/thumbplayer/adapter/h;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(I)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->e:Ljava/util/Map;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(I)V

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->l:Ljava/util/Map;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->n:Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->d:Ljava/util/ArrayList;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method private a(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "1lsm @@fyi ~/~@i@o@@f~u@ol d~a@   ~c~ob~@ t~~ b~~~o@4~K@@@rvo@i  t@@~o~S~@ @ b/~@~ n. ~ M~ @s~~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget p1, p0, Lcom/tencent/thumbplayer/adapter/c;->m:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    add-int/2addr p1, v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/c;->m:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v3, 0x6

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPTrackInfo;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput v1, p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object p2, p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 p2, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-boolean p2, p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    iput-boolean v0, p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isExclusive:Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-boolean p2, p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isInternal:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/c;->n:Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method

.method private a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    iget p1, p0, Lcom/tencent/thumbplayer/adapter/c;->m:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 p2, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    add-int/2addr p1, p2

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/c;->m:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPTrackInfo;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x3

    move v2, v0

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput v0, p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object p3, p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 p3, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-boolean p3, p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-boolean p2, p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isExclusive:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-boolean p3, p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isInternal:Z

    const/4 v2, 0x6

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/c;->n:Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public a(I)Lcom/tencent/thumbplayer/api/TPTrackInfo;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->l:Ljava/util/Map;

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    check-cast p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p1
.end method

.method public a()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->b:Ljava/util/Map;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->c:Ljava/util/Map;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/c;->h:Z

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v2, 0x6

    move v3, v2

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/c;->i:F

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/c;->j:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/c;->k:F

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->l:Ljava/util/Map;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x3

    move v2, v0

    move v2, v0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->a:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/c;->e:Ljava/util/Map;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    new-instance v1, Lcom/tencent/thumbplayer/adapter/h;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v1}, Lcom/tencent/thumbplayer/adapter/h;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/c;->f:Lcom/tencent/thumbplayer/adapter/h;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->g:Lcom/tencent/thumbplayer/adapter/c$b;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->o:Lcom/tencent/thumbplayer/api/TPProgramInfo;

    const/4 v3, 0x4

    const/4 v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/c;->m:I

    const/4 v2, 0x5

    move v3, v2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->n:Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->d:Ljava/util/ArrayList;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method

.method public a(F)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/c;->i:F

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public a(IJLcom/tencent/thumbplayer/api/TPTrackInfo;)V
    .locals 4

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->l:Ljava/util/Map;

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p4}, Lcom/tencent/thumbplayer/api/TPTrackInfo;->getTrackType()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {v0, v1, p4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-ltz p1, :cond_6

    const/4 v3, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->n:Ljava/util/ArrayList;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-lt p1, v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto/16 :goto_1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/adapter/c$c;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/tencent/thumbplayer/adapter/c$c;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    iput p1, v0, Lcom/tencent/thumbplayer/adapter/c$c;->a:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-wide p2, v0, Lcom/tencent/thumbplayer/adapter/c$c;->b:J

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/c;->n:Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz p2, :cond_5

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget p3, p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v1, p4, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v3, 0x3

    if-ne p3, v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object p3, p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v2, 0x3

    shl-int/2addr v3, v2

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p3

    const/4 v3, 0x4

    if-eqz p3, :cond_2

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object p3, p4, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p3

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-nez p3, :cond_3

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object p3, p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v3, 0x7

    iget-object v1, p4, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz p3, :cond_4

    :cond_3
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p3, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-boolean p3, p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    iput-object p2, v0, Lcom/tencent/thumbplayer/adapter/c$c;->c:Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :cond_4
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 p3, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-boolean p3, p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_5
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/c;->d:Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void

    :cond_6
    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string p3, "erdm naxIk:c"

    const-string/jumbo p3, "rask:endcI x"

    const/4 v3, 0x3

    const-string p3, "dIncorakt:x "

    const-string/jumbo p3, "track Index:"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string p1, "comasbtzti klf IriLv,asieinid n:"

    const-string p1, " iimtznn,si  sLtii c:aedavrIkflo"

    const/4 v3, 0x7

    const-string/jumbo p1, "niatIsurok zilfi si:d eaLt,vicns"

    const-string p1, " is invalid, trackInfoList size:"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/c;->n:Ljava/util/ArrayList;

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string p2, "PPayaakplrosabPc"

    const-string/jumbo p2, "yPkloaPasabcarmP"

    const/4 v3, 0x3

    const-string/jumbo p2, "mPalsraPqkTabPay"

    const-string p2, "TPPlaybackParams"

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method public a(Landroid/content/res/AssetFileDescriptor;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->f:Lcom/tencent/thumbplayer/adapter/h;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/h;->a(Landroid/content/res/AssetFileDescriptor;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public a(Landroid/os/ParcelFileDescriptor;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->f:Lcom/tencent/thumbplayer/adapter/h;

    const/4 v1, 0x4

    xor-int/2addr v2, v1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/h;->a(Landroid/os/ParcelFileDescriptor;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public a(Landroid/view/Surface;)V
    .locals 2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/c;->a:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public a(Landroid/view/SurfaceHolder;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/c;->a:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/e;Ljava/util/Map;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/tencent/thumbplayer/adapter/a/e;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->f:Lcom/tencent/thumbplayer/adapter/h;

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/h;->a(Lcom/tencent/thumbplayer/adapter/a/e;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/c;->f:Lcom/tencent/thumbplayer/adapter/h;

    const/4 v1, 0x0

    xor-int/2addr v2, v1

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/adapter/h;->a(Ljava/util/Map;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPOptionalParam;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->e:Ljava/util/Map;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {v0, v1, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPProgramInfo;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/c;->o:Lcom/tencent/thumbplayer/api/TPProgramInfo;

    const/4 v1, 0x1

    const/4 v0, 0x3

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->f:Lcom/tencent/thumbplayer/adapter/h;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/h;->a(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/c;->j:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->f:Lcom/tencent/thumbplayer/adapter/h;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/h;->a(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/c;->f:Lcom/tencent/thumbplayer/adapter/h;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/adapter/h;->a(Ljava/util/Map;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/adapter/c$d;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/tencent/thumbplayer/adapter/c$d;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object p1, v0, Lcom/tencent/thumbplayer/adapter/c$d;->a:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object p2, v0, Lcom/tencent/thumbplayer/adapter/c$d;->d:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object p3, v0, Lcom/tencent/thumbplayer/adapter/c$d;->b:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p4, v0, Lcom/tencent/thumbplayer/adapter/c$d;->c:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/c;->b:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-interface {p2, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-direct {p0, p1, p3, p4}, Lcom/tencent/thumbplayer/adapter/c;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x2

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/TPOptionalParam;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/adapter/c$a;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/tencent/thumbplayer/adapter/c$a;-><init>()V

    const/4 v2, 0x1

    iput-object p1, v0, Lcom/tencent/thumbplayer/adapter/c$a;->a:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p2, v0, Lcom/tencent/thumbplayer/adapter/c$a;->d:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object p3, v0, Lcom/tencent/thumbplayer/adapter/c$a;->b:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object p4, v0, Lcom/tencent/thumbplayer/adapter/c$a;->c:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/c;->c:Ljava/util/Map;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-interface {p2, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0, p1, p3}, Lcom/tencent/thumbplayer/adapter/c;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public a(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/tencent/thumbplayer/adapter/c;->h:Z

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public a(ZJJ)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->g:Lcom/tencent/thumbplayer/adapter/c$b;

    const/4 v2, 0x5

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/adapter/c$b;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {v0}, Lcom/tencent/thumbplayer/adapter/c$b;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->g:Lcom/tencent/thumbplayer/adapter/c$b;

    :cond_0
    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->g:Lcom/tencent/thumbplayer/adapter/c$b;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-boolean p1, v0, Lcom/tencent/thumbplayer/adapter/c$b;->a:Z

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-wide p2, v0, Lcom/tencent/thumbplayer/adapter/c$b;->b:J

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-wide p4, v0, Lcom/tencent/thumbplayer/adapter/c$b;->c:J

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public b(I)Lcom/tencent/thumbplayer/api/TPOptionalParam;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->e:Ljava/util/Map;

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    check-cast p1, Lcom/tencent/thumbplayer/api/TPOptionalParam;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p1
.end method

.method public b()Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/tencent/thumbplayer/api/TPTrackInfo;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->n:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public b(F)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/c;->k:F

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public b(IJLcom/tencent/thumbplayer/api/TPTrackInfo;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/c;->l:Ljava/util/Map;

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    invoke-virtual {p4}, Lcom/tencent/thumbplayer/api/TPTrackInfo;->getTrackType()I

    move-result p3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {p2, p3}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-ltz p1, :cond_7

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/c;->n:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-lt p1, p2, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto/16 :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/c;->n:Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz p2, :cond_4

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x1

    check-cast p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget p3, p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, p4, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-ne p3, v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object p3, p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p3

    const/4 v2, 0x4

    if-eqz p3, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object p3, p4, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-nez p3, :cond_3

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object p3, p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p4, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz p3, :cond_1

    :cond_3
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-boolean p1, p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    :cond_4
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/c;->d:Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_5
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz p2, :cond_6

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x0

    check-cast p2, Lcom/tencent/thumbplayer/adapter/c$c;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object p3, p2, Lcom/tencent/thumbplayer/adapter/c$c;->c:Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz p3, :cond_5

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p3, p4}, Lcom/tencent/thumbplayer/api/TPTrackInfo;->equals(Ljava/lang/Object;)Z

    move-result p3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz p3, :cond_5

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/c;->d:Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_6
    const/4 v2, 0x7

    const/4 v1, 0x2

    return-void

    :cond_7
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    const-string p3, ":asedbncIt k"

    const-string p3, "I kx:bdcenat"

    const/4 v2, 0x3

    const-string p3, "atIm d:rxnck"

    const-string/jumbo p3, "track Index:"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const-string p1, "d,toovtsLsalkii  ienzn iIf:uasr "

    const-string p1, " aIcr,udfat:siiinleo zL  ssvtnki"

    const/4 v2, 0x7

    const-string/jumbo p1, "iIlzebs ifvoi sr t:ia Lt,dknncas"

    const-string p1, " is invalid, trackInfoList size:"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/c;->n:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string p2, "aaPsbkulPyaPmcTa"

    const-string p2, "TPPlaybackParams"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->f:Lcom/tencent/thumbplayer/adapter/h;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/h;->a(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method public b(Z)V
    .locals 5

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->g:Lcom/tencent/thumbplayer/adapter/c$b;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance v0, Lcom/tencent/thumbplayer/adapter/c$b;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v0}, Lcom/tencent/thumbplayer/adapter/c$b;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->g:Lcom/tencent/thumbplayer/adapter/c$b;

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->g:Lcom/tencent/thumbplayer/adapter/c$b;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-boolean p1, v0, Lcom/tencent/thumbplayer/adapter/c$b;->a:Z

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-wide/16 v1, 0x0

    const/4 v4, 0x2

    const-wide/16 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput-wide v1, v0, Lcom/tencent/thumbplayer/adapter/c$b;->b:J

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x3

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput-wide v1, v0, Lcom/tencent/thumbplayer/adapter/c$b;->c:J

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-void
.end method

.method public c()Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/tencent/thumbplayer/adapter/c$c;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->d:Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public d()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->a:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public e()Lcom/tencent/thumbplayer/adapter/h;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->f:Lcom/tencent/thumbplayer/adapter/h;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public f()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->f:Lcom/tencent/thumbplayer/adapter/h;

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->h()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    shr-int/2addr v2, v1

    return v0
.end method

.method public g()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/c;->h:Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public h()F
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/c;->i:F

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public i()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->j:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-object v0
.end method

.method public j()F
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/c;->k:F

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public k()Lcom/tencent/thumbplayer/adapter/c$b;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->g:Lcom/tencent/thumbplayer/adapter/c$b;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public l()Lcom/tencent/thumbplayer/api/TPProgramInfo;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/c;->o:Lcom/tencent/thumbplayer/api/TPProgramInfo;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public m()Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/adapter/c$d;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/c;->b:Ljava/util/Map;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Map;->size()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/c;->b:Ljava/util/Map;

    const/4 v4, 0x0

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v2, :cond_0

    const/4 v3, 0x1

    const/4 v3, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object v0
.end method

.method public n()Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/adapter/c$a;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/c;->c:Ljava/util/Map;

    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-interface {v1}, Ljava/util/Map;->size()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/c;->c:Ljava/util/Map;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object v0
.end method

.method public o()Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/TPOptionalParam;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/c;->e:Ljava/util/Map;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/Map;->size()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/c;->e:Ljava/util/Map;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object v0
.end method

.method public p()Z
    .locals 5

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->g()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v2, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-ne v0, v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    return v0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v1
.end method
