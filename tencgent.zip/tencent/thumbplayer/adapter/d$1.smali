.class Lcom/tencent/thumbplayer/adapter/d$1;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/f/a$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/adapter/d;->a(Lcom/tencent/thumbplayer/api/richmedia/ITPRichMediaSynchronizer;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/adapter/d;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/adapter/d;)V
    .locals 2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/d$1;->a:Lcom/tencent/thumbplayer/adapter/d;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(Lcom/tencent/thumbplayer/api/richmedia/ITPRichMediaSynchronizer;)J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s~~b@~~ o~oS@m ~@b i @~~~Mov@iuo~@~@/~ ~or n@obft l/4 @.~~@i@@ @1f@ ~ @d @~~ c-~@tl s @a@@~~y "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d$1;->a:Lcom/tencent/thumbplayer/adapter/d;

    const/4 v2, 0x4

    move v3, v2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/adapter/d;->n()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-wide v0
.end method
