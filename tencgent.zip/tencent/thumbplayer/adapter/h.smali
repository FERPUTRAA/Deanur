.class public Lcom/tencent/thumbplayer/adapter/h;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/lang/String;

.field private b:I

.field private c:Landroid/os/ParcelFileDescriptor;

.field private d:Landroid/content/res/AssetFileDescriptor;

.field private e:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private f:Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;

.field private g:Lcom/tencent/thumbplayer/adapter/a/e;


# direct methods
.method protected constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->e:Ljava/util/Map;

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "bos@nit@ ~@t~@~~~S@~~ ~f @@ i~~b.1/o~~@ M~r~ol@~@@/ fK c~@ ~l ~im@o-~@ u  @@ o~@d y @b4o s ~v~@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->a:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method protected a(Landroid/content/res/AssetFileDescriptor;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->a:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput v1, p0, Lcom/tencent/thumbplayer/adapter/h;->b:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/h;->e:Ljava/util/Map;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->c:Landroid/os/ParcelFileDescriptor;

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/h;->d:Landroid/content/res/AssetFileDescriptor;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method protected a(Landroid/os/ParcelFileDescriptor;)V
    .locals 4

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->a:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    iput v1, p0, Lcom/tencent/thumbplayer/adapter/h;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/h;->e:Ljava/util/Map;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/h;->c:Landroid/os/ParcelFileDescriptor;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->d:Landroid/content/res/AssetFileDescriptor;

    const/4 v3, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/e;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->a:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v1, 0x3

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput v1, p0, Lcom/tencent/thumbplayer/adapter/h;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->c:Landroid/os/ParcelFileDescriptor;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->d:Landroid/content/res/AssetFileDescriptor;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/h;->g:Lcom/tencent/thumbplayer/adapter/a/e;

    const/4 v3, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method protected a(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->a:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput v1, p0, Lcom/tencent/thumbplayer/adapter/h;->b:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/h;->e:Ljava/util/Map;

    const/4 v3, 0x2

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->c:Landroid/os/ParcelFileDescriptor;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->d:Landroid/content/res/AssetFileDescriptor;

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/h;->f:Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method protected a(Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/h;->a:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/h;->b:I

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/h;->c:Landroid/os/ParcelFileDescriptor;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/h;->d:Landroid/content/res/AssetFileDescriptor;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method protected a(Ljava/util/Map;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->e:Ljava/util/Map;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->e:Ljava/util/Map;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance p1, Ljava/util/HashMap;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {p1, v1}, Ljava/util/HashMap;-><init>(I)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    const/4 v3, 0x7

    return-void
.end method

.method public b()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->e:Ljava/util/Map;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public c()Landroid/os/ParcelFileDescriptor;
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->c:Landroid/os/ParcelFileDescriptor;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public d()Landroid/content/res/AssetFileDescriptor;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->d:Landroid/content/res/AssetFileDescriptor;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public e()Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->f:Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public f()Lcom/tencent/thumbplayer/adapter/a/e;
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->g:Lcom/tencent/thumbplayer/adapter/a/e;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public g()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/h;->b:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method protected h()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->a:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->c:Landroid/os/ParcelFileDescriptor;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->d:Landroid/content/res/AssetFileDescriptor;

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v1, 0x4

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->f:Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/h;->g:Lcom/tencent/thumbplayer/adapter/a/e;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0

    :cond_1
    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method
