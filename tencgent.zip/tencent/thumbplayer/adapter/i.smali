.class public Lcom/tencent/thumbplayer/adapter/i;
.super Ljava/lang/Object;


# instance fields
.field private a:Lcom/tencent/thumbplayer/api/TPPlayerState;


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/api/TPPlayerState;)V
    .locals 2
    .param p1    # Lcom/tencent/thumbplayer/api/TPPlayerState;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method private static a(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s~@ ro@@t ~~l .@f y~b n~ ~~~@ o~@~ o b@-~@ @Sl@~1~s@ ~@o~u~o  ~a/v@dM4@ic@~~~ m @bKifo~@@~t/ i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const/4 v0, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/16 v0, 0x8

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/16 v0, 0x9

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    return p0

    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 p0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return p0
.end method

.method private static b(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    return p0
.end method

.method private static c(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v1, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x3

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v1, 0x4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    move v3, v2

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x6

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/16 v1, 0x8

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-nez v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/16 v1, 0x9

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    return p0

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    return v0
.end method

.method private static d(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p0, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return p0
.end method

.method private static e(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v1, 0x4

    move v2, v1

    const/4 v0, 0x3

    const/4 v0, 0x5

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x6

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x7

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz p0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return p0

    :cond_1
    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 p0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return p0
.end method

.method private static f(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x5

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x6

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 p0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p0

    :cond_1
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 p0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x0

    return p0
.end method

.method private static g(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x4

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x5

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/16 v0, 0x8

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/16 v0, 0x9

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x6

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x7

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return p0

    :cond_1
    :goto_0
    const/4 v1, 0x5

    move v2, v1

    const/4 p0, 0x1

    move v2, p0

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return p0
.end method

.method private static h(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v1, 0x4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v1, 0x5

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v1, 0x6

    move v3, v1

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/16 v1, 0x8

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/16 v1, 0x9

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/16 v1, 0xa

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    return p0

    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    return v0
.end method

.method private static i(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x5

    shl-int/2addr v2, v0

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x6

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x7

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz p0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 p0, 0x0

    const/4 v2, 0x3

    return p0

    :cond_1
    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 p0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x4

    return p0
.end method

.method private static j(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x5

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x6

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/16 v0, 0x8

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/16 v0, 0x9

    const/4 v2, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v0, 0x7

    shr-int/2addr v2, v0

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 p0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return p0

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 p0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return p0
.end method

.method private static k(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v1, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x6

    const/4 v1, 0x4

    const/4 v3, 0x7

    move v2, v1

    move v2, v1

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    if-nez v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x5

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez v1, :cond_1

    const/4 v3, 0x7

    const/16 v1, 0x8

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-nez v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v1, 0x9

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v1, 0x7

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    return p0

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method private static l(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 4

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v1, 0x3

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v2, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    if-nez v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v1, 0x5

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    if-nez v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x6

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/16 v1, 0x8

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/16 v1, 0x9

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x7

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    return p0

    :cond_1
    :goto_0
    const/4 v3, 0x2

    return v0
.end method

.method private static m(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x1

    or-int/2addr v3, v2

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    if-nez v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez v1, :cond_1

    const/4 v2, 0x6

    move v3, v2

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x6

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-nez v1, :cond_1

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/16 v1, 0x8

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/16 v1, 0x9

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x7

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    return p0

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    return v0
.end method

.method private static n(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v1, 0x5

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-nez v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    move v3, v2

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/16 v1, 0x8

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/16 v1, 0x9

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x7

    move v3, v1

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 p0, 0x0

    move v3, p0

    const/4 v2, 0x2

    and-int/2addr v3, v2

    return p0

    :cond_1
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    return v0
.end method

.method private static o(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x4

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v0, 0x5

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/16 v0, 0x8

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/16 v0, 0x9

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x7

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 p0, 0x0

    move v2, p0

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return p0

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 p0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return p0
.end method

.method private static p(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v3, 0x1

    const/4 v1, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez v1, :cond_1

    const/4 v3, 0x2

    const/4 v1, 0x5

    const/4 v3, 0x7

    xor-int/2addr v2, v1

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    if-nez v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x6

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    if-nez v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/16 v1, 0x8

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/16 v1, 0x9

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    move v3, v1

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez v1, :cond_1

    const/4 v2, 0x1

    move v3, v2

    const/16 v1, 0xa

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    return p0

    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    return v0
.end method

.method private static q(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v2, 0x6

    const/4 v0, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return p0
.end method

.method private static r(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x4

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x5

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x6

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return p0

    :cond_1
    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 p0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return p0
.end method

.method private static s(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v1, 0x3

    move v2, v1

    const/4 v0, 0x6

    const/4 v0, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x5

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    if-nez v0, :cond_1

    const/4 v1, 0x4

    move v2, v1

    const/4 v0, 0x1

    const/4 v0, 0x6

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x3

    if-eqz p0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 p0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return p0

    :cond_1
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 p0, 0x1

    const/4 v2, 0x7

    return p0
.end method

.method private static t(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v1, 0x3

    move v2, v1

    const/4 v0, 0x4

    xor-int/2addr v2, v0

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x5

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x6

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x5

    return p0

    :cond_1
    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 p0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return p0
.end method

.method private static u(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    move v2, v1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x5

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x6

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 p0, 0x2

    const/4 p0, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return p0

    :cond_1
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return p0
.end method

.method private static v(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x5

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v0, 0x6

    const/4 v2, 0x3

    move v1, v0

    move v1, v0

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 p0, 0x0

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return p0

    :cond_1
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return p0
.end method

.method private static w(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x5

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x7

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/16 v0, 0x8

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz p0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return p0

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 p0, 0x1

    const/4 v1, 0x3

    move v2, v1

    return p0
.end method

.method private static x(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v0, 0x5

    or-int/2addr v1, v0

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x6

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    if-eqz p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    return p0

    :cond_1
    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 p0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    return p0
.end method

.method private static y(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x5

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/16 v0, 0x8

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/16 v0, 0x9

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v0, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x7

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 p0, 0x5

    const/4 v2, 0x4

    const/4 p0, 0x0

    const/4 v2, 0x0

    return p0

    :cond_1
    :goto_0
    const/4 v2, 0x4

    const/4 p0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x0

    return p0
.end method


# virtual methods
.method public final a(I)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v0, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-ne p1, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->a(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x0

    if-ne p1, v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->b(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return p1

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-ne p1, v0, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->c(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return p1

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x4

    move v2, v0

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-ne p1, v0, :cond_3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->d(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p1

    :cond_3
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x5

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-ne p1, v0, :cond_4

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->e(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x7

    return p1

    :cond_4
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x6

    const/4 v2, 0x1

    const/4 v1, 0x3

    if-ne p1, v0, :cond_5

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->f(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    return p1

    :cond_5
    const/4 v2, 0x4

    const/4 v0, 0x7

    const/4 v2, 0x5

    move v1, v0

    const/4 v2, 0x4

    if-ne p1, v0, :cond_6

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->g(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    return p1

    :cond_6
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/16 v0, 0x8

    if-ne p1, v0, :cond_7

    const/4 v2, 0x0

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->h(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return p1

    :cond_7
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/16 v0, 0x9

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-ne p1, v0, :cond_8

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->i(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p1

    :cond_8
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/16 v0, 0xb

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-ne p1, v0, :cond_9

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->j(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return p1

    :cond_9
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/16 v0, 0xc

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-ne p1, v0, :cond_a

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->k(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return p1

    :cond_a
    const/4 v2, 0x6

    const/16 v0, 0xd

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-ne p1, v0, :cond_b

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->m(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p1

    :cond_b
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/16 v0, 0xe

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-ne p1, v0, :cond_c

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->n(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return p1

    :cond_c
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/16 v0, 0xf

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-ne p1, v0, :cond_d

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->o(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    return p1

    :cond_d
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/16 v0, 0x10

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-ne p1, v0, :cond_e

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->p(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    return p1

    :cond_e
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/16 v0, 0x11

    const/4 v2, 0x0

    const/4 v1, 0x3

    if-ne p1, v0, :cond_f

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->x(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return p1

    :cond_f
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/16 v0, 0x12

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne p1, v0, :cond_10

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->y(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    return p1

    :cond_10
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/16 v0, 0x13

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-ne p1, v0, :cond_11

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->l(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return p1

    :cond_11
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return p1
.end method

.method public final b(I)Z
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    if-ne p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->q(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-ne p1, v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->r(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p1

    :cond_1
    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-ne p1, v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->s(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return p1

    :cond_2
    const/4 v2, 0x4

    const/4 v0, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-ne p1, v0, :cond_3

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->t(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return p1

    :cond_3
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-ne p1, v0, :cond_4

    const/4 v2, 0x4

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->u(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return p1

    :cond_4
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x6

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-ne p1, v0, :cond_5

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->v(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    return p1

    :cond_5
    const/4 v0, 0x7

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-ne p1, v0, :cond_6

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/i;->a:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/i;->w(Lcom/tencent/thumbplayer/api/TPPlayerState;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p1

    :cond_6
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return p1
.end method
