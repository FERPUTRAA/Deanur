.class public Lcom/tencent/thumbplayer/adapter/g;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/adapter/a/c$a;
.implements Lcom/tencent/thumbplayer/adapter/a/c$b;
.implements Lcom/tencent/thumbplayer/adapter/a/c$c;
.implements Lcom/tencent/thumbplayer/adapter/a/c$d;
.implements Lcom/tencent/thumbplayer/adapter/a/c$e;
.implements Lcom/tencent/thumbplayer/adapter/a/c$f;
.implements Lcom/tencent/thumbplayer/adapter/a/c$g;
.implements Lcom/tencent/thumbplayer/adapter/a/c$h;
.implements Lcom/tencent/thumbplayer/adapter/a/c$i;
.implements Lcom/tencent/thumbplayer/adapter/a/c$j;
.implements Lcom/tencent/thumbplayer/adapter/a/c$k;
.implements Lcom/tencent/thumbplayer/adapter/a/c$l;
.implements Lcom/tencent/thumbplayer/adapter/a/c$m;
.implements Lcom/tencent/thumbplayer/adapter/a/c$n;
.implements Lcom/tencent/thumbplayer/adapter/a/c$o;
.implements Lcom/tencent/thumbplayer/adapter/a/c$p;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/adapter/g$a;
    }
.end annotation


# instance fields
.field private a:Lcom/tencent/thumbplayer/adapter/a/c$i;

.field private b:Lcom/tencent/thumbplayer/adapter/a/c$c;

.field private c:Lcom/tencent/thumbplayer/adapter/a/c$h;

.field private d:Lcom/tencent/thumbplayer/adapter/a/c$f;

.field private e:Lcom/tencent/thumbplayer/adapter/a/c$j;

.field private f:Lcom/tencent/thumbplayer/adapter/a/c$p;

.field private g:Lcom/tencent/thumbplayer/adapter/a/c$l;

.field private h:Lcom/tencent/thumbplayer/adapter/a/c$n;

.field private i:Lcom/tencent/thumbplayer/adapter/a/c$a;

.field private j:Lcom/tencent/thumbplayer/adapter/a/c$m;

.field private k:Lcom/tencent/thumbplayer/adapter/a/c$o;

.field private l:Lcom/tencent/thumbplayer/adapter/a/c$b;

.field private m:Lcom/tencent/thumbplayer/adapter/a/c$k;

.field private n:Lcom/tencent/thumbplayer/adapter/a/c$e;

.field private o:Lcom/tencent/thumbplayer/adapter/a/c$g;

.field private p:Lcom/tencent/thumbplayer/adapter/a/c$d;

.field private q:Lcom/tencent/thumbplayer/adapter/g$a;

.field private r:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string v0, "PrsLesneaTleirSPs"

    const-string v0, "eessPlTnrPieLrySa"

    const/4 v2, 0x3

    const-string/jumbo v0, "yrtmaeTerPPnSeiLl"

    const-string v0, "TPPlayerListenerS"

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->r:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-instance p1, Lcom/tencent/thumbplayer/adapter/g$a;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->r:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p1, v0}, Lcom/tencent/thumbplayer/adapter/g$a;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->a:Lcom/tencent/thumbplayer/adapter/a/c$i;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->b:Lcom/tencent/thumbplayer/adapter/a/c$c;

    const/4 v1, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->c:Lcom/tencent/thumbplayer/adapter/a/c$h;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->d:Lcom/tencent/thumbplayer/adapter/a/c$f;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->e:Lcom/tencent/thumbplayer/adapter/a/c$j;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->f:Lcom/tencent/thumbplayer/adapter/a/c$p;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->g:Lcom/tencent/thumbplayer/adapter/a/c$l;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->h:Lcom/tencent/thumbplayer/adapter/a/c$n;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->i:Lcom/tencent/thumbplayer/adapter/a/c$a;

    const/4 v2, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->j:Lcom/tencent/thumbplayer/adapter/a/c$m;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->k:Lcom/tencent/thumbplayer/adapter/a/c$o;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->l:Lcom/tencent/thumbplayer/adapter/a/c$b;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->m:Lcom/tencent/thumbplayer/adapter/a/c$k;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->n:Lcom/tencent/thumbplayer/adapter/a/c$e;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->o:Lcom/tencent/thumbplayer/adapter/a/c$g;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->p:Lcom/tencent/thumbplayer/adapter/a/c$d;

    const/4 v1, 0x5

    shr-int/2addr v2, v1

    return-void
.end method


# virtual methods
.method public a(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "Mo@-oi~ nl~1~@ v ~~~~lKo~b@@@4~ sfoo~   ~    ~@~@Sf~@~/b@ @abr @mo~@.u~@@ ti@~~@td@~iy@c@/ ~@ ~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->k:Lcom/tencent/thumbplayer/adapter/a/c$o;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/c$o;->a(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p1
.end method

.method public a(Ljava/lang/String;I)Lcom/tencent/thumbplayer/api/TPRemoteSdpInfo;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->p:Lcom/tencent/thumbplayer/adapter/a/c$d;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/adapter/a/c$d;->a(Ljava/lang/String;I)Lcom/tencent/thumbplayer/api/TPRemoteSdpInfo;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p1
.end method

.method public a()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->a:Lcom/tencent/thumbplayer/adapter/a/c$i;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/c$i;->a()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public a(IIJJ)V
    .locals 9
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPErrorType;
        .end annotation
    .end param

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->d:Lcom/tencent/thumbplayer/adapter/a/c$f;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    move v1, p1

    move v1, p1

    move v1, p1

    move v1, p1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    move v2, p2

    move v2, p2

    const/4 v8, 0x5

    move v2, p2

    move v2, p2

    move-wide v3, p3

    move-wide v5, p5

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-interface/range {v0 .. v6}, Lcom/tencent/thumbplayer/adapter/a/c$f;->a(IIJJ)V

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    return-void
.end method

.method public a(IJJLjava/lang/Object;)V
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->c:Lcom/tencent/thumbplayer/adapter/a/c$h;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    move v1, p1

    move v1, p1

    move-wide v2, p2

    move-wide v4, p4

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-interface/range {v0 .. v6}, Lcom/tencent/thumbplayer/adapter/a/c$h;->a(IJJLjava/lang/Object;)V

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    return-void
.end method

.method public a(JJ)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->f:Lcom/tencent/thumbplayer/adapter/a/c$p;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {v0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/adapter/a/c$p;->a(JJ)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$a;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    if-nez p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->i:Lcom/tencent/thumbplayer/adapter/a/c$a;

    const/4 v1, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$b;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    if-nez p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->l:Lcom/tencent/thumbplayer/adapter/a/c$b;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$c;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    if-nez p1, :cond_0

    const/4 v0, 0x6

    xor-int/2addr v1, v0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->b:Lcom/tencent/thumbplayer/adapter/a/c$c;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$d;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    if-nez p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->p:Lcom/tencent/thumbplayer/adapter/a/c$d;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$e;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-nez p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->n:Lcom/tencent/thumbplayer/adapter/a/c$e;

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$f;)V
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    if-nez p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->d:Lcom/tencent/thumbplayer/adapter/a/c$f;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$g;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    if-nez p1, :cond_0

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->o:Lcom/tencent/thumbplayer/adapter/a/c$g;

    const/4 v1, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$h;)V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    if-nez p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->c:Lcom/tencent/thumbplayer/adapter/a/c$h;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$i;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    if-nez p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->a:Lcom/tencent/thumbplayer/adapter/a/c$i;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$j;)V
    .locals 2

    const/4 v1, 0x6

    if-nez p1, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->e:Lcom/tencent/thumbplayer/adapter/a/c$j;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$k;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    if-nez p1, :cond_0

    const/4 v0, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->m:Lcom/tencent/thumbplayer/adapter/a/c$k;

    const/4 v1, 0x3

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$l;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    if-nez p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v0, 0x0

    move v1, v0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->g:Lcom/tencent/thumbplayer/adapter/a/c$l;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$m;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    if-nez p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->j:Lcom/tencent/thumbplayer/adapter/a/c$m;

    const/4 v1, 0x2

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$n;)V
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x6

    if-nez p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->h:Lcom/tencent/thumbplayer/adapter/a/c$n;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$o;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    if-nez p1, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->k:Lcom/tencent/thumbplayer/adapter/a/c$o;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$p;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    if-nez p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->f:Lcom/tencent/thumbplayer/adapter/a/c$p;

    const/4 v0, 0x3

    shl-int/2addr v1, v0

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;)V
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->i:Lcom/tencent/thumbplayer/adapter/a/c$a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/c$a;->a(Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPDrmInfo;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->o:Lcom/tencent/thumbplayer/adapter/a/c$g;

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/c$g;->a(Lcom/tencent/thumbplayer/api/TPDrmInfo;)V

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPPlayerDetailInfo;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->n:Lcom/tencent/thumbplayer/adapter/a/c$e;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/c$e;->a(Lcom/tencent/thumbplayer/api/TPPlayerDetailInfo;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPSubtitleData;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->g:Lcom/tencent/thumbplayer/adapter/a/c$l;

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/c$l;->a(Lcom/tencent/thumbplayer/api/TPSubtitleData;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->j:Lcom/tencent/thumbplayer/adapter/a/c$m;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/c$m;->a(Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;)V
    .locals 3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->h:Lcom/tencent/thumbplayer/adapter/a/c$n;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/c$n;->a(Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string/jumbo p1, "riPlrbePtyTenesLa"

    const-string/jumbo p1, "ltPmenLiTaPeyrsre"

    const/4 v2, 0x6

    const-string/jumbo p1, "ryaSiPuTsLelrnePt"

    const-string p1, "TPPlayerListenerS"

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->r:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->r:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/adapter/g$a;->a(Lcom/tencent/thumbplayer/adapter/g$a;Ljava/lang/String;)Ljava/lang/String;

    :cond_1
    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public b(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->l:Lcom/tencent/thumbplayer/adapter/a/c$b;

    const/4 v1, 0x7

    move v2, v1

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/c$b;->b(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p1
.end method

.method public b()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->b:Lcom/tencent/thumbplayer/adapter/a/c$c;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/c$c;->b()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method public b(II)V
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->m:Lcom/tencent/thumbplayer/adapter/a/c$k;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/adapter/a/c$k;->b(II)V

    const/4 v2, 0x5

    return-void
.end method

.method public c()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->e:Lcom/tencent/thumbplayer/adapter/a/c$j;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/c$j;->c()V

    const/4 v2, 0x3

    return-void
.end method

.method public d()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->q:Lcom/tencent/thumbplayer/adapter/g$a;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->a:Lcom/tencent/thumbplayer/adapter/a/c$i;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->b:Lcom/tencent/thumbplayer/adapter/a/c$c;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->c:Lcom/tencent/thumbplayer/adapter/a/c$h;

    const/4 v2, 0x2

    const/4 v1, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->d:Lcom/tencent/thumbplayer/adapter/a/c$f;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->e:Lcom/tencent/thumbplayer/adapter/a/c$j;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->f:Lcom/tencent/thumbplayer/adapter/a/c$p;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->g:Lcom/tencent/thumbplayer/adapter/a/c$l;

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->h:Lcom/tencent/thumbplayer/adapter/a/c$n;

    const/4 v1, 0x2

    and-int/2addr v2, v1

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->i:Lcom/tencent/thumbplayer/adapter/a/c$a;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->j:Lcom/tencent/thumbplayer/adapter/a/c$m;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->m:Lcom/tencent/thumbplayer/adapter/a/c$k;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->k:Lcom/tencent/thumbplayer/adapter/a/c$o;

    const/4 v2, 0x3

    const/4 v1, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->l:Lcom/tencent/thumbplayer/adapter/a/c$b;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->n:Lcom/tencent/thumbplayer/adapter/a/c$e;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->o:Lcom/tencent/thumbplayer/adapter/a/c$g;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/g;->p:Lcom/tencent/thumbplayer/adapter/a/c$d;

    const/4 v2, 0x5

    return-void
.end method
