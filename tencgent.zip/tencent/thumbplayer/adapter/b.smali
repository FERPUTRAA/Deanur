.class public Lcom/tencent/thumbplayer/adapter/b;
.super Ljava/lang/Object;


# static fields
.field private static t:Ljava/lang/String; = "TPPlaybackInfo"


# instance fields
.field private a:Ljava/lang/String;

.field private b:Ljava/lang/String;

.field private c:I

.field private d:I

.field private e:J

.field private f:J

.field private g:J

.field private h:Ljava/lang/String;

.field private i:I

.field private j:J

.field private k:I

.field private l:J

.field private m:I

.field private n:J

.field private o:J

.field private p:J

.field private q:I

.field private r:Ljava/lang/String;

.field private s:J

.field private u:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/tencent/thumbplayer/adapter/b;->s:J

    const/4 v2, 0x3

    move v3, v2

    return-void
.end method

.method public static a(Ljava/lang/String;)Lcom/tencent/thumbplayer/adapter/b;
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "~~s  4@~l y~~c@@v~@@s@ ~~~o@t f~@o~@1 ~~ @@ ub/~~@r~~ b@/dK oo@   ~S  ino@@~@.~ba-lim o @~~fi@@t"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x5

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-eqz v0, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    new-instance p0, Lcom/tencent/thumbplayer/adapter/b;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/b;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    return-object p0

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string/jumbo v0, "n/"

    const-string v0, "/n"

    const/4 v8, 0x6

    const-string/jumbo v0, "n/"

    const-string v0, "\n"

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    const/4 v1, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    move v2, v1

    move v2, v1

    const/4 v8, 0x1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    array-length v3, p0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-ge v2, v3, :cond_4

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    aget-object v3, p0, v2

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string v4, "#"

    const-string v4, "#"

    const/4 v8, 0x1

    const-string v4, "#"

    const-string v4, "#"

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-nez v3, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    aget-object v3, p0, v2

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string v4, "="

    const-string v4, "="

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-eqz v3, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x6

    aget-object v3, p0, v2

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-eqz v3, :cond_1

    const/4 v7, 0x7

    xor-int/2addr v8, v7

    array-length v4, v3

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    const/4 v5, 0x2

    const/4 v8, 0x7

    if-lt v4, v5, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    aget-object v4, v3, v1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v5, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    aget-object v3, v3, v5

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-interface {v0, v4, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x4

    goto :goto_2

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    sget-object v4, Lcom/tencent/thumbplayer/adapter/b;->t:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    const-string/jumbo v6, "parseInfo, "

    const-string/jumbo v6, "parseInfo, "

    const/4 v8, 0x0

    const-string/jumbo v6, "parseInfo, "

    const-string/jumbo v6, "parseInfo, "

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    if-eqz v3, :cond_2

    const/4 v7, 0x1

    or-int/2addr v8, v7

    array-length v6, v3

    const/4 v7, 0x5

    move v8, v7

    if-lez v6, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x3

    aget-object v3, v3, v1

    const/4 v8, 0x2

    const/4 v7, 0x7

    goto :goto_1

    :cond_2
    const/4 v8, 0x3

    const-string/jumbo v3, "param null, "

    const/4 v8, 0x0

    const-string/jumbo v3, "param null, "

    const-string/jumbo v3, "param null, "

    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string/jumbo v3, "tsmm pie"

    const-string/jumbo v3, "ytspei m"

    const/4 v8, 0x4

    const-string/jumbo v3, "pmitoyse"

    const-string/jumbo v3, "is empty"

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {v4, v3}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    :goto_2
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    goto/16 :goto_0

    :cond_4
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-instance p0, Lcom/tencent/thumbplayer/adapter/b;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/b;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    const-string/jumbo v1, "mCiaFbtmteraonn"

    const-string v1, "earmniFCatmoont"

    const/4 v8, 0x6

    const-string v1, "aatrotuoeirnnmF"

    const-string v1, "ContainerFormat"

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-eqz v2, :cond_5

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/adapter/b;->b(Ljava/lang/String;)V

    :cond_5
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string v1, "eCoceddpVo"

    const-string v1, "ecVCoidoed"

    const/4 v8, 0x6

    const-string/jumbo v1, "odoVdicCqe"

    const-string v1, "VideoCodec"

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-eqz v2, :cond_6

    const/4 v8, 0x6

    const/4 v7, 0x4

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/adapter/b;->d(Ljava/lang/String;)V

    :cond_6
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string/jumbo v1, "iAsdcoodbC"

    const-string v1, "ecdCoboAdi"

    const/4 v8, 0x2

    const-string v1, "Adcmoouedi"

    const-string v1, "AudioCodec"

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    if-eqz v2, :cond_7

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x0

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/adapter/b;->e(Ljava/lang/String;)V

    :cond_7
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string/jumbo v1, "tWuio"

    const-string/jumbo v1, "iutWd"

    const/4 v8, 0x3

    const-string v1, "btdhW"

    const-string v1, "Width"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-eqz v2, :cond_8

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    check-cast v1, Ljava/lang/String;

    const/4 v7, 0x6

    or-int/2addr v8, v7

    invoke-static {v1}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p0, v1, v2}, Lcom/tencent/thumbplayer/adapter/b;->a(J)V

    :cond_8
    const/4 v8, 0x4

    const/4 v7, 0x0

    const-string/jumbo v1, "ugHetp"

    const-string/jumbo v1, "hpgeHt"

    const/4 v8, 0x4

    const-string/jumbo v1, "tpHeig"

    const-string v1, "Height"

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz v2, :cond_9

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-static {v1}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p0, v1, v2}, Lcom/tencent/thumbplayer/adapter/b;->b(J)V

    :cond_9
    const/4 v7, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    const-string/jumbo v1, "oRteVeiaqBqi"

    const-string v1, "aVdBitieqeRo"

    const/4 v8, 0x4

    const-string/jumbo v1, "otstReidBiVe"

    const-string v1, "VideoBitRate"

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-eqz v2, :cond_a

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {v1}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p0, v1, v2}, Lcom/tencent/thumbplayer/adapter/b;->c(J)V

    :cond_a
    const/4 v8, 0x7

    const/4 v7, 0x5

    const-string/jumbo v1, "euamoAditisR"

    const-string v1, "RasditeuoAiB"

    const/4 v8, 0x5

    const-string v1, "BtARooeadiiu"

    const-string v1, "AudioBitRate"

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    if-eqz v2, :cond_b

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {v1}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {p0, v1, v2}, Lcom/tencent/thumbplayer/adapter/b;->d(J)V

    :cond_b
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    const-string v1, "SpetRbmlaa"

    const-string v1, "SampleRate"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v8, 0x3

    if-eqz v2, :cond_c

    const/4 v8, 0x5

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v1}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x2

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {p0, v1, v2}, Lcom/tencent/thumbplayer/adapter/b;->e(J)V

    :cond_c
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string/jumbo v1, "lenhmsua"

    const-string/jumbo v1, "nhnmales"

    const-string/jumbo v1, "hnnaselp"

    const-string v1, "Channels"

    const/4 v8, 0x5

    const/4 v7, 0x7

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-eqz v2, :cond_d

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/adapter/b;->d(I)V

    :cond_d
    const/4 v7, 0x1

    move v8, v7

    const-string v1, "Dftooiieqn"

    const-string/jumbo v1, "ifoDonitei"

    const/4 v8, 0x3

    const-string/jumbo v1, "iisofnteni"

    const-string v1, "Definition"

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    if-eqz v2, :cond_e

    const/4 v8, 0x6

    const/4 v7, 0x5

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/adapter/b;->c(Ljava/lang/String;)V

    :cond_e
    const/4 v7, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    return-object p0
.end method


# virtual methods
.method public a()J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/tencent/thumbplayer/adapter/b;->e:J

    const/4 v3, 0x1

    const/4 v2, 0x6

    return-wide v0
.end method

.method public a(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/b;->c:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    return-void
.end method

.method public a(J)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-wide p1, p0, Lcom/tencent/thumbplayer/adapter/b;->e:J

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public b()J
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/tencent/thumbplayer/adapter/b;->f:J

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-wide v0
.end method

.method public b(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/b;->q:I

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method

.method public b(J)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-wide p1, p0, Lcom/tencent/thumbplayer/adapter/b;->f:J

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/b;->a:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/b;->a:Ljava/lang/String;

    const/4 v2, 0x2

    return-object v0
.end method

.method public c(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/b;->i:I

    const/4 v1, 0x3

    return-void
.end method

.method public c(J)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-wide p1, p0, Lcom/tencent/thumbplayer/adapter/b;->g:J

    const/4 v1, 0x5

    return-void
.end method

.method public c(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/b;->r:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public d()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/b;->r:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public d(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/b;->k:I

    const/4 v1, 0x4

    return-void
.end method

.method public d(J)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-wide p1, p0, Lcom/tencent/thumbplayer/adapter/b;->j:J

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public d(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/b;->b:Ljava/lang/String;

    const/4 v0, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public e()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/b;->c:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method public e(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/b;->m:I

    return-void
.end method

.method public e(J)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-wide p1, p0, Lcom/tencent/thumbplayer/adapter/b;->l:J

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public e(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/b;->h:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public f()J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-wide v0, p0, Lcom/tencent/thumbplayer/adapter/b;->g:J

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-wide v0
.end method

.method public f(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/b;->u:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public f(J)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-wide p1, p0, Lcom/tencent/thumbplayer/adapter/b;->n:J

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public g()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/b;->m:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method public g(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/b;->d:I

    const/4 v1, 0x4

    return-void
.end method

.method public g(J)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-wide p1, p0, Lcom/tencent/thumbplayer/adapter/b;->s:J

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public h()J
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-wide v0, p0, Lcom/tencent/thumbplayer/adapter/b;->n:J

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-wide v0
.end method

.method public h(J)V
    .locals 2

    const/4 v0, 0x2

    move v1, v0

    iput-wide p1, p0, Lcom/tencent/thumbplayer/adapter/b;->o:J

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public i()J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-wide v0, p0, Lcom/tencent/thumbplayer/adapter/b;->s:J

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-wide v0
.end method

.method public i(J)V
    .locals 2

    const/4 v1, 0x2

    iput-wide p1, p0, Lcom/tencent/thumbplayer/adapter/b;->p:J

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public j()J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/tencent/thumbplayer/adapter/b;->o:J

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-wide v0
.end method

.method public k()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-wide v0, p0, Lcom/tencent/thumbplayer/adapter/b;->p:J

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-wide v0
.end method

.method public l()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/b;->u:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public m()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/b;->d:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public n()V
    .locals 6

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/b;->a:Ljava/lang/String;

    const/4 v5, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/b;->b:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x4

    move v5, v4

    iput v1, p0, Lcom/tencent/thumbplayer/adapter/b;->c:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    iput v1, p0, Lcom/tencent/thumbplayer/adapter/b;->d:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x1

    iput-wide v2, p0, Lcom/tencent/thumbplayer/adapter/b;->e:J

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    iput-wide v2, p0, Lcom/tencent/thumbplayer/adapter/b;->f:J

    const/4 v5, 0x3

    iput-wide v2, p0, Lcom/tencent/thumbplayer/adapter/b;->g:J

    const/4 v5, 0x0

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/b;->h:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    iput v1, p0, Lcom/tencent/thumbplayer/adapter/b;->i:I

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput-wide v2, p0, Lcom/tencent/thumbplayer/adapter/b;->j:J

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    iput v1, p0, Lcom/tencent/thumbplayer/adapter/b;->k:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    iput-wide v2, p0, Lcom/tencent/thumbplayer/adapter/b;->l:J

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v0, 0x2

    shl-int/2addr v5, v0

    const/4 v4, 0x3

    const/4 v4, 0x7

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/b;->q:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput v1, p0, Lcom/tencent/thumbplayer/adapter/b;->m:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    iput-wide v2, p0, Lcom/tencent/thumbplayer/adapter/b;->n:J

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    iput-wide v2, p0, Lcom/tencent/thumbplayer/adapter/b;->o:J

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput-wide v2, p0, Lcom/tencent/thumbplayer/adapter/b;->p:J

    const/4 v5, 0x4

    const/4 v4, 0x5

    iput v1, p0, Lcom/tencent/thumbplayer/adapter/b;->u:I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v5, 0x3

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    iput-wide v0, p0, Lcom/tencent/thumbplayer/adapter/b;->s:J

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-void
.end method
