.class Lcom/tencent/thumbplayer/adapter/a/b/b$1;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/adapter/a/b/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/adapter/a/b/b;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/adapter/a/b/b;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$1;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method private a(ILjava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "t~s/  1@@- o@@ @d @~@~l.lo @y ~~~f@@Ms@~c~i~o  ui@~~rmS 4 n~@~t@@@f~vo@~~ ~~  bio~@ @b a/@ Ko~b~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$1;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v1, 0x0

    move v2, v1

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->b(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/adapter/a/b/b$a;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$1;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->b(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/adapter/a/b/b$a;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {v0, p1, p2}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method public onASyncCallResult(IJII)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$1;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/e/a;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo v2, "tccmoRTles nplyleCnyAl,:aSua"

    const-string v2, ":asSaolccl teluylRnpyTelA,nC"

    const-string v2, ",nTAoSlyls:aRnlue otapclcCyl"

    const-string/jumbo v2, "onASyncCallResult, callType:"

    const/4 v4, 0x4

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string v2, "a uq,bmeo"

    const-string v2, "eoum, qap"

    const/4 v4, 0x1

    const-string v2, ",eoq: upu"

    const-string v2, ", opaque:"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v2, "royere poT:r"

    const-string v2, ":e royropreT"

    const/4 v4, 0x0

    const-string v2, ",rr: eoeqrpy"

    const-string v2, ", errorType:"

    const/4 v4, 0x6

    const/4 v3, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v1, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const-string v2, ",esororbC:re"

    const-string v2, "Cee,oborr:dr"

    const/4 v4, 0x4

    const-string v2, "Co,mered :rr"

    const-string v2, ", errorCode:"

    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, p5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/b/b$b;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b$b;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput p1, v0, Lcom/tencent/thumbplayer/adapter/a/b/b$b;->a:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput-wide p2, v0, Lcom/tencent/thumbplayer/adapter/a/b/b$b;->b:J

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput p4, v0, Lcom/tencent/thumbplayer/adapter/a/b/b$b;->c:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput p5, v0, Lcom/tencent/thumbplayer/adapter/a/b/b$b;->d:I

    const/4 v4, 0x1

    const/4 p1, 0x1

    const/4 v4, 0x7

    shr-int/2addr v3, p1

    const/4 v4, 0x4

    invoke-direct {p0, p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b/b$1;->a(ILjava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void
.end method

.method public onDetailInfo(Lcom/tencent/thumbplayer/core/common/TPDetailInfo;)V
    .locals 6

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$1;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/e/a;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string/jumbo v2, "oiI ontyDuf,latpeo:"

    const-string/jumbo v2, "t,fyDoupoant:I ienl"

    const/4 v5, 0x4

    const-string/jumbo v2, "oDtI,bnn ela:fiyopt"

    const-string/jumbo v2, "onDetailInfo, type:"

    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget v2, p1, Lcom/tencent/thumbplayer/core/common/TPDetailInfo;->type:I

    const/4 v4, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const-string/jumbo v2, "pm ei:u"

    const-string/jumbo v2, "p e:i,m"

    const/4 v5, 0x0

    const-string/jumbo v2, "p,me t:"

    const-string v2, ", time:"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-wide v2, p1, Lcom/tencent/thumbplayer/core/common/TPDetailInfo;->timeSince1970Us:J

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v0, 0x5

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b$1;->a(ILjava/lang/Object;)V

    const/4 v5, 0x1

    return-void
.end method

.method public onError(II)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$1;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/e/a;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const-string/jumbo v2, "rosTmroeqrEn y,:g"

    const-string/jumbo v2, "onError, msgType:"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string/jumbo v2, "qrsC ,rree:o"

    const-string v2, " ore:eorq,Cr"

    const/4 v4, 0x0

    const-string v2, ": dmrooeCre,"

    const-string v2, ", errorCode:"

    const/4 v4, 0x7

    const/4 v3, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/b/b$c;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b$c;-><init>()V

    const/4 v3, 0x7

    move v4, v3

    iput p1, v0, Lcom/tencent/thumbplayer/adapter/a/b/b$c;->a:I

    const/4 v4, 0x2

    iput p2, v0, Lcom/tencent/thumbplayer/adapter/a/b/b$c;->b:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 p1, 0x4

    const/4 v4, 0x1

    invoke-direct {p0, p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b/b$1;->a(ILjava/lang/Object;)V

    const/4 v3, 0x1

    move v4, v3

    return-void
.end method

.method public onInfoLong(IJJ)V
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    const/16 v0, 0xfd

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-ne p1, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDrmType;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDrmType;

    const/4 v2, 0x2

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDrmType;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDrmType;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    long-to-int p2, p2

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/a;->b(I)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/b/b$d;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b$d;-><init>()V

    const/4 v2, 0x3

    iput p1, v0, Lcom/tencent/thumbplayer/adapter/a/b/b$d;->a:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-wide p2, v0, Lcom/tencent/thumbplayer/adapter/a/b/b$d;->b:J

    const/4 v2, 0x1

    iput-wide p4, v0, Lcom/tencent/thumbplayer/adapter/a/b/b$d;->c:J

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 p1, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0, p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b/b$1;->a(ILjava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public onInfoObject(ILjava/lang/Object;)V
    .locals 5

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$1;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(Lcom/tencent/thumbplayer/adapter/a/b/b;I)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$1;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/e/a;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string v2, ":seyo,opfnOcteIojnTo in"

    const-string v2, ":psyfoTce,Iennoionj Oft"

    const/4 v4, 0x5

    const-string/jumbo v2, "n oyebfonte,nopOIj:ibTf"

    const-string/jumbo v2, "onInfoObject, infoType:"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo v2, "ramojau,bm "

    const-string/jumbo v2, "j,omaarmb P"

    const/4 v4, 0x1

    const-string/jumbo v2, "mao,a bprPj"

    const-string v2, ", objParam:"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x6

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/b/b$e;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b$e;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput p1, v0, Lcom/tencent/thumbplayer/adapter/a/b/b$e;->a:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput-object p2, v0, Lcom/tencent/thumbplayer/adapter/a/b/b$e;->b:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 p1, 0x3

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {p0, p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b/b$1;->a(ILjava/lang/Object;)V

    const/4 v4, 0x1

    return-void
.end method
