.class Lcom/tencent/thumbplayer/adapter/a/b/b$3;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/player/ITPNativePlayerVideoFrameCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/adapter/a/b/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/adapter/a/b/b;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/adapter/a/b/b;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$3;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v0, 0x3

    and-int/2addr v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public onVideoFrame(Lcom/tencent/thumbplayer/core/common/TPVideoFrame;I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ls u~ M@@@o.vf@~~tra /ld @~4~b ~i~ @/~@@n@t@ cmb 1K f s~~ ~@~~@~Sio~ @@ @@@ i~ob~~~~o@@- ~o yo "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/core/common/TPVideoFrame;)Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$3;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p2}, Lcom/tencent/thumbplayer/adapter/a/b/b;->c(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/adapter/g;

    move-result-object p2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method
