.class final Lcom/tencent/thumbplayer/adapter/a/b/a$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/adapter/a/b/a;->a(Landroid/content/SharedPreferences;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/SharedPreferences;


# direct methods
.method constructor <init>(Landroid/content/SharedPreferences;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/a$1;->a:Landroid/content/SharedPreferences;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@@so@@l@ ~cu~o@a@ ovftt @s~  oMi~ lb~@K~@~/@~@  ~S o~ ~d~~o  n ~/y @@@@fi~ -4@ i@~r@~b~.~~1 ~b~@"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x5

    const/4 v0, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    new-array v1, v0, [I

    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPThumbplayerCapabilityHelper;->getDRMCapabilities()[I

    move-result-object v1
    :try_end_0
    .catch Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    goto :goto_0

    :catch_0
    move-exception v2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    const-string/jumbo v3, "slCmDPTabrapmiy"

    const-string v3, "TrsmCyaPilabDpi"

    const/4 v7, 0x6

    const-string/jumbo v3, "iPbtorapCimylTa"

    const-string v3, "TPDrmCapability"

    const/4 v7, 0x2

    invoke-static {v3, v2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v6, 0x4

    move v7, v6

    const-string v2, "TDiapbPlatyCmrm"

    const-string/jumbo v2, "mtimypPrbTaalCD"

    const/4 v7, 0x4

    const-string/jumbo v2, "iCyrbPuimtalDpa"

    const-string v2, "TPDrmCapability"

    const/4 v6, 0x4

    move v7, v6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    const-string v4, "aamiyryplpiPlblbeypa,pi :McTtoDtharilbPRe uTaC"

    const-string/jumbo v4, "hpuaolectHbeallMtPCppybyiTblryaPT:iria  RDi,am"

    const/4 v7, 0x2

    const-string v4, " bbaCb:lqayue yiMPRT,tplHaaaDiPryThtppeeilrlim"

    const-string v4, "TPThumbPlayerCapabilityHelper, DRM capability:"

    const/4 v6, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v1}, Ljava/util/Arrays;->toString([I)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    or-int/2addr v7, v6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x6

    invoke-static {v2, v3}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    array-length v2, v1

    const/4 v7, 0x2

    if-nez v2, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    return-void

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    new-instance v2, Ljava/util/HashSet;

    const/4 v7, 0x5

    const/4 v6, 0x2

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    array-length v3, v1

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-ge v0, v3, :cond_1

    const/4 v6, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    aget v4, v1, v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    const-class v5, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDrmType;

    const-class v5, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDrmType;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {v5, v4}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v2, v4}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    goto :goto_1

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/a$1;->a:Landroid/content/SharedPreferences;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    const-string v1, "TBsYICDIAARTPSI__Lb"

    const-string v1, "CAPIDbTLSIT_R_IYALB"

    const/4 v7, 0x6

    const-string v1, "CATm_LRDMIABLIST_IP"

    const-string v1, "DRM_CAPABILITY_LIST"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    const/4 v7, 0x5

    const/4 v6, 0x4

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const/4 v7, 0x1

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const/4 v6, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    monitor-enter v0

    :try_start_1
    const/4 v6, 0x6

    move v7, v6

    invoke-static {v2}, Lcom/tencent/thumbplayer/adapter/a/b/a;->a(Ljava/util/Set;)Ljava/util/Set;

    const/4 v7, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/a/b/a;->c()Ljava/util/Set;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/adapter/a/b/a;->b()Ljava/util/Set;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-interface {v1, v2}, Ljava/util/Set;->removeAll(Ljava/util/Collection;)Z

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    monitor-exit v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    return-void

    :catchall_0
    move-exception v1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    throw v1
.end method
