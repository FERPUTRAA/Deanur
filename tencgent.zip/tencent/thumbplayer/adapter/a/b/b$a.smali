.class Lcom/tencent/thumbplayer/adapter/a/b/b$a;
.super Landroid/os/Handler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/adapter/a/b/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "a"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/adapter/a/b/b;

.field private b:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcom/tencent/thumbplayer/adapter/a/b/b;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/adapter/a/b/b;Landroid/os/Looper;Lcom/tencent/thumbplayer/adapter/a/b/b;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v1, 0x7

    const/4 v0, 0x7

    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    new-instance p1, Ljava/lang/ref/WeakReference;

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p1, p3}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->b:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method private a(II)V
    .locals 10
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$NativeErrorType;
        .end annotation
    .end param

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "~isf~~-@@1~@~c bt@yv~@~soaf@~  4 ~~.d/ K~~~b@nio ~~t~   @~@Su~@o o  @@bri@Ml /o@  @~@~~ @l@@m o@"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v8, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->c(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/adapter/g;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapErrorType;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapErrorType;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapErrorType;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapErrorType;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result v2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x2

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v9, 0x0

    const-wide/16 v6, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    move v3, p2

    move v3, p2

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual/range {v1 .. v7}, Lcom/tencent/thumbplayer/adapter/g;->a(IIJJ)V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/adapter/a/b/b$b;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget v0, p1, Lcom/tencent/thumbplayer/adapter/a/b/b$b;->a:I

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x6

    move v2, v1

    move v2, v1

    const/4 v3, 0x3

    if-eq v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eq v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(Lcom/tencent/thumbplayer/adapter/a/b/b;Lcom/tencent/thumbplayer/adapter/a/b/b$b;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->e(Lcom/tencent/thumbplayer/adapter/a/b/b;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v3, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->d(Lcom/tencent/thumbplayer/adapter/a/b/b;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/adapter/a/b/b$d;)V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget v0, p1, Lcom/tencent/thumbplayer/adapter/a/b/b$d;->a:I

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/16 v1, 0x9a

    const/4 v6, 0x3

    const/4 v5, 0x2

    if-eq v0, v1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/16 v1, 0xfa

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eq v0, v1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v1, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(Lcom/tencent/thumbplayer/adapter/a/b/b;ILcom/tencent/thumbplayer/adapter/a/b/b$d;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    return-void

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-wide v1, p1, Lcom/tencent/thumbplayer/adapter/a/b/b$d;->b:J

    const/4 v6, 0x4

    iget-wide v3, p1, Lcom/tencent/thumbplayer/adapter/a/b/b$d;->c:J

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v0, v1, v2, v3, v4}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(Lcom/tencent/thumbplayer/adapter/a/b/b;JJ)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-void

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->f(Lcom/tencent/thumbplayer/adapter/a/b/b;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/adapter/a/b/b$e;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget v0, p1, Lcom/tencent/thumbplayer/adapter/a/b/b$e;->a:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/16 v1, 0x1f6

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eq v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v1, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(Lcom/tencent/thumbplayer/adapter/a/b/b;ILcom/tencent/thumbplayer/adapter/a/b/b$e;)V

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    iget-object v0, p1, Lcom/tencent/thumbplayer/adapter/a/b/b$e;->b:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    instance-of v0, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->g(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/api/TPSubtitleData;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object p1, p1, Lcom/tencent/thumbplayer/adapter/a/b/b$e;->b:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    check-cast p1, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object p1, v0, Lcom/tencent/thumbplayer/api/TPSubtitleData;->subtitleData:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->c(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/adapter/g;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->g(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/api/TPSubtitleData;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPSubtitleData;)V

    :cond_1
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/core/common/TPDetailInfo;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/core/common/TPDetailInfo;)Lcom/tencent/thumbplayer/api/TPPlayerDetailInfo;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->c(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/adapter/g;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPPlayerDetailInfo;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->b:Ljava/lang/ref/WeakReference;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    check-cast v0, Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/e/a;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo v0, "s lmukans iemfRl"

    const-string/jumbo v0, "lusRkslW  amfeni"

    const/4 v4, 0x5

    const-string/jumbo v0, "mWeakRef is null"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eq v0, v1, :cond_5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v1, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eq v0, v1, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x3

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eq v0, v1, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eq v0, v1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v1, 0x5

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eq v0, v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/e/a;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string v2, "es go:mam"

    const-string v2, " msmag:se"

    const/4 v4, 0x0

    const-string/jumbo v2, "s:s gbmee"

    const-string/jumbo v2, "message :"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    iget p1, p1, Landroid/os/Message;->what:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string p1, "  onngu enictorot"

    const-string/jumbo p1, "ncinotrooone  gt "

    const/4 v4, 0x2

    const-string p1, " g nicnpoiorent t"

    const-string p1, "  not recognition"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    check-cast p1, Lcom/tencent/thumbplayer/core/common/TPDetailInfo;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a(Lcom/tencent/thumbplayer/core/common/TPDetailInfo;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    check-cast p1, Lcom/tencent/thumbplayer/adapter/a/b/b$c;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v0, p1, Lcom/tencent/thumbplayer/adapter/a/b/b$c;->a:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget p1, p1, Lcom/tencent/thumbplayer/adapter/a/b/b$c;->b:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a(II)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    check-cast p1, Lcom/tencent/thumbplayer/adapter/a/b/b$e;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a(Lcom/tencent/thumbplayer/adapter/a/b/b$e;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void

    :cond_4
    const/4 v4, 0x5

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    check-cast p1, Lcom/tencent/thumbplayer/adapter/a/b/b$d;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a(Lcom/tencent/thumbplayer/adapter/a/b/b$d;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-void

    :cond_5
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v4, 0x4

    check-cast p1, Lcom/tencent/thumbplayer/adapter/a/b/b$b;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b$a;->a(Lcom/tencent/thumbplayer/adapter/a/b/b$b;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void
.end method
