.class public Lcom/tencent/thumbplayer/adapter/a/b/c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/adapter/a/b/c$a;
    }
.end annotation


# static fields
.field private static a:Ljava/lang/String; = "TPThumbPlayerUtils"


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method

.method private static a(J)J
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "@vs @~~@b~~ a ~@~o~~ @@@@~~~bl@@ @~~~1/dr @~@ K@ o~o  Mo bt~.4@ s-um@f/  @l~ tc@i ii@So~~ ~f@~on"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x6

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSubtitleRenderParams;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSubtitleRenderParams;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSubtitleRenderParams;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSubtitleRenderParams;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getEntrySetOfToNativeMap(Ljava/lang/Class;)Ljava/util/Set;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v9, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    move-wide v3, v1

    :cond_0
    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-eqz v5, :cond_1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    check-cast v5, Ljava/util/Map$Entry;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    check-cast v6, Ljava/lang/Number;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v6}, Ljava/lang/Number;->longValue()J

    move-result-wide v6

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    and-long/2addr v6, p0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    cmp-long v6, v6, v1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-lez v6, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x2

    const/4 v8, 0x5

    check-cast v5, Ljava/lang/Number;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v5}, Ljava/lang/Number;->longValue()J

    move-result-wide v5

    const/4 v9, 0x3

    const/4 v8, 0x0

    or-long/2addr v3, v5

    const/4 v9, 0x3

    goto :goto_0

    :cond_1
    const/4 v9, 0x1

    return-wide v3
.end method

.method public static a(Lcom/tencent/thumbplayer/core/common/TPAudioFrame;)Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-nez p0, :cond_0

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    const/4 p0, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-object p0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-instance v0, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;

    const/4 v6, 0x7

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;-><init>()V

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioSampleFormat;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioSampleFormat;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget v2, p0, Lcom/tencent/thumbplayer/core/common/TPAudioFrame;->format:I

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;->format:I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPAudioFrame;->data:[[B

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;->data:[[B

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPAudioFrame;->linesize:[I

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;->size:[I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPAudioFrame;->sampleRate:I

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;->sampleRate:I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/common/TPAudioFrame;->channelLayout:J

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;->channelLayout:J

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/common/TPAudioFrame;->ptsUs:J

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x5

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    div-long/2addr v1, v3

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;->ptsMs:J

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPAudioFrame;->nbSamples:I

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;->nbSamples:I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget p0, p0, Lcom/tencent/thumbplayer/core/common/TPAudioFrame;->channels:I

    const/4 v6, 0x1

    iput p0, v0, Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;->channels:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;)Lcom/tencent/thumbplayer/api/TPDashFormat;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/api/TPDashFormat;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPDashFormat;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;->representationId:Ljava/lang/String;

    const/4 v3, 0x4

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPDashFormat;->representationId:Ljava/lang/String;

    const/4 v2, 0x7

    move v3, v2

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;->codecs:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPDashFormat;->codecs:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;->mimeType:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPDashFormat;->mimeType:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;->language:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPDashFormat;->language:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;->width:I

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPDashFormat;->width:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;->height:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPDashFormat;->height:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;->bandwidth:I

    const/4 v3, 0x2

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPDashFormat;->bandwidth:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;->audioChannels:I

    const/4 v2, 0x0

    move v3, v2

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPDashFormat;->audioChannels:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;->audioSamplingRate:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPDashFormat;->audioSamplingRate:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget p0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;->frameRate:F

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput p0, v0, Lcom/tencent/thumbplayer/api/TPDashFormat;->frameRate:F

    const/4 v3, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;)Lcom/tencent/thumbplayer/api/TPDrmInfo;
    .locals 5
    .param p0    # Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x7

    const/4 v3, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPDrmInfo;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mSecureLevel:I

    const/4 v4, 0x6

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmSecureLevel:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mSupportSecureDecoder:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmSupportSecureDecoder:I

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mSupportSecureDecrypt:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmSupportSecureDecrypt:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mComponentName:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmComponentName:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapReportDrmType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapReportDrmType;

    const/4 v3, 0x3

    or-int/2addr v4, v3

    iget v2, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mDrmType:I

    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmType:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mPrepareSTimeMs:J

    const/4 v4, 0x5

    const/4 v3, 0x0

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmPrepareStartTimeMs:J

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mPrepareETimeMs:J

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmPrepareEndTimeMs:J

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mOpenSessionSTimeMs:J

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmOpenSessionStartTimeMs:J

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mOpenSessionETimeMs:J

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmOpenSessionEndTimeMs:J

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mGetProvisionReqSTimeMs:J

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmGetProvisionReqStartTimeMs:J

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mGetProvisionReqETimeMs:J

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmGetProvisionReqEndTimeMs:J

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mSendProvisionReqTimeMs:J

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmSendProvisionReqTimeMs:J

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mRecvProvisionRespTimeMs:J

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmRecvProvisionRespTimeMs:J

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mProvideProvisionRespSTimeMs:J

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmProvideProvisionRespStartTimeMs:J

    const/4 v4, 0x0

    const/4 v3, 0x6

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mProvideProvisionRespETimeMs:J

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmProvideProvisionRespEndTimeMs:J

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mGetKeyReqSTimeMs:J

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmGetKeyReqStartTimeMs:J

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mGetKeyReqETimeMs:J

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmGetKeyReqEndTimeMs:J

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mSendKeyReqTimeMs:J

    const/4 v3, 0x7

    move v4, v3

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmSendKeyReqTimeMs:J

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mRecvKeyRespTimeMs:J

    const/4 v4, 0x1

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmRecvKeyRespTimeMs:J

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mProvideKeyRespSTimeMs:J

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmProvideKeyRespStartTimeMs:J

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams$TPPlayerDrmParams;->mProvideKeyRespETimeMs:J

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPDrmInfo;->drmProvideKeyRespEndTimeMs:J

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/core/common/TPDetailInfo;)Lcom/tencent/thumbplayer/api/TPPlayerDetailInfo;
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-nez p0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/4 p0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    return-object p0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/api/TPPlayerDetailInfo;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDetailInfoType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDetailInfoType;

    const/4 v7, 0x3

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDetailInfoType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDetailInfoType;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget v2, p0, Lcom/tencent/thumbplayer/core/common/TPDetailInfo;->type:I

    const/4 v7, 0x7

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-wide v2, p0, Lcom/tencent/thumbplayer/core/common/TPDetailInfo;->timeSince1970Us:J

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x0

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x3

    const/4 v6, 0x6

    div-long/2addr v2, v4

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-direct {v0, v1, v2, v3}, Lcom/tencent/thumbplayer/api/TPPlayerDetailInfo;-><init>(IJ)V

    const/4 v6, 0x0

    shl-int/2addr v7, v6

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$MediaCodecInfo;)Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaCodecInfo;
    .locals 5

    const/4 v4, 0x4

    if-nez p0, :cond_0

    const/4 v3, 0x3

    shl-int/2addr v4, v3

    const/4 p0, 0x0

    move v4, p0

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-object p0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-instance v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaCodecInfo;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaCodecInfo;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$MediaCodecInfo;->mediaType:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eq v1, v2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    sget v1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaCodecInfo;->TP_DEC_MEDIA_TYPE_UNKNOWN:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    sget v1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaCodecInfo;->TP_DEC_MEDIA_TYPE_AUDIO:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_0

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    sget v1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaCodecInfo;->TP_DEC_MEDIA_TYPE_VIDEO:I

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaCodecInfo;->mediaType:I

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$MediaCodecInfo;->infoType:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v1, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eq v1, v2, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x2

    sget v1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaCodecInfo;->TP_INFO_UNKNOWN:I

    goto :goto_1

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x2

    sget v1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaCodecInfo;->TP_INFO_MEDIA_CODEC_EXCEPTION:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_1

    :cond_4
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget v1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaCodecInfo;->TP_INFO_MEDIA_CODEC_READY:I

    :goto_1
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaCodecInfo;->infoType:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object p0, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$MediaCodecInfo;->msg:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-object p0, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaCodecInfo;->msg:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$MediaDrmInfo;)Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaDrmInfo;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaDrmInfo;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaDrmInfo;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-boolean v1, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$MediaDrmInfo;->supportSecureDecoder:Z

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-boolean v1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaDrmInfo;->supportSecureDecoder:Z

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-boolean v1, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$MediaDrmInfo;->supportSecureDecrypt:Z

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-boolean v1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaDrmInfo;->supportSecureDecrypt:Z

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$MediaDrmInfo;->componentName:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaDrmInfo;->componentName:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDrmType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDrmType;

    const/4 v3, 0x2

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDrmType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDrmType;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget p0, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$MediaDrmInfo;->drmType:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v1, p0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput p0, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaDrmInfo;->drmType:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoCropInfo;)Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoCropInfo;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez p0, :cond_0

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x0

    move v2, p0

    move v2, p0

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoCropInfo;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoCropInfo;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoCropInfo;->width:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoCropInfo;->width:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoCropInfo;->height:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoCropInfo;->height:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoCropInfo;->cropLeft:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoCropInfo;->cropLeft:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoCropInfo;->cropRight:I

    const/4 v3, 0x6

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoCropInfo;->cropRight:I

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoCropInfo;->cropTop:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoCropInfo;->cropTop:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget p0, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoCropInfo;->cropBottom:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput p0, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoCropInfo;->cropBottom:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoSeiInfo;)Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoSeiInfo;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-nez p0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 p0, 0x0

    const/4 v4, 0x4

    return-object p0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoSeiInfo;

    const/4 v4, 0x6

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoSeiInfo;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const/4 v4, 0x4

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapCodecType;

    const/4 v4, 0x3

    iget v2, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoSeiInfo;->videoCodecType:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoSeiInfo;->videoCodecType:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-boolean v2, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoSeiInfo;->isSpecialType:Z

    const/4 v4, 0x4

    if-eqz v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoSeiInfo;->videoSeiType:I

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoSeiInfo;->videoSeiType:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto :goto_2

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/16 v2, 0x1a

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-ne v1, v2, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoH264SeiType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoH264SeiType;

    const/4 v4, 0x0

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoH264SeiType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoH264SeiType;

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v2, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoSeiInfo;->videoSeiType:I

    const/4 v3, 0x4

    move v4, v3

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    goto :goto_0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/16 v2, 0xac

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-ne v1, v2, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoHevcSeiType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoHevcSeiType;

    const/4 v4, 0x5

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoHevcSeiType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoHevcSeiType;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    goto :goto_1

    :cond_3
    :goto_2
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoSeiInfo;->dataSize:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoSeiInfo;->seiDataSize:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object p0, p0, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoSeiInfo;->data:[B

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p0, v1}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-object p0, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoSeiInfo;->seiData:[B

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-nez p0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 p0, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x2

    return-object p0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    new-instance v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMediaType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMediaType;

    const/4 v6, 0x7

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMediaType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMediaType;

    const/4 v5, 0x0

    move v6, v5

    iget v2, p0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->mediaType:I

    const/4 v6, 0x6

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->mediaType:I

    const/4 v6, 0x4

    if-nez v1, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPixelFormat;

    const/4 v6, 0x4

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPixelFormat;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPixelFormat;

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    iget v2, p0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->format:I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->format:I

    const/4 v6, 0x7

    const/4 v5, 0x7

    goto :goto_1

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-ne v1, v2, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioSampleFormat;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioSampleFormat;

    const/4 v6, 0x2

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioSampleFormat;

    const/4 v5, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->data:[[B

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->data:[[B

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->linesize:[I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->size:[I

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->sampleRate:I

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->sampleRate:I

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->channelLayout:J

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->channelLayout:J

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->ptsUs:J

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x1

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    div-long/2addr v1, v3

    const/4 v6, 0x2

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->ptsMs:J

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->nbSamples:I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->nbSamples:I

    const/4 v6, 0x0

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->channels:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->channels:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->width:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->width:I

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->height:I

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->height:I

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->sampleAspectRatioNum:I

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->sampleAspectRatioNum:I

    const/4 v5, 0x3

    const/4 v5, 0x7

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->sampleAspectRatioDen:I

    const/4 v6, 0x0

    const/4 v5, 0x1

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->sampleAspectRatioDen:I

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->rotation:I

    const/4 v6, 0x5

    const/4 v5, 0x6

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->rotation:I

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object p0, p0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->perfData:Ljava/util/HashMap;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    iput-object p0, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->perfData:Ljava/util/HashMap;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/core/common/TPSubtitleFrame;)Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-nez p0, :cond_0

    const/4 v5, 0x2

    move v6, v5

    const/4 p0, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-object p0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPSubtitleFrame;->data:[[B

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->data:[[B

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPSubtitleFrame;->linesize:[I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->lineSize:[I

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSubtitleFormat;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSubtitleFormat;

    const/4 v6, 0x5

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSubtitleFormat;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSubtitleFormat;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget v2, p0, Lcom/tencent/thumbplayer/core/common/TPSubtitleFrame;->format:I

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->format:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPSubtitleFrame;->height:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->srcHeight:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget v2, p0, Lcom/tencent/thumbplayer/core/common/TPSubtitleFrame;->width:I

    const/4 v6, 0x2

    const/4 v5, 0x0

    iput v2, v0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->srcWidth:I

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->dstHeight:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    iput v2, v0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->dstWidth:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPSubtitleFrame;->rotation:I

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->rotation:I

    const/4 v6, 0x0

    const/4 v5, 0x5

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/common/TPSubtitleFrame;->ptsUs:J

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x5

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    div-long/2addr v1, v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;->ptsMs:J

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceDolbyVisionInfo;)Lcom/tencent/thumbplayer/api/TPSurfaceDolbyVisionInfo;
    .locals 4

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object p0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/api/TPSurfaceDolbyVisionInfo;

    const/4 v3, 0x2

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPSurfaceDolbyVisionInfo;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceDolbyVisionInfo;->mProfile:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPSurfaceDolbyVisionInfo;->mProfile:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceDolbyVisionInfo;->mLevel:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPSurfaceDolbyVisionInfo;->mLevel:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget p0, p0, Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceDolbyVisionInfo;->mBlSignalCompatibilityId:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput p0, v0, Lcom/tencent/thumbplayer/api/TPSurfaceDolbyVisionInfo;->mBlSignalCompatibilityId:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v0
.end method

.method private static a(Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceRenderInfo$TPVideoCropInfo;)Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;
    .locals 4

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 p0, 0x0

    move v3, p0

    const/4 v2, 0x6

    move v3, v2

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceRenderInfo$TPVideoCropInfo;->cropLeft:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->cropLeft:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceRenderInfo$TPVideoCropInfo;->cropRight:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->cropRight:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceRenderInfo$TPVideoCropInfo;->cropTop:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->cropTop:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceRenderInfo$TPVideoCropInfo;->cropBottom:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->cropBottom:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceRenderInfo$TPVideoCropInfo;->width:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->width:I

    iget p0, p0, Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceRenderInfo$TPVideoCropInfo;->height:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput p0, v0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;->height:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceRenderInfo;)Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceRenderInfo;->displayWidth:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo;->displayWidth:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget v1, p0, Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceRenderInfo;->displayHeight:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo;->displayHeight:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    iget-object p0, p0, Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceRenderInfo;->videoCropInfo:Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceRenderInfo$TPVideoCropInfo;

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceRenderInfo$TPVideoCropInfo;)Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object p0, v0, Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo;->videoCropInfo:Lcom/tencent/thumbplayer/api/TPSurfaceRenderInfo$TPVideoCropInfo;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/core/common/TPVideoFrame;)Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;
    .locals 7

    const/4 v6, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->data:[[B

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->data:[[B

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->linesize:[I

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->lineSize:[I

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPixelFormat;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPixelFormat;

    const/4 v6, 0x0

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPixelFormat;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPixelFormat;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget v2, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->format:I

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->format:I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->height:I

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->srcHeight:I

    const/4 v6, 0x5

    const/4 v5, 0x1

    iget v2, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->width:I

    const/4 v5, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    iput v2, v0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->srcWidth:I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->dstHeight:I

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    iput v2, v0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->dstWidth:I

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->sampleAspectRatioDen:I

    const/4 v6, 0x0

    if-lez v1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget v3, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->sampleAspectRatioNum:I

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-lez v3, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    int-to-float v3, v3

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    int-to-float v1, v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    div-float/2addr v3, v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    int-to-float v1, v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    mul-float/2addr v3, v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->dstWidth:I

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->rotation:I

    const/4 v6, 0x7

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->rotation:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->ptsUs:J

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x1

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    div-long/2addr v1, v3

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;->ptsMs:J

    const/4 v5, 0x3

    and-int/2addr v6, v5

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/core/common/TPVideoPacket;)Lcom/tencent/thumbplayer/api/TPVideoPacketBuffer;
    .locals 7

    const/4 v6, 0x0

    if-nez p0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 p0, 0x0

    const/4 v5, 0x6

    or-int/2addr v6, v5

    return-object p0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/api/TPVideoPacketBuffer;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPVideoPacketBuffer;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPVideoPacket;->mData:[B

    const/4 v5, 0x6

    move v6, v5

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPVideoPacketBuffer;->mData:[B

    const/4 v6, 0x2

    const/4 v5, 0x5

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPVideoPacket;->mSize:I

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPVideoPacketBuffer;->mSize:I

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/common/TPVideoPacket;->mPtsUs:J

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    div-long/2addr v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPVideoPacketBuffer;->mPtsMs:J

    const/4 v6, 0x2

    iget-wide v1, p0, Lcom/tencent/thumbplayer/core/common/TPVideoPacket;->mDtsUs:J

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    div-long/2addr v1, v3

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPVideoPacketBuffer;->mDtsMs:J

    const/4 v6, 0x4

    iget-object p0, p0, Lcom/tencent/thumbplayer/core/common/TPVideoPacket;->mDolbyVisionInfo:Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceDolbyVisionInfo;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {p0}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceDolbyVisionInfo;)Lcom/tencent/thumbplayer/api/TPSurfaceDolbyVisionInfo;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    iput-object p0, v0, Lcom/tencent/thumbplayer/api/TPVideoPacketBuffer;->mDolbyVisionInfo:Lcom/tencent/thumbplayer/api/TPSurfaceDolbyVisionInfo;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/api/TPAudioAttributes;)Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-nez p0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 p0, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    return-object p0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/api/TPAudioAttributes;->getUsage()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapTPAudioAttributeUsage;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapTPAudioAttributeUsage;

    const/4 v5, 0x6

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapTPAudioAttributeUsage;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapTPAudioAttributeUsage;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/api/TPAudioAttributes;->getContentType()I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/api/TPAudioAttributes;->getFlags()I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    and-int/2addr v2, v3

    const/4 v5, 0x4

    if-eqz v2, :cond_1

    const/4 v5, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v3, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/api/TPAudioAttributes;->getFlags()I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    and-int/lit8 v2, v2, 0x10

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eqz v2, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x5

    or-int/lit8 v3, v3, 0x10

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/api/TPAudioAttributes;->getFlags()I

    move-result p0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    and-int/lit16 p0, p0, 0x100

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz p0, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    or-int/lit16 v3, v3, 0x100

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {p0}, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->setUsage(I)Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->setContentType(I)Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p0, v3}, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->setFlags(I)Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->build()Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    return-object p0
.end method

.method public static a(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-nez p0, :cond_0

    const/4 v6, 0x5

    const/4 p0, 0x0

    const/4 v6, 0x6

    move v5, p0

    move v5, p0

    const/4 v6, 0x2

    return-object p0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;

    const/4 v6, 0x7

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMediaType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMediaType;

    const/4 v6, 0x2

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMediaType;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMediaType;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget v2, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->mediaType:I

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    iput v1, v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->mediaType:I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-nez v1, :cond_1

    const/4 v6, 0x5

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPixelFormat;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPixelFormat;

    const/4 v6, 0x6

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPixelFormat;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPixelFormat;

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget v2, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->format:I

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    iput v1, v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->format:I

    const/4 v5, 0x1

    move v6, v5

    goto :goto_1

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v2, 0x1

    const/4 v6, 0x0

    if-ne v1, v2, :cond_2

    const/4 v5, 0x5

    move v6, v5

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioSampleFormat;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioSampleFormat;

    const/4 v6, 0x7

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioSampleFormat;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioSampleFormat;

    const/4 v5, 0x0

    move v6, v5

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->data:[[B

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    iput-object v1, v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->data:[[B

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->size:[I

    const/4 v6, 0x5

    const/4 v5, 0x7

    iput-object v1, v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->linesize:[I

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->sampleRate:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    iput v1, v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->sampleRate:I

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-wide v1, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->channelLayout:J

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    iput-wide v1, v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->channelLayout:J

    const/4 v6, 0x3

    const/4 v5, 0x1

    iget-wide v1, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->ptsMs:J

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x3

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    mul-long/2addr v1, v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    iput-wide v1, v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->ptsUs:J

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->nbSamples:I

    const/4 v5, 0x1

    move v6, v5

    iput v1, v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->nbSamples:I

    const/4 v6, 0x5

    const/4 v5, 0x0

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->channels:I

    const/4 v6, 0x0

    const/4 v5, 0x0

    iput v1, v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->channels:I

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->width:I

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    iput v1, v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->width:I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->height:I

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    iput v1, v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->height:I

    const/4 v6, 0x2

    const/4 v5, 0x2

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->sampleAspectRatioNum:I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    iput v1, v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->sampleAspectRatioNum:I

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->sampleAspectRatioDen:I

    const/4 v5, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    iput v1, v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->sampleAspectRatioDen:I

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->rotation:I

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    iput v1, v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->rotation:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    iget-object p0, p0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->perfData:Ljava/util/HashMap;

    const/4 v5, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    iput-object p0, v0, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->perfData:Ljava/util/HashMap;

    const/4 v5, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;)Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez p0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 p0, 0x5

    const/4 p0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object p0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig$Builder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig$Builder;-><init>()V

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->getMinDecreaseDurationMs()J

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig$Builder;->setMinDecreaseDurationMs(J)Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig$Builder;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->getMaxIncreaseDurationMs()J

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig$Builder;->setMaxIncreaseDurationMs(J)Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig$Builder;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->getPerIncreaseDurationMs()J

    move-result-wide v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig$Builder;->setPerIncreaseDurationMs(J)Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig$Builder;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->getPerDecreaseDurationMs()J

    move-result-wide v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig$Builder;->setPerDecreaseDurationMs(J)Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig$Builder;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->getAdjustIntervalThresholdMs()J

    move-result-wide v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig$Builder;->setAdjustIntervalThresholdMs(J)Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig$Builder;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;->getFrozenThresholdMs()J

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig$Builder;->setFrozenThresholdMs(J)Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig$Builder;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig$Builder;->build()Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object p0
.end method

.method public static a(Lcom/tencent/thumbplayer/api/TPRemoteSdpInfo;)Lcom/tencent/thumbplayer/core/demuxer/TPNativeRemoteSdpInfo;
    .locals 4

    const/4 v3, 0x1

    if-nez p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Lcom/tencent/thumbplayer/core/demuxer/TPNativeRemoteSdpInfo;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/demuxer/TPNativeRemoteSdpInfo;-><init>()V

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-boolean v1, p0, Lcom/tencent/thumbplayer/api/TPRemoteSdpInfo;->isSuccess:Z

    const/4 v3, 0x0

    iput-boolean v1, v0, Lcom/tencent/thumbplayer/core/demuxer/TPNativeRemoteSdpInfo;->isSuccess:Z

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object p0, p0, Lcom/tencent/thumbplayer/api/TPRemoteSdpInfo;->remoteSdp:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object p0, v0, Lcom/tencent/thumbplayer/core/demuxer/TPNativeRemoteSdpInfo;->remoteSdp:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0
.end method

.method public static a(Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;)Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-nez p0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 p0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object p0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;->canvasWidth:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput v1, v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;->canvasWidth:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;->canvasHeight:I

    const/4 v4, 0x5

    iput v1, v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;->canvasHeight:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    iget-wide v1, p0, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;->paramFlags:J

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(J)J

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput-wide v1, v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;->paramFlags:J

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-wide v1, p0, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;->paramPriorityFlags:J

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(J)J

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    iput-wide v1, v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;->paramPriorityFlags:J

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;->familyName:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput-object v1, v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;->familyName:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;->fontSize:F

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput v1, v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;->fontSize:F

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;->fontColor:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput v1, v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;->fontColor:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;->fontStyleFlags:I

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    int-to-long v1, v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/adapter/a/b/c;->b(J)I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    iput v1, v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;->fontStyleFlags:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;->outlineWidth:F

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput v1, v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;->outlineWidth:F

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;->outlineColor:I

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput v1, v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;->outlineColor:I

    const/4 v3, 0x5

    move v4, v3

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;->lineSpace:F

    const/4 v4, 0x6

    const/4 v3, 0x2

    iput v1, v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;->lineSpace:F

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;->startMargin:F

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput v1, v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;->startMargin:F

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;->endMargin:F

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput v1, v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;->endMargin:F

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget v1, p0, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;->verticalMargin:F

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput v1, v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;->verticalMargin:F

    const/4 v4, 0x4

    const/4 v3, 0x6

    iget p0, p0, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;->fontScale:F

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput p0, v0, Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;->fontScale:F

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object v0
.end method

.method private static b(J)I
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x4

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSubtitleFontStyle;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSubtitleFontStyle;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSubtitleFontStyle;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSubtitleFontStyle;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->getEntrySetOfToNativeMap(Ljava/lang/Class;)Ljava/util/Set;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x4

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v1, 0x0

    :cond_0
    :goto_0
    const/4 v7, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-eqz v2, :cond_1

    const/4 v8, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    check-cast v3, Ljava/lang/Number;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    int-to-long v3, v3

    const/4 v7, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    and-long/2addr v3, p0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x5

    const-wide/16 v5, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    cmp-long v3, v3, v5

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-lez v3, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    check-cast v2, Ljava/lang/Number;

    const/4 v8, 0x3

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    or-int/2addr v1, v2

    const/4 v7, 0x0

    move v8, v7

    goto :goto_0

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    return v1
.end method
