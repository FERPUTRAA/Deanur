.class Lcom/tencent/thumbplayer/adapter/a/b/b$4;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/player/ITPNativePlayerSubtitleFrameCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/adapter/a/b/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/adapter/a/b/b;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/adapter/a/b/b;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$4;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onSubtitleFrame(Lcom/tencent/thumbplayer/core/common/TPSubtitleFrame;I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "s~sf v~@bb~@~@Soi t@l~r@@-@o~~a@b@  @~l  M~n.~1@i@~u ~ ~~@  @@/toc 4~f~d~@ ~K @@/@y~~ m ~  o~@oi"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/core/common/TPSubtitleFrame;)Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$4;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p2}, Lcom/tencent/thumbplayer/adapter/a/b/b;->c(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/adapter/g;

    move-result-object p2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method
