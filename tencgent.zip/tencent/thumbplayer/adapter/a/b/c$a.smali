.class public Lcom/tencent/thumbplayer/adapter/a/b/c$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/adapter/a/b/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field private final a:I

.field private final b:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->a:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->a:I

    const/4 v1, 0x5

    iput p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "dbsy@   ra1~K@@@ /~sc~~-~@~o ~@ @@io~~~in@.o~l~m@~~~  ~o ttSM ~4@l   bf@ ~o@@ i~@u@@@ fb ~o@~/@v"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->a:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, -0x1

    const/4 v3, 0x4

    if-eq v0, v1, :cond_1

    const/4 v3, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    return v0

    :cond_1
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    return v0
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->a:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method
