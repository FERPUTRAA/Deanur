.class Lcom/tencent/thumbplayer/adapter/a/b/b$5;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/player/ITPNativePlayerPostProcessFrameCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/adapter/a/b/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/adapter/a/b/b;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/adapter/a/b/b;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$5;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onPostProcessFrame(Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;I)Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s / ~ i ~@~~~ @o lot~  @i~rS~d@n@fob14@vlyc @of@~@  m~~@@o @@~.MK~~@@b~t/ -au~~ ~o@bi@@s @@~ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput p2, v0, Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;->eventFlag:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget p1, p1, Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;->mediaType:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$5;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->c(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/adapter/g;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;

    move-result-object p1

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 p2, 0x2

    const/4 p2, 0x1

    const/4 v2, 0x4

    if-ne p1, p2, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$5;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->c(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/adapter/g;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/adapter/g;->b(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p1
.end method
