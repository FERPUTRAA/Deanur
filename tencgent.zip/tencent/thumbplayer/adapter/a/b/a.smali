.class public Lcom/tencent/thumbplayer/adapter/a/b/a;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static b:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance v0, Ljava/util/HashSet;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    sput-object v0, Lcom/tencent/thumbplayer/adapter/a/b/a;->a:Ljava/util/Set;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance v0, Ljava/util/HashSet;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    sput-object v0, Lcom/tencent/thumbplayer/adapter/a/b/a;->b:Ljava/util/Set;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic a(Ljava/util/Set;)Ljava/util/Set;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "t@sb~o@@~ @ y@SM~n o/@i~@~l. o@K~ @~@~4 os@a@u~ib~~/l@o @~ d f@~ ~b~@vmr ~-@~ ~  @c~@f 1~o ~~i@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    sput-object p0, Lcom/tencent/thumbplayer/adapter/a/b/a;->a:Ljava/util/Set;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method public static declared-synchronized a(Landroid/content/Context;)V
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const/4 v4, 0x5

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v1, "TpbmaiayirPCmlt"

    const-string v1, "basCamlTiPtiyrp"

    const/4 v4, 0x5

    const-string/jumbo v1, "ybaporCDmitlTia"

    const-string v1, "TPDrmCapability"

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string/jumbo v2, "tC mabaiinilDpmTtrbyP"

    const-string v2, "atrmmat nTyCPiDliib,p"

    const/4 v4, 0x4

    const-string v2, "aii,r uTClnDPiimtbatp"

    const-string v2, "TPDrmCapability, init"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string v1, "TPDrmCapability"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string v2, "eehams p,terrpspgeTdnP  aclrefDaot.rbyCi"

    const-string v2, "ar toltea.sgfncdherysTpe,errePbmpeD i aC"

    const/4 v4, 0x2

    const-string/jumbo v2, "leih.sebqra D fperpr,tameCcsntadei Prgey"

    const-string v2, "TPDrmCapability, get shared preferences."

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v1, v2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string v1, "PMsRDACB_L_AIYITb"

    const-string v1, "I_DRAbLI_PBMYTTAC"

    const/4 v4, 0x7

    const-string v1, "BYImLRDTC__PMPATA"

    const-string v1, "TP_DRM_CAPABILITY"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string v1, "CDIToLSATL_uPBI_YAR"

    const-string v1, "AS_TDRu_BLIIIACYLPT"

    const/4 v4, 0x6

    const-string v1, "T_ASLbT_MBIIDPAICRY"

    const-string v1, "DRM_CAPABILITY_LIST"

    const/4 v4, 0x6

    sget-object v2, Lcom/tencent/thumbplayer/adapter/a/b/a;->a:Ljava/util/Set;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-interface {p0, v1, v2}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    sput-object v1, Lcom/tencent/thumbplayer/adapter/a/b/a;->a:Ljava/util/Set;
    :try_end_1
    .catch Ljava/lang/ClassCastException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :catch_0
    move-exception v1

    :try_start_2
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string/jumbo v2, "tbmpyarpPTCDili"

    const/4 v4, 0x2

    const-string v2, "TPDrmCapability"

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-static {v2, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/b/a;->a:Ljava/util/Set;

    const/4 v4, 0x0

    const/4 v3, 0x3

    sget-object v2, Lcom/tencent/thumbplayer/adapter/a/b/a;->b:Ljava/util/Set;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {v1, v2}, Ljava/util/Set;->removeAll(Ljava/util/Collection;)Z

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p0}, Lcom/tencent/thumbplayer/adapter/a/b/a;->a(Landroid/content/SharedPreferences;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    return-void

    :catchall_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    monitor-exit v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    throw p0
.end method

.method private static a(Landroid/content/SharedPreferences;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/utils/o;->a()Lcom/tencent/thumbplayer/utils/o;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/utils/o;->d()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance v1, Lcom/tencent/thumbplayer/adapter/a/b/a$1;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v1, p0}, Lcom/tencent/thumbplayer/adapter/a/b/a$1;-><init>(Landroid/content/SharedPreferences;)V

    const/4 v3, 0x6

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/4 v3, 0x3

    return-void
.end method

.method public static declared-synchronized a(I)Z
    .locals 7
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_DRM_TYPE;
        .end annotation
    .end param

    const/4 v6, 0x3

    const/4 v5, 0x5

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const/4 v6, 0x0

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    monitor-enter v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 v1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v2, -0x1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-ne p0, v2, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    monitor-exit v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    return v1

    :cond_0
    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    sget-object v3, Lcom/tencent/thumbplayer/adapter/a/b/a;->a:Ljava/util/Set;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz v4, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    check-cast v4, Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v4, v2}, Lcom/tencent/thumbplayer/utils/b;->a(Ljava/lang/String;I)I

    move-result v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-ne v4, p0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    monitor-exit v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/4 p0, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    return p0

    :cond_2
    const/4 v5, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    monitor-exit v0

    const/4 v5, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    return v1

    :catchall_0
    move-exception p0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    monitor-exit v0

    const/4 v6, 0x5

    throw p0
.end method

.method public static declared-synchronized a()[I
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const/4 v8, 0x0

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const/4 v7, 0x3

    move v8, v7

    monitor-enter v0

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/b/a;->a:Ljava/util/Set;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-interface {v1}, Ljava/util/Set;->size()I

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    new-array v1, v1, [I

    const/4 v8, 0x7

    const/4 v7, 0x1

    sget-object v2, Lcom/tencent/thumbplayer/adapter/a/b/a;->a:Ljava/util/Set;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v3, 0x1

    const/4 v3, 0x0

    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-eqz v4, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    check-cast v4, Ljava/lang/String;

    const/4 v8, 0x5

    const/4 v7, 0x2

    add-int/lit8 v5, v3, 0x1

    const/4 v7, 0x6

    xor-int/2addr v8, v7

    const/4 v6, -0x1

    move v8, v6

    const/4 v7, 0x1

    move v8, v7

    invoke-static {v4, v6}, Lcom/tencent/thumbplayer/utils/b;->a(Ljava/lang/String;I)I

    move-result v4

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x1

    aput v4, v1, v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    move v3, v5

    move v3, v5

    const/4 v8, 0x6

    move v3, v5

    move v3, v5

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    monitor-exit v0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x0

    monitor-exit v0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    throw v1
.end method

.method static synthetic b()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/b/a;->b:Ljava/util/Set;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public static declared-synchronized b(I)V
    .locals 4
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_DRM_TYPE;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const/4 v3, 0x2

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/b/a;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    monitor-enter v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, -0x1

    const/4 v2, 0x4

    move v3, v2

    if-ne p0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    return-void

    :cond_0
    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/b/a;->b:Ljava/util/Set;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {v1, p0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x3

    sget-object p0, Lcom/tencent/thumbplayer/adapter/a/b/a;->a:Ljava/util/Set;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/b/a;->b:Ljava/util/Set;

    const/4 v3, 0x7

    invoke-interface {p0, v1}, Ljava/util/Set;->removeAll(Ljava/util/Collection;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    throw p0
.end method

.method static synthetic c()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/b/a;->a:Ljava/util/Set;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method
