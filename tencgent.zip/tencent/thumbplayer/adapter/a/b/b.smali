.class public Lcom/tencent/thumbplayer/adapter/a/b/b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/adapter/a/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/adapter/a/b/b$c;,
        Lcom/tencent/thumbplayer/adapter/a/b/b$e;,
        Lcom/tencent/thumbplayer/adapter/a/b/b$d;,
        Lcom/tencent/thumbplayer/adapter/a/b/b$b;,
        Lcom/tencent/thumbplayer/adapter/a/b/b$a;
    }
.end annotation


# static fields
.field static final a:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

.field private c:Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;

.field private d:Lcom/tencent/thumbplayer/adapter/a/b/b$a;

.field private e:Lcom/tencent/thumbplayer/adapter/g;

.field private f:Lcom/tencent/thumbplayer/adapter/a/a;

.field private g:Lcom/tencent/thumbplayer/api/TPSubtitleData;

.field private h:Lcom/tencent/thumbplayer/e/a;

.field private i:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback;

.field private j:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerAudioFrameCallback;

.field private k:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerVideoFrameCallback;

.field private l:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerSubtitleFrameCallback;

.field private m:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerPostProcessFrameCallback;

.field private n:Lcom/tencent/thumbplayer/core/demuxer/ITPNativeDemuxerCallback;

.field private o:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerEventRecordCallback;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/b/b$8;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b$8;-><init>()V

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    sput-object v0, Lcom/tencent/thumbplayer/adapter/a/b/b;->a:Ljava/util/Set;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v0, Lcom/tencent/thumbplayer/api/TPSubtitleData;

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPSubtitleData;-><init>()V

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->g:Lcom/tencent/thumbplayer/api/TPSubtitleData;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/b/b$1;

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/adapter/a/b/b$1;-><init>(Lcom/tencent/thumbplayer/adapter/a/b/b;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->i:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/b/b$2;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/adapter/a/b/b$2;-><init>(Lcom/tencent/thumbplayer/adapter/a/b/b;)V

    const/4 v2, 0x1

    or-int/2addr v3, v2

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->j:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerAudioFrameCallback;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/b/b$3;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/adapter/a/b/b$3;-><init>(Lcom/tencent/thumbplayer/adapter/a/b/b;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->k:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerVideoFrameCallback;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/b/b$4;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/adapter/a/b/b$4;-><init>(Lcom/tencent/thumbplayer/adapter/a/b/b;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->l:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerSubtitleFrameCallback;

    const/4 v3, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/b/b$5;

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/adapter/a/b/b$5;-><init>(Lcom/tencent/thumbplayer/adapter/a/b/b;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->m:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerPostProcessFrameCallback;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/b/b$6;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/adapter/a/b/b$6;-><init>(Lcom/tencent/thumbplayer/adapter/a/b/b;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->n:Lcom/tencent/thumbplayer/core/demuxer/ITPNativeDemuxerCallback;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/b/b$7;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/adapter/a/b/b$7;-><init>(Lcom/tencent/thumbplayer/adapter/a/b/b;)V

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->o:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerEventRecordCallback;

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x4

    const-string v1, "essyTrbauhPTl"

    const-string/jumbo v1, "husePrymbTTal"

    const/4 v3, 0x3

    const-string/jumbo v1, "yhPmauTrmPble"

    const-string v1, "TPThumbPlayer"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, p2, v1}, Lcom/tencent/thumbplayer/e/a;-><init>(Lcom/tencent/thumbplayer/e/b;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x7

    const/4 v2, 0x3

    new-instance p2, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p2, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->i:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback;

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setMessageCallback(Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback;)I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v2, 0x3

    move v3, v2

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->j:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerAudioFrameCallback;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setAudioFrameCallback(Lcom/tencent/thumbplayer/core/player/ITPNativePlayerAudioFrameCallback;)I

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x0

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->k:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerVideoFrameCallback;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setVideoFrameCallback(Lcom/tencent/thumbplayer/core/player/ITPNativePlayerVideoFrameCallback;)I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->l:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerSubtitleFrameCallback;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setSubtitleFrameCallback(Lcom/tencent/thumbplayer/core/player/ITPNativePlayerSubtitleFrameCallback;)I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->m:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerPostProcessFrameCallback;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setPostProcessFrameCallback(Lcom/tencent/thumbplayer/core/player/ITPNativePlayerPostProcessFrameCallback;)I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->n:Lcom/tencent/thumbplayer/core/demuxer/ITPNativeDemuxerCallback;

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setDemuxerCallback(Lcom/tencent/thumbplayer/core/demuxer/ITPNativeDemuxerCallback;)I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->o:Lcom/tencent/thumbplayer/core/player/ITPNativePlayerEventRecordCallback;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setEventRecordCallback(Lcom/tencent/thumbplayer/core/player/ITPNativePlayerEventRecordCallback;)I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance p1, Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->c:Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance p1, Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x5

    const/4 v2, 0x1

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/e/a;->b()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-direct {p1, p2}, Lcom/tencent/thumbplayer/adapter/g;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    new-instance p2, Lcom/tencent/thumbplayer/adapter/a/b/b$a;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p2, p0, p1, p0}, Lcom/tencent/thumbplayer/adapter/a/b/b$a;-><init>(Lcom/tencent/thumbplayer/adapter/a/b/b;Landroid/os/Looper;Lcom/tencent/thumbplayer/adapter/a/b/b;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->d:Lcom/tencent/thumbplayer/adapter/a/b/b$a;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance p2, Lcom/tencent/thumbplayer/adapter/a/b/b$a;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p2, p0, p1, p0}, Lcom/tencent/thumbplayer/adapter/a/b/b$a;-><init>(Lcom/tencent/thumbplayer/adapter/a/b/b;Landroid/os/Looper;Lcom/tencent/thumbplayer/adapter/a/b/b;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->d:Lcom/tencent/thumbplayer/adapter/a/b/b$a;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->d:Lcom/tencent/thumbplayer/adapter/a/b/b$a;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/core/player/TPNativePlayerProgramInfo;)Lcom/tencent/thumbplayer/api/TPProgramInfo;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "b@n o ~@ @ @~@~i- d~io@@~uoo~s rm@@~bS ~@~~/  o@~~o~@i~~~lf.@@a@~@b1o  ~ @/t@~l~v@ f4~Mc@yt  ~ K"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    if-eqz p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/api/TPProgramInfo;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPProgramInfo;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    iget-object v1, p1, Lcom/tencent/thumbplayer/core/player/TPNativePlayerProgramInfo;->url:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPProgramInfo;->url:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-wide v1, p1, Lcom/tencent/thumbplayer/core/player/TPNativePlayerProgramInfo;->bandwidth:J

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPProgramInfo;->bandwidth:J

    const/4 v4, 0x1

    const/4 v3, 0x6

    iget-object v1, p1, Lcom/tencent/thumbplayer/core/player/TPNativePlayerProgramInfo;->resolution:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x7

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPProgramInfo;->resolution:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget v1, p1, Lcom/tencent/thumbplayer/core/player/TPNativePlayerProgramInfo;->programId:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPProgramInfo;->programId:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-boolean p1, p1, Lcom/tencent/thumbplayer/core/player/TPNativePlayerProgramInfo;->actived:Z

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput-boolean p1, v0, Lcom/tencent/thumbplayer/api/TPProgramInfo;->actived:Z

    const/4 v4, 0x3

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 p1, 0x0

    const/4 v4, 0x0

    return-object p1
.end method

.method private a(Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;)Lcom/tencent/thumbplayer/api/TPTrackInfo;
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPTrackInfo;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v1, p1, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->trackName:Ljava/lang/String;

    const/4 v6, 0x1

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v6, 0x5

    iget v1, p1, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->trackType:I

    const/4 v5, 0x4

    shl-int/2addr v6, v5

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget v1, p1, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->contianerType:I

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->containerType:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v2, 0x1

    const/4 v6, 0x3

    if-ne v1, v2, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v1, v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->hlsTag:Lcom/tencent/thumbplayer/api/TPHlsTag;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v2, p1, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->hlsTag:Lcom/tencent/thumbplayer/core/common/TPMediaTrackHlsTag;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v3, v2, Lcom/tencent/thumbplayer/core/common/TPMediaTrackHlsTag;->name:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput-object v3, v1, Lcom/tencent/thumbplayer/api/TPHlsTag;->name:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-wide v3, v2, Lcom/tencent/thumbplayer/core/common/TPMediaTrackHlsTag;->bandwidth:J

    const/4 v6, 0x5

    iput-wide v3, v1, Lcom/tencent/thumbplayer/api/TPHlsTag;->bandwidth:J

    const/4 v6, 0x1

    const/4 v5, 0x3

    iget-object v3, v2, Lcom/tencent/thumbplayer/core/common/TPMediaTrackHlsTag;->resolution:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    iput-object v3, v1, Lcom/tencent/thumbplayer/api/TPHlsTag;->resolution:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget v3, v2, Lcom/tencent/thumbplayer/core/common/TPMediaTrackHlsTag;->framerate:F

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    iput v3, v1, Lcom/tencent/thumbplayer/api/TPHlsTag;->framerate:F

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v3, v2, Lcom/tencent/thumbplayer/core/common/TPMediaTrackHlsTag;->codecs:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    iput-object v3, v1, Lcom/tencent/thumbplayer/api/TPHlsTag;->codecs:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v3, v2, Lcom/tencent/thumbplayer/core/common/TPMediaTrackHlsTag;->groupId:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x3

    iput-object v3, v1, Lcom/tencent/thumbplayer/api/TPHlsTag;->groupId:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v2, v2, Lcom/tencent/thumbplayer/core/common/TPMediaTrackHlsTag;->language:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput-object v2, v1, Lcom/tencent/thumbplayer/api/TPHlsTag;->language:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v2, 0x5

    const/4 v6, 0x7

    const/4 v2, 0x2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-ne v1, v2, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v1, p1, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->dashFormat:Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;)Lcom/tencent/thumbplayer/api/TPDashFormat;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    iput-object v1, v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->dashFormat:Lcom/tencent/thumbplayer/api/TPDashFormat;

    :cond_1
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-boolean v1, p1, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->isExclusive:Z

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    iput-boolean v1, v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isExclusive:Z

    const/4 v6, 0x5

    iget-boolean v1, p1, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->isSelected:Z

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    iput-boolean v1, v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-boolean p1, p1, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->isInternal:Z

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    iput-boolean p1, v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isInternal:Z

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    return-object v0
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/e/a;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v1, 0x2

    return-object p0
.end method

.method private a()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v1, " seemb ahayrsalepe"

    const-string v1, "aasmyrh llepe aese"

    const/4 v3, 0x0

    const-string v1, "eaypahu eserlrae s"

    const-string/jumbo v1, "player has release"

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    throw v0
.end method

.method private a(ILcom/tencent/thumbplayer/adapter/a/b/b$d;)V
    .locals 10
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$NativeErrorType;
        .end annotation
    .end param

    const/4 v8, 0x6

    move v9, v8

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMsgInfo;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMsgInfo;

    const/4 v9, 0x4

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMsgInfo;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMsgInfo;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result v2

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-gez v2, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    const-string/jumbo v1, "yTo:esmp"

    const-string v1, "Tmspoe:y"

    const/4 v9, 0x5

    const-string/jumbo v1, "msgType:"

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-string/jumbo p1, "torrncctqeovnmo,n toPfeb n ubyItala "

    const-string/jumbo p1, "nnotmbtr tac ,obr uIvneeloftyP c aon"

    const/4 v9, 0x3

    const-string p1, "  s onhrntmo tatceloanI fyr,oucnevtP"

    const-string p1, ", cannot convert to thumbPlayer Info"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    return-void

    :cond_0
    const/4 v9, 0x4

    iget-wide v0, p2, Lcom/tencent/thumbplayer/adapter/a/b/b$d;->b:J

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget-wide v5, p2, Lcom/tencent/thumbplayer/adapter/a/b/b$d;->c:J

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    const/16 p1, 0xcb

    const/4 v9, 0x5

    const/4 v8, 0x5

    if-eq v2, p1, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    const/16 p1, 0xcc

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-eq v2, p1, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    const-string/jumbo p2, "unhandled thumbPlayerInfo="

    const/4 v8, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p2, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    move-wide v3, v0

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    goto :goto_1

    :cond_1
    const/4 v8, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const/4 v9, 0x3

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapVideoDecoderType;

    goto :goto_0

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioDecoderType;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioDecoderType;

    const/4 v9, 0x5

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioDecoderType;

    const-class p1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapAudioDecoderType;

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    long-to-int p2, v0

    const/4 v9, 0x7

    const/4 v8, 0x7

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result p1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    int-to-long p1, p1

    move-wide v3, p1

    :goto_1
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    const/4 v7, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x6

    invoke-virtual/range {v1 .. v7}, Lcom/tencent/thumbplayer/adapter/g;->a(IJJLjava/lang/Object;)V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    return-void
.end method

.method private a(ILcom/tencent/thumbplayer/adapter/a/b/b$e;)V
    .locals 10
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$NativeMsgInfo;
        .end annotation
    .end param

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMsgInfo;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMsgInfo;

    const/4 v9, 0x6

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMsgInfo;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMsgInfo;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result v2

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-ltz v2, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget-object p2, p2, Lcom/tencent/thumbplayer/adapter/a/b/b$e;->b:Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-nez p2, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    goto/16 :goto_3

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    packed-switch v2, :pswitch_data_0

    :goto_0
    :pswitch_0
    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    goto :goto_2

    :pswitch_1
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    check-cast p2, Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {p2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-string v1, "JP_mLY_A_PTFOIRNETBSTOUETE:TCBIL_NuE"

    const-string v1, "NSECYEu:TOPATR_LOILBEPFT_NBTOJIE_UT_"

    const/4 v9, 0x1

    const-string v1, "OU_FoE_CS_NEPLINYTPE:TR_ITTBBOLTJEAO"

    const-string v1, "TP_PLAYER_INFO_OBJECT_SUBTITLE_NOTE:"

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v9, 0x6

    goto :goto_0

    :pswitch_2
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    check-cast p2, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$MediaDrmInfo;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {p2}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$MediaDrmInfo;)Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaDrmInfo;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    goto :goto_1

    :pswitch_3
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    check-cast p2, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoSeiInfo;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {p2}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoSeiInfo;)Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoSeiInfo;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    goto :goto_1

    :pswitch_4
    const/4 v9, 0x5

    check-cast p2, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$MediaCodecInfo;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-static {p2}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$MediaCodecInfo;)Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPMediaCodecInfo;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x5

    goto :goto_1

    :pswitch_5
    const/4 v9, 0x3

    check-cast p2, Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoCropInfo;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {p2}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/core/player/ITPNativePlayerMessageCallback$VideoCropInfo;)Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPVideoCropInfo;

    move-result-object p1

    :goto_1
    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    :goto_2
    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v9, 0x1

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    const-wide/16 v5, 0x0

    const/4 v9, 0x4

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual/range {v1 .. v7}, Lcom/tencent/thumbplayer/adapter/g;->a(IJJLjava/lang/Object;)V

    const/4 v9, 0x7

    return-void

    :cond_1
    :goto_3
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const-string/jumbo v1, "y:Tgmbps"

    const-string v1, ":ygsmpTp"

    const/4 v9, 0x6

    const-string/jumbo v1, "m:gpysue"

    const-string/jumbo v1, "msgType:"

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    move v9, v8

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    const-string/jumbo p1, "f ltru peyqaInmnovn Pr,acntot oeoc h"

    const-string p1, "cPof lIrqottoatanneonv,eumytn  rh  c"

    const/4 v9, 0x5

    const-string/jumbo p1, "o Inheo q t t,trrv afnuoleonnamctPcb"

    const-string p1, ", cannot convert to thumbPlayer Info"

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    return-void

    :pswitch_data_0
    .packed-switch 0x1f4
        :pswitch_5
        :pswitch_0
        :pswitch_4
        :pswitch_3
        :pswitch_0
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method private a(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;)V
    .locals 4
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->convertToNativeOptionalId(I)Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->a()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const-string/jumbo v0, "g s  atn  , pdnay:liiairilsblfripynnnps eodiiad ate,I rapMuldnna ooov"

    const-string/jumbo v0, "nvsliia  opfoyna ,ad ioli dgrsi dialetlntapoIo:e run  naa,pnidn Myrpb"

    const/4 v3, 0x5

    const-string v0, "  rmeygvdbpnaplntiie, dnIaaorioisili, :r ip n upd fl aalnnodaoayontoM"

    const-string/jumbo v0, "player optionalIdMapping boolean is invalid, not found in array, id: "

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v1, 0x3

    const/4 v3, 0x4

    const/4 v2, 0x2

    if-eq p1, v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string/jumbo v1, "n:tioDepmptooy"

    const-string v1, ":onmotyeipptDI"

    const/4 v3, 0x7

    const-string v1, "D pitbonpe:Iyo"

    const-string/jumbo v1, "optionID type:"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo v0, "tiomtmuon lpeie n"

    const-string/jumbo v0, "temtoneopslmin  i"

    const/4 v3, 0x1

    const-string/jumbo v0, "mmilnt p enspeit "

    const-string v0, " is not implement"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v2, 0x0

    or-int/2addr v3, v2

    return-void

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->c:Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-boolean p2, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;->value:Z

    const/4 v3, 0x3

    invoke-virtual {p1, v0, p2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;->setBool(IZ)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method private a(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;)V
    .locals 4
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->convertToNativeOptionalId(I)Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->a()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string/jumbo v0, "ntpo ofrq: oMnlaeya nId i   g lapriabnaifiir ltn udvolasdyidp,opa,i"

    const-string/jumbo v0, "i ad bp,iMdiuflo rplgiivnnoi i,yndo nIp dal raaot:yfreltta op a ans"

    const/4 v3, 0x1

    const-string v0, "disnnnipotrslfynopodaitio  elaItaf,y pdar puda  aol:iilagMiv  , n r"

    const-string/jumbo v0, "player optionalIdMapping float is invalid, not found in array, id: "

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v2, 0x0

    move v3, v2

    const/4 p1, 0x2

    const/4 p1, 0x7

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eq p1, v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo v1, "ionmID:uo"

    const-string v1, ":tinoDuIo"

    const/4 v3, 0x7

    const-string/jumbo v1, "pD:toIoni"

    const-string/jumbo v1, "optionID:"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string v0, " tnasbftoli p"

    const-string/jumbo v0, "tlif  sptnao "

    const/4 v3, 0x3

    const-string/jumbo v0, "f ai ou stnlt"

    const-string v0, " is not float"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->c:Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    iget p2, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;->value:F

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1, v0, p2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;->setFloat(IF)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void
.end method

.method private a(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;)V
    .locals 8
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->convertToNativeOptionalId(I)Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->a()Z

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x4

    if-eqz v1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string v0, " rg  irpat doa a,epprfpgioiioa  nn dlnyayniMsu,ionno naq ldvlditpI"

    const-string/jumbo v0, "iylnadtaq ad,pn sl,odln i eivaiap o o r g pani lufignoMonyrdItiprn"

    const/4 v7, 0x3

    const-string/jumbo v0, "player optionalIdMapping long is invalid, not found in array, id: "

    const/4 v7, 0x3

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    return-void

    :cond_0
    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result p1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v7, 0x5

    if-eq p1, v1, :cond_4

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    const/4 v2, 0x3

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-eq p1, v2, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v1, 0x4

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-eq p1, v1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    move v7, v6

    const-string/jumbo v1, "piIspneoq: tty"

    const-string/jumbo v1, "oes:pitItpy Dn"

    const/4 v7, 0x4

    const-string v1, "DosIoettppyn :"

    const-string/jumbo v1, "optionID type:"

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    move v7, v6

    const-string/jumbo v0, "nitmmns ol epti m"

    const-string v0, "eesmtin  lm timon"

    const-string v0, " is not implement"

    const/4 v7, 0x0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    return-void

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->c:Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget-wide v1, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    long-to-int p2, v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    invoke-virtual {p1, v0, p2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;->setInt(II)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    return-void

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->c:Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget-wide v2, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x1

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    cmp-long p2, v2, v4

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-lez p2, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    goto :goto_0

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {p1, v0, v1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;->setBool(IZ)V

    const/4 v7, 0x0

    return-void

    :cond_4
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->c:Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-wide v1, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v7, 0x0

    const/4 v6, 0x4

    invoke-virtual {p1, v0, v1, v2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;->setLong(IJ)V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    return-void
.end method

.method private a(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;)V
    .locals 4
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->convertToNativeOptionalId(I)Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo v0, "ty: oceToO,fIioi otenatadaonpileeNvklvd"

    const-string v0, ":ecIoiykavOaeon,tioepTd tNnvoradf iellt"

    const/4 v3, 0x2

    const-string v0, "d ad:bvIto e ifeveaTyancponotitNe,iOrlk"

    const-string v0, "convertToNativeOptionalId failed, key: "

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->a()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string v0, "ct dIpuiruvnlit o e aidbyol n,,ga a rpona: ldMpnoaitipornsynajie dbi"

    const-string/jumbo v0, "irap btnriroiplninep v  Moe y,yn :it,aaddltib  cnpaiaajs uo odndoIgl"

    const/4 v3, 0x7

    const-string v0, " y naatpi,ig on usvyr pdoe aoiip: prpIiajeodltlncoibndntfdn aa, i lr"

    const-string/jumbo v0, "player optionalIdMapping object is invalid, not found in array, id: "

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/16 v1, 0x7e

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eq p1, v1, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/16 v1, 0x19e

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eq p1, v1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string v1, " etnyoptqipIDu"

    const-string v1, " eottIupyniDpo"

    const/4 v3, 0x0

    const-string/jumbo v1, "tostnD ype:oip"

    const-string/jumbo v1, "optionID type:"

    const/4 v3, 0x2

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    move v3, v2

    const-string v0, " opmm lnni peistt"

    const-string/jumbo v0, "piitls p t enmone"

    const/4 v3, 0x7

    const-string/jumbo v0, "tostoem nil  iemp"

    const-string v0, " is not implement"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object p1, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;->objectValue:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    check-cast p1, Lcom/tencent/thumbplayer/api/TPAudioAttributes;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/api/TPAudioAttributes;)Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->c:Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p2, v0, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;->setObject(ILjava/lang/Object;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object p1, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;->objectValue:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    check-cast p1, Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;

    const/4 v2, 0x7

    move v3, v2

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/api/TPJitterBufferConfig;)Lcom/tencent/thumbplayer/core/demuxer/TPNativeJitterBufferConfig;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->c:Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p2, v0, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;->setObject(ILjava/lang/Object;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method private a(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;)V
    .locals 6
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->convertToNativeOptionalId(I)Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->a()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string/jumbo v0, "i nMebdrvaqrdpip,t oinipnuga,noa:q iefyiu aonl_  dyilir snpeo unatl tad"

    const-string v0, "  sdiao qyatfMlngi_enloalie,odut  ,yed iainudp  a prpnuoqnn:arivIitprin"

    const/4 v5, 0x7

    const-string/jumbo v0, "toyd lueoveon np fnaeigartlu ynion ipi:u i s_uia,dqapaiMr ,  idalIdpnrt"

    const-string/jumbo v0, "player optionalIdMapping queue_int is invalid, not found in array, id: "

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v1, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;->queueValue:[I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    array-length v1, v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-nez v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto/16 :goto_1

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result p1

    const/4 v5, 0x1

    const/4 v1, 0x5

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eq p1, v1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string/jumbo v1, "sytIp:np oDiot"

    const-string v1, ":estoonpD ytiI"

    const/4 v5, 0x1

    const-string/jumbo v1, "otopnD :qpyIti"

    const-string/jumbo v1, "optionID type:"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v0, "emstioml in mntps"

    const-string/jumbo v0, "ieom nts elmtmnpi"

    const/4 v5, 0x2

    const-string/jumbo v0, "lmtme te oipi snm"

    const-string v0, " is not implement"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-void

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 p1, 0x4

    const/4 p1, 0x0

    :goto_0
    const/4 v5, 0x3

    iget-object v1, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;->queueValue:[I

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    array-length v1, v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-ge p1, v1, :cond_3

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->c:Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v3, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;->queueValue:[I

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    aget v3, v3, p1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v1, v2, v3}, Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;->addQueueInt(II)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    add-int/lit8 p1, p1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    goto :goto_0

    :cond_3
    return-void

    :cond_4
    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v0, "amrioin meouynp ue eit spta"

    const-string/jumbo v0, "i aqonm ne  earistpeupytuim"

    const-string/jumbo v0, "queueint params is empty in"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-void
.end method

.method private a(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;)V
    .locals 6
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->convertToNativeOptionalId(I)Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->a()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string/jumbo v0, "tafMdbIop,n gnbqsinnavapoou i eoli_n a dyustai,ud reniranp ydlritr:ip  eil"

    const-string v0, "dr,uIbogpo,dg :adpsqeira dM iil_lralireonn nyyuetu it viniaintao fnn p pas"

    const/4 v5, 0x4

    const-string v0, "  itMnurp i up nnd,naurtog:tl osaqagdd_ipiondy ilnaaulfay,ov ei seI neirpi"

    const-string/jumbo v0, "player optionalIdMapping queue_string is invalid, not found in array, id: "

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-void

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v1, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;->queueValue:[Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz v1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    array-length v1, v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    if-nez v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    goto/16 :goto_1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v1, 0x6

    const/4 v5, 0x2

    if-eq p1, v1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo v1, "nipy:e popDttu"

    const-string v1, " otiDtueypnp:I"

    const/4 v5, 0x2

    const-string/jumbo v1, "pi:tynpIqeotoD"

    const-string/jumbo v1, "optionID type:"

    const/4 v4, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const-string/jumbo v0, "itso sitnmm leenp"

    const-string v0, " esioltppi emnntm"

    const/4 v5, 0x4

    const-string v0, "emomn  itpsenmi l"

    const-string v0, " is not implement"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-void

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v1, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;->queueValue:[Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    array-length v1, v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-ge p1, v1, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->c:Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;

    const/4 v4, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v3, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;->queueValue:[Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    aget-object v3, v3, p1

    const/4 v4, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v1, v2, v3}, Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;->addQueueString(ILjava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    add-int/lit8 p1, p1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto :goto_0

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    return-void

    :cond_4
    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string/jumbo v0, "ginuotraspSei p qurey msniate q"

    const-string/jumbo v0, "mgisy saqruiS npetieq  urmaenpt"

    const/4 v5, 0x0

    const-string v0, " n ymbuiigerenisau psta eprStqm"

    const-string/jumbo v0, "queue String params is empty in"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-void
.end method

.method private a(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->convertToNativeOptionalId(I)Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->a()Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v0, ",io  uundy: ,prtl  f l nisgipain e npIdavinalrrsnotiastdMidpranayoog"

    const-string v0, ",rsIngpalsn tai olMprn pieiaanidoni to grr n,dutolyvsnd aifa:iyid  p"

    const/4 v3, 0x1

    const-string v0, " pslti p iiryrpaga, p fdlr npidyotsudoanen viM:Itoaig ona,di ilrnnna"

    const-string/jumbo v0, "player optionalIdMapping string is invalid, not found in array, id: "

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 p1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eq p1, v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string/jumbo v1, "oo:DpnmIq"

    const-string v1, "It:mDpnoo"

    const/4 v3, 0x1

    const-string/jumbo v1, "posInD:it"

    const-string/jumbo v1, "optionID:"

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const-string v0, " snmnroitsog t"

    const-string/jumbo v0, "g s otno rsitn"

    const/4 v3, 0x0

    const-string v0, " osgottis inr "

    const-string v0, " is not string"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v2, 0x0

    shr-int/2addr v3, v2

    return-void

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->c:Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object p2, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;->value:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1, v0, p2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;->setString(ILjava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method

.method private a(JJ)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/adapter/g;->a(JJ)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/adapter/a/b/b$b;)V
    .locals 10

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    iget v1, p1, Lcom/tencent/thumbplayer/adapter/a/b/b$b;->a:I

    const-class v2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMsgInfo;

    const-class v2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMsgInfo;

    const/4 v9, 0x7

    const-class v2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMsgInfo;

    const-class v2, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapMsgInfo;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {v2, v1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toTPIntValue(Ljava/lang/Class;I)I

    move-result v1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget v2, p1, Lcom/tencent/thumbplayer/adapter/a/b/b$b;->c:I

    const/4 v9, 0x2

    const/4 v8, 0x0

    int-to-long v2, v2

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    iget v4, p1, Lcom/tencent/thumbplayer/adapter/a/b/b$b;->d:I

    const/4 v9, 0x5

    const/4 v8, 0x5

    int-to-long v4, v4

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    iget-wide v6, p1, Lcom/tencent/thumbplayer/adapter/a/b/b$b;->b:J

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual/range {v0 .. v6}, Lcom/tencent/thumbplayer/adapter/g;->a(IJJLjava/lang/Object;)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/b/b;ILcom/tencent/thumbplayer/adapter/a/b/b$d;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(ILcom/tencent/thumbplayer/adapter/a/b/b$d;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/b/b;ILcom/tencent/thumbplayer/adapter/a/b/b$e;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(ILcom/tencent/thumbplayer/adapter/a/b/b$e;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/b/b;JJ)V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(JJ)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/b/b;Lcom/tencent/thumbplayer/adapter/a/b/b$b;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(Lcom/tencent/thumbplayer/adapter/a/b/b$b;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/b/b;I)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->d(I)Z

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x7

    return p0
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/adapter/a/b/b$a;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->d:Lcom/tencent/thumbplayer/adapter/a/b/b$a;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method private b()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/g;->a()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method private b(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;)V
    .locals 8
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->convertToNativeOptionalId(I)Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->a()Z

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v1, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-string v0, "a giabntynrInMr ndir ,pa:ai ,opsi  pofoldv o dsltiilpgriyn aeainndut"

    const/4 v7, 0x2

    const-string/jumbo v0, "paotabrena ,navil:y   rl orIinl dnignsgMnu y  toppaa diiinddfp,itrio"

    const-string/jumbo v0, "player optionalIdMapping string is invalid, not found in array, id: "

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x5

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    return-void

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result p1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    const/4 v1, 0x3

    const/4 v7, 0x1

    const/4 v6, 0x4

    if-eq p1, v1, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string/jumbo v1, "itouynuIpD:t p"

    const-string/jumbo v1, "o nDptuoypti:I"

    const/4 v7, 0x3

    const-string v1, "Ion:ttDppio py"

    const-string/jumbo v1, "optionID type:"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-string v0, " espoin qtpten mm"

    const-string/jumbo v0, "mp iiospt  mneetn"

    const/4 v7, 0x3

    const-string v0, "eostm t nisneipml"

    const-string v0, " is not implement"

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    return-void

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v7, 0x6

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-boolean p2, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;->value:Z

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz p2, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v7, 0x2

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    goto :goto_0

    :cond_2
    const/4 v7, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x1

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual/range {v0 .. v5}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setOptionLong(IJJ)I

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-void
.end method

.method private b(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;)V
    .locals 8
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->convertToNativeOptionalId(I)Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->a()Z

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v1, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x2

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const-string v0, ",oampI iny, d paru irngtraoo :apiplMivtnas onldeind   iinldnofla g"

    const-string/jumbo v0, "player optionalIdMapping long is invalid, not found in array, id: "

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    return-void

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    const/4 v1, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eq p1, v1, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v1, 0x3

    const/4 v7, 0x6

    const/4 v6, 0x1

    if-eq p1, v1, :cond_1

    const/4 v6, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v1, 0x4

    const/4 v6, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-eq p1, v1, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    const-string/jumbo v1, "poDtot neoI:iq"

    const-string/jumbo v1, "notyoitIqDe:p "

    const-string/jumbo v1, "optionID type:"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string/jumbo v0, "t stismmni opele "

    const-string/jumbo v0, "omispbmt ni ele t"

    const-string v0, " is not implement"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    return-void

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-wide v2, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-wide v4, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->param1:J

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual/range {v0 .. v5}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setOptionLong(IJJ)I

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    return-void
.end method

.method private b(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->convertToNativeOptionalId(I)Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v0, "iam uiuida, n:prpvote M selnndpojlb  rn na,pgoyraitfoiIadd yi t noc"

    const-string v0, "ddnmogi rbjIsi apaetriaintMlvo nlo  pi: etc   oy,fnpodnup,anariiy d"

    const/4 v3, 0x3

    const-string v0, "I :piygpidaiofrod ntliop ja d,vaoorree   pipind,c nnaitnnMab ta yul"

    const-string/jumbo v0, "player optionaIdMapping object is invalid, not found in array, id: "

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/16 v1, 0x3e9

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eq p1, v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const-string/jumbo v1, "pD:iyonIqtpeo "

    const-string v1, "en oopIpoyDi:t"

    const/4 v3, 0x1

    const-string/jumbo v1, "p sni:oDtetoIy"

    const-string/jumbo v1, "optionID type:"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v0, " plms mnobmi etie"

    const-string/jumbo v0, "temslbi iptnm eo "

    const/4 v3, 0x4

    const-string/jumbo v0, "iemoontmen p ist "

    const-string v0, " is not implement"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object p1, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;->objectValue:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    check-cast p1, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;)Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p2, v0, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setOptionObject(ILjava/lang/Object;)I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method

.method private b(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;)V
    .locals 4
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPOptionalId;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->convertToNativeOptionalId(I)Lcom/tencent/thumbplayer/adapter/a/b/c$a;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->a()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string v0, " MiigbdifrarlIl,datnupsgponoi s, irepytnl na r yau vnd ndti o ipoan:"

    const-string v0, " s ,niuniinIuieg a:itniy aoro gi ,lp didnonrpl yrvMrpsonp tadladt fa"

    const/4 v3, 0x3

    const-string v0, "   dp udpn gMood,nniyfolsalv goyiap:iu,reitripislnn raiia aI nnttrd "

    const-string/jumbo v0, "player optionalIdMapping string is invalid, not found in array, id: "

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eq p1, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string/jumbo v1, "opoi t:penIpyp"

    const-string/jumbo v1, "peiIotDpo:npy "

    const/4 v3, 0x7

    const-string v1, "DiyonotpqIe: p"

    const-string/jumbo v1, "optionID type:"

    const/4 v3, 0x7

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->b()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v0, "tmsml  qp nsiotin"

    const-string/jumbo v0, "mp oiil qtst ennm"

    const/4 v3, 0x3

    const-string/jumbo v0, "nismmtopmi e  enl"

    const-string v0, " is not implement"

    const/4 v2, 0x7

    or-int/2addr v3, v2

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/b/c$a;->c()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object p2, p2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;->value:Ljava/lang/String;

    const/4 v3, 0x2

    invoke-virtual {p1, v0, p2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setOptionObject(ILjava/lang/Object;)I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method static synthetic c(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/adapter/g;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p0
.end method

.method private c()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/g;->c()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method private d()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/g;->b()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method static synthetic d(Lcom/tencent/thumbplayer/adapter/a/b/b;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->b()V

    const/4 v0, 0x2

    and-int/2addr v1, v0

    return-void
.end method

.method private d(I)Z
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/b/b;->a:Ljava/util/Set;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return p1
.end method

.method static synthetic e(Lcom/tencent/thumbplayer/adapter/a/b/b;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->c()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    return-void
.end method

.method static synthetic f(Lcom/tencent/thumbplayer/adapter/a/b/b;)V
    .locals 2

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->d()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic g(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/api/TPSubtitleData;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->g:Lcom/tencent/thumbplayer/api/TPSubtitleData;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method


# virtual methods
.method public a(F)V
    .locals 5

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v1, "ansAtatsidRioue:oi"

    const/4 v4, 0x5

    const-string/jumbo v1, "setAudioGainRatio:"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p1}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const-string v0, ",l eoamnpas uareereetrs lhd"

    const-string v0, "elsmra ale,a  hneeturdrspey"

    const/4 v4, 0x7

    const-string/jumbo v0, "rrysabseaehp dueaetnl e,rlr"

    const-string/jumbo v0, "player has released, return"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setAudioVolume(F)I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void
.end method

.method public a(I)V
    .locals 6

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string/jumbo v1, "koeToeu"

    const-string v1, "Tkeooes"

    const/4 v5, 0x5

    const-string/jumbo v1, "pkeeo:T"

    const-string/jumbo v1, "seekTo:"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, p1, v1, v2, v3}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->seekToAsync(IIJ)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-nez v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string/jumbo v2, "ptnssoibq:kootiee"

    const-string/jumbo v2, "s:etobneios pkiot"

    const-string v2, " ksoesoisnt: eopt"

    const-string/jumbo v2, "seek to position:"

    const/4 v5, 0x2

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string p1, "!eal!iu f"

    const-string p1, "e!im!ldaf"

    const-string p1, " failed!!"

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    throw v0
.end method

.method public a(II)V
    .locals 5
    .param p2    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSeekMode;
        .end annotation
    .end param

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string v2, "esoeoTp"

    const-string/jumbo v2, "psToe:e"

    const/4 v4, 0x7

    const-string v2, "eoesTbk"

    const-string/jumbo v2, "seekTo:"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v2, "ud qo:"

    const-string v2, ": qdom"

    const/4 v4, 0x1

    const-string/jumbo v2, "opmed:"

    const-string v2, " mode:"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSeekMode;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSeekMode;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSeekMode;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSeekMode;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v1, p2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x1

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, p1, p2, v1, v2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->seekToAsync(IIJ)I

    move-result p2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-nez p2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance p2, Ljava/lang/IllegalStateException;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string/jumbo v1, "stke ostqio:soe p"

    const-string v1, " osets tes:oikpio"

    const/4 v4, 0x5

    const-string/jumbo v1, "t:si nipesootksoe"

    const-string/jumbo v1, "seek to position:"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string p1, "!dlmefa!m"

    const-string p1, "!ifmdle!a"

    const/4 v4, 0x0

    const-string/jumbo p1, "fd!eoi! a"

    const-string p1, " failed!!"

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p2
.end method

.method public a(IJ)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo v1, "oclTabekcer"

    const-string v1, "celToceatrk"

    const/4 v3, 0x6

    const-string/jumbo v1, "kesarcuceTl"

    const-string/jumbo v1, "selectTrack"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo p2, "rahrslupte be rneerya a,sed"

    const-string/jumbo p2, "slreybeenrsrer hdatuae a,l "

    const/4 v3, 0x0

    const-string p2, "ehaldu sqnt eyesarrrlarpee,"

    const-string/jumbo p2, "player has released, return"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, p1, p2, p3}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->selectTrackAsync(IJ)I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public a(Landroid/content/res/AssetFileDescriptor;)V
    .locals 14

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x0

    if-eqz p1, :cond_1

    const/4 v13, 0x3

    const/4 v12, 0x4

    invoke-virtual {p1}, Landroid/content/res/AssetFileDescriptor;->getParcelFileDescriptor()Landroid/os/ParcelFileDescriptor;

    move-result-object v0

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x7

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->detachFd()I

    move-result v2

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x6

    invoke-virtual {p1}, Landroid/content/res/AssetFileDescriptor;->getStartOffset()J

    move-result-wide v7

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x0

    invoke-virtual {p1}, Landroid/content/res/AssetFileDescriptor;->getLength()J

    move-result-wide v9

    const/4 v13, 0x1

    const/4 v12, 0x5

    invoke-static {v2}, Landroid/os/ParcelFileDescriptor;->fromFd(I)Landroid/os/ParcelFileDescriptor;

    move-result-object v0

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x0

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->detachFd()I

    move-result v11

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x3

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->close()V

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x6

    invoke-virtual {p1}, Landroid/content/res/AssetFileDescriptor;->close()V

    const/4 v12, 0x2

    const/4 v13, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v13, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x1

    const-string v3, "DSsuretoauat ec"

    const-string v3, "Dea:atuur etocS"

    const/4 v13, 0x3

    const-string/jumbo v3, "setDataSource: "

    const/4 v13, 0x0

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x3

    const-string p1, "F :m, ypla"

    const-string/jumbo p1, "lF:y p pa,"

    const/4 v13, 0x3

    const-string p1, "Fy:dop, l "

    const-string p1, ", playFd: "

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    move v13, v12

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x4

    const-string/jumbo p1, "f ot bsfq:"

    const-string p1, "eoft sf q:"

    const/4 v13, 0x1

    const-string p1, ",tf:sou f "

    const-string p1, ", offset: "

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x5

    invoke-virtual {v1, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x4

    const-string/jumbo p1, "h:s,e tgn "

    const/4 v13, 0x7

    const-string/jumbo p1, "l:n ,htpg "

    const-string p1, ", length: "

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    invoke-virtual {v1, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    const-string/jumbo p1, "r a:tc,equdp "

    const-string p1, ", captureFd: "

    const/4 v13, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x6

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    move-wide v3, v7

    move-wide v5, v9

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x5

    invoke-virtual/range {v1 .. v6}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setDataSource(IJJ)I

    move-result p1

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x1

    if-nez p1, :cond_0

    const/4 v12, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x5

    new-instance p1, Lcom/tencent/thumbplayer/a/d;

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x7

    move v4, v11

    move v4, v11

    move v4, v11

    move v4, v11

    move-wide v5, v7

    move-wide v7, v9

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x3

    invoke-direct/range {v3 .. v8}, Lcom/tencent/thumbplayer/a/d;-><init>(IJJ)V

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->f:Lcom/tencent/thumbplayer/adapter/a/a;

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x1

    return-void

    :cond_0
    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x6

    const-string/jumbo v0, "frsuemr!ad eualDtdi etSos a!fl"

    const-string v0, "!uem Sddual!lfarat efetrasDo i"

    const/4 v13, 0x1

    const-string/jumbo v0, "uddmffteau! otSa al e!sDlirrea"

    const-string/jumbo v0, "setDataSource url afd failed!!"

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x1

    throw p1

    :cond_1
    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v13, 0x0

    const/4 v12, 0x2

    const-string/jumbo v0, "facuorsuirso! oS lldaDa et!eun "

    const-string/jumbo v0, "lru o lanSesDductaa! !sefio lru"

    const/4 v13, 0x6

    const-string/jumbo v0, "ulic!butolsaresde! fa n autDlrS"

    const-string/jumbo v0, "setDataSource url afd is null!!"

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x4

    throw p1
.end method

.method public a(Landroid/os/ParcelFileDescriptor;)V
    .locals 9

    const/4 v8, 0x5

    if-eqz p1, :cond_1

    const/4 v7, 0x6

    and-int/2addr v8, v7

    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->detachFd()I

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-static {v1}, Landroid/os/ParcelFileDescriptor;->fromFd(I)Landroid/os/ParcelFileDescriptor;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x5

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->detachFd()I

    move-result v6

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->close()V

    const/4 v8, 0x3

    const/4 v7, 0x5

    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->close()V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const-string/jumbo v3, "setDataSource: "

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-string p1, "Fyp:,lubd"

    const-string p1, "Fy:labpd,"

    const/4 v8, 0x5

    const-string p1, "Fydp a:pl"

    const-string p1, ", playFd:"

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-string/jumbo p1, "ur p:uteqF,cd"

    const-string p1, " cF,ueu:drapt"

    const/4 v8, 0x4

    const-string/jumbo p1, "r sdp:aF,u ce"

    const-string p1, ", captureFd: "

    const/4 v8, 0x6

    const/4 v7, 0x5

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v8, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v8, 0x2

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual/range {v0 .. v5}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setDataSource(IJJ)I

    move-result p1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-nez p1, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    new-instance p1, Lcom/tencent/thumbplayer/a/d;

    const/4 v8, 0x3

    invoke-direct {p1, v6}, Lcom/tencent/thumbplayer/a/d;-><init>(I)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->f:Lcom/tencent/thumbplayer/adapter/a/a;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    return-void

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    const-string v0, " udmtir efsfe eaSppl!aao!rlcDt"

    const-string/jumbo v0, "roeutdepupt  !arelal icfSfDsa!"

    const/4 v8, 0x7

    const-string/jumbo v0, "iSdrolteDcfrusl edof p tuaa!!a"

    const-string/jumbo v0, "setDataSource url pfd failed!!"

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    throw p1

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-string/jumbo v0, "tS nea oqeutl!drllprsDci fusa !"

    const/4 v8, 0x0

    const-string/jumbo v0, "setDataSource url pfd is null!!"

    const/4 v7, 0x3

    move v8, v7

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    throw p1
.end method

.method public a(Landroid/view/Surface;)V
    .locals 5

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v2, "f,Scebusscie:elfau ?  a srnlsrt "

    const-string/jumbo v2, "lcs ?:iSursefuuncarfeta e, s  sl"

    const/4 v4, 0x4

    const-string/jumbo v2, "rnsiefuua   cec?ef t s,rllua :sS"

    const-string/jumbo v2, "setSurface, surface is null ? : "

    const/4 v4, 0x6

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez p1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-nez v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const-string/jumbo v0, "rd uermpareelsps,anyt aeehl"

    const-string v0, ",uemnhteslrae dpeaer  rlays"

    const/4 v4, 0x6

    const-string/jumbo v0, "here,e tqesl paaedrns arrlu"

    const-string/jumbo v0, "player has released, return"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setVideoSurface(Landroid/view/Surface;)I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-nez p1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-void

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x1

    const-string v0, "adselfif eucseatr!S"

    const-string/jumbo v0, "setSurface failed!!"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    throw p1
.end method

.method public a(Landroid/view/SurfaceHolder;)V
    .locals 5

    const/4 v3, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x2

    const/4 v3, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v2, "cermdlHSaeecefr u in?Hro ,rl lo:das fuuso"

    const-string v2, ",ddloHsroco cnr uerl iesaHfal?fue S rue:l"

    const/4 v4, 0x4

    const-string/jumbo v2, "rH ro?lrcensu Sf   ,odleduc:fHseo auerall"

    const-string v2, "SurfaceHolder, surfaceHolder is null ? : "

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-nez p1, :cond_0

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x0

    move v3, v2

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v2, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-nez v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v0, "byh sbaedllrns prreeu atra,"

    const-string/jumbo v0, "tpd, brasausrnrahelr leee y"

    const/4 v4, 0x4

    const-string v0, "eeu s uhl treneadrap,ryaers"

    const-string/jumbo v0, "player has released, return"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-void

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz p1, :cond_2

    const/4 v4, 0x3

    invoke-interface {p1}, Landroid/view/SurfaceHolder;->getSurface()Landroid/view/Surface;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-nez v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const-string v0, "Su/uefurcrcrfelea0dfro."

    const/4 v4, 0x2

    const-string/jumbo v0, "reaufdrpr0ofrec.H/ufcel"

    const-string v0, "SurfaceHolder\uff0cerr."

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-void

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-nez p1, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 p1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_1

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-interface {p1}, Landroid/view/SurfaceHolder;->getSurface()Landroid/view/Surface;

    move-result-object p1

    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setVideoSurface(Landroid/view/Surface;)I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-nez p1, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void

    :cond_4
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v0, " ueaffpeqlS!dcse!rt"

    const-string/jumbo v0, "l!atfu pSedrsfe!eca"

    const/4 v4, 0x0

    const-string v0, "dcsSrafaitf ueel!se"

    const-string/jumbo v0, "setSurface failed!!"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$a;)V
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$a;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$b;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$b;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$c;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$c;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$d;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$d;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$e;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$e;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$f;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$f;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$g;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$g;)V

    const/4 v2, 0x2

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$h;)V
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$h;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$i;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$i;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$j;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$j;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$l;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$l;)V

    const/4 v2, 0x0

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$m;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$m;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$n;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$n;)V

    const/4 v2, 0x1

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$o;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$o;)V

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$p;)V
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$p;)V

    const/4 v1, 0x1

    move v2, v1

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPCaptureParams;Lcom/tencent/thumbplayer/api/TPCaptureCallBack;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x1

    const/4 v3, 0x2

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v2, "et mcpaiparurqe,Vdso"

    const-string/jumbo v2, "rtppc,uiqd oeraaVsae"

    const/4 v4, 0x6

    const-string/jumbo v2, "tVraodaormiu,ppec ae"

    const-string v2, "captureVideo, params"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->f:Lcom/tencent/thumbplayer/adapter/a/a;

    const/4 v4, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x1

    iget v1, p1, Lcom/tencent/thumbplayer/api/TPCaptureParams;->width:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput v1, v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->width:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v1, p1, Lcom/tencent/thumbplayer/api/TPCaptureParams;->height:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    iput v1, v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->height:I

    const/4 v4, 0x3

    iget v1, p1, Lcom/tencent/thumbplayer/api/TPCaptureParams;->format:I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput v1, v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->format:I

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-wide v1, p1, Lcom/tencent/thumbplayer/api/TPCaptureParams;->requestedTimeMsToleranceAfter:J

    const/4 v4, 0x0

    const/4 v3, 0x2

    iput-wide v1, v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->requestedTimeMsToleranceAfter:J

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-wide v1, p1, Lcom/tencent/thumbplayer/api/TPCaptureParams;->requestedTimeMsToleranceBefore:J

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-wide v1, v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->requestedTimeMsToleranceBefore:J

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->f:Lcom/tencent/thumbplayer/adapter/a/a;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->n()J

    move-result-wide v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {p1, v1, v2, v0, p2}, Lcom/tencent/thumbplayer/adapter/a/a;->a(JLcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;Lcom/tencent/thumbplayer/api/TPCaptureCallBack;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    const p1, 0xf424d

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-interface {p2, p1}, Lcom/tencent/thumbplayer/api/TPCaptureCallBack;->onCaptureVideoFailed(I)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPOptionalParam;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const-string/jumbo v2, "setPlayerOptionalParam:"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string v0, "as eab t,slheuarslyrdrneper"

    const-string v0, ",psrraaasue  dethreeslnyr l"

    const/4 v4, 0x1

    const-string/jumbo v0, "seser uaaet p, dlrheaurnlye"

    const-string/jumbo v0, "player has released, return"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamType()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/16 v2, 0x1f4

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-ne v0, v1, :cond_2

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-ge v0, v2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamBoolean()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-void

    :cond_1
    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamBoolean()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->b(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamType()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-ne v0, v1, :cond_4

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-ge v0, v2, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;)V

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->b(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-void

    :cond_4
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamType()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x6

    const/4 v4, 0x5

    if-ne v0, v1, :cond_5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-ge v0, v2, :cond_9

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamFloat()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamFloat;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-void

    :cond_5
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamType()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x3

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-ne v0, v1, :cond_7

    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-ge v0, v2, :cond_6

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamString()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void

    :cond_6
    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamString()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->b(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamString;)V

    const/4 v4, 0x0

    return-void

    :cond_7
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamType()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x4

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-ne v0, v1, :cond_8

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-ge v0, v2, :cond_9

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamQueueInt()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueInt;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-void

    :cond_8
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamType()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v1, 0x5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-ne v0, v1, :cond_a

    const/4 v3, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-ge v0, v2, :cond_9

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamQueueString()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamQueueString;)V

    :cond_9
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-void

    :cond_a
    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamType()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v1, 0x7

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-ne v0, v1, :cond_c

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-ge v0, v2, :cond_b

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamObject()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void

    :cond_b
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamObject()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;->b(ILcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-void

    :cond_c
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v0, "tnrorr pamtn pa,amtpnuwuiaae rlennsymiP k o"

    const-string/jumbo v0, "tnoma  aulrm ne mpta tryiwrspeaiPuokaonnn,r"

    const/4 v4, 0x7

    const-string/jumbo v0, "rrnylP tq ooa  unampenttnpmewsuar,oapnriika"

    const-string/jumbo v0, "optionalParam param type is unknown, return"

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)V
    .locals 5

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x5

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string v2, "erseuoa:tcD sat"

    const-string v2, ":ateorsaDuS etc"

    const/4 v4, 0x1

    const-string v2, "e: mrutDcSetasa"

    const-string/jumbo v2, "setDataSource: "

    const/4 v4, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz p1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;->getUrl()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setDataSource(Ljava/lang/String;)I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/a/d;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {v0, p1}, Lcom/tencent/thumbplayer/a/d;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->f:Lcom/tencent/thumbplayer/adapter/a/a;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v4, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v0, "sAidoatod!uesteb sfraec Sletim!aa"

    const-string v0, "eeAaSbour!sdl seiat!detafameis ct"

    const/4 v4, 0x2

    const-string v0, "ASt!ebDafac ddtosraeiim!tessa ele"

    const-string/jumbo v0, "setDataSource mediaAsset failed!!"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    throw p1

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v0, "as!sleuiua ntsu mld "

    const-string/jumbo v0, "uaeas ums!dltil ne s"

    const/4 v4, 0x7

    const-string v0, "!a ssadpilieunes  tm"

    const-string/jumbo v0, "media asset is null!"

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;IJ)V
    .locals 5
    .param p2    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSwitchDefMode;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v2, ": ipDetiqeciwitmesfnstodnisa"

    const-string/jumbo v2, "tewf:aDpceAiite oimtnsindsis"

    const/4 v4, 0x4

    const-string/jumbo v2, "fessitcDtiAnaioiisem:dwesnh "

    const-string/jumbo v2, "switchDefinition mediaAsset:"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo v2, "ue:mq qp"

    const-string/jumbo v2, "qpua: eq"

    const/4 v4, 0x6

    const-string v2, ":a qopou"

    const-string v2, " opaque:"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v1, p3, p4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz p1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSwitchDefMode;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSwitchDefMode;

    const/4 v4, 0x4

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSwitchDefMode;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSwitchDefMode;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {v0, p2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;->getUrl()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1, p2, p3, p4}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->switchDefinitionAsync(Ljava/lang/String;IJ)I

    move-result p2

    const/4 v4, 0x6

    const/4 v3, 0x7

    if-nez p2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance p2, Lcom/tencent/thumbplayer/a/d;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;->getUrl()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-direct {p2, p1}, Lcom/tencent/thumbplayer/a/d;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->f:Lcom/tencent/thumbplayer/adapter/a/a;

    const/4 v4, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo p2, "seeasbihntnf wd ivnatcD nittoiiis"

    const-string/jumbo p2, "scsevft Dea tidntiihlnniaiotins w"

    const/4 v4, 0x4

    const-string/jumbo p2, "iltnesucfaisiiivDwantoetnnidi  ht"

    const-string/jumbo p2, "switchDefinition in invalid state"

    const/4 v3, 0x7

    move v4, v3

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    throw p1

    :cond_1
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/e/b;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v1, Lcom/tencent/thumbplayer/e/b;

    const/4 v3, 0x5

    and-int/2addr v4, v3

    const-string/jumbo v2, "yurlbhTpPaemT"

    const-string/jumbo v2, "ruPmlmehyaTbT"

    const/4 v4, 0x1

    const-string v2, "PmbTeyrhqulPT"

    const-string v2, "TPThumbPlayer"

    const/4 v3, 0x6

    move v4, v3

    invoke-direct {v1, p1, v2}, Lcom/tencent/thumbplayer/e/b;-><init>(Lcom/tencent/thumbplayer/e/b;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->a(Lcom/tencent/thumbplayer/e/b;)V

    const/4 v4, 0x0

    if-eqz p1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/e/a;->a()Lcom/tencent/thumbplayer/e/b;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/e/b;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/adapter/g;->a(Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string/jumbo v2, "rdseNlieusaloVA:amemrmaPszioto"

    const-string/jumbo v2, "tmasozoAiNorrlVaeomilmaeu:Pdes"

    const/4 v4, 0x3

    const-string/jumbo v2, "setAudioNormalizeVolumeParams:"

    const/4 v3, 0x2

    const/4 v3, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x2

    const-string/jumbo v0, "teyms ralab erpl,rrn sdheee"

    const-string/jumbo v0, "rrsl,bapler hee ty ereduasn"

    const/4 v4, 0x7

    const-string/jumbo v0, "hsleoresnlayeadtpa er rur, "

    const-string/jumbo v0, "player has released, return"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setAudioNormalizeVolumeParams(Ljava/lang/String;)I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void
.end method

.method public a(Ljava/lang/String;IJ)V
    .locals 5
    .param p2    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSwitchDefMode;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string v2, "cie ubtirilsuof:Dinnw"

    const-string/jumbo v2, "re lniufiwt:inouciDst"

    const/4 v4, 0x4

    const-string/jumbo v2, "i:furoulitshc itDweni"

    const-string/jumbo v2, "switchDefinition url:"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    move v4, v3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v2, "eqpopuap"

    const-string/jumbo v2, "pue qaop"

    const/4 v4, 0x3

    const-string/jumbo v2, "qop:aeu "

    const-string v2, " opaque:"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, p3, p4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSwitchDefMode;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSwitchDefMode;

    const/4 v4, 0x0

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSwitchDefMode;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSwitchDefMode;

    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v0, p2}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->switchDefinitionAsync(Ljava/lang/String;IJ)I

    move-result p2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-nez p2, :cond_1

    const/4 v3, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->f:Lcom/tencent/thumbplayer/adapter/a/a;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-interface {p2}, Lcom/tencent/thumbplayer/adapter/a/a;->a()V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 p2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->f:Lcom/tencent/thumbplayer/adapter/a/a;

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    new-instance p2, Lcom/tencent/thumbplayer/a/d;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {p2, p1}, Lcom/tencent/thumbplayer/a/d;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->f:Lcom/tencent/thumbplayer/adapter/a/a;

    const/4 v3, 0x0

    xor-int/2addr v4, v3

    return-void

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x0

    move v4, v3

    const-string p2, "aisDsttsifealnncv ttii hii enwnqd"

    const-string p2, " aiiofitqniitntehdtwDniscvna els "

    const/4 v4, 0x5

    const-string/jumbo p2, "waimdlhneiftaDt ii iittesnncni so"

    const-string/jumbo p2, "switchDefinition in invalid state"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    throw p1
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v2, "teoaotceDSursas"

    const-string/jumbo v2, "tesaaDroe stuSc"

    const/4 v4, 0x0

    const-string/jumbo v2, "eusttb SDac:are"

    const-string/jumbo v2, "setDataSource: "

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, p1, p2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setDataSource(Ljava/lang/String;Ljava/util/Map;)I

    move-result p2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez p2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance p2, Lcom/tencent/thumbplayer/a/d;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {p2, p1}, Lcom/tencent/thumbplayer/a/d;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->f:Lcom/tencent/thumbplayer/adapter/a/a;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-void

    :cond_0
    const/4 v4, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x2

    const-string/jumbo p2, "i dd!durSe amr!trelaD tcfaeen lsuoahe"

    const-string p2, "dDsmtdie aear!o a!ulltr Shcenfe redua"

    const/4 v4, 0x4

    const-string p2, "al l itpr!aScatren!ahesree ufodd adDu"

    const-string/jumbo p2, "setDataSource url and header failed!!"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    throw p1
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;IJ)V
    .locals 9
    .param p3    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSwitchDefMode;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;IJ)V"
        }
    .end annotation

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v8, 0x0

    const/4 v7, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string/jumbo v2, "iuiloiicqer otDnwnfht"

    const-string/jumbo v2, "oitDoeuwiih:itn rnfcl"

    const/4 v8, 0x7

    const-string/jumbo v2, "teswliicihnf :uisotrn"

    const-string/jumbo v2, "switchDefinition url:"

    const/4 v7, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const-string/jumbo v2, "th:mbdaeptH"

    const-string/jumbo v2, "p:hetbtHade"

    const/4 v8, 0x6

    const-string/jumbo v2, "rtHpo:dathe"

    const-string/jumbo v2, "httpHeader:"

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    const-string v2, "auqu bep"

    const-string/jumbo v2, "oeau puq"

    const/4 v8, 0x4

    const-string v2, "epouaqu "

    const-string v2, " opaque:"

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v1, p4, p5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    const/4 v8, 0x4

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSwitchDefMode;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSwitchDefMode;

    const/4 v8, 0x4

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSwitchDefMode;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapSwitchDefMode;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-static {v0, p3}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result v4

    const/4 v8, 0x3

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-wide v5, p4

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual/range {v1 .. v6}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->switchDefinitionAsync(Ljava/lang/String;Ljava/util/Map;IJ)I

    move-result p2

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    if-nez p2, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->f:Lcom/tencent/thumbplayer/adapter/a/a;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-eqz p2, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x7

    invoke-interface {p2}, Lcom/tencent/thumbplayer/adapter/a/a;->a()V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/4 p2, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->f:Lcom/tencent/thumbplayer/adapter/a/a;

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    new-instance p2, Lcom/tencent/thumbplayer/a/d;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-direct {p2, p1}, Lcom/tencent/thumbplayer/a/d;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->f:Lcom/tencent/thumbplayer/adapter/a/a;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    return-void

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    const-string/jumbo p2, "vinadwipsno etihst cDfinaintleipt"

    const-string/jumbo p2, "isstDiepah  toiii naevtnfninclwtd"

    const/4 v8, 0x5

    const-string/jumbo p2, "sifeiatlqeowtnti nnatdcii nvDih i"

    const-string/jumbo p2, "switchDefinition in invalid state"

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    throw p1
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object p3, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    const-string/jumbo v0, "tustdqScSirbealde"

    const-string/jumbo v0, "tdcSraelqbitdoSeu"

    const/4 v2, 0x2

    const-string v0, "durmldeaeobtictSS"

    const-string v0, "addSubtitleSource"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p3, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object p3, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-nez p3, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string/jumbo p2, "saneo ueyrrars hs raeetp,ll"

    const-string/jumbo p2, "nuspsrh yla leaeree ter,ars"

    const/4 v2, 0x4

    const-string p2, "eeretbdhaysle,ae pnrr  surl"

    const-string/jumbo p2, "player has released, return"

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p3, p1, p4, p2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->addSubtitleTrackSource(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)I

    const/4 v2, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/List;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/TPOptionalParam;",
            ">;)V"
        }
    .end annotation

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string/jumbo v0, "ucomTcurikdeuaAoraS"

    const-string v0, "drrmeaodkuuTaiocASc"

    const/4 v8, 0x6

    const-string v0, "cocdruSpudkadoraTiA"

    const-string v0, "addAudioTrackSource"

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p2, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v8, 0x5

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-nez p2, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-string/jumbo p2, "ysneelrhqsrre  adea pr,ouel"

    const-string/jumbo p2, "s,p oeaadrunrehtyer  selrle"

    const/4 v8, 0x6

    const-string/jumbo p2, "s sanp a tshereeed,aerrllyr"

    const-string/jumbo p2, "player has released, return"

    const/4 v7, 0x2

    or-int/2addr v8, v7

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    return-void

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x3

    new-instance p2, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPAudioTrackInfo;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-direct {p2}, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPAudioTrackInfo;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    iput-object p1, p2, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPAudioTrackInfo;->audioTrackUrl:Ljava/lang/String;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    iput-object p4, p2, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPAudioTrackInfo;->paramData:Ljava/util/List;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->e:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-eqz v0, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    const/16 v1, 0x3f4

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v8, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v8, 0x2

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual/range {v0 .. v6}, Lcom/tencent/thumbplayer/adapter/g;->a(IJJLjava/lang/Object;)V

    :cond_1
    const/4 v8, 0x1

    iget-object p1, p2, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPAudioTrackInfo;->proxyUrl:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-eqz p1, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    iget-object p4, p2, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPAudioTrackInfo;->audioTrackUrl:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x4

    iget-object p2, p2, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPAudioTrackInfo;->httpHeader:Ljava/util/Map;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {p1, p4, p3, p2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->addAudioTrackSource(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)I

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    return-void

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v8, 0x3

    const/4 v7, 0x0

    iget-object p4, p2, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPAudioTrackInfo;->proxyUrl:Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    iget-object p2, p2, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPAudioTrackInfo;->httpHeader:Ljava/util/Map;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {p1, p4, p3, p2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->addAudioTrackSource(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)I

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    return-void
.end method

.method public a(Z)V
    .locals 5

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x7

    and-int/2addr v4, v3

    const-string v1, "Me:mtupettOutu"

    const-string/jumbo v1, "setOutputMute:"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v4, 0x4

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v0, " bseoeledepeusyr, ar rtaaln"

    const-string v0, ", seaburarlneyltsrep e dear"

    const/4 v4, 0x2

    const-string v0, "ee e bnareyaspdeal,rr shltr"

    const-string/jumbo v0, "player has released, return"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setAudioMute(Z)I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-void
.end method

.method public a(ZJJ)V
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v9, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-string v2, "asptuoueLoc:"

    const-string/jumbo v2, "tapos:ueLobc"

    const/4 v9, 0x5

    const-string/jumbo v2, "setLoopback:"

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-string/jumbo v2, "ooMl:nopprtt aiosSPti"

    const-string v2, "SiaotoMptt: sooinlsrP"

    const/4 v9, 0x3

    const-string v2, ": lapsosqrotnitiMSotP"

    const-string v2, " loopStartPositionMs:"

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    const-string v2, "P sodsinsiMootop:En"

    const-string v2, " loopEndPositionMs:"

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v1, p4, p5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    and-int/2addr v9, v8

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v8, 0x1

    move v9, v8

    if-nez v2, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-string/jumbo p2, "raem rptyaer, haqeus dlnler"

    const-string/jumbo p2, "serdhl ,qa rrreetunla peeay"

    const/4 v9, 0x3

    const-string/jumbo p2, "peleontauser aa,esdrrlrhy e"

    const-string/jumbo p2, "player has released, return"

    const/4 v9, 0x7

    const/4 v8, 0x2

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    return-void

    :cond_0
    const/4 v9, 0x7

    move v3, p1

    move v3, p1

    const/4 v9, 0x2

    move v3, p1

    move v3, p1

    move-wide v4, p2

    move-wide v6, p4

    const/4 v9, 0x1

    const/4 v8, 0x1

    invoke-virtual/range {v2 .. v7}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setLoopback(ZJJ)I

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-nez p1, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    return-void

    :cond_1
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x2

    const-string/jumbo p2, "t ksebl!bfolp seicoaa"

    const-string p2, " csaadpl!e biteolokfs"

    const/4 v9, 0x7

    const-string p2, "aesa!fue  odk!tbcoipl"

    const-string/jumbo p2, "set loopback failed!!"

    const/4 v9, 0x5

    const/4 v8, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    throw p1
.end method

.method public b(I)J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;

    const/4 v3, 0x7

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;

    const-class v0, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-gez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo v0, "r r de po1Ipfon-tantuum m,nr"

    const-string/jumbo v0, "po-m tdnnrodu,uar  feIn t1mr"

    const/4 v3, 0x3

    const-string v0, " ou pdrmqnetrfanrnI,u1 o -da"

    const-string/jumbo v0, "paramId not found, return -1"

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x4

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-wide v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->getPropertyLong(I)J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    return-wide v0
.end method

.method public b(F)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string/jumbo v1, "o:slpdRseeSoaaytie"

    const-string v1, "RaasoileeS:edoPpty"

    const/4 v4, 0x5

    const-string v1, "eiSmlyRoatste:edPp"

    const-string/jumbo v1, "setPlaySpeedRatio:"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {p1}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo v0, "teheorurb adrsalpeelasn yre"

    const-string v0, "dyslnbe preleratrhsa eeura "

    const/4 v4, 0x4

    const-string/jumbo v0, "player has released, return"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v3, 0x0

    move v4, v3

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setPlaybackRate(F)I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void
.end method

.method public b(IJ)V
    .locals 4

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v1, "ecatreuksTl"

    const/4 v3, 0x2

    const-string v1, "ccletbrsaTk"

    const-string/jumbo v1, "selectTrack"

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo p2, "pyes,s praaealenuedrhrret l"

    const/4 v3, 0x6

    const-string p2, "a  areutheunsyle,l asedrerr"

    const-string/jumbo p2, "player has released, return"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, p1, p2, p3}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->deselectTrackAsync(IJ)I

    return-void
.end method

.method public b(Z)V
    .locals 10

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-string/jumbo v1, "qestL:kpacop"

    const-string v1, "b:Lpaskcqeot"

    const/4 v9, 0x0

    const-string/jumbo v1, "oakcpb:Lqste"

    const-string/jumbo v1, "setLoopback:"

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-nez v2, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-string/jumbo v0, "yestelerapren,uralard s h s"

    const/4 v9, 0x3

    const-string v0, "assarhespyer len, e edratlu"

    const-string/jumbo v0, "player has released, return"

    const/4 v9, 0x0

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x5

    return-void

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x6

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const-wide/16 v6, -0x1

    const-wide/16 v6, -0x1

    const/4 v9, 0x1

    const-wide/16 v6, -0x1

    const-wide/16 v6, -0x1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    move v3, p1

    move v3, p1

    const/4 v9, 0x2

    move v3, p1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual/range {v2 .. v7}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setLoopback(ZJJ)I

    const/4 v9, 0x2

    return-void
.end method

.method public c(Z)Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object p1

    :cond_0
    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->getDynamicStatisticParams(Z)Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p1
.end method

.method public c(I)Ljava/lang/String;
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string v0, ""

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string/jumbo v2, "gtgmoimrt:nyeSPerp"

    const-string/jumbo v2, "rnymrirgtPe:pegotS"

    const-string/jumbo v2, "rntgo:etPtrporSyge"

    const-string/jumbo v2, "getPropertyString:"

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v6, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;

    const-class v1, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapPropertyId;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v1, p1}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result v1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-gez v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const-string/jumbo v4, "ttduebo. I,tVTP.NpoypareMgiatiPpMico,(vyrnollePSayreatstaKgpeetNsvaTrr"

    const-string v4, "S(ryoarl,ptareIutgveaaPys.MetyovP stKtVprgleaMitioPNpT,ictapNrnepedT.o"

    const/4 v6, 0x3

    const-string/jumbo v4, "getPropertyString, tpToNativeValue(TPNativeKeyMap.MapPropertyId.class,"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    const-string/jumbo p1, "etu),rurb"

    const-string p1, "e, rrbu)t"

    const/4 v6, 0x2

    const-string/jumbo p1, "nurr)etp,"

    const-string p1, "), return"

    const/4 v6, 0x3

    const/4 v5, 0x2

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    or-int/2addr v6, v5

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v2, p1}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-object v0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p1, v1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->getPropertyString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-object p1

    :catch_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string v1, "d tueofnqporanuuand r rI,"

    const-string v1, " nda uurnrpondou fa,temrI"

    const/4 v6, 0x6

    const-string/jumbo v1, "nasro ntrradp,eIuomt nduf"

    const-string/jumbo v1, "paramId not found, return"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p1, v1}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-object v0
.end method

.method public c(IJ)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v1, "noImaeparergPgt,c loemmpx:dr"

    const-string/jumbo v1, "xo gem,pmractdlarPrne:egoprI"

    const-string/jumbo v1, "oepmo:gn,roI Pgrtecdalrexmra"

    const-string/jumbo v1, "selectProgram, programIndex:"

    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    move v4, v3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string p2, ",elpsbaysdelrt ueeqrrrhn  a"

    const-string p2, "eehlee,tqnysprae saurrr  dl"

    const/4 v4, 0x7

    const-string/jumbo p2, "uyn edustahrraepllae,es rre"

    const-string/jumbo p2, "player has released, return"

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, p1, p2, p3}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->selectProgramAsync(IJ)I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void
.end method

.method public f()V
    .locals 4

    const/4 v2, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const-string/jumbo v1, "prraese"

    const-string/jumbo v1, "rpseear"

    const/4 v3, 0x1

    const-string/jumbo v1, "rqraeep"

    const-string/jumbo v1, "prepare"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->c:Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setInitConfig(Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->prepare()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v1, "! amdeeerirlpapf"

    const/4 v3, 0x2

    const-string/jumbo v1, "resr!ipa!ae dfle"

    const-string/jumbo v1, "prepare failed!!"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    throw v0
.end method

.method public g()V
    .locals 4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v1, "pscmreyorapA"

    const-string v1, "Aapeocerpsyr"

    const/4 v3, 0x6

    const-string v1, "eacpoyArnesp"

    const-string/jumbo v1, "prepareAsync"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->c:Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->setInitConfig(Lcom/tencent/thumbplayer/core/player/TPNativePlayerInitConfig;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->prepareAsync()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string/jumbo v1, "pe!p baArlcifyabe!nrd"

    const-string/jumbo v1, "p faebdrAr!cli!ynapee"

    const/4 v3, 0x2

    const-string v1, "aA erducryalpnep!s!ie"

    const-string/jumbo v1, "prepareAsync failed!!"

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    throw v0
.end method

.method public h()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string/jumbo v1, "stptu"

    const-string/jumbo v1, "sutta"

    const/4 v3, 0x3

    const-string/jumbo v1, "strqa"

    const-string/jumbo v1, "start"

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->start()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo v1, "stsitr!!dpalaf"

    const-string/jumbo v1, "tiesalapfrd!t!"

    const/4 v3, 0x2

    const-string/jumbo v1, "t!dml! riseaat"

    const-string/jumbo v1, "start failed!!"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    throw v0
.end method

.method public i()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string/jumbo v1, "qaspo"

    const-string/jumbo v1, "pauqs"

    const/4 v3, 0x2

    const-string v1, "buase"

    const-string/jumbo v1, "pause"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->pause()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v1, "u sdfaeilaes!!"

    const/4 v3, 0x3

    const-string/jumbo v1, "fpalieuesuda!!"

    const-string/jumbo v1, "pause failed!!"

    const/4 v2, 0x0

    move v3, v2

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    throw v0
.end method

.method public j()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string/jumbo v1, "spot"

    const-string/jumbo v1, "post"

    const/4 v4, 0x4

    const-string/jumbo v1, "otsp"

    const-string/jumbo v1, "stop"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a()V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v1, " mesbofpopr"

    const-string/jumbo v1, "oesmrbe pof"

    const/4 v4, 0x6

    const-string v1, "e brsofoqtp"

    const-string/jumbo v1, "stop before"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->stop()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x5

    const-string/jumbo v2, "rasosotfte"

    const-string/jumbo v2, "o fsoeartt"

    const/4 v4, 0x2

    const-string/jumbo v2, "ortm patse"

    const-string/jumbo v2, "stop after"

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-virtual {v1, v2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const-string/jumbo v1, "poi ofesb!a!d"

    const-string/jumbo v1, "psi!lboadf !e"

    const/4 v4, 0x4

    const-string/jumbo v1, "isod!b!aetf l"

    const-string/jumbo v1, "stop failed!!"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    throw v0
.end method

.method public k()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v1, "uutrs"

    const-string/jumbo v1, "rutes"

    const/4 v3, 0x0

    const-string/jumbo v1, "septe"

    const-string/jumbo v1, "reset"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const-string v1, "dtlrs  .q,aphyeaeeeeerp slr"

    const-string v1, " ehsallpsrysre,t ae.ee prde"

    const-string v1, "e.sesersadhela t erl,p syea"

    const-string/jumbo v1, "reset, player has released."

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo v1, "tsrmeerefe o"

    const-string/jumbo v1, "reset before"

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->reset()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->d:Lcom/tencent/thumbplayer/adapter/a/b/b$a;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v1, "rqrtotsfe e"

    const-string/jumbo v1, "trtrea sqfe"

    const/4 v3, 0x3

    const-string/jumbo v1, "srretbaet e"

    const-string/jumbo v1, "reset after"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method public l()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v1, "eselsru"

    const-string/jumbo v1, "rlsseee"

    const/4 v3, 0x1

    const-string/jumbo v1, "preelae"

    const-string/jumbo v1, "release"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x1

    const/4 v1, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->release()V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    :cond_0
    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->f:Lcom/tencent/thumbplayer/adapter/a/a;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/a;->a()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->f:Lcom/tencent/thumbplayer/adapter/a/a;

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->d:Lcom/tencent/thumbplayer/adapter/a/b/b$a;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->d:Lcom/tencent/thumbplayer/adapter/a/b/b$a;

    :cond_2
    const/4 v3, 0x1

    return-void
.end method

.method public m()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string v1, " ydmualsq, r sapnlear er0eert"

    const-string/jumbo v1, "trrmese erle,ayap unlsr0  eda"

    const/4 v3, 0x6

    const-string v1, "ess t nrul,aeperar0le e radys"

    const-string/jumbo v1, "player has released, return 0"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-wide v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->getDurationMs()J

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-wide v0
.end method

.method public n()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string/jumbo v1, "hldmetnr a0ers ,prle eua yeas"

    const-string/jumbo v1, "player has released, return 0"

    const/4 v2, 0x0

    or-int/2addr v3, v2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-wide v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->getCurrentPositionMs()J

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-wide v0
.end method

.method public o()J
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string v1, ",lauoe stsr nel0oayerrd  reha"

    const-string v1, "   ros nslpla,eeadetauerryr0h"

    const/4 v5, 0x3

    const-string v1, "0rlsdbu,ehsrreerayaate   lp n"

    const-string/jumbo v1, "player has released, return 0"

    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-wide v0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->getBufferedDurationMs()J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v2}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->getCurrentPositionMs()J

    move-result-wide v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    add-long/2addr v0, v2

    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-wide v0
.end method

.method public p()I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string/jumbo v1, "rte dhua0a ,el ue beerlsrsnya"

    const-string/jumbo v1, "sunaebe 0eers lh yl,a drtrrae"

    const-string/jumbo v1, "ryteaedpph neaslr rla0seru,e "

    const-string/jumbo v1, "player has released, return 0"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    and-int/2addr v3, v0

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    return v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->getVideoWidth()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    return v0
.end method

.method public q()I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x0

    move v3, v2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string v1, "0rluldenqte e rsesyu raa,pa h"

    const-string v1, " aer ,uspyrtlnedlrau 0erseah "

    const/4 v3, 0x4

    const-string v1, " asredrp e,0snulehae lsryatre"

    const-string/jumbo v1, "player has released, return 0"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    return v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->getVideoHeight()I

    move-result v0

    const/4 v3, 0x5

    return v0
.end method

.method public r()[Lcom/tencent/thumbplayer/api/TPTrackInfo;
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x0

    and-int/2addr v5, v1

    const/4 v4, 0x1

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string v2, "dprmua re0s rpn,aeytaehlrlse "

    const-string/jumbo v2, "rala nep0r,uadetp se reeyrshl"

    const/4 v5, 0x2

    const-string v2, "eh uorta esllypr r0eaare ndse"

    const-string/jumbo v2, "player has released, return 0"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0, v2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    return-object v1

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->getTrackInfo()[Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    array-length v2, v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-gtz v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_1

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    array-length v1, v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    new-array v1, v1, [Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    array-length v3, v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-ge v2, v3, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    aget-object v3, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {p0, v3}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;)Lcom/tencent/thumbplayer/api/TPTrackInfo;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    aput-object v3, v1, v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    return-object v1
.end method

.method public s()[Lcom/tencent/thumbplayer/api/TPProgramInfo;
    .locals 6

    const/4 v4, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string v2, "ear0qbn,aru d eerrpyathsel  s"

    const-string/jumbo v2, "sa, arhtqranrsel0 ep rd leeyu"

    const/4 v5, 0x3

    const-string v2, "e n0esuryrlud eeara,al hp est"

    const-string/jumbo v2, "player has released, return 0"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-object v1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->getProgramInfo()[Lcom/tencent/thumbplayer/core/player/TPNativePlayerProgramInfo;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    array-length v2, v0

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-gtz v2, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    goto :goto_1

    :cond_1
    const/4 v5, 0x1

    array-length v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-array v1, v1, [Lcom/tencent/thumbplayer/api/TPProgramInfo;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    array-length v3, v0

    const/4 v5, 0x2

    if-ge v2, v3, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    aget-object v3, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {p0, v3}, Lcom/tencent/thumbplayer/adapter/a/b/b;->a(Lcom/tencent/thumbplayer/core/player/TPNativePlayerProgramInfo;)Lcom/tencent/thumbplayer/api/TPProgramInfo;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    aput-object v3, v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-object v1
.end method

.method public t()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->h:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string/jumbo v1, "trnaa up ,s1har dee-rslyrpeees"

    const-string/jumbo v1, "uesran e,hadrr sye p a1e-retls"

    const/4 v3, 0x5

    const-string v1, "-e adr sqrr1raa plhyeestenl, u"

    const-string/jumbo v1, "player has released, return -1"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x0

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-wide v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->getDemuxerOffsetInFile()J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-wide v0
.end method

.method public u()Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b;->b:Lcom/tencent/thumbplayer/core/player/TPNativePlayer;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0

    :cond_0
    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/player/TPNativePlayer;->getGeneralPlayFlowParams()Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method
