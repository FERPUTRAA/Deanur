.class Lcom/tencent/thumbplayer/adapter/a/b/b$6;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/demuxer/ITPNativeDemuxerCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/adapter/a/b/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/adapter/a/b/b;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/adapter/a/b/b;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$6;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    return-void
.end method


# virtual methods
.method public onSdpExchange(Ljava/lang/String;I)Lcom/tencent/thumbplayer/core/demuxer/TPNativeRemoteSdpInfo;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s~~o@~~ @mSvuiblboat~r M@@  ~@o~n@@/fcb@ ~ oK ~@@i~~-@1  dio~.@ ~~t @@@@s/oy~~  ~~  ~~@~ f@l4@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/b/b$6;->a:Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/b/b;->c(Lcom/tencent/thumbplayer/adapter/a/b/b;)Lcom/tencent/thumbplayer/adapter/g;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0, p1, p2}, Lcom/tencent/thumbplayer/adapter/g;->a(Ljava/lang/String;I)Lcom/tencent/thumbplayer/api/TPRemoteSdpInfo;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/api/TPRemoteSdpInfo;)Lcom/tencent/thumbplayer/core/demuxer/TPNativeRemoteSdpInfo;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p1
.end method
