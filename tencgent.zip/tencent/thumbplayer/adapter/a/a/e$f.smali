.class Lcom/tencent/thumbplayer/adapter/a/a/e$f;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/adapter/a/a/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "f"
.end annotation


# instance fields
.field a:I

.field b:J

.field c:J

.field d:I

.field e:I

.field f:I

.field g:Ljava/lang/String;

.field h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/thumbplayer/adapter/a/a/e$1;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e$f;-><init>()V

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method
