.class final enum Lcom/tencent/thumbplayer/adapter/a/a/e$e;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/adapter/a/a/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4018
    name = "e"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/tencent/thumbplayer/adapter/a/a/e$e;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

.field public static final enum b:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

.field public static final enum c:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

.field public static final enum d:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

.field public static final enum e:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

.field public static final enum f:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

.field public static final enum g:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

.field public static final enum h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

.field public static final enum i:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

.field public static final enum j:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

.field private static final synthetic k:[Lcom/tencent/thumbplayer/adapter/a/a/e$e;


# direct methods
.method static constructor <clinit>()V
    .locals 16

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const-string v1, "ILED"

    const-string v1, "LDEI"

    const-string v1, "LEDI"

    const-string v1, "IDLE"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/tencent/thumbplayer/adapter/a/a/e$e;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->a:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    new-instance v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const-string v3, "TssIIENLADI"

    const-string v3, "ITsANDIZLIE"

    const-string v3, "TIZmIAIEILD"

    const-string v3, "INITIALIZED"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4}, Lcom/tencent/thumbplayer/adapter/a/a/e$e;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->b:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    new-instance v3, Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const-string v5, "PRNAoGPEI"

    const-string v5, "PREPARING"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6}, Lcom/tencent/thumbplayer/adapter/a/a/e$e;-><init>(Ljava/lang/String;I)V

    sput-object v3, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->c:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    new-instance v5, Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const-string v7, "AERPPbRm"

    const-string v7, "AEPmERRP"

    const-string v7, "PDPREEuA"

    const-string v7, "PREPARED"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8}, Lcom/tencent/thumbplayer/adapter/a/a/e$e;-><init>(Ljava/lang/String;I)V

    sput-object v5, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->d:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    new-instance v7, Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const-string/jumbo v9, "pSTEDTo"

    const-string v9, "DSRToET"

    const-string v9, "SqTEADR"

    const-string v9, "STARTED"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10}, Lcom/tencent/thumbplayer/adapter/a/a/e$e;-><init>(Ljava/lang/String;I)V

    sput-object v7, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->e:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    new-instance v9, Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const-string v11, "SAsPUD"

    const-string v11, "SAPDUb"

    const-string v11, "PUEmAS"

    const-string v11, "PAUSED"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12}, Lcom/tencent/thumbplayer/adapter/a/a/e$e;-><init>(Ljava/lang/String;I)V

    sput-object v9, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->f:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    new-instance v11, Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const-string v13, "EuTPoPD"

    const-string v13, "EPPTSDu"

    const-string v13, "PPDETbS"

    const-string v13, "STOPPED"

    const/4 v14, 0x6

    invoke-direct {v11, v13, v14}, Lcom/tencent/thumbplayer/adapter/a/a/e$e;-><init>(Ljava/lang/String;I)V

    sput-object v11, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->g:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    new-instance v13, Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const-string v15, "PEOTLpuC"

    const-string v15, "OCELPMTp"

    const-string v15, "ELPCOTEp"

    const-string v15, "COMPLETE"

    const/4 v14, 0x7

    invoke-direct {v13, v15, v14}, Lcom/tencent/thumbplayer/adapter/a/a/e$e;-><init>(Ljava/lang/String;I)V

    sput-object v13, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    new-instance v15, Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const-string/jumbo v14, "qRRqO"

    const-string v14, "REOqR"

    const-string v14, "RRsOR"

    const-string v14, "ERROR"

    const/16 v12, 0x8

    invoke-direct {v15, v14, v12}, Lcom/tencent/thumbplayer/adapter/a/a/e$e;-><init>(Ljava/lang/String;I)V

    sput-object v15, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->i:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    new-instance v14, Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const-string v12, "ESRmsLE"

    const-string v12, "REsLESA"

    const-string v12, "SEEAoLR"

    const-string v12, "RELEASE"

    const/16 v10, 0x9

    invoke-direct {v14, v12, v10}, Lcom/tencent/thumbplayer/adapter/a/a/e$e;-><init>(Ljava/lang/String;I)V

    sput-object v14, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->j:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/16 v12, 0xa

    new-array v12, v12, [Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    aput-object v0, v12, v2

    aput-object v1, v12, v4

    aput-object v3, v12, v6

    aput-object v5, v12, v8

    const/4 v0, 0x4

    aput-object v7, v12, v0

    const/4 v0, 0x5

    aput-object v9, v12, v0

    const/4 v0, 0x6

    aput-object v11, v12, v0

    const/4 v0, 0x7

    aput-object v13, v12, v0

    const/16 v0, 0x8

    aput-object v15, v12, v0

    aput-object v14, v12, v10

    sput-object v12, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->k:[Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/tencent/thumbplayer/adapter/a/a/e$e;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ 1i buot ~f@~o@ s o~~b  S@o@/@ K@ ~ d~rl~ .-@i@4@~~l~@Mbo ~~~ @ b@c~~@~@niov~ay /~@@~@m~t@ f@~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v2, 0x4

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const-class v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v1, 0x4

    move v2, v1

    check-cast p0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0
.end method

.method public static values()[Lcom/tencent/thumbplayer/adapter/a/a/e$e;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->k:[Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v2, 0x4

    const/4 v1, 0x3

    invoke-virtual {v0}, [Lcom/tencent/thumbplayer/adapter/a/a/e$e;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast v0, [Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method
