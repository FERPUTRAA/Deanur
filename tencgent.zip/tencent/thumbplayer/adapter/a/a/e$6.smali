.class Lcom/tencent/thumbplayer/adapter/a/a/e$6;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/adapter/a/a/e;->B()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/adapter/a/a/e$a;

.field final synthetic b:Lcom/tencent/thumbplayer/adapter/a/a/e;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/adapter/a/a/e;Lcom/tencent/thumbplayer/adapter/a/a/e$a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$6;->b:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v1, 0x4

    const/4 v0, 0x3

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$6;->a:Lcom/tencent/thumbplayer/adapter/a/a/e$a;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    :goto_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~1s~/ry~f~b@@i~o M~u  @~ tf~@4~@~d@ot-~K~@~~o ~  ~@@ ~ So o@a~ s~@  ~i@n  m ~@b/@ll.@v@@b ci@@@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$6;->a:Lcom/tencent/thumbplayer/adapter/a/a/e$a;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-boolean v0, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$a;->a:Z

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$6;->b:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->j(Lcom/tencent/thumbplayer/adapter/a/a/e;)V

    const/4 v2, 0x5

    move v3, v2

    const-wide/16 v0, 0x190

    const/4 v3, 0x5

    const-wide/16 v0, 0x190

    const-wide/16 v0, 0x190

    :try_start_0
    const/4 v2, 0x1

    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method
