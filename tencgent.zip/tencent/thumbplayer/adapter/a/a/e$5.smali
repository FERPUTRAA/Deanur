.class Lcom/tencent/thumbplayer/adapter/a/a/e$5;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/adapter/a/a/e;->z()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/adapter/a/a/e;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/adapter/a/a/e;)V
    .locals 2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$5;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public run()V
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "l@s4@@ c~~ v@~~imS~o@f@K@ -f~   @~o@bul@r~ yis /@ M~o~ ~/  b@ot ~~@@@~.~noo~ba 1 ~ @i@~@@~~~@ dt"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$5;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->e(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->c:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v9, 0x3

    if-ne v0, v1, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$5;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v8, 0x4

    shr-int/2addr v9, v8

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->c(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/e/a;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-string v1, "TttmreckePprepi tsrraaCorreesrmTt uhomso,"

    const-string v1, ",TsrotkrtuscmmCrTperttosParh a rrieeeeoep"

    const-string v1, " ComoreetmTpcritotaepieruo, earskrthesrrP"

    const-string/jumbo v1, "startCheckPrepareTimeoutTimer, post error"

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$5;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v8, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->i:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/adapter/a/a/e;->a(Lcom/tencent/thumbplayer/adapter/a/a/e;Lcom/tencent/thumbplayer/adapter/a/a/e$e;)Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$5;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->g(Lcom/tencent/thumbplayer/adapter/a/a/e;)V

    const/4 v8, 0x2

    and-int/2addr v9, v8

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$5;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->h(Lcom/tencent/thumbplayer/adapter/a/a/e;)V

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$5;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->i(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$f;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-eqz v1, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    const/16 v2, 0x7d1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/16 v0, -0x6e

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->d(I)I

    move-result v3

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x4

    const-wide/16 v4, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v9, 0x2

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-interface/range {v1 .. v7}, Lcom/tencent/thumbplayer/adapter/a/c$f;->a(IIJJ)V

    :cond_0
    const/4 v8, 0x1

    const/4 v9, 0x6

    return-void
.end method
