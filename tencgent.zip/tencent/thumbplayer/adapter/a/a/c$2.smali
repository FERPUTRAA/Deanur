.class Lcom/tencent/thumbplayer/adapter/a/a/c$2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/adapter/a/a/c;->a(J)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/adapter/a/a/c;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/adapter/a/a/c;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$2;->a:Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v1, 0x2

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @slysK~ moa~@ u~i  @ cr~n~M~~@o@~f@@S /@  @~~4~@@/ ~o@b~l toid~@~@vi~~ f~  b~ @@-t@oo1@@b~  @~."

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$2;->a:Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/adapter/a/a/c;->a(Lcom/tencent/thumbplayer/adapter/a/a/c;I)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method
