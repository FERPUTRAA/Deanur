.class Lcom/tencent/thumbplayer/adapter/a/a/e$3;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/adapter/a/a/a$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/adapter/a/a/e;-><init>(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/adapter/a/a/e;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/adapter/a/a/e;)V
    .locals 2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$3;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a(IJ)V
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$3;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->d(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$h;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-eqz v0, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$3;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->d(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$h;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x5

    const/4 v2, 0x4

    const/4 v9, 0x2

    const/4 v8, 0x3

    const-wide/16 v3, 0x7d0

    const-wide/16 v3, 0x7d0

    const/4 v9, 0x4

    const-wide/16 v3, 0x7d0

    const-wide/16 v3, 0x7d0

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/a/e;->d(I)I

    move-result p1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    int-to-long v5, p1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-interface/range {v1 .. v7}, Lcom/tencent/thumbplayer/adapter/a/c$h;->a(IJJLjava/lang/Object;)V

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    return-void
.end method

.method public a(J)V
    .locals 10

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$3;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->e(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->e:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-ne v0, v1, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$3;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->f(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/a/a;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/a/a;->b()V

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$3;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->d(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$h;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-eqz v0, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$3;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->d(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$h;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    const/4 v2, 0x4

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x7

    const-wide/16 v3, 0x3e8

    const/4 v9, 0x5

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    const-wide/16 v5, 0x0

    const/4 v9, 0x3

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-interface/range {v1 .. v7}, Lcom/tencent/thumbplayer/adapter/a/c$h;->a(IJJLjava/lang/Object;)V

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    return-void
.end method
