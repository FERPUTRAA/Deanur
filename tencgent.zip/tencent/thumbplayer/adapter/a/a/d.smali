.class public Lcom/tencent/thumbplayer/adapter/a/a/d;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/adapter/a/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/adapter/a/a/d$a;
    }
.end annotation


# instance fields
.field private a:Lcom/tencent/thumbplayer/e/a;

.field private b:Lcom/tencent/thumbplayer/e/b;

.field private c:Landroid/content/Context;

.field private d:Lcom/tencent/thumbplayer/adapter/a/b;

.field private e:Lcom/tencent/thumbplayer/api/TPPlayerState;

.field private f:Lcom/tencent/thumbplayer/adapter/g;

.field private g:Lcom/tencent/thumbplayer/adapter/a/a/d$a;

.field private h:Lcom/tencent/thumbplayer/adapter/c;

.field private i:Lcom/tencent/thumbplayer/adapter/i;

.field private j:Lcom/tencent/thumbplayer/adapter/b;

.field private k:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;",
            ">;"
        }
    .end annotation
.end field

.field private l:I

.field private m:Z

.field private n:Z

.field private o:Ljava/util/LinkedList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedList<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)V
    .locals 4

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x6

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->l:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/e/b;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v1, "ClsSaytyemePsTiPlr"

    const-string v1, "CtsllyPsyPamrieSpe"

    const-string v1, "TPSystemClipPlayer"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0, p2, v1}, Lcom/tencent/thumbplayer/e/b;-><init>(Lcom/tencent/thumbplayer/e/b;Ljava/lang/String;)V

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->b:Lcom/tencent/thumbplayer/e/b;

    const/4 v3, 0x2

    new-instance p2, Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {p2, v0}, Lcom/tencent/thumbplayer/e/a;-><init>(Lcom/tencent/thumbplayer/e/b;)V

    const/4 v2, 0x1

    xor-int/2addr v3, v2

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->c:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance p1, Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x7

    move v3, v2

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPPlayerState;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance p1, Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p1}, Lcom/tencent/thumbplayer/adapter/c;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance p1, Lcom/tencent/thumbplayer/adapter/a/a/d$a;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 p2, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {p1, p0, p2}, Lcom/tencent/thumbplayer/adapter/a/a/d$a;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/d;Lcom/tencent/thumbplayer/adapter/a/a/d$1;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->g:Lcom/tencent/thumbplayer/adapter/a/a/d$a;

    const/4 v3, 0x4

    const/4 v2, 0x4

    new-instance p1, Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x4

    move v3, v2

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/e/a;->b()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {p1, p2}, Lcom/tencent/thumbplayer/adapter/g;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance p1, Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {p1, p2}, Lcom/tencent/thumbplayer/adapter/i;-><init>(Lcom/tencent/thumbplayer/api/TPPlayerState;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x3

    const/4 v2, 0x3

    new-instance p1, Ljava/util/ArrayList;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v3, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/a/d;Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o~~moro@~o~~ ~  t@n~.@l@~So~ ~@ y~m  ~~@@@  l~oMa~i@@ /f@~~@@ @/bbK~  4~@b@@f ~@id@-ui  ~@tc~ vs"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/d;->a(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p0
.end method

.method private a(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v1, 0x7

    or-int/2addr v3, v1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p1

    :cond_0
    const/4 v2, 0x1

    move v3, v2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object p1
.end method

.method private a()V
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-eqz v0, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    const/16 v1, 0x98

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    iget v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->l:I

    const/4 v9, 0x3

    const/4 v8, 0x6

    int-to-long v2, v2

    const/4 v9, 0x3

    const/4 v8, 0x3

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x0

    const/4 v6, 0x0

    const/4 v9, 0x2

    move v8, v6

    move v8, v6

    invoke-virtual/range {v0 .. v6}, Lcom/tencent/thumbplayer/adapter/g;->a(IJJLjava/lang/Object;)V

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->m:Z

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-eqz v0, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->h()V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->n:Z

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-eqz v0, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-eqz v0, :cond_2

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->o:Ljava/util/LinkedList;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-static {v0}, Lcom/tencent/thumbplayer/utils/b;->a(Ljava/util/Collection;)Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-nez v0, :cond_2

    const/4 v8, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->o:Ljava/util/LinkedList;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v0}, Ljava/util/LinkedList;->poll()Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    check-cast v0, Ljava/lang/Long;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-eqz v0, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    const/4 v2, 0x3

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v9, 0x5

    const-wide/16 v5, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    const/4 v7, 0x0

    const/4 v9, 0x2

    invoke-virtual/range {v1 .. v7}, Lcom/tencent/thumbplayer/adapter/g;->a(IJJLjava/lang/Object;)V

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/4 v0, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->n:Z

    :cond_2
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    return-void

    :cond_3
    const/4 v9, 0x4

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    const/4 v1, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    if-nez v0, :cond_4

    const/4 v9, 0x2

    const/4 v8, 0x6

    return-void

    :cond_4
    const/4 v9, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    const/4 v1, 0x4

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v8, 0x6

    move v9, v8

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    if-eqz v0, :cond_5

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/g;->a()V

    :cond_5
    const/4 v9, 0x2

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v9, 0x2

    const/4 v8, 0x4

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->b(Lcom/tencent/thumbplayer/adapter/a/b;)V

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    return-void
.end method

.method private a(IIJJ)V
    .locals 9

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v8, 0x0

    const/4 v1, 0x4

    const/4 v8, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v8, 0x3

    if-nez v0, :cond_0

    const/4 v8, 0x5

    return-void

    :cond_0
    const/4 v8, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v8, 0x4

    move v2, p1

    move v2, p1

    move v2, p1

    move v2, p1

    const/4 v8, 0x1

    move v3, p2

    move v3, p2

    move-wide v4, p3

    move-wide v6, p5

    const/4 v8, 0x5

    invoke-virtual/range {v1 .. v7}, Lcom/tencent/thumbplayer/adapter/g;->a(IIJJ)V

    const/4 v8, 0x1

    return-void
.end method

.method private a(IJJLjava/lang/Object;)V
    .locals 9

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v8, 0x6

    const/4 v1, 0x3

    const/4 v8, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v8, 0x5

    if-nez v0, :cond_0

    const/4 v8, 0x4

    return-void

    :cond_0
    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v8, 0x2

    move v2, p1

    move v2, p1

    move v2, p1

    move v2, p1

    move-wide v3, p2

    move-wide v5, p4

    move-object v7, p6

    move-object v7, p6

    move-object v7, p6

    move-object v7, p6

    const/4 v8, 0x0

    invoke-virtual/range {v1 .. v7}, Lcom/tencent/thumbplayer/adapter/g;->a(IJJLjava/lang/Object;)V

    const/4 v8, 0x7

    return-void
.end method

.method private a(JJ)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x6

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->j:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, p3, p4}, Lcom/tencent/thumbplayer/adapter/b;->b(J)V

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->j:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p1, p2}, Lcom/tencent/thumbplayer/adapter/b;->a(J)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/adapter/g;->a(JJ)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/a/d;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->a()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/a/d;IIJJ)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct/range {p0 .. p6}, Lcom/tencent/thumbplayer/adapter/a/a/d;->a(IIJJ)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/a/d;IJJLjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct/range {p0 .. p6}, Lcom/tencent/thumbplayer/adapter/a/a/d;->a(IJJLjava/lang/Object;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/a/d;JJ)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/adapter/a/a/d;->a(JJ)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/a/d;Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/d;->a(Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/a/d;Lcom/tencent/thumbplayer/api/TPSubtitleData;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/d;->a(Lcom/tencent/thumbplayer/api/TPSubtitleData;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/a/d;Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/d;->a(Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/adapter/a/b;)V
    .locals 9

    const/4 v7, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->g()I

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    const/4 v1, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    if-ne v1, v0, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v8, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->c()Landroid/os/ParcelFileDescriptor;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x6

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Landroid/os/ParcelFileDescriptor;)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    goto :goto_0

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->g()I

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/4 v1, 0x4

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-ne v1, v0, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->d()Landroid/content/res/AssetFileDescriptor;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Landroid/content/res/AssetFileDescriptor;)V

    :cond_1
    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->g()I

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    if-nez v0, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v7, 0x3

    or-int/2addr v8, v7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/adapter/h;->b()Ljava/util/Map;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-interface {p1, v0, v1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Ljava/lang/String;Ljava/util/Map;)V

    :cond_2
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->o()Ljava/util/List;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-eqz v1, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x4

    check-cast v1, Lcom/tencent/thumbplayer/api/TPOptionalParam;

    const/4 v7, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-interface {p1, v1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/api/TPOptionalParam;)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    goto :goto_1

    :cond_3
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->m()Ljava/util/List;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_2
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-eqz v1, :cond_4

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    check-cast v1, Lcom/tencent/thumbplayer/adapter/c$d;

    const/4 v8, 0x1

    iget-object v2, v1, Lcom/tencent/thumbplayer/adapter/c$d;->a:Ljava/lang/String;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-object v3, v1, Lcom/tencent/thumbplayer/adapter/c$d;->d:Ljava/util/Map;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-object v4, v1, Lcom/tencent/thumbplayer/adapter/c$d;->b:Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-object v1, v1, Lcom/tencent/thumbplayer/adapter/c$d;->c:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-interface {p1, v2, v3, v4, v1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    goto :goto_2

    :cond_4
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->n()Ljava/util/List;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-eqz v1, :cond_5

    const/4 v8, 0x3

    const/4 v7, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    check-cast v1, Lcom/tencent/thumbplayer/adapter/c$a;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-object v2, v1, Lcom/tencent/thumbplayer/adapter/c$a;->a:Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget-object v3, v1, Lcom/tencent/thumbplayer/adapter/c$a;->d:Ljava/util/Map;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    iget-object v4, v1, Lcom/tencent/thumbplayer/adapter/c$a;->b:Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget-object v1, v1, Lcom/tencent/thumbplayer/adapter/c$a;->c:Ljava/util/List;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-interface {p1, v2, v3, v4, v1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/List;)V

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    goto :goto_3

    :cond_5
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v7, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->k()Lcom/tencent/thumbplayer/adapter/c$b;

    move-result-object v0

    const/4 v8, 0x1

    if-eqz v0, :cond_6

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->k()Lcom/tencent/thumbplayer/adapter/c$b;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-boolean v2, v0, Lcom/tencent/thumbplayer/adapter/c$b;->a:Z

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->k()Lcom/tencent/thumbplayer/adapter/c$b;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    iget-wide v3, v0, Lcom/tencent/thumbplayer/adapter/c$b;->b:J

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->k()Lcom/tencent/thumbplayer/adapter/c$b;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    iget-wide v5, v0, Lcom/tencent/thumbplayer/adapter/c$b;->c:J

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-interface/range {v1 .. v6}, Lcom/tencent/thumbplayer/adapter/a/b;->a(ZJJ)V

    :cond_6
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->g()Z

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Z)V

    const/4 v7, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->h()F

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    const/4 v1, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    cmpl-float v0, v0, v1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-eqz v0, :cond_7

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->h()F

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(F)V

    :cond_7
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->j()F

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    cmpl-float v0, v0, v1

    const/4 v8, 0x1

    if-eqz v0, :cond_8

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->j()F

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->b(F)V

    :cond_8
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->d()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    instance-of v0, v0, Landroid/view/SurfaceHolder;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-eqz v0, :cond_9

    const/4 v8, 0x6

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->d()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    check-cast v0, Landroid/view/SurfaceHolder;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Landroid/view/SurfaceHolder;)V

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    goto :goto_4

    :cond_9
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->d()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    instance-of v0, v0, Landroid/view/Surface;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-eqz v0, :cond_a

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->d()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    check-cast v0, Landroid/view/Surface;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Landroid/view/Surface;)V

    :cond_a
    :goto_4
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->g:Lcom/tencent/thumbplayer/adapter/a/a/d$a;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$h;)V

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->g:Lcom/tencent/thumbplayer/adapter/a/a/d$a;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$i;)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->g:Lcom/tencent/thumbplayer/adapter/a/a/d$a;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$c;)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->g:Lcom/tencent/thumbplayer/adapter/a/a/d$a;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$f;)V

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->g:Lcom/tencent/thumbplayer/adapter/a/a/d$a;

    const/4 v8, 0x0

    const/4 v7, 0x5

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$j;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->g:Lcom/tencent/thumbplayer/adapter/a/a/d$a;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$p;)V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->g:Lcom/tencent/thumbplayer/adapter/a/a/d$a;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$l;)V

    const/4 v8, 0x3

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x7

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/api/TPSubtitleData;)V
    .locals 4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x7

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPSubtitleData;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;)V
    .locals 4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x7

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/adapter/a/a/d;Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/d;->b(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method private b(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x7

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p1

    :cond_0
    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->b(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p1
.end method

.method private b(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)Ljava/util/List;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;",
            ")",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x4

    const/4 v7, 0x7

    instance-of v0, p1, Lcom/tencent/thumbplayer/b/e;

    const/4 v7, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-nez v0, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    instance-of v1, p1, Lcom/tencent/thumbplayer/b/g;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-nez v1, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    instance-of v1, p1, Lcom/tencent/thumbplayer/b/h;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-eqz v1, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x6

    goto :goto_0

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string v0, " telosPatseimly eee lm  clrsssom: disuaameirigya! e"

    const-string v0, "esdmc aate lyam  tuemllPaoiirles missgr!aie: s esey"

    const/4 v8, 0x6

    const-string v0, "ePu!dbtyst a ed argeislslmiilm:as mlsyca  ee oeeasr"

    const-string/jumbo v0, "system mediaPlayer : media asset is illegal source!"

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    throw p1

    :cond_1
    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    new-instance v1, Ljava/util/ArrayList;

    const/4 v7, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v2, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-eqz v0, :cond_3

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    check-cast p1, Lcom/tencent/thumbplayer/b/e;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/b/e;->getAllAVTracks()Ljava/util/List;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {p1}, Lcom/tencent/thumbplayer/utils/b;->a(Ljava/util/Collection;)Z

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x4

    if-nez v0, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-eqz v0, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    check-cast p1, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;->getAllTrackClips()Ljava/util/List;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    goto :goto_1

    :cond_2
    const/4 v7, 0x7

    const/4 v8, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string/jumbo v0, "puwtneuaa   erecs!atdkhmtsyt  arvo ec"

    const-string v0, "empty av tracks when set data source!"

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    throw p1

    :cond_3
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    instance-of v0, p1, Lcom/tencent/thumbplayer/b/g;

    const/4 v7, 0x0

    or-int/2addr v8, v7

    if-eqz v0, :cond_4

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    check-cast p1, Lcom/tencent/thumbplayer/b/g;

    const/4 v8, 0x6

    const/4 v7, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/b/g;->getAllTrackClips()Ljava/util/List;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x2

    goto :goto_1

    :cond_4
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    check-cast p1, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-interface {v1, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_1
    const/4 v8, 0x1

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v8, 0x6

    const-wide/16 v3, 0x0

    :goto_2
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-ge v2, p1, :cond_5

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x4

    check-cast p1, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-interface {p1, v3, v4}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->setStartPositionMs(J)V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    check-cast p1, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v8, 0x2

    const/4 v7, 0x1

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getOriginalDurationMs()J

    move-result-wide v5

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    add-long/2addr v3, v5

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    goto :goto_2

    :cond_5
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    return-object v1
.end method

.method private b()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v1, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->l:I

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    add-int/lit8 v1, v1, -0x1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-lt v0, v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v1, 0x7

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/g;->b()V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-void

    :cond_1
    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->l:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-wide/16 v1, 0x0

    const/4 v5, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v5, 0x3

    invoke-direct {p0, v0, v1, v2}, Lcom/tencent/thumbplayer/adapter/a/a/d;->d(IJ)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-void

    :catch_0
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const-string/jumbo v3, "lnleoenChdmteOoap"

    const/4 v5, 0x1

    const-string/jumbo v3, "tannopCphlmOleee:"

    const-string/jumbo v3, "handleOnComplete:"

    const/4 v4, 0x5

    move v5, v4

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-void
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/adapter/a/a/d;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->b()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method private b(Lcom/tencent/thumbplayer/adapter/a/b;)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->r()[Lcom/tencent/thumbplayer/api/TPTrackInfo;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-void

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    array-length v2, v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-ge v1, v2, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    aget-object v2, v0, v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v2}, Lcom/tencent/thumbplayer/api/TPTrackInfo;->getTrackType()I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v3, v2}, Lcom/tencent/thumbplayer/adapter/c;->a(I)Lcom/tencent/thumbplayer/api/TPTrackInfo;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    aget-object v3, v0, v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v3, v2}, Lcom/tencent/thumbplayer/api/TPTrackInfo;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x6

    if-eqz v2, :cond_1

    const/4 v4, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-interface {p1, v1, v2, v3}, Lcom/tencent/thumbplayer/adapter/a/b;->a(IJ)V

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    return-void
.end method

.method private c()Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;
    .locals 4

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->l:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    check-cast v0, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0
.end method

.method static synthetic c(Lcom/tencent/thumbplayer/adapter/a/a/d;)V
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->d()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method private d()V
    .locals 4

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x5

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x7

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->is(I)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->h()V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/g;->c()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void
.end method

.method private d(I)V
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v8, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v8, 0x1

    const/4 v7, 0x1

    if-ge v0, v1, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x4

    check-cast v1, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-interface {v1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getStartPositionMs()J

    move-result-wide v1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    int-to-long v3, p1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    cmp-long v1, v1, v3

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-gtz v1, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v7, 0x2

    move v8, v7

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    check-cast v1, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v8, 0x0

    invoke-interface {v1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getStartPositionMs()J

    move-result-wide v1

    const/4 v8, 0x6

    const/4 v7, 0x1

    iget-object v5, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-interface {v5, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    check-cast v5, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    invoke-interface {v5}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getOriginalDurationMs()J

    move-result-wide v5

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    add-long/2addr v1, v5

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x2

    cmp-long v1, v3, v1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-gtz v1, :cond_0

    :try_start_0
    const/4 v8, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    check-cast v1, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    invoke-interface {v1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getStartPositionMs()J

    move-result-wide v1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    sub-long/2addr v3, v1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct {p0, v0, v3, v4}, Lcom/tencent/thumbplayer/adapter/a/a/d;->d(IJ)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    goto :goto_1

    :catch_0
    move-exception v1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    const-string/jumbo v4, "s:reiCeaqtbeyplPl"

    const-string v4, "eerstbPeaCypl:ill"

    const/4 v8, 0x5

    const-string/jumbo v4, "yes:ePilslpetarcC"

    const-string/jumbo v4, "selectClipPlayer:"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v2, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    :cond_0
    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    goto/16 :goto_0

    :cond_1
    const/4 v7, 0x0

    move v8, v7

    return-void
.end method

.method private d(IJ)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string v2, "cohmrPu: ctiaiwylNpsl"

    const-string v2, "e:iwsiul NratlPphocyc"

    const/4 v4, 0x3

    const-string/jumbo v2, "iricow: lNasyctpehP:o"

    const-string/jumbo v2, "switchPlayer: clipNo:"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string v2, "a orpbs oPtit:n "

    const-string v2, " aotiotps s:nr P"

    const/4 v4, 0x7

    const-string/jumbo v2, "ooarnsu ttts :P "

    const-string v2, "   startPostion:"

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->b(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->l()V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->m:Z

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->l:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v4, 0x6

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    check-cast p1, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getFilePath()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->b(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->e()Lcom/tencent/thumbplayer/adapter/a/b;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz p1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance p1, Lcom/tencent/thumbplayer/api/TPOptionalParam;

    const/4 v3, 0x4

    move v4, v3

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/16 v0, 0x64

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1, v0, p2, p3}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->buildLong(IJ)Lcom/tencent/thumbplayer/api/TPOptionalParam;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {p2, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/api/TPOptionalParam;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x7

    invoke-interface {p1}, Lcom/tencent/thumbplayer/adapter/a/b;->f()V

    const/4 v4, 0x1

    return-void

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo p2, "r  rfqepy dorr,atelape cleia"

    const-string p2, " lr aretqeydercpro laa erif,"

    const/4 v4, 0x7

    const-string/jumbo p2, "oaryefa qld cip ,reeeta rlre"

    const-string p2, "error , create player failed"

    const/4 v4, 0x7

    const/4 v3, 0x5

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    throw p1
.end method

.method private e()Lcom/tencent/thumbplayer/adapter/a/b;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->c:Landroid/content/Context;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->b:Lcom/tencent/thumbplayer/e/b;

    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-direct {v0, v1, v2}, Lcom/tencent/thumbplayer/adapter/a/a/e;-><init>(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->j:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-nez v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance v1, Lcom/tencent/thumbplayer/adapter/b;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {v1}, Lcom/tencent/thumbplayer/adapter/b;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->j:Lcom/tencent/thumbplayer/adapter/b;

    :cond_0
    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->a(Lcom/tencent/thumbplayer/adapter/a/b;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object v0
.end method


# virtual methods
.method public a(F)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(F)V

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(F)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method public a(I)V
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/16 v1, 0x9

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-nez v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    return-void

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    int-to-long v0, p1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->c()Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    move-result-object v2

    const/4 v6, 0x2

    xor-int/2addr v7, v6

    invoke-interface {v2}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getStartPositionMs()J

    move-result-wide v2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    cmp-long v2, v0, v2

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-ltz v2, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->c()Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x7

    invoke-interface {v2}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getStartPositionMs()J

    move-result-wide v2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->c()Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-interface {v4}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getOriginalDurationMs()J

    move-result-wide v4

    const/4 v7, 0x6

    const/4 v6, 0x7

    add-long/2addr v2, v4

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    cmp-long v2, v0, v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-gtz v2, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-eqz v2, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string/jumbo v3, "sks oest"

    const-string/jumbo v3, "oeseskt "

    const/4 v7, 0x0

    const-string v3, "ekom s:t"

    const-string/jumbo v3, "seek to:"

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v3, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v2, p1}, Lcom/tencent/thumbplayer/e/a;->b(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v7, 0x0

    const/4 v6, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->c()Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x0

    invoke-interface {v2}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getStartPositionMs()J

    move-result-wide v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    sub-long/2addr v0, v2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    long-to-int v0, v0

    const/4 v6, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(I)V

    const/4 v6, 0x6

    move v7, v6

    return-void

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/d;->d(I)V

    :cond_2
    const/4 v7, 0x5

    return-void
.end method

.method public a(II)V
    .locals 8
    .param p2    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSeekMode;
        .end annotation
    .end param

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v6, 0x7

    const/4 v6, 0x3

    const/16 v1, 0x9

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-nez v0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    return-void

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    int-to-long v0, p1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->c()Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x4

    invoke-interface {v2}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getStartPositionMs()J

    move-result-wide v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    cmp-long v2, v0, v2

    const/4 v7, 0x7

    if-ltz v2, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->c()Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    move-result-object v2

    const/4 v7, 0x5

    invoke-interface {v2}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getStartPositionMs()J

    move-result-wide v2

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->c()Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-interface {v4}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getOriginalDurationMs()J

    move-result-wide v4

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    add-long/2addr v2, v4

    const/4 v7, 0x5

    cmp-long v2, v0, v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-gtz v2, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-eqz v2, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string v4, " omkoet:"

    const-string/jumbo v4, "k tm:soe"

    const/4 v7, 0x0

    const-string/jumbo v4, "sk:eebot"

    const-string/jumbo v4, "seek to:"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-string/jumbo p1, "u=omd/"

    const-string/jumbo p1, "mdo=o/"

    const/4 v7, 0x0

    const-string p1, "/pd=mo"

    const-string p1, "/mode="

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-virtual {v2, p1}, Lcom/tencent/thumbplayer/e/a;->b(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v7, 0x0

    const/4 v6, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->c()Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-interface {v2}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getStartPositionMs()J

    move-result-wide v2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    sub-long/2addr v0, v2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    long-to-int v0, v0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-interface {p1, v0, p2}, Lcom/tencent/thumbplayer/adapter/a/b;->a(II)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    return-void

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/d;->d(I)V

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    return-void
.end method

.method public a(IJ)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    const-string/jumbo p2, "t.rereaoqekpndtp stclosuTb"

    const-string/jumbo p2, "nr Tobecer.ottaedclpupktss"

    const/4 v1, 0x6

    const-string/jumbo p2, "ucsnpdteoe.atsp krTtocrlse"

    const-string/jumbo p2, "selectTrack not supported."

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v1, 0x0

    return-void
.end method

.method public a(Landroid/content/res/AssetFileDescriptor;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Landroid/content/res/AssetFileDescriptor;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public a(Landroid/os/ParcelFileDescriptor;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Landroid/os/ParcelFileDescriptor;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public a(Landroid/view/Surface;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v1, 0x4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Landroid/view/Surface;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Landroid/view/Surface;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const-string/jumbo v0, "iiumaa fvtsSste uctr ln,da"

    const-string/jumbo v0, "icvls,uttiSu a rdsaa eenft"

    const-string/jumbo v0, "ras,o ae vntettfais lcuiSd"

    const-string/jumbo v0, "setSurface , state invalid"

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    throw p1
.end method

.method public a(Landroid/view/SurfaceHolder;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Landroid/view/SurfaceHolder;)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Landroid/view/SurfaceHolder;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string v0, "elnucbtaedoStivHap ad esr, trfie"

    const-string/jumbo v0, "ialft tpcv,eHelti ue oasnderaSdr"

    const/4 v3, 0x6

    const-string v0, "eevusoutditsafeldrca rHt  aSniel"

    const-string/jumbo v0, "setSurfaceHolder , state invalid"

    const/4 v3, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$a;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string/jumbo v0, "frc yatpa Mitpulaernopea daotyqensop t ser mudsim"

    const-string v0, "deauylraqi sf oytap pt emrnn aeesuasrtom cMootipd"

    const/4 v2, 0x7

    const-string/jumbo v0, "r tMrierqtup lnaeodesyapuaafuioamnpd oyo cemsts t"

    const-string/jumbo v0, "system Mediaplayer cannot support audio frame out"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x7

    move v2, v1

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$b;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string v0, "Mesr  a  laeftoiersdy tcpu cipsstoruteoapoe osspmosuyartpmadn"

    const-string/jumbo v0, "ussc p msooemeMtsfeepcrttrosd pastyp  osp oaaoar elyudaiurtni"

    const/4 v2, 0x5

    const-string/jumbo v0, "plsmccs rpsdnpeyoatt tmesnfysa apruooou  oeMapr om eausedtitr"

    const-string/jumbo v0, "system Mediaplayer cannot support audio postprocess frame out"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$c;)V
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$c;)V

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$d;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$e;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$f;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$f;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$g;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$h;)V
    .locals 3

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$h;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$i;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$i;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$j;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$j;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$l;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$l;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$m;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$n;)V
    .locals 3

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string/jumbo v0, "rppdoe laneaaosMao tpeu ti cdmetse  ouynfrmymtosi"

    const-string/jumbo v0, "p tmsleony dmtprpusyf cMuaieaa eioor e tsvnemdtoa"

    const/4 v2, 0x7

    const-string v0, "a eeobrdtsdpucoteiaeo rfplinvoytMaypsst  mea mrnu"

    const-string/jumbo v0, "system Mediaplayer cannot support video frame out"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$o;)V
    .locals 3

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string/jumbo v0, "syas uuc ss oipotndMetrosmpmeoei s ro olaeutpcpftrayoneeda pv"

    const-string v0, "emryotnmse daopi sstteecs udofys si nplooMrpotcuoepvpaar et a"

    const/4 v2, 0x5

    const-string/jumbo v0, "specau pop cfo idirdsryastm rte am lrMtoenpnsseoepopvatoy tsu"

    const-string/jumbo v0, "system Mediaplayer cannot support video postprocess frame out"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$p;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$p;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPCaptureParams;Lcom/tencent/thumbplayer/api/TPCaptureCallBack;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/api/TPCaptureParams;Lcom/tencent/thumbplayer/api/TPCaptureCallBack;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPOptionalParam;)V
    .locals 10

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    const/16 v1, 0x64

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-ne v0, v1, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    iget-wide v0, v0, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    long-to-int v0, v0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-string/jumbo v2, "tttinb:iqoaorps"

    const-string/jumbo v2, "sirtnbtp:itsooa"

    const/4 v9, 0x7

    const-string/jumbo v2, "t:sattpos iinso"

    const-string/jumbo v2, "start position:"

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v1, v2}, Lcom/tencent/thumbplayer/e/a;->b(Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-ge v1, v2, :cond_1

    const/4 v9, 0x6

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    check-cast v2, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-interface {v2}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getStartPositionMs()J

    move-result-wide v2

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    int-to-long v4, v0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    cmp-long v2, v2, v4

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-gtz v2, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    check-cast v2, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v9, 0x6

    invoke-interface {v2}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getStartPositionMs()J

    move-result-wide v2

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    iget-object v6, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-interface {v6, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    check-cast v6, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v9, 0x1

    invoke-interface {v6}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getOriginalDurationMs()J

    move-result-wide v6

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    add-long/2addr v2, v6

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    cmp-long v2, v4, v2

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-gtz v2, :cond_0

    const/4 v8, 0x3

    or-int/2addr v9, v8

    iput v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->l:I

    const/4 v9, 0x5

    const/4 v8, 0x5

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v9, 0x3

    const/4 v8, 0x4

    iget-object v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-interface {v3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x2

    const/4 v8, 0x2

    check-cast v3, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v9, 0x0

    invoke-interface {v3}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getFilePath()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {v2, v3}, Lcom/tencent/thumbplayer/adapter/c;->b(Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget-object v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-interface {v3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    check-cast v3, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-interface {v3}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getStartPositionMs()J

    move-result-wide v6

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    sub-long/2addr v4, v6

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    iput-wide v4, v2, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    :cond_0
    const/4 v9, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    goto/16 :goto_0

    :cond_1
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-eqz v0, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/api/TPOptionalParam;)V

    :cond_2
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v9, 0x4

    const/4 v8, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Lcom/tencent/thumbplayer/api/TPOptionalParam;)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/d;->b(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)Ljava/util/List;

    move-result-object p1

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->l:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    check-cast p1, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getFilePath()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->b(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v0, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->a(Ljava/lang/Exception;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string/jumbo v0, "lo mp ypcsaetne aesreiwat  !  ctmertchlpesudxensiu"

    const-string/jumbo v0, "p ans uxpteyohmidynsc ercptus a ceew aeeetst ril!l"

    const/4 v3, 0x0

    const-string/jumbo v0, "exception when system clip player set data source!"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;IJ)V
    .locals 4
    .param p2    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSwitchDefMode;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/d;->b(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)Ljava/util/List;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/utils/b;->a(Ljava/util/Collection;)Z

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez p2, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->n()J

    move-result-wide v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 p1, 0x1

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-boolean p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->n:Z

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->o:Ljava/util/LinkedList;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/tencent/thumbplayer/utils/b;->a(Ljava/util/Collection;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz p1, :cond_0

    const/4 v3, 0x6

    new-instance p1, Ljava/util/LinkedList;

    const/4 v3, 0x2

    const/4 v2, 0x2

    invoke-direct {p1}, Ljava/util/LinkedList;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->o:Ljava/util/LinkedList;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->o:Ljava/util/LinkedList;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Ljava/util/LinkedList;->offer(Ljava/lang/Object;)Z

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string p3, "aocuowtlpnetp p  :sydtiittny yihinsspcheirtw ct l,lceoNorrif  e r"

    const-string/jumbo p3, "slao ndp riil   otpcN,tpsucyw ehicrwyiri shrytlftnteeti  tnpe:coi"

    const/4 v3, 0x4

    const-string/jumbo p3, "try to switch definition with system clip player, current clipNo:"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget p3, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->l:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    long-to-int p1, v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/d;->d(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x6

    move v3, v2

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v2, 0x0

    const/4 v2, 0x6

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->a(Ljava/lang/Exception;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo p2, "nisiebmiw w eyo fpnpphttxlsir i indteccnoelqtacs!ehe"

    const-string p2, "  dyaoi qrcxtiemhep eitinnteciepwh lynpsin!feltoswcs"

    const/4 v3, 0x4

    const-string p2, "cwcedeuah  imeileoo ppnwfhx stitiyspntleirntyce  !ni"

    const-string/jumbo p2, "exception when system clip player switch definition!"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw p1

    :cond_1
    const/4 v2, 0x7

    move v3, v2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string/jumbo p2, "seiein pcspitispxto!onoArhaecphstiDt dtth iwywc iuewcemieens  l e f"

    const-string/jumbo p2, "exswsuoemtidahtc tpfs ew Aholenyptie!tnicwiisn   inechc prii steoDe"

    const/4 v3, 0x4

    const-string/jumbo p2, "simwtte qpectuln Dsnedoieawisspyw toi ni  chnehepr !ehif toecxmicti"

    const-string/jumbo p2, "exception when switch Definition with clip mediaAsset empty source!"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/e/b;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x4

    new-instance v1, Lcom/tencent/thumbplayer/e/b;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v2, "tTsPeylprsmiPyClSm"

    const-string v2, "TeSmPCrlpPsymtiayl"

    const/4 v4, 0x3

    const-string/jumbo v2, "eyymtPrPCpTiaelsmS"

    const-string v2, "TPSystemClipPlayer"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v1, p1, v2}, Lcom/tencent/thumbplayer/e/b;-><init>(Lcom/tencent/thumbplayer/e/b;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->a(Lcom/tencent/thumbplayer/e/b;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz p1, :cond_0

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/e/a;->a()Lcom/tencent/thumbplayer/e/b;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/e/b;->a()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public a(Ljava/lang/String;IJ)V
    .locals 2
    .param p2    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSwitchDefMode;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p1, p2}, Lcom/tencent/thumbplayer/adapter/c;->a(Ljava/lang/String;Ljava/util/Map;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p2, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;IJ)V
    .locals 2
    .param p3    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSwitchDefMode;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;IJ)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    const-string/jumbo p2, "u ptooa.ldspuoirtbdSeeSdonoructt"

    const-string p2, "Searopptdo tbdtdco. ounuesutSirl"

    const/4 v1, 0x4

    const-string p2, "edt ebeupddunt.roplacsourtb StSo"

    const-string p2, "addSubtitleSource not supported."

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/List;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/TPOptionalParam;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    const-string/jumbo p2, "ooeicTupdadpruorue bd .kaotcnrAtuS"

    const-string/jumbo p2, "nor abudpeddou et.ooraAturcdSkTpic"

    const/4 v1, 0x1

    const-string p2, "addAudioTrackSource not supported."

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public a(Z)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x3

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Z)V

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method public a(ZJJ)V
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v8, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    const/4 v1, 0x3

    const/4 v9, 0x2

    const/4 v8, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-nez v0, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    return-void

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-eqz v1, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    move v2, p1

    move v2, p1

    move v2, p1

    move v2, p1

    move-wide v3, p2

    move-wide v5, p4

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-interface/range {v1 .. v6}, Lcom/tencent/thumbplayer/adapter/a/b;->a(ZJJ)V

    :cond_1
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    move v3, p1

    move v3, p1

    const/4 v9, 0x4

    move v3, p1

    move v3, p1

    move-wide v4, p2

    move-wide v6, p4

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual/range {v2 .. v7}, Lcom/tencent/thumbplayer/adapter/c;->a(ZJJ)V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    return-void
.end method

.method public b(I)J
    .locals 4

    const/4 v2, 0x2

    move v3, v2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->b(I)J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-wide v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x7

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x5

    return-wide v0
.end method

.method public b(F)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v2, 0x2

    move v3, v2

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->b(F)V

    :cond_1
    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->b(F)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method public b(IJ)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v0, 0x1

    const/4 v0, 0x5

    const-string/jumbo p2, "spee plpotrd eruuoncTtdacsk."

    const-string/jumbo p2, "euodceusesokeltrTnpc d.rta p"

    const/4 v1, 0x3

    const-string/jumbo p2, "t .ksdceqrpleortnod eteTsucp"

    const-string p2, "deselectTrack not supported."

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public b(Z)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x3

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->b(Z)V

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->b(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method public c(Z)Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p1
.end method

.method public c(I)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->c(I)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p1

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x2

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p1
.end method

.method public c(IJ)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    const-string/jumbo p2, "tpssuroe.emetns rptodlc apor"

    const-string p2, " s.edPoptcunaproosettpemr lr"

    const/4 v1, 0x6

    const-string/jumbo p2, "oglmrspP oaoeeeudnpm t.tcrrs"

    const-string/jumbo p2, "selectProgram not supported."

    const/4 v1, 0x3

    const/4 v0, 0x7

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    return-void
.end method

.method public f()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->f()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_2

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->e()Lcom/tencent/thumbplayer/adapter/a/b;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x3

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->f()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string v1, "e llorrrqrae,ie eadopfter  y"

    const-string/jumbo v1, "rfrt ee q aalidpeer,yalerro "

    const/4 v3, 0x6

    const-string/jumbo v1, "teae b ridar aol yfcerep,elr"

    const-string v1, "error , create player failed"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    throw v0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance v0, Ljava/io/IOException;

    const/4 v3, 0x4

    const-string v1, "a rsdeuaorpauls, pae crido ,inv r ete"

    const-string v1, " ,s reors  aed ocuetar aa,dlevriinprp"

    const/4 v3, 0x2

    const-string v1, "cea,aerpe e nuaa svpd,rt riiprdolr  o"

    const-string v1, "error , prepare , data source invalid"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    throw v0
.end method

.method public g()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->f()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/d;->e()Lcom/tencent/thumbplayer/adapter/a/b;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x3

    or-int/2addr v3, v2

    const/4 v1, 0x3

    move v3, v1

    const/4 v2, 0x4

    or-int/2addr v3, v2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->g()V

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v1, "aleare,eqpeyo trmrd fiacl  r"

    const-string/jumbo v1, "r emifraellr,are tcrp  eydao"

    const/4 v3, 0x5

    const-string v1, "e,seerer  llfcetaarpri ydaor"

    const-string v1, "error , create player failed"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    throw v0

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string v1, "eismretrl aiveiaau,r oridp don   eon,t ,als aapecr rv"

    const-string v1, "dtaronr r otpepaisrecrd,raiaes de e uvavan  ,l,loi i "

    const/4 v3, 0x7

    const-string v1, "error , prepare , state invalid , data source invalid"

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    throw v0
.end method

.method public h()V
    .locals 4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x5

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->h()V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    return-void

    :catch_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string v1, "aa,tooirn,lbretrva s es dirt"

    const-string/jumbo v1, "vnrrlbtases  rira,tt,  adoei"

    const/4 v3, 0x1

    const-string/jumbo v1, "rtr  brnie,talsaovda,ittse r"

    const-string v1, "error , start ,state invalid"

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    throw v0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v1, ",ytue uup lnrsr ra  itr,lorsel"

    const-string/jumbo v1, "ls teeu  lr,r,ryp orausn itr l"

    const/4 v3, 0x3

    const-string v1, " aleor,p rl nsuaierts rpl r y,"

    const-string v1, "error , start , player is null"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    throw v0
.end method

.method public i()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x6

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->i()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    return-void

    :catch_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string/jumbo v1, "pladtv iqsurr,poe ai, a tere"

    const-string/jumbo v1, "li,rdotpvaree a,stp easr  iu"

    const/4 v3, 0x3

    const-string/jumbo v1, "irstea,,esdvai  relo nrtupas"

    const-string v1, "error , pause ,state invalid"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    throw v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string/jumbo v1, "qrlmrepn olp ,a ir, elsr ea sy"

    const-string v1, "  ,olrr qprrye p nuls,eaelsia "

    const/4 v3, 0x2

    const-string v1, ",losolrsrrap,el  ye  r ae unui"

    const-string v1, "error , pause , player is null"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    throw v0
.end method

.method public j()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v1, 0x7

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x1

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/16 v0, 0x9

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/16 v2, 0x8

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-interface {v1}, Lcom/tencent/thumbplayer/adapter/a/b;->j()V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void

    :catchall_0
    move-exception v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :catch_0
    :try_start_1
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string/jumbo v2, "pt e bairnviarest ar,o,l ues"

    const-string v2, "a s aopirrl,esrvaesti,n eu t"

    const-string/jumbo v2, "i,  nau rt,rvtu rsalspdieaoe"

    const-string v2, "error , pause ,state invalid"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    throw v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v2, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    throw v1

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v1, "prsoraep  ,ml,   intelyru srp"

    const-string/jumbo v1, "reem  l rpusl,a , ptonry sril"

    const/4 v4, 0x1

    const-string/jumbo v1, "olr e y qtu srp i pln,sareorl"

    const-string v1, "error , stop , player is null"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    throw v0
.end method

.method public k()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x4

    move v4, v3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v2, "tts:r,stnseute  errco"

    const-string v2, " et,octrreesren:ts ut"

    const/4 v4, 0x6

    const-string v2, "aeemret tre:srntcsu t"

    const-string/jumbo v2, "reset, current state:"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    and-int/2addr v4, v3

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->k()V

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->a()V

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/g;->d()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v4, 0x2

    return-void
.end method

.method public l()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const-string/jumbo v2, "utcso esneaee :atberrrt"

    const-string/jumbo v2, "lnec:b seta eeutsetarrr"

    const/4 v4, 0x5

    const-string/jumbo v2, "release, current state:"

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->l()V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->h:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->a()V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->f:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/g;->d()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/16 v1, 0xb

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void
.end method

.method public m()J
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v6, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz v3, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    check-cast v3, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-interface {v3}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getOriginalDurationMs()J

    move-result-wide v3

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    add-long/2addr v1, v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    return-wide v1
.end method

.method public n()J
    .locals 7

    const/4 v6, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v6, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v6, 0x7

    const/4 v2, 0x0

    const/4 v6, 0x5

    move v5, v2

    move v5, v2

    :goto_0
    const/4 v6, 0x2

    iget-object v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v6, 0x6

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-ge v2, v3, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->l:I

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-ge v2, v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->k:Ljava/util/List;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    check-cast v3, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-interface {v3}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getOriginalDurationMs()J

    move-result-wide v3

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    add-long/2addr v0, v3

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v6, 0x6

    const/16 v3, 0xc

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v2, v3}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-nez v2, :cond_1

    const/4 v6, 0x0

    return-wide v0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-interface {v2}, Lcom/tencent/thumbplayer/adapter/a/b;->n()J

    move-result-wide v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    add-long/2addr v0, v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    return-wide v0
.end method

.method public o()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v1, 0xf

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->j:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->k()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-wide v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-wide v0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->o()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-wide v0
.end method

.method public p()I
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->j:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 v1, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-nez v0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    return v1

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->a()J

    move-result-wide v2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x4

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    cmp-long v0, v2, v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-lez v0, :cond_1

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->j:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->a()J

    move-result-wide v0

    const/4 v7, 0x0

    const/4 v6, 0x5

    long-to-int v0, v0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    return v0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/16 v2, 0xd

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v0, v2}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-nez v0, :cond_2

    const/4 v6, 0x0

    move v7, v6

    return v1

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->j:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-interface {v1}, Lcom/tencent/thumbplayer/adapter/a/b;->p()I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    int-to-long v1, v1

    const/4 v7, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/adapter/b;->a(J)V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    goto :goto_0
.end method

.method public q()I
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->j:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/4 v1, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-nez v0, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    return v1

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->b()J

    move-result-wide v2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x2

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    cmp-long v0, v2, v4

    const/4 v6, 0x6

    xor-int/2addr v7, v6

    if-lez v0, :cond_1

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->j:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->b()J

    move-result-wide v0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    long-to-int v0, v0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    return v0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->i:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v6, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/16 v2, 0xd

    const/4 v7, 0x3

    invoke-virtual {v0, v2}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-nez v0, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    return v1

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->j:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-interface {v1}, Lcom/tencent/thumbplayer/adapter/a/b;->q()I

    move-result v1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    int-to-long v1, v1

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/adapter/b;->b(J)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    goto :goto_0
.end method

.method public r()[Lcom/tencent/thumbplayer/api/TPTrackInfo;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v1, ".nfgtbdtrInrotou Tpekopa se"

    const-string v1, "drenprutatt  ougkpoone.ITsf"

    const/4 v3, 0x5

    const-string v1, " npotou.at dekcgtfusrpnIroT"

    const-string/jumbo v1, "getTrackInfo not supported."

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-array v0, v0, [Lcom/tencent/thumbplayer/api/TPTrackInfo;

    return-object v0
.end method

.method public s()[Lcom/tencent/thumbplayer/api/TPProgramInfo;
    .locals 4

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/d;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x1

    const-string v1, " fenpogpapdeootrsIgt rPpmu.nt"

    const-string/jumbo v1, "guafsmgpro ornedpIPeptt.o otn"

    const/4 v3, 0x6

    const-string v1, "dternnpeq rr oguapgo.fIsooPtm"

    const-string/jumbo v1, "getProgramInfo not supported."

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-array v0, v0, [Lcom/tencent/thumbplayer/api/TPProgramInfo;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0
.end method

.method public t()J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-wide v0
.end method

.method public u()Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method
