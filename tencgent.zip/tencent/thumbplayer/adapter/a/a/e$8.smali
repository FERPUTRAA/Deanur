.class Lcom/tencent/thumbplayer/adapter/a/a/e$8;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/media/MediaPlayer$OnTimedTextListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/adapter/a/a/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/adapter/a/a/e;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/adapter/a/a/e;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$8;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onTimedText(Landroid/media/MediaPlayer;Landroid/media/TimedText;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@rs~b@ @.@a~@K@ ~o @ M~b4f~@~@i/1~ @ ~ b~o@@l~o~no /-  t@fd~l@ @uso@~m~~yoiS@t~~@ c~i  ~v ~~ @ @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$8;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/a/e;->a(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$l;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz p1, :cond_1

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance p1, Lcom/tencent/thumbplayer/api/TPSubtitleData;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPSubtitleData;-><init>()V

    const/4 v3, 0x2

    if-eqz p2, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p2}, Landroid/media/TimedText;->getText()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string p2, ""

    const-string p2, ""

    const/4 v3, 0x0

    const-string p2, ""

    const-string p2, ""

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object p2, p1, Lcom/tencent/thumbplayer/api/TPSubtitleData;->subtitleData:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$8;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p2}, Lcom/tencent/thumbplayer/adapter/a/a/e;->B(Lcom/tencent/thumbplayer/adapter/a/a/e;)I

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    int-to-long v0, p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-wide v0, p1, Lcom/tencent/thumbplayer/api/TPSubtitleData;->trackIndex:J

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$8;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v3, 0x7

    const/4 v2, 0x6

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/adapter/a/a/e;->n()J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-wide v0, p1, Lcom/tencent/thumbplayer/api/TPSubtitleData;->startPositionMs:J

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$8;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p2}, Lcom/tencent/thumbplayer/adapter/a/a/e;->a(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$l;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {p2, p1}, Lcom/tencent/thumbplayer/adapter/a/c$l;->a(Lcom/tencent/thumbplayer/api/TPSubtitleData;)V

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method
