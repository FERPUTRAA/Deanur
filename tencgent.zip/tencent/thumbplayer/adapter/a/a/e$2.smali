.class Lcom/tencent/thumbplayer/adapter/a/a/e$2;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/adapter/a/a/a$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/adapter/a/a/e;-><init>(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/adapter/a/a/e;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/adapter/a/a/e;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$2;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "c@si@~ys ~ ~~dou o4 M ~K@o @-S@@ ~o b~~t~l/f@i@~@o@~tb. ~~ v1n~@i@~@~b@@@@~l  ~~fo~/@ @  ~ a@rm "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$2;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->e(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->f:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eq v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$2;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->e(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->e:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eq v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-wide/16 v0, -0x1

    const/4 v3, 0x2

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-wide v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$2;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->n()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-wide v0
.end method
