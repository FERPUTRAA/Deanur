.class Lcom/tencent/thumbplayer/adapter/a/a/c$1;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/subtitle/ITPSubtitleParserCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/adapter/a/a/c;->a(Ljava/lang/String;Ljava/util/Map;J)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:Lcom/tencent/thumbplayer/adapter/a/a/c;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/adapter/a/a/c;J)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->b:Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-wide p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->a:J

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onGetCurrentPlayPositionMs()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "aos@ /oyr ~~~b~f.Kvibl~~m@nt s~o/ ~@i ~@@@~ ~@t@  S ~ i d~@o~@ @  @u~~~o~@@ f~~ @ @-ocM@l@~@1b4@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->b:Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/c;->c(Lcom/tencent/thumbplayer/adapter/a/a/c;)Lcom/tencent/thumbplayer/adapter/a/a/a$d;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->b:Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/c;->c(Lcom/tencent/thumbplayer/adapter/a/a/c;)Lcom/tencent/thumbplayer/adapter/a/a/a$d;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/a/a$d;->a()J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-wide v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-wide v0
.end method

.method public onLoadResult(I)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo v0, "sesmixo:tlRdndaoe,uL"

    const-string v0, "LxsedtuoiRn:od,aseln"

    const/4 v3, 0x7

    const-string/jumbo v0, "uLaioetxes,Rn:dloo n"

    const-string/jumbo v0, "onLoadResult, index:"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string/jumbo v0, "lTystbPEyPumtSbertSainxelal"

    const-string/jumbo v0, "naPmyresbrtaTSxStyellPuElit"

    const/4 v3, 0x4

    const-string/jumbo v0, "tSteelusuairyntrylTEPxbaelS"

    const-string v0, "TPSysPlayerExternalSubtitle"

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->b:Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-wide v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->a:J

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p1, v0, v1}, Lcom/tencent/thumbplayer/adapter/a/a/c;->a(Lcom/tencent/thumbplayer/adapter/a/a/c;J)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public onSelectResult(IJ)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const-string v1, " cetenup,eCerdtleSloosoR"

    const-string v1, "ele:onteerutSoso Rl,ecdC"

    const/4 v3, 0x0

    const-string/jumbo v1, "untorl:eq,eseelSrCoRcetd"

    const-string/jumbo v1, "onSelectResult, errCode:"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string v1, "bessaOcu:tp,qee"

    const-string v1, "au,qpbe :sOeect"

    const/4 v3, 0x5

    const-string/jumbo v1, "q ,maeu:eplcets"

    const-string v1, ", selectOpaque:"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string p2, "ep ,ooauq="

    const-string p2, ", opaque ="

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-wide p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->a:J

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string p3, "EtSyPbesuSrteaelxlnbirlPuty"

    const-string/jumbo p3, "tbiEaPulaselSertnuPSytexyrl"

    const/4 v3, 0x6

    const-string p3, "TPSysPlayerExternalSubtitle"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p3, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->b:Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p2}, Lcom/tencent/thumbplayer/adapter/a/a/c;->a(Lcom/tencent/thumbplayer/adapter/a/a/c;)Lcom/tencent/thumbplayer/adapter/a/a/a$c;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz p2, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->b:Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/a/c;->a(Lcom/tencent/thumbplayer/adapter/a/a/c;)Lcom/tencent/thumbplayer/adapter/a/a/a$c;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-wide p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->a:J

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {p1, p2, p3}, Lcom/tencent/thumbplayer/adapter/a/a/a$c;->a(J)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->b:Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p2}, Lcom/tencent/thumbplayer/adapter/a/a/c;->a(Lcom/tencent/thumbplayer/adapter/a/a/c;)Lcom/tencent/thumbplayer/adapter/a/a/a$c;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz p2, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->b:Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p2}, Lcom/tencent/thumbplayer/adapter/a/a/c;->a(Lcom/tencent/thumbplayer/adapter/a/a/c;)Lcom/tencent/thumbplayer/adapter/a/a/a$c;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->a:J

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {p2, p1, v0, v1}, Lcom/tencent/thumbplayer/adapter/a/a/a$c;->a(IJ)V

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method public onSubtitleError(II)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const-string/jumbo v1, "nS,irtureptoxuidoEbrne:"

    const-string/jumbo v1, "uontxrnp,rl:eoitiedSbrE"

    const/4 v3, 0x5

    const-string/jumbo v1, "rnrutoepd,in:elbrtoi Ex"

    const-string/jumbo v1, "onSubtitleError, index:"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const-string v1, "C:ereorrqd, "

    const/4 v3, 0x1

    const-string v1, "der erroqC:,"

    const-string v1, ", errorCode:"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const-string v1, "EtsreTaySxtyntllSsebserPilu"

    const-string/jumbo v1, "iusrrtanealyPTstyltebSlxEeS"

    const/4 v3, 0x5

    const-string v1, "elbmSsaTrPSaytxiulenrEyetlt"

    const-string v1, "TPSysPlayerExternalSubtitle"

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->b:Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/c;->b(Lcom/tencent/thumbplayer/adapter/a/a/c;)Lcom/tencent/thumbplayer/adapter/a/a/a$b;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/adapter/a/a/a$b;->a(II)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method

.method public onSubtitleFrame(Lcom/tencent/thumbplayer/core/common/TPSubtitleFrame;)V
    .locals 4

    const/4 v3, 0x0

    const-string/jumbo v0, "rasroumltStTnyxeeltPPSbEeay"

    const-string/jumbo v0, "ulamSeertlTtPneaySiysbtEPxr"

    const/4 v3, 0x7

    const-string/jumbo v0, "tSentbubyEyraiSrsllTetelxPP"

    const-string v0, "TPSysPlayerExternalSubtitle"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v1, "irnlFtuSoabmeto"

    const-string v1, "SnttobiemFoular"

    const/4 v3, 0x6

    const-string/jumbo v1, "nilFeSrpumbaoet"

    const-string/jumbo v1, "onSubtitleFrame"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->b:Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/c;->d(Lcom/tencent/thumbplayer/adapter/a/a/c;)Lcom/tencent/thumbplayer/adapter/a/a/a$a;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->b:Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/c;->d(Lcom/tencent/thumbplayer/adapter/a/a/c;)Lcom/tencent/thumbplayer/adapter/a/a/a$a;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/a$a;->a(Lcom/tencent/thumbplayer/core/common/TPSubtitleFrame;)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method public onSubtitleNote(Ljava/lang/String;)V
    .locals 4

    const/4 v2, 0x3

    move v3, v2

    const-string/jumbo v0, "xaybelesqltaSePlrPTibStnEyr"

    const-string/jumbo v0, "tuESTbPaeSlPleylnrrxyaibets"

    const/4 v3, 0x0

    const-string/jumbo v0, "nSseyiSrlEtttyuralexPaesTbP"

    const-string v0, "TPSysPlayerExternalSubtitle"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo v1, "obumnettluSeoN"

    const-string/jumbo v1, "onbttNuSteluoe"

    const/4 v3, 0x6

    const-string/jumbo v1, "teinoSolNttobu"

    const-string/jumbo v1, "onSubtitleNote"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->b:Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/c;->d(Lcom/tencent/thumbplayer/adapter/a/a/c;)Lcom/tencent/thumbplayer/adapter/a/a/a$a;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c$1;->b:Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/c;->d(Lcom/tencent/thumbplayer/adapter/a/a/c;)Lcom/tencent/thumbplayer/adapter/a/a/a$a;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/a$a;->a(Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method
