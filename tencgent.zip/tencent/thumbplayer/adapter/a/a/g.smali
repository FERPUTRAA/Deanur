.class public final synthetic Lcom/tencent/thumbplayer/adapter/a/a/g;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/media/MediaPlayer;JI)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~si oi@~  ~@M ft~~~ @@-S b@in /~a f@~@t @@@ro ~lo~m/@d ~c~~~~ o~su@l@@1o~ ~@.@b@~~ ~ v4 @@o@byK"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2, p3}, Landroid/media/MediaPlayer;->seekTo(JI)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method
