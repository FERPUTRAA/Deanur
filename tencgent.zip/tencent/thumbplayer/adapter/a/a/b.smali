.class public Lcom/tencent/thumbplayer/adapter/a/a/b;
.super Landroid/media/MediaPlayer;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    invoke-direct {p0}, Landroid/media/MediaPlayer;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method protected finalize()V
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~s~ol@ @@-4d~@~tf ~ @@l@Kbu .o/ ~o@~io @@@@@~s@~ vf~m nM@      1~c~@@oi~ oy~~b~/bS~~~  @@~~tra@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    invoke-super {p0}, Landroid/media/MediaPlayer;->finalize()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void

    :catch_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string v1, "]bTmPvMrrlPPi.uejlyaahaeamdTsea[y"

    const-string/jumbo v1, "lasPjmyTaMhidea[ruyerevlT.Paa]PbT"

    const/4 v3, 0x0

    const-string/jumbo v1, "vyjioaTaPae.TPTuMmP]yad[rlleebahP"

    const-string v1, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method

.method public getCurrentPosition()I
    .locals 4

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-super {p0}, Landroid/media/MediaPlayer;->getCurrentPosition()I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    return v0

    :catch_0
    move-exception v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v1, "iah]PbudmajaPlbeme.lTP[rMavrPTaey"

    const-string/jumbo v1, "vaTmrhdP[malPaTyiaa.]MlyPePerjube"

    const/4 v3, 0x0

    const-string/jumbo v1, "jvPiTTuuyyaarTbe][eaPMPlamPhdral."

    const-string v1, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return v0
.end method

.method public getDuration()I
    .locals 4

    :try_start_0
    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-super {p0}, Landroid/media/MediaPlayer;->getDuration()I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    return v0

    :catch_0
    move-exception v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string v1, "aahTPivpl]rrjPTTodeaaMalyemPey.[P"

    const-string v1, "eibToPerarm[lyTj.aPleMPPadya]hvaT"

    const-string v1, "eParulaPqhTavy[TbremPiaPMTae]djyl"

    const-string v1, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    return v0
.end method

.method public getSelectedTrack(I)I
    .locals 3

    :try_start_0
    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroid/media/MediaPlayer;->getSelectedTrack(I)I

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return p1

    :catch_0
    move-exception p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string v0, "ebsPMuaPlyeeTrhavad]jP[Tr.aTilbPy"

    const-string/jumbo v0, "ydailbhPeraeTu]TjbMePyT[aravalPP."

    const/4 v2, 0x0

    const-string v0, "TPamrah.[MPay]jlbTTlyaPdivPrmaeee"

    const-string v0, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return p1
.end method

.method public getTrackInfo()[Landroid/media/MediaPlayer$TrackInfo;
    .locals 4

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-super {p0}, Landroid/media/MediaPlayer;->getTrackInfo()[Landroid/media/MediaPlayer$TrackInfo;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object v0

    :catch_0
    move-exception v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo v1, "hT]joaPeulamPvPiyrMTyauearlbPTea."

    const-string/jumbo v1, "uedT.PuvaMyalPairlbmPyTPeh]eaTarj"

    const/4 v3, 0x1

    const-string v1, "PeyyPbbPh]avPTlrriuajTa.Md[aemTea"

    const-string v1, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v0, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-array v0, v0, [Landroid/media/MediaPlayer$TrackInfo;

    const/4 v3, 0x0

    return-object v0
.end method

.method public getVideoHeight()I
    .locals 4

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-super {p0}, Landroid/media/MediaPlayer;->getVideoHeight()I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const-string v1, "]yeTliuuyaMldaPPbaaa.mTePrThPr[jv"

    const-string v1, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    return v0
.end method

.method public getVideoWidth()I
    .locals 4

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-super {p0}, Landroid/media/MediaPlayer;->getVideoWidth()I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v1, "p[brPPepueTjPhedarTai].lPyaaMyTla"

    const-string/jumbo v1, "laej.lypTehTPPbmaieaM[dTr]rauPPay"

    const/4 v3, 0x4

    const-string v1, "al.Piv][qeTdjarThrMPayaPPTebmuyea"

    const-string v1, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    const/4 v0, 0x0

    move v3, v0

    :goto_0
    const/4 v2, 0x7

    const/4 v3, 0x5

    return v0
.end method

.method public prepare()V
    .locals 4

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    invoke-super {p0}, Landroid/media/MediaPlayer;->prepare()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void

    :catch_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v1, "aaaj.lTTqePPaeyTrybmPv]idearhPul["

    const/4 v3, 0x2

    const-string v1, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method public release()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x4

    const-string v0, "PjseT[umasPTrP.eiealTbd]hMlyaaPyv"

    const-string v0, ".PsPhPe]iumdPveae[alayTylTMajTrba"

    const-string/jumbo v0, "harmydPM[PuejTiemrealaPTa.]TaPblv"

    const-string v0, "TPThumbPlayer[TPMediaPlayer.java]"

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string v1, "WN1"

    const-string v1, "NW1"

    const/4 v5, 0x0

    const-string v1, "WN1"

    const-string v1, "N1W"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string v1, "099mo"

    const-string v1, "099mX"

    const/4 v5, 0x7

    const-string v1, "bT90X"

    const-string v1, "X909T"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-nez v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v1, "X909"

    const-string v1, "990X"

    const/4 v5, 0x1

    const-string v1, "099X"

    const-string v1, "X909"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string v1, "1TN"

    const-string v1, "TN1"

    const/4 v5, 0x5

    const-string v1, "1NT"

    const-string v1, "N1T"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v1, :cond_1

    :cond_0
    const/4 v4, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-super {p0, v1}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-super {p0, v1}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-super {p0, v1}, Landroid/media/MediaPlayer;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-super {p0, v1}, Landroid/media/MediaPlayer;->setOnInfoListener(Landroid/media/MediaPlayer$OnInfoListener;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-super {p0, v1}, Landroid/media/MediaPlayer;->setOnBufferingUpdateListener(Landroid/media/MediaPlayer$OnBufferingUpdateListener;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-super {p0, v1}, Landroid/media/MediaPlayer;->setOnSeekCompleteListener(Landroid/media/MediaPlayer$OnSeekCompleteListener;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-super {p0, v1}, Landroid/media/MediaPlayer;->setOnVideoSizeChangedListener(Landroid/media/MediaPlayer$OnVideoSizeChangedListener;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-super {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string/jumbo v3, "odrdp2ueAmaH"

    const-string v3, "AHproda2dmen"

    const/4 v5, 0x0

    const-string v3, "drdAe2aplnHm"

    const-string/jumbo v3, "mA2dpHandler"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v2, p0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    check-cast v2, Landroid/os/Handler;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v2, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_1

    :catch_0
    move-exception v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto :goto_0

    :catch_1
    move-exception v1

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    :goto_1
    :try_start_1
    const/4 v4, 0x6

    move v5, v4

    invoke-super {p0}, Landroid/media/MediaPlayer;->release()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-void

    :catch_2
    move-exception v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x2

    or-int/2addr v5, v4

    return-void
.end method

.method public reset()V
    .locals 4

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-super {p0}, Landroid/media/MediaPlayer;->reset()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void

    :catch_0
    move-exception v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo v1, "vaP.yMdPqaTirTrTlePbu[la]aaeeyhmP"

    const-string v1, "]eaeTbmaMhPyaTe[rliduTbPvPaayr.lP"

    const/4 v3, 0x2

    const-string v1, "aTsvaea.yTmjulaPdMahlbePy[erPiPT]"

    const-string v1, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    return-void
.end method

.method public setDataSource(Landroid/content/Context;Landroid/net/Uri;)V
    .locals 2

    :try_start_0
    const/4 v1, 0x2

    invoke-super {p0, p1, p2}, Landroid/media/MediaPlayer;->setDataSource(Landroid/content/Context;Landroid/net/Uri;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void

    :catch_0
    move-exception p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    const-string/jumbo p2, "ibTrmauPa[lyadujrel.ehPyvTTP]eaMP"

    const/4 v1, 0x2

    const-string p2, "PiMmaeyPdlmv]hT[.lPaTjaTyrPbeaear"

    const-string p2, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v1, 0x3

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public setDataSource(Landroid/content/Context;Landroid/net/Uri;Ljava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/net/Uri;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    :try_start_0
    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-super {p0, p1, p2, p3}, Landroid/media/MediaPlayer;->setDataSource(Landroid/content/Context;Landroid/net/Uri;Ljava/util/Map;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void

    :catch_0
    move-exception p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    const-string/jumbo p2, "vjTPodMr]aPTualaehyPTr.eaamylPi[e"

    const-string p2, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method

.method public setDataSource(Ljava/io/FileDescriptor;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-super {p0, p1}, Landroid/media/MediaPlayer;->setDataSource(Ljava/io/FileDescriptor;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void

    :catch_0
    move-exception p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string v0, "Pda.abb]p[ljyyPahmPlerTarvTuiPTMe"

    const-string/jumbo v0, "vmiTdeTpPlayaaTPuj.lebrMh]PaPy[er"

    const/4 v2, 0x6

    const-string v0, "abily]uhPreePduajamPMa[rvTl.aPeyT"

    const-string v0, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public setDisplay(Landroid/view/SurfaceHolder;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-super {p0, p1}, Landroid/media/MediaPlayer;->setDisplay(Landroid/view/SurfaceHolder;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void

    :catch_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string v0, "PlPadrylqMybeaT.jTvTeheui]aPm[raa"

    const/4 v2, 0x3

    const-string v0, "[bayeulpaPyPihdjerPl]TaTmvaMTe.ar"

    const-string v0, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public setLooping(Z)V
    .locals 3

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-super {p0, p1}, Landroid/media/MediaPlayer;->setLooping(Z)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void

    :catch_0
    move-exception p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string v0, "]aarjsreqhlTeyPPelmPbMaT[aTv.adyu"

    const-string v0, "b.sM[TePreldTejhrmvluTy]aPaPaPaya"

    const-string v0, "aesyeia]PTbvTamhPearlPlTyMr.Pdjau"

    const-string v0, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public setPlaybackParams(Landroid/media/PlaybackParams;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-super {p0, p1}, Landroid/media/MediaPlayer;->setPlaybackParams(Landroid/media/PlaybackParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void

    :catch_0
    move-exception p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string v0, "drhmTeyPaubPilPeaM.aTTrmjavlP[my]"

    const-string v0, "ayTmmTPP[lyeaPTidrMl]ahj.arPavube"

    const/4 v2, 0x4

    const-string v0, "T[haoyeaalPuer]MrT.TmejbyPvPilaad"

    const-string v0, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v2, 0x3

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public setSurface(Landroid/view/Surface;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-super {p0, p1}, Landroid/media/MediaPlayer;->setSurface(Landroid/view/Surface;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void

    :catch_0
    move-exception p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string v0, "eeiaov]aMaPjhuad.rleTTrPyPPbaylT["

    const/4 v2, 0x7

    const-string v0, "PTPPmbhaTyMPl[ereaaalyjaubT.rv]de"

    const-string v0, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public setVolume(FF)V
    .locals 2

    :try_start_0
    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-super {p0, p1, p2}, Landroid/media/MediaPlayer;->setVolume(FF)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void

    :catch_0
    move-exception p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    const-string p2, "e.a[TbmPlerylbdiPv]aajayhrPaePuMT"

    const/4 v1, 0x3

    const-string p2, "ayTTjauTa]v[Pd.bPiPmhrrealeuPeylM"

    const-string p2, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public stop()V
    .locals 4

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-super {p0}, Landroid/media/MediaPlayer;->stop()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    return-void

    :catch_0
    move-exception v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo v1, "hPeareuTPl.bl[aPuryajyvMmdieTTPa]"

    const/4 v3, 0x4

    const-string v1, "T[eaar.pePlPadhlTaTju]vraMimyybPP"

    const-string v1, "TPThumbPlayer[TPMediaPlayer.java]"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    and-int/2addr v3, v2

    return-void
.end method
