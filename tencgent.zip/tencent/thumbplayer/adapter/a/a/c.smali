.class public Lcom/tencent/thumbplayer/adapter/a/a/c;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/adapter/a/a/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/adapter/a/a/c$a;
    }
.end annotation


# instance fields
.field a:I

.field b:Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;

.field private c:Lcom/tencent/thumbplayer/adapter/a/a/a$a;

.field private d:Lcom/tencent/thumbplayer/adapter/a/a/a$d;

.field private e:Lcom/tencent/thumbplayer/adapter/a/a/a$c;

.field private f:Lcom/tencent/thumbplayer/adapter/a/a/a$b;

.field private g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

.field private h:Ljava/lang/String;

.field private i:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "*>;"
        }
    .end annotation
.end field

.field private final j:Ljava/lang/Object;

.field private k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->a:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v0, 0x0

    shr-int/2addr v2, v0

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->i:Ljava/util/concurrent/Future;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance v0, Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->j:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->a:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v2, 0x6

    const/4 v1, 0x2

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v2, 0x1

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/a/c;)Lcom/tencent/thumbplayer/adapter/a/a/a$c;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ s li ~@~~t@@rKo ~ /@  ~o~M@@~@bto~~@on@@@~uid4o1a~y @~@~ @m~i ~f fb@.  ~@l@c-~~bs@v~ So~~ @/  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->e:Lcom/tencent/thumbplayer/adapter/a/a/a$c;

    const/4 v1, 0x3

    return-object p0
.end method

.method private a(J)V
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->b:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v8, 0x5

    if-eq v0, v1, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const-string/jumbo p1, "nyemlsilaeuteSltPErTaxrtPby"

    const-string p1, "TusEyrrtlneetSSlexitPlabayP"

    const/4 v8, 0x6

    const-string p1, "TPSysPlayerExternalSubtitle"

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-string v0, ",easoapStl,peeeetm:i rlt laga"

    const-string/jumbo v0, "llrmaeeettl  ppit,aeSa,greas:"

    const/4 v8, 0x3

    const-string v0, "aae,lbS,pgtrlttlreisa ee:te a"

    const-string/jumbo v0, "prepare, illegalState, state:"

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    return-void

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v8, 0x2

    const/4 v7, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;->getTrackInfo()[Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-eqz v0, :cond_5

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    array-length v1, v0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-gtz v1, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    goto/16 :goto_0

    :cond_1
    const/4 v8, 0x7

    const/4 v1, 0x0

    move v7, v1

    move v7, v1

    const/4 v8, 0x7

    aget-object v0, v0, v1

    const/4 v8, 0x6

    iget v0, v0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->trackType:I

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    const/4 v2, 0x3

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-eq v0, v2, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    sget-object p1, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->e:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v8, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-string/jumbo p1, "tyaytEulStnPluereilaboeTSsx"

    const-string p1, "SenioluearExtPlyaSlbPyTttes"

    const/4 v8, 0x4

    const-string/jumbo p1, "reylslaptStPiyblaEeSrntPexT"

    const-string p1, "TPSysPlayerExternalSubtitle"

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string p2, "bo.tpahpqy aa r encp,k,terrmrettec "

    const-string p2, "e mrybe trea ,tcpkrprtan ,a.htpcoer"

    const/4 v8, 0x0

    const-string/jumbo p2, "tksroanpht rtme,c  ce,ar yt. rpreep"

    const-string/jumbo p2, "prepare, err, track type not match."

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    move v8, v7

    return-void

    :cond_2
    const/4 v8, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v0, v1, p1, p2}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;->selectTrackAsync(IJ)I

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    sget-object p1, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->c:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->a:I

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-nez p1, :cond_4

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->j:Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    monitor-enter p1

    :try_start_0
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->i:Ljava/util/concurrent/Future;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    if-eqz p2, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v0, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-interface {p2, v0}, Ljava/util/concurrent/Future;->cancel(Z)Z

    const/4 v8, 0x5

    const/4 p2, 0x0

    const/4 v8, 0x1

    move v7, p2

    move v7, p2

    const/4 v8, 0x5

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->i:Ljava/util/concurrent/Future;

    :cond_3
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/utils/o;->a()Lcom/tencent/thumbplayer/utils/o;

    move-result-object p2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/utils/o;->e()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    new-instance v1, Lcom/tencent/thumbplayer/adapter/a/a/c$2;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-direct {v1, p0}, Lcom/tencent/thumbplayer/adapter/a/a/c$2;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/c;)V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-wide/16 v4, 0xc8

    const-wide/16 v4, 0xc8

    const/4 v8, 0x4

    const-wide/16 v4, 0xc8

    const-wide/16 v4, 0xc8

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    sget-object v6, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-interface/range {v0 .. v6}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleAtFixedRate(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object p2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->i:Ljava/util/concurrent/Future;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    monitor-exit p1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    return-void

    :catchall_0
    move-exception p2

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    throw p2

    :cond_4
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    return-void

    :cond_5
    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string/jumbo p1, "ulSlrtunybTEaxaPsylriPeeetS"

    const/4 v8, 0x2

    const-string/jumbo p1, "ytlmSlberxistSEuPPaTeaernty"

    const-string p1, "TPSysPlayerExternalSubtitle"

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    const-string/jumbo p2, "fr ko,r.,atIet emnesporipapscyrep "

    const-string/jumbo p2, "tymIeetpsope rkp, a rp,csreia.frn "

    const/4 v8, 0x3

    const-string/jumbo p2, "prepare, err, trackInfos is empty."

    const/4 v7, 0x4

    move v8, v7

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    sget-object p1, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->e:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v8, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/a/c;I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/c;->b(I)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/a/c;J)V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x7

    invoke-direct {p0, p1, p2}, Lcom/tencent/thumbplayer/adapter/a/a/c;->a(J)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/adapter/a/a/c;)Lcom/tencent/thumbplayer/adapter/a/a/a$b;
    .locals 2

    const/4 v0, 0x6

    move v1, v0

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->f:Lcom/tencent/thumbplayer/adapter/a/a/a$b;

    const/4 v0, 0x7

    move v1, v0

    return-object p0
.end method

.method private b(I)V
    .locals 9

    const/4 v7, 0x2

    move v8, v7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->d:Lcom/tencent/thumbplayer/adapter/a/a/a$d;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->c:Lcom/tencent/thumbplayer/adapter/a/a/a$a;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string v2, "aenEebxSerPTllqsalPibytrutS"

    const-string/jumbo v2, "stttSPuaqirSaybPTnxrEeleell"

    const/4 v8, 0x2

    const-string v2, "aPrxtuuyaelrbyeTeitnPSSsltE"

    const-string v2, "TPSysPlayerExternalSubtitle"

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-eqz v0, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-nez v1, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/a/a$d;->a()J

    move-result-wide v3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    cmp-long v0, v3, v5

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-gez v0, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string/jumbo p1, "oosl,sup tbpur ucFlnico:in"

    const-string/jumbo p1, "subPollFunc, cur position:"

    const/4 v7, 0x2

    move v8, v7

    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {v2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    return-void

    :cond_1
    const/4 v7, 0x3

    move v8, v7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v7, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v0, v3, v4, p1}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;->getSubtitleText(JI)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->h:Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {v0, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-eqz v0, :cond_2

    const/4 v7, 0x7

    move v8, v7

    return-void

    :cond_2
    const/4 v7, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->h:Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/a/a$e;

    const/4 v8, 0x6

    invoke-direct {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/a$e;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-interface {v1, v0}, Lcom/tencent/thumbplayer/adapter/a/a/a$a;->a(Lcom/tencent/thumbplayer/adapter/a/a/a$e;)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    return-void

    :cond_3
    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    const-string/jumbo v3, "sioplFs qcsnb:ousPul"

    const-string v3, "Pnssb uoLcislF:olpsu"

    const/4 v8, 0x2

    const-string v3, "L:sobl,noFucpsuiP ls"

    const-string/jumbo v3, "subPollFunc, posLis:"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-direct {p1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string v0, "L:,miub s"

    const/4 v8, 0x2

    const-string v0, ",Lumsi: b"

    const-string v0, ", subLis:"

    const/4 v8, 0x0

    const/4 v7, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {v2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    return-void
.end method

.method static synthetic c(Lcom/tencent/thumbplayer/adapter/a/a/c;)Lcom/tencent/thumbplayer/adapter/a/a/a$d;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->d:Lcom/tencent/thumbplayer/adapter/a/a/a$d;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic d(Lcom/tencent/thumbplayer/adapter/a/a/c;)Lcom/tencent/thumbplayer/adapter/a/a/a$a;
    .locals 2

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->c:Lcom/tencent/thumbplayer/adapter/a/a/a$a;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method


# virtual methods
.method public a()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->b:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string/jumbo v2, "sryooutxStnlPaPaelbtTeySrel"

    const-string/jumbo v2, "teaxorPPSrnSlealsETyuelbtty"

    const/4 v4, 0x0

    const-string/jumbo v2, "yilPebuybretTSstlaESxalenPt"

    const-string v2, "TPSysPlayerExternalSubtitle"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eq v0, v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v1, "rS,beeue lealstetgp:aaai,r pl"

    const-string/jumbo v1, "teiStbree slgel:pa, ptraeala,"

    const/4 v4, 0x5

    const-string/jumbo v1, "sreSalgpla:e  ,tpapteieltrat,"

    const-string/jumbo v1, "prepare, illegalState, state:"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    shr-int/2addr v4, v3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v2, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v0, "qraueppe"

    const-string v0, "e.prpeua"

    const/4 v4, 0x7

    const-string/jumbo v0, "res.rppa"

    const-string/jumbo v0, "prepare."

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v2, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;->init()V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;->loadAsync()V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->b:Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-virtual {v1, v0}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;->setRenderParams(Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;)V

    :cond_1
    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void
.end method

.method public a(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->a:I

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/a/a$a;)V
    .locals 2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->c:Lcom/tencent/thumbplayer/adapter/a/a/a$a;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/a/a$b;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->f:Lcom/tencent/thumbplayer/adapter/a/a/a$b;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/a/a$c;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->e:Lcom/tencent/thumbplayer/adapter/a/a/a$c;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/a/a$d;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->d:Lcom/tencent/thumbplayer/adapter/a/a/a$d;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/b/c;->a(Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;)Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->b:Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;->setRenderParams(Lcom/tencent/thumbplayer/core/subtitle/TPNativeSubtitleRenderParams;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;J)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;J)V"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v4, 0x5

    const/4 v3, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->a:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const-string/jumbo v2, "iaSmTyblaxePSeneuttlrpPstrE"

    const-string/jumbo v2, "iSytTbtpPatSreeePllaEulxrsn"

    const/4 v4, 0x7

    const-string/jumbo v2, "nyraoeEltluPlSriPbeTayStesx"

    const-string v2, "TPSysPlayerExternalSubtitle"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eq v0, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string p2, "e aesbtqtgiseSa,ltDuaorlteSe: ,tacl"

    const-string p2, "eoeSuesaq,:atlt cDgaia,tSl slaetter"

    const-string/jumbo p2, "lSaesgut,eoD:etaSteaill,atsrct ueta"

    const-string/jumbo p2, "setDataSource, illegalState, state:"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const-string p2, " utomeap,stSlrter,Dai gesuau nllra:lg"

    const-string/jumbo p2, "mos,lreiltt uentalg De,r :uuSslgaeraa"

    const/4 v4, 0x5

    const-string/jumbo p2, "l lta gmqlrSt:,eaer,uneoacerlu tugaiD"

    const-string/jumbo p2, "setDataSource, illegal argument, url:"

    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void

    :cond_1
    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string/jumbo v1, "ruDmearsS,auctle:ot "

    const/4 v4, 0x1

    const-string/jumbo v1, "t src,u srSuelDatao:"

    const-string/jumbo v1, "setDataSource, url: "

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    invoke-static {v2, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string v0, "br mSruo!tllaaTucm,D=n atr.uessepe S"

    const-string v0, " uecoTSr!Durtenp=lss . elmtSuParb,aa"

    const/4 v4, 0x3

    const-string v0, "erPaolDup cs ,butSTerlot =sS!ra.nema"

    const-string/jumbo v0, "setDataSource, mTpSubParser != null."

    const/4 v4, 0x2

    invoke-static {v2, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->w(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;->stop()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;->unInit()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v3, 0x0

    move v4, v3

    new-instance v1, Lcom/tencent/thumbplayer/adapter/a/a/c$1;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v1, p0, p3, p4}, Lcom/tencent/thumbplayer/adapter/a/a/c$1;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/c;J)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget p3, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->a:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v0, p1, p2, v1, p3}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;-><init>(Ljava/lang/String;Ljava/util/Map;Lcom/tencent/thumbplayer/core/subtitle/ITPSubtitleParserCallback;I)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    sget-object p1, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->b:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-void
.end method

.method public b()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->c:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v4, 0x5

    const-string/jumbo v2, "rnliabesuPrPalSxyeetbSbtTly"

    const-string v2, "TxralbsyeeSPytilleartunStbP"

    const-string v2, "etSrPiurstEaTelPlbSlytenuay"

    const-string v2, "TPSysPlayerExternalSubtitle"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eq v0, v1, :cond_0

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v1, "S,eagetpa ryil: tsaelstscuttt,aA"

    const-string v1, "aaeaitusglct,,ntAS latsttsre:e y"

    const-string/jumbo v1, "stSstgetqr, ecnaey ,Alstaaatil:t"

    const-string/jumbo v1, "startAsync, illegalState, state:"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v2, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v0, "ssspctyaAr"

    const-string/jumbo v0, "sAcnrsapyt"

    const/4 v4, 0x7

    const-string/jumbo v0, "ttsmrnsyaA"

    const-string/jumbo v0, "startAsync"

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v2, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v4, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;->startAsync()V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-void
.end method

.method public c()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v4, 0x1

    const/4 v3, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->c:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v3, 0x4

    move v4, v3

    const-string v2, "eeqPotESbSxalanultyylrPsTie"

    const-string/jumbo v2, "sPyailSuqaEbxtPTeetStrlynle"

    const/4 v4, 0x4

    const-string v2, "SetEbbTsultlityxPrneySPeaal"

    const-string v2, "TPSysPlayerExternalSubtitle"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eq v0, v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string/jumbo v1, "patsseucnsg,testtelSa:,u  alleAy"

    const-string/jumbo v1, "sas:ltee,gesy,ulsAca aet anptltS"

    const/4 v4, 0x4

    const-string/jumbo v1, "lset:ayplagnAapasu,cest ,tS ieet"

    const-string/jumbo v1, "pauseAsync, illegalState, state:"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v2, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo v0, "maucsynsqA"

    const-string v0, "acAmyusnse"

    const/4 v4, 0x6

    const-string/jumbo v0, "uyseAsapsn"

    const-string/jumbo v0, "pauseAsync"

    const/4 v3, 0x7

    shr-int/2addr v4, v3

    invoke-static {v2, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;->pauseAsync()V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method

.method public d()V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string/jumbo v0, "lPSmPiualaeoSbylrnyetetExrT"

    const-string v0, "PelSoneeurPTrsybyEaaiSltxtl"

    const-string v0, "aelboxTntsttyuSyielPrPelEra"

    const-string v0, "TPSysPlayerExternalSubtitle"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string v1, "btbs."

    const-string v1, "bpst."

    const/4 v5, 0x4

    const-string v1, ".upto"

    const-string/jumbo v1, "stop."

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v5, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->b:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eq v0, v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->c:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    if-eq v0, v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->e:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-ne v0, v1, :cond_2

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v0, :cond_1

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;->stop()V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;->unInit()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x6

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string/jumbo v1, "llEteSnpteaSyltbrraPuPuysxe"

    const-string v1, "SltSunueiePlyrtxaPElyastrbe"

    const/4 v5, 0x3

    const-string/jumbo v1, "tlStPEsTqPlyaaeebitlryuSrnx"

    const-string v1, "TPSysPlayerExternalSubtitle"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    iput-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->a:I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-nez v0, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->j:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    monitor-enter v0

    :try_start_1
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->i:Ljava/util/concurrent/Future;

    const/4 v5, 0x0

    const/4 v4, 0x5

    if-eqz v1, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v3, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-interface {v1, v3}, Ljava/util/concurrent/Future;->cancel(Z)Z

    const/4 v4, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    iput-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->i:Ljava/util/concurrent/Future;

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    monitor-exit v0

    const/4 v5, 0x5

    goto :goto_1

    :catchall_0
    move-exception v1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    throw v1

    :cond_4
    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->d:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-void
.end method

.method public e()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v0, "SesyyutpxatrelPPitSTraenlbl"

    const/4 v5, 0x7

    const-string v0, "ErseaStlnleuetPbTyaySxslrtP"

    const-string v0, "TPSysPlayerExternalSubtitle"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo v1, "qesmet"

    const-string/jumbo v1, "etqres"

    const/4 v5, 0x3

    const-string v1, "erteo."

    const-string/jumbo v1, "reset."

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->a:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eq v0, v1, :cond_1

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;->stop()V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;->unInit()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v1, "itytebSnPuyElxarbstTraPelSl"

    const-string v1, "eSselrxtTlubatPrPneESyaltiy"

    const/4 v5, 0x3

    const-string v1, "TPSysPlayerExternalSubtitle"

    const/4 v5, 0x4

    const/4 v4, 0x2

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    iput-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->g:Lcom/tencent/thumbplayer/core/subtitle/TPSubtitleParser;

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->j:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    monitor-enter v0

    :try_start_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->i:Ljava/util/concurrent/Future;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-interface {v1, v3}, Ljava/util/concurrent/Future;->cancel(Z)Z

    const/4 v5, 0x5

    iput-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->i:Ljava/util/concurrent/Future;

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/c$a;->a:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->k:Lcom/tencent/thumbplayer/adapter/a/a/c$a;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-void

    :catchall_0
    move-exception v1

    :try_start_2
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    throw v1
.end method

.method public f()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string/jumbo v0, "latmlrSnyEreieTaPxSybtsetPl"

    const/4 v3, 0x1

    const-string v0, "eTsyerutlPnlaSyStbxutPEilar"

    const-string v0, "TPSysPlayerExternalSubtitle"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string v1, ".eeerasp"

    const-string v1, ".ereoeas"

    const-string/jumbo v1, "ql.esera"

    const-string/jumbo v1, "release."

    const/4 v2, 0x6

    move v3, v2

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->d:Lcom/tencent/thumbplayer/adapter/a/a/a$d;

    const/4 v3, 0x3

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/c;->c:Lcom/tencent/thumbplayer/adapter/a/a/a$a;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method
