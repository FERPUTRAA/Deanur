.class public Lcom/tencent/thumbplayer/adapter/a/a/e;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/adapter/a/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/adapter/a/a/e$d;,
        Lcom/tencent/thumbplayer/adapter/a/a/e$f;,
        Lcom/tencent/thumbplayer/adapter/a/a/e$c;,
        Lcom/tencent/thumbplayer/adapter/a/a/e$e;,
        Lcom/tencent/thumbplayer/adapter/a/a/e$b;,
        Lcom/tencent/thumbplayer/adapter/a/a/e$a;
    }
.end annotation


# instance fields
.field private A:Lcom/tencent/thumbplayer/adapter/a/c$l;

.field private B:Lcom/tencent/thumbplayer/adapter/a/c$m;

.field private volatile C:Landroid/media/MediaPlayer;

.field private D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

.field private E:Lcom/tencent/thumbplayer/a/c;

.field private F:Ljava/lang/Object;

.field private G:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "*>;"
        }
    .end annotation
.end field

.field private final H:Ljava/lang/Object;

.field private I:J

.field private J:Lcom/tencent/thumbplayer/adapter/a/a/e$a;

.field private final K:Ljava/lang/Object;

.field private L:I

.field private M:I

.field private final N:Ljava/lang/Object;

.field private O:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "*>;"
        }
    .end annotation
.end field

.field private P:Z

.field private volatile Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

.field private volatile R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

.field private S:Z

.field private T:J

.field private U:J

.field private V:I

.field private W:I

.field private volatile X:Z

.field private Y:I

.field private Z:I

.field private a:Lcom/tencent/thumbplayer/e/a;

.field private aa:I

.field private ab:I

.field private ac:I

.field private ad:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/adapter/a/a/e$b;",
            ">;"
        }
    .end annotation
.end field

.field private ae:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/adapter/a/a/e$b;",
            ">;"
        }
    .end annotation
.end field

.field private af:Lcom/tencent/thumbplayer/adapter/a/a/a;

.field private ag:J

.field private ah:Lcom/tencent/thumbplayer/adapter/a/a/e$f;

.field private ai:Landroid/media/MediaPlayer$OnTimedTextListener;
    .annotation build Landroid/annotation/TargetApi;
        value = 0x10
    .end annotation
.end field

.field private b:Landroid/content/Context;

.field private c:Z

.field private d:J

.field private e:J

.field private f:Ljava/lang/String;

.field private g:Ljava/io/FileDescriptor;

.field private h:Landroid/content/res/AssetFileDescriptor;

.field private i:Z

.field private j:F

.field private k:F

.field private l:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private m:I

.field private n:J

.field private o:Z

.field private p:J

.field private q:I

.field private r:I

.field private s:Lcom/tencent/thumbplayer/api/TPAudioAttributes;

.field private t:Z

.field private u:Lcom/tencent/thumbplayer/adapter/a/c$i;

.field private v:Lcom/tencent/thumbplayer/adapter/a/c$c;

.field private w:Lcom/tencent/thumbplayer/adapter/a/c$h;

.field private x:Lcom/tencent/thumbplayer/adapter/a/c$f;

.field private y:Lcom/tencent/thumbplayer/adapter/a/c$j;

.field private z:Lcom/tencent/thumbplayer/adapter/a/c$p;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)V
    .locals 12

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x7

    const/4 v0, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->c:Z

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x7

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v11, 0x5

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x4

    iput-wide v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->d:J

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    iput-wide v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->e:J

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x6

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->i:Z

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x1

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    iput v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->j:F

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    iput v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->k:F

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->m:I

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x0

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v11, 0x3

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x0

    iput-wide v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->n:J

    const/4 v11, 0x2

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->o:Z

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x0

    iput-wide v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->p:J

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x0

    const/4 v5, -0x1

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    iput v5, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->q:I

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    iput v5, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->r:I

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x7

    const/4 v6, 0x0

    const/4 v11, 0x4

    const/4 v10, 0x7

    iput-object v6, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->s:Lcom/tencent/thumbplayer/api/TPAudioAttributes;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x2

    const/4 v7, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x7

    iput-boolean v7, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->t:Z

    const/4 v11, 0x2

    const/4 v10, 0x5

    iput-object v6, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->G:Ljava/util/concurrent/Future;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x1

    new-instance v8, Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x6

    iput-object v8, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->H:Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x0

    const-wide/16 v8, 0x61a8

    const-wide/16 v8, 0x61a8

    const/4 v11, 0x4

    const-wide/16 v8, 0x61a8

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x4

    iput-wide v8, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->I:J

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    new-instance v8, Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x4

    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    const/4 v11, 0x2

    iput-object v8, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->K:Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v8, 0x3

    shr-int/2addr v11, v8

    const/4 v10, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x7

    iput v8, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->L:I

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x3

    const/16 v8, 0x1e

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x2

    iput v8, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->M:I

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x2

    new-instance v8, Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x3

    iput-object v8, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->N:Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x4

    iput-object v6, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->O:Ljava/util/concurrent/Future;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x3

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->P:Z

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x1

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->S:Z

    const/4 v11, 0x3

    iput-wide v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->T:J

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x2

    iput-wide v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->U:J

    const/4 v11, 0x6

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->V:I

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x6

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->W:I

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->X:Z

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Y:I

    const/4 v10, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    iput v5, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Z:I

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->aa:I

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x0

    iput v5, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ab:I

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x5

    iput v5, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ac:I

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v10, 0x5

    xor-int/2addr v11, v10

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ad:Ljava/util/List;

    const/4 v10, 0x1

    move v11, v10

    new-instance v0, Ljava/util/ArrayList;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v10, 0x4

    const/4 v11, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ae:Ljava/util/List;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x7

    iput-wide v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ag:J

    const/4 v11, 0x6

    const/4 v10, 0x2

    iput-object v6, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ah:Lcom/tencent/thumbplayer/adapter/a/a/e$f;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/a/e$8;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/adapter/a/a/e$8;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e;)V

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ai:Landroid/media/MediaPlayer$OnTimedTextListener;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x5

    new-instance v0, Lcom/tencent/thumbplayer/e/a;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x7

    const-string v1, "STsMlystPayeimdasPr"

    const-string/jumbo v1, "idsrSelsTyeymPaPtaM"

    const/4 v11, 0x5

    const-string/jumbo v1, "riamySeMatelesdTymP"

    const-string v1, "TPSystemMediaPlayer"

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-direct {v0, p2, v1}, Lcom/tencent/thumbplayer/e/a;-><init>(Lcom/tencent/thumbplayer/e/b;Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->b:Landroid/content/Context;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    new-instance p1, Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-direct {p1, p0, v6}, Lcom/tencent/thumbplayer/adapter/a/a/e$d;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e;Lcom/tencent/thumbplayer/adapter/a/a/e$1;)V

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    new-instance p1, Lcom/tencent/thumbplayer/adapter/a/a/e$b;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-direct {p1, v6}, Lcom/tencent/thumbplayer/adapter/a/a/e$b;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e$1;)V

    const/4 v11, 0x6

    const/4 v10, 0x7

    new-instance p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-direct {p2}, Lcom/tencent/thumbplayer/api/TPTrackInfo;-><init>()V

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x6

    iput-object p2, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->a:Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v10, 0x1

    and-int/2addr v11, v10

    iput-boolean v7, p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    const/4 v11, 0x4

    const-string v0, "dia_o1o"

    const-string v0, "_dimoa1"

    const/4 v11, 0x5

    const-string v0, "auo_1bd"

    const-string v0, "audio_1"

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x0

    iput-object v0, p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v11, 0x1

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ad:Ljava/util/List;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-interface {p2, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->b()V

    const/4 v11, 0x5

    const/4 v10, 0x6

    new-instance p1, Lcom/tencent/thumbplayer/adapter/a/a/c;

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-direct {p1}, Lcom/tencent/thumbplayer/adapter/a/a/c;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x4

    new-instance p2, Lcom/tencent/thumbplayer/adapter/a/a/e$1;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-direct {p2, p0}, Lcom/tencent/thumbplayer/adapter/a/a/e$1;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e;)V

    const/4 v11, 0x1

    const/4 v10, 0x4

    invoke-interface {p1, p2}, Lcom/tencent/thumbplayer/adapter/a/a/a;->a(Lcom/tencent/thumbplayer/adapter/a/a/a$a;)V

    const/4 v11, 0x4

    const/4 v10, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    new-instance p2, Lcom/tencent/thumbplayer/adapter/a/a/e$2;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-direct {p2, p0}, Lcom/tencent/thumbplayer/adapter/a/a/e$2;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e;)V

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-interface {p1, p2}, Lcom/tencent/thumbplayer/adapter/a/a/a;->a(Lcom/tencent/thumbplayer/adapter/a/a/a$d;)V

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    new-instance p2, Lcom/tencent/thumbplayer/adapter/a/a/e$3;

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-direct {p2, p0}, Lcom/tencent/thumbplayer/adapter/a/a/e$3;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e;)V

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-interface {p1, p2}, Lcom/tencent/thumbplayer/adapter/a/a/a;->a(Lcom/tencent/thumbplayer/adapter/a/a/a$c;)V

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    new-instance p2, Lcom/tencent/thumbplayer/adapter/a/a/e$4;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-direct {p2, p0}, Lcom/tencent/thumbplayer/adapter/a/a/e$4;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e;)V

    const/4 v11, 0x6

    const/4 v10, 0x3

    invoke-interface {p1, p2}, Lcom/tencent/thumbplayer/adapter/a/a/a;->a(Lcom/tencent/thumbplayer/adapter/a/a/a$b;)V

    const/4 v10, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    return-void
.end method

.method static synthetic A(Lcom/tencent/thumbplayer/adapter/a/a/e;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "y@/ o@u@@oi @@@~ rl~ Mn~~ o~-~m .f1   @ b~@o@S@@  ~@i@ @/c~fu@~4o~b~ab~v~ od ~ts@~ l~ti~@K~ @~@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    iget p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->q:I

    const/4 v0, 0x6

    move v1, v0

    return p0
.end method

.method private declared-synchronized A()V
    .locals 5

    const/4 v4, 0x5

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->H:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    monitor-enter v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->G:Ljava/util/concurrent/Future;

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {v1, v2}, Ljava/util/concurrent/Future;->cancel(Z)Z

    const/4 v4, 0x5

    const/4 v1, 0x7

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->G:Ljava/util/concurrent/Future;

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    monitor-exit p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-void

    :catchall_0
    move-exception v1

    :try_start_2
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    throw v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :catchall_1
    move-exception v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    monitor-exit p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    throw v0
.end method

.method static synthetic B(Lcom/tencent/thumbplayer/adapter/a/a/e;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Z:I

    const/4 v0, 0x5

    move v1, v0

    return p0
.end method

.method private B()V
    .locals 9

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->K:Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->G()Z

    move-result v1

    const/4 v8, 0x0

    if-nez v1, :cond_0

    const/4 v7, 0x7

    move v8, v7

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string/jumbo v2, "pfd oiBprCaTcthb nfccsmnfki,krrotfusryeheie   orebebtigneiuo"

    const-string/jumbo v2, "uCseontiifmreufirediTrfB eoap,ntefrcbsfkcbnyrooe ghki bht c "

    const/4 v8, 0x0

    const-string v2, "bcfdhrueqrr irtieeabtokonu mgkTeynsb  pCsinBcff,ferfedtci oi"

    const-string/jumbo v2, "startCheckBufferingTimer, forbidden check buffer by position"

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v1, v2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    monitor-exit v0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    return-void

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->J:Lcom/tencent/thumbplayer/adapter/a/a/e$a;

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-nez v1, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    new-instance v1, Lcom/tencent/thumbplayer/adapter/a/a/e$a;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/4 v2, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-direct {v1, v2}, Lcom/tencent/thumbplayer/adapter/a/a/e$a;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e$1;)V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->J:Lcom/tencent/thumbplayer/adapter/a/a/e$a;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/4 v2, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    iput-boolean v2, v1, Lcom/tencent/thumbplayer/adapter/a/a/e$a;->a:Z

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/utils/o;->a()Lcom/tencent/thumbplayer/utils/o;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v2}, Lcom/tencent/thumbplayer/utils/o;->e()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    new-instance v3, Lcom/tencent/thumbplayer/adapter/a/a/e$6;

    const/4 v8, 0x6

    const/4 v7, 0x2

    invoke-direct {v3, p0, v1}, Lcom/tencent/thumbplayer/adapter/a/a/e$6;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e;Lcom/tencent/thumbplayer/adapter/a/a/e$a;)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    sget-object v4, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x6

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-interface {v2, v3, v5, v6, v4}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    iput-object v2, v1, Lcom/tencent/thumbplayer/adapter/a/a/e$a;->b:Ljava/util/concurrent/Future;

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    monitor-exit v0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    return-void

    :catchall_0
    move-exception v1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    throw v1
.end method

.method private declared-synchronized C()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->K:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    monitor-enter v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->J:Lcom/tencent/thumbplayer/adapter/a/a/e$a;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    iput-boolean v2, v1, Lcom/tencent/thumbplayer/adapter/a/a/e$a;->a:Z

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, v1, Lcom/tencent/thumbplayer/adapter/a/a/e$a;->b:Ljava/util/concurrent/Future;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x7

    invoke-interface {v1, v2}, Ljava/util/concurrent/Future;->cancel(Z)Z

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->J:Lcom/tencent/thumbplayer/adapter/a/a/e$a;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput-object v2, v1, Lcom/tencent/thumbplayer/adapter/a/a/e$a;->b:Ljava/util/concurrent/Future;

    const/4 v4, 0x1

    iput-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->J:Lcom/tencent/thumbplayer/adapter/a/a/e$a;

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    monitor-exit p0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void

    :catchall_0
    move-exception v1

    :try_start_2
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    throw v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :catchall_1
    move-exception v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    monitor-exit p0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    throw v0
.end method

.method private D()V
    .locals 15

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->n()J

    move-result-wide v2

    iget-wide v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->U:J

    iput-wide v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->U:J

    iget-object v4, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    sget-object v5, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->e:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v7, 0x0

    if-eq v4, v5, :cond_1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->f:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    if-ne v0, v1, :cond_0

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->X:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const-string/jumbo v1, "nnstefeeft dbadct ns rpihni fgvskugbau naEfne eBdsu,e"

    const-string/jumbo v1, "gp bub cue nvtnetnBefsdgsdE kesaunrefeehinaandfit, f "

    const-string/jumbo v1, "udimbBnstt rkgdeguaaf epfffseuen taccnnihendseve  E n"

    const-string v1, "checkBuffingEvent, pause state and send end buffering"

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    iput-boolean v7, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->X:Z

    iput v7, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Y:I

    iget-object v8, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->w:Lcom/tencent/thumbplayer/adapter/a/c$h;

    if-eqz v8, :cond_0

    const/16 v9, 0xc9

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v12, 0x0

    const-wide/16 v12, 0x0

    const-wide/16 v12, 0x0

    const-wide/16 v12, 0x0

    const/4 v14, 0x0

    invoke-interface/range {v8 .. v14}, Lcom/tencent/thumbplayer/adapter/a/c$h;->a(IJJLjava/lang/Object;)V

    :cond_0
    return-void

    :cond_1
    iget-boolean v4, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->c:Z

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    if-eqz v4, :cond_2

    iget-wide v8, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->e:J

    cmp-long v4, v8, v5

    if-lez v4, :cond_4

    cmp-long v4, v2, v8

    if-ltz v4, :cond_4

    iget-boolean v4, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->P:Z

    if-nez v4, :cond_4

    iget-object v4, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    new-instance v8, Ljava/lang/StringBuilder;

    const-string/jumbo v9, "psknoeoEtki  fo,vudcnni uceg nbhckcairiPptfouBeo,s"

    const-string v9, "BuetoguoiniifsEiekfebac,pr :ok nnc ocphvnk,uscd Pt"

    const-string/jumbo v9, "skt,ibcpkeoao cfrclnhoevtnpPkn: ob sEui giue,fnidc"

    const-string v9, "checkBuffingEvent, loopback skip end, curPosition:"

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string/jumbo v9, "spiootupMSnott,i:rPmaoL"

    const-string v9, ",otiPoSp:sLn toiprmaMto"

    const-string/jumbo v9, "rtottm pLsoSnpMo:,sioiP"

    const-string v9, ", mLoopStartPositionMs:"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v9, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->d:J

    invoke-virtual {v8, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v8}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    iget-object v4, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    iget-wide v8, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->d:J

    long-to-int v8, v8

    invoke-virtual {v4, v8}, Landroid/media/MediaPlayer;->seekTo(I)V

    goto :goto_0

    :cond_2
    iget-wide v8, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->n:J

    cmp-long v4, v8, v5

    if-lez v4, :cond_4

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->m()J

    move-result-wide v8

    iget-wide v10, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->n:J

    sub-long/2addr v8, v10

    cmp-long v4, v2, v8

    if-ltz v4, :cond_4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string/jumbo v4, "naqe,ipaqkefsrB cuvtkneonc i md,gBs eD:tinEf"

    const-string/jumbo v4, "n,:umustqekcsfnfe n,i iBogBte dreakcvEpiDn a"

    const-string v4, "eks tuge,Dnctkad,rsiBpmenes Eafv:cnufBihi on"

    const-string v4, "checkBuffingEvent, skip end, mBaseDuration: "

    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-wide v4, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->T:J

    invoke-virtual {v1, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string/jumbo v4, "icrm,o nPtsus:"

    const-string/jumbo v4, "nis:tiPcsr,u o"

    const-string/jumbo v4, "oo torPuisni:c"

    const-string v4, ", curPosition:"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, "e,mpmbsE:SndMci l"

    const-string/jumbo v2, "pMim ieScdl:nmEs,"

    const-string v2, ", mSkipEndMilsec:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->n:J

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->e()V

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->C()V

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->v:Lcom/tencent/thumbplayer/adapter/a/c$c;

    if-eqz v0, :cond_3

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/c$c;->b()V

    :cond_3
    return-void

    :cond_4
    :goto_0
    cmp-long v0, v2, v0

    if-eqz v0, :cond_5

    iget-wide v8, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ag:J

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    add-long/2addr v8, v10

    iput-wide v8, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ag:J

    :cond_5
    if-nez v0, :cond_8

    cmp-long v0, v2, v5

    if-lez v0, :cond_8

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Y:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Y:I

    iget v4, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->L:I

    if-lt v0, v4, :cond_6

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->X:Z

    if-nez v0, :cond_6

    iput-boolean v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->X:Z

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const-string/jumbo v1, "sngfcfutrctfeoo ntegp,csinsdehvni  oBaiaekfEunnu orbihgten"

    const-string/jumbo v1, "sutgoBanf,niev choptoohierfn,igrfcdtnineutcsak ne esgn bEf"

    const-string/jumbo v1, "nsncsnfpfgt nnctnec daoneueskBtfrEeohvrb if gui,apehig ,ti"

    const-string v1, "checkBuffingEvent, position no change,send start buffering"

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->w:Lcom/tencent/thumbplayer/adapter/a/c$h;

    if-eqz v0, :cond_6

    const/16 v1, 0xc8

    iget-wide v4, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->T:J

    iget-wide v8, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ag:J

    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-interface/range {v0 .. v6}, Lcom/tencent/thumbplayer/adapter/a/c$h;->a(IJJLjava/lang/Object;)V

    :cond_6
    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Y:I

    iget v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->M:I

    if-lt v0, v1, :cond_a

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const-string/jumbo v1, "frcEBb fqru esgtoeknvocepnhr"

    const-string/jumbo v1, "secctbopriBeorErufngkv ehf n"

    const-string/jumbo v1, "ttseip krfgnuceEvnBsohrofce "

    const-string v1, "checkBuffingEvent post error"

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->i:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->e()V

    iput-boolean v7, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->X:Z

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->C()V

    iget-object v8, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->x:Lcom/tencent/thumbplayer/adapter/a/c$f;

    if-eqz v8, :cond_7

    const/16 v9, 0x7d1

    const/16 v0, -0x6e

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->g(I)I

    move-result v10

    const-wide/16 v11, 0x0

    const-wide/16 v11, 0x0

    const-wide/16 v11, 0x0

    const-wide/16 v11, 0x0

    const-wide/16 v13, 0x0

    const-wide/16 v13, 0x0

    const-wide/16 v13, 0x0

    const-wide/16 v13, 0x0

    invoke-interface/range {v8 .. v14}, Lcom/tencent/thumbplayer/adapter/a/c$f;->a(IIJJ)V

    :cond_7
    return-void

    :cond_8
    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->X:Z

    if-eqz v0, :cond_9

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const-string v1, "E fm  scgfeneBupnckndnne,d aiov,hnneeiiigfrtsotg ubfce"

    const-string v1, "e,ffg,ueh oigsendftB nen nogpeburncidhavitief ncncks E"

    const-string v1, "cinnotdutcneebiuc vk fdo nseni ,ehnrfehpiBggfEn,aegsf "

    const-string v1, "checkBuffingEvent, position change, send end buffering"

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->w:Lcom/tencent/thumbplayer/adapter/a/c$h;

    if-eqz v0, :cond_9

    const/16 v1, 0xc9

    iget-wide v4, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->T:J

    iget-wide v8, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ag:J

    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-interface/range {v0 .. v6}, Lcom/tencent/thumbplayer/adapter/a/c$h;->a(IJJLjava/lang/Object;)V

    :cond_9
    iput-boolean v7, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->X:Z

    iput v7, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Y:I

    :cond_a
    return-void
.end method

.method private E()V
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->N:Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->O:Ljava/util/concurrent/Future;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-nez v1, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/utils/o;->a()Lcom/tencent/thumbplayer/utils/o;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/utils/o;->e()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    new-instance v2, Lcom/tencent/thumbplayer/adapter/a/a/e$7;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {v2, p0}, Lcom/tencent/thumbplayer/adapter/a/a/e$7;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e;)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    iget v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->M:I

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    mul-int/lit16 v3, v3, 0x190

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    int-to-long v3, v3

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    sget-object v5, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {v1, v2, v3, v4, v5}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->O:Ljava/util/concurrent/Future;

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    monitor-exit v0

    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    return-void

    :catchall_0
    move-exception v1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    throw v1
.end method

.method private declared-synchronized F()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->N:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    monitor-enter v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v3, 0x0

    move v4, v3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->O:Ljava/util/concurrent/Future;

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v1, v2}, Ljava/util/concurrent/Future;->cancel(Z)Z

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x1

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->O:Ljava/util/concurrent/Future;

    :cond_0
    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    monitor-exit p0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-void

    :catchall_0
    move-exception v1

    :try_start_2
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    throw v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :catchall_1
    move-exception v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    monitor-exit p0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    throw v0
.end method

.method private G()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->o:Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0

    :cond_0
    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->t:Z

    const/4 v2, 0x7

    const/4 v1, 0x5

    return v0
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/a/e;I)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->W:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return p1
.end method

.method private a()Landroid/media/MediaPlayer;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/a/b;

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {v0}, Lcom/tencent/thumbplayer/adapter/a/a/b;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v2, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnInfoListener(Landroid/media/MediaPlayer$OnInfoListener;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnBufferingUpdateListener(Landroid/media/MediaPlayer$OnBufferingUpdateListener;)V

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnSeekCompleteListener(Landroid/media/MediaPlayer$OnSeekCompleteListener;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnVideoSizeChangedListener(Landroid/media/MediaPlayer$OnVideoSizeChangedListener;)V

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ai:Landroid/media/MediaPlayer$OnTimedTextListener;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnTimedTextListener(Landroid/media/MediaPlayer$OnTimedTextListener;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/a/e;Lcom/tencent/thumbplayer/adapter/a/a/e$e;)Lcom/tencent/thumbplayer/adapter/a/a/e$e;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v0, 0x4

    move v1, v0

    return-object p1
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$l;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->A:Lcom/tencent/thumbplayer/adapter/a/c$l;

    const/4 v0, 0x6

    shr-int/2addr v1, v0

    return-object p0
.end method

.method private a(Landroid/media/MediaPlayer;)V
    .locals 5

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-class v0, Landroid/media/MediaPlayer;

    const-class v0, Landroid/media/MediaPlayer;

    const/4 v4, 0x2

    const-string/jumbo v1, "tEdpnbanrHmve"

    const-string/jumbo v1, "lHmatdrpvnEen"

    const/4 v4, 0x7

    const-string v1, "EndveHuelrmnt"

    const-string/jumbo v1, "mEventHandler"

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    check-cast p1, Landroid/os/Handler;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-class v0, Landroid/os/Handler;

    const-class v0, Landroid/os/Handler;

    const/4 v4, 0x5

    const-class v0, Landroid/os/Handler;

    const-class v0, Landroid/os/Handler;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string/jumbo v2, "laCkamlpb"

    const-string v2, "Caaklmlbq"

    const/4 v4, 0x1

    const-string v2, "aCllckbmq"

    const-string/jumbo v2, "mCallback"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    check-cast v1, Landroid/os/Handler$Callback;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    new-instance v1, Lcom/tencent/thumbplayer/adapter/a/a/e$c;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v1, p1}, Lcom/tencent/thumbplayer/adapter/a/a/e$c;-><init>(Landroid/os/Handler;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void

    :catch_0
    move-exception p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo v2, "mediaPlayerExceptionHook, "

    const-string/jumbo v2, "mediaPlayerExceptionHook, "

    const/4 v4, 0x3

    const-string/jumbo v2, "mediaPlayerExceptionHook, "

    const-string/jumbo v2, "mediaPlayerExceptionHook, "

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void
.end method

.method private a(Landroid/media/MediaPlayer;II)V
    .locals 5
    .param p3    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSeekMode;
        .end annotation
    .end param

    const/4 v3, 0x7

    move v4, v3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/16 v1, 0x1a

    const/4 v4, 0x4

    const/4 v3, 0x6

    if-ge v0, v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object p3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x1

    const/4 v3, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string/jumbo v2, "vossie kc wesr rt on tdsl,:in uo to"

    const/4 v4, 0x2

    const-string/jumbo v2, "onsi ltid   soretnswuo r, stevocr: "

    const-string/jumbo v2, "os ver is too low, current sdk int:"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string/jumbo v0, "ioimmhn  t(asitts nosspe euensked6si ,T  nt2isloMs, )"

    const-string/jumbo v0, "t 2moodnttsnsi6  u,seeniltoTs )ihi( aenseM,  i epskss"

    const/4 v4, 0x5

    const-string/jumbo v0, "tieto M  asi hn, p6n)T(a soeeouskeis2dlessiosn,its nt"

    const-string v0, ", is less than 26, use seekTo(int positionMs) instead"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p3, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1, p2}, Landroid/media/MediaPlayer;->seekTo(I)V

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-ne p3, v0, :cond_2

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    move v0, v1

    move v0, v1

    const/4 v4, 0x6

    move v0, v1

    const/4 v3, 0x2

    move v4, v3

    goto :goto_0

    :cond_2
    const/4 v3, 0x7

    move v4, v3

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-ne p3, v2, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto :goto_0

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v0, 0x3

    const/4 v4, 0x7

    if-ne p3, v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    move v0, v2

    move v0, v2

    const/4 v4, 0x6

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v4, 0x0

    int-to-long v1, p2

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {p1, v1, v2, v0}, Lcom/tencent/thumbplayer/adapter/a/a/g;->a(Landroid/media/MediaPlayer;JI)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void

    :catch_0
    move-exception p3

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, p3}, Lcom/tencent/thumbplayer/e/a;->a(Ljava/lang/Exception;)V

    :try_start_1
    const/4 v4, 0x7

    const/4 v3, 0x0

    iget-object p3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x6

    if-ne p3, v0, :cond_4

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    sget-object p3, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->e:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    iput-object p3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    :cond_4
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Landroid/media/MediaPlayer;->seekTo(I)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-void

    :catch_1
    move-exception p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/e/a;->a(Ljava/lang/Exception;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    return-void
.end method

.method private declared-synchronized a(Lcom/tencent/thumbplayer/adapter/a/a/e$f;)V
    .locals 13

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x1

    iget-object v0, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->g:Ljava/lang/String;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->n()J

    move-result-wide v1

    const/4 v12, 0x4

    const/4 v11, 0x0

    iput-wide v1, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->c:J

    const/4 v12, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x5

    iput-object v1, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ac:I

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    iput v1, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->e:I

    const/4 v12, 0x3

    const/4 v11, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Z:I

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x5

    iput v1, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->f:I

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x7

    const-string/jumbo v3, "pseSobtRerproy stl,ae:"

    const-string v3, ",atsoper yeortSspRla:e"

    const/4 v12, 0x4

    const-string v3, "apraepuleyss ,St:trtoe"

    const-string/jumbo v3, "playerResetStart, pos:"

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x3

    iget-wide v3, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->c:J

    const/4 v11, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x1

    const-string v3, ",t aestp"

    const-string v3, "eats b,t"

    const/4 v12, 0x7

    const-string/jumbo v3, "q:test,a"

    const-string v3, ", state:"

    const/4 v11, 0x7

    and-int/2addr v12, v11

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x1

    iget-object v3, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-virtual {v1, v2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x6

    const/4 v1, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x4

    iput-boolean v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->S:Z

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->v()V

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x6

    sget-object v2, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->a:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x6

    iput-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x3

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->g:Ljava/io/FileDescriptor;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x4

    if-eqz v2, :cond_0

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x2

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->g:Ljava/io/FileDescriptor;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-virtual {v0, v2}, Landroid/media/MediaPlayer;->setDataSource(Ljava/io/FileDescriptor;)V

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x3

    goto :goto_0

    :cond_0
    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x4

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->h:Landroid/content/res/AssetFileDescriptor;

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x1

    if-eqz v2, :cond_1

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-direct {p0, v2}, Lcom/tencent/thumbplayer/adapter/a/a/e;->b(Landroid/content/res/AssetFileDescriptor;)V

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x7

    goto :goto_0

    :cond_1
    const/4 v12, 0x0

    iget v2, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->d:I

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-direct {p0, v2}, Lcom/tencent/thumbplayer/adapter/a/a/e;->e(I)V

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x7

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->l:Ljava/util/Map;

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    if-eqz v2, :cond_2

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-interface {v2}, Ljava/util/Map;->isEmpty()Z

    move-result v2

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x5

    if-nez v2, :cond_2

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x0

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v12, 0x0

    iget-object v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->b:Landroid/content/Context;

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x6

    iget-object v4, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->l:Ljava/util/Map;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {v2, v3, v0, v4}, Landroid/media/MediaPlayer;->setDataSource(Landroid/content/Context;Landroid/net/Uri;Ljava/util/Map;)V

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x4

    goto :goto_0

    :cond_2
    const/4 v12, 0x0

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x7

    invoke-virtual {v2, v0}, Landroid/media/MediaPlayer;->setDataSource(Ljava/lang/String;)V

    :goto_0
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->b:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v12, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->F:Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x4

    if-nez v0, :cond_3

    const/4 v12, 0x3

    const/4 v11, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x0

    const/4 v2, 0x0

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-virtual {v0, v2}, Landroid/media/MediaPlayer;->setDisplay(Landroid/view/SurfaceHolder;)V

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x1

    goto :goto_1

    :cond_3
    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x7

    instance-of v2, v0, Landroid/view/SurfaceHolder;

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x5

    if-eqz v2, :cond_4

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v12, 0x3

    const/4 v11, 0x7

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->F:Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x0

    check-cast v2, Landroid/view/SurfaceHolder;

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-virtual {v0, v2}, Landroid/media/MediaPlayer;->setDisplay(Landroid/view/SurfaceHolder;)V

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x2

    goto :goto_1

    :cond_4
    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x7

    instance-of v0, v0, Landroid/view/Surface;

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x2

    if-eqz v0, :cond_5

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x1

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->F:Ljava/lang/Object;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x0

    check-cast v2, Landroid/view/Surface;

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-virtual {v0, v2}, Landroid/media/MediaPlayer;->setSurface(Landroid/view/Surface;)V

    :cond_5
    :goto_1
    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ah:Lcom/tencent/thumbplayer/adapter/a/a/e$f;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x5

    if-eqz v0, :cond_8

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget v2, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->a:I

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x0

    iget v3, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->a:I

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x0

    if-eq v2, v3, :cond_8

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x0

    iget-object v4, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->w:Lcom/tencent/thumbplayer/adapter/a/c$h;

    const/4 v12, 0x7

    if-ne v2, v1, :cond_6

    const/4 v12, 0x1

    const/4 v1, 0x5

    const/4 v12, 0x7

    const/4 v1, 0x3

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x4

    goto :goto_2

    :cond_6
    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x1

    const/4 v1, 0x4

    :goto_2
    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x1

    move v5, v1

    move v5, v1

    const/4 v12, 0x2

    move v5, v1

    move v5, v1

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x6

    if-eqz v4, :cond_7

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x7

    iget-wide v6, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->b:J

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v12, 0x5

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x7

    const/4 v10, 0x0

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-interface/range {v4 .. v10}, Lcom/tencent/thumbplayer/adapter/a/c$h;->a(IJJLjava/lang/Object;)V

    :cond_7
    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x2

    iget-object v1, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x4

    iput-object v1, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v12, 0x6

    iget-wide v0, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->c:J

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x4

    iput-wide v0, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->c:J

    :cond_8
    const/4 v11, 0x0

    const/4 v12, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ah:Lcom/tencent/thumbplayer/adapter/a/a/e$f;

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x6

    iget-object p1, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->c:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v12, 0x4

    const/4 v11, 0x6

    if-eq p1, v0, :cond_9

    const/4 v12, 0x2

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->d:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x3

    if-eq p1, v0, :cond_9

    const/4 v12, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->e:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v12, 0x0

    const/4 v11, 0x5

    if-eq p1, v0, :cond_9

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->f:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x4

    if-ne p1, v0, :cond_a

    :cond_9
    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->g()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_a
    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    monitor-exit p0

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x6

    monitor-exit p0

    const/4 v11, 0x0

    move v12, v11

    throw p1
.end method

.method private a(Lcom/tencent/thumbplayer/api/TPAudioAttributes;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x2

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->s:Lcom/tencent/thumbplayer/api/TPAudioAttributes;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/api/TPAudioAttributes;->toAndroidMediaAudioAttributes()Landroid/media/AudioAttributes;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setAudioAttributes(Landroid/media/AudioAttributes;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo v2, "i:ssotPuAnoabudeiPt I liaeta aiut  d,reMyre"

    const-string v2, "M  t tu,oeeiuirrdaPios :etlba etadautPyIiAn"

    const/4 v4, 0x3

    const-string v2, "adumattdasuAPieto tes tP eayeinilb,oI M :ir"

    const-string/jumbo v2, "set audio attributes into MediaPlayer, API:"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    and-int/2addr v4, v3

    const-string p1, ">=21, "

    const-string p1, ">=21, "

    const/4 v4, 0x0

    const-string p1, ">=21, "

    const-string p1, ">=21, "

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->s:Lcom/tencent/thumbplayer/api/TPAudioAttributes;

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPAudioAttributes;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/adapter/a/a/e$e;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->d:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v1, 0x5

    and-int/2addr v2, v1

    if-eq p1, v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->e:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eq p1, v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->f:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    if-ne p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p1

    :cond_1
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    return p1
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/a/a/e;Z)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->X:Z

    const/4 v1, 0x4

    const/4 v0, 0x1

    return p1
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/adapter/a/a/e;I)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->V:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    return p1
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/adapter/a/a/e;Lcom/tencent/thumbplayer/adapter/a/a/e$e;)Lcom/tencent/thumbplayer/adapter/a/a/e$e;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$m;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->B:Lcom/tencent/thumbplayer/adapter/a/c$m;

    const/4 v1, 0x4

    return-object p0
.end method

.method private b()V
    .locals 3

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->a()Landroid/media/MediaPlayer;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->a:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v1, 0x6

    shr-int/2addr v2, v1

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v1, 0x3

    or-int/2addr v2, v1

    return-void
.end method

.method private b(Landroid/content/res/AssetFileDescriptor;)V
    .locals 9

    const/4 v8, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v8, 0x5

    const/16 v1, 0x18

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-lt v0, v1, :cond_0

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/f;->a(Landroid/media/MediaPlayer;Landroid/content/res/AssetFileDescriptor;)V

    const/4 v8, 0x2

    const/4 v7, 0x1

    return-void

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p1}, Landroid/content/res/AssetFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p1}, Landroid/content/res/AssetFileDescriptor;->getStartOffset()J

    move-result-wide v3

    const/4 v7, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p1}, Landroid/content/res/AssetFileDescriptor;->getLength()J

    move-result-wide v5

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual/range {v1 .. v6}, Landroid/media/MediaPlayer;->setDataSource(Ljava/io/FileDescriptor;JJ)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    return-void
.end method

.method private b(Lcom/tencent/thumbplayer/adapter/a/a/e$e;)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->j:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eq p1, v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    return p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return p1
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/adapter/a/a/e;Z)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->P:Z

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    return p1
.end method

.method static synthetic c(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/e/a;
    .locals 2

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method

.method private c()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->a(Lcom/tencent/thumbplayer/adapter/a/a/e$e;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->g:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v2, 0x3

    move v3, v2

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v1, "ati olrMopsyP.ape"

    const-string v1, ".rpi aspytPldoeMa"

    const/4 v3, 0x6

    const-string/jumbo v1, "lsypobdatMi.eaPe "

    const-string v1, "MediaPlayer stop."

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->stop()V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method static synthetic d(I)I
    .locals 2

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->g(I)I

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic d(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$h;
    .locals 2

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->w:Lcom/tencent/thumbplayer/adapter/a/c$h;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p0
.end method

.method private d()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->b(Lcom/tencent/thumbplayer/adapter/a/a/e$e;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->j:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string/jumbo v1, "lrP eeusaya.aMqdliee"

    const-string/jumbo v1, "lliyMaeaqePda.ere se"

    const/4 v3, 0x6

    const-string v1, "ePeMliapelrs .daeray"

    const-string v1, "MediaPlayer release."

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->release()V

    :cond_0
    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method private d(IJ)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Lcom/tencent/thumbplayer/adapter/a/a/e$f;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e$1;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    iput-wide p2, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->b:J

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput p1, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->d:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 p1, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput p1, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->a:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->f:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object p1, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->g:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->a(Lcom/tencent/thumbplayer/adapter/a/a/e$f;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method

.method static synthetic e(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/a/e$e;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v1, 0x7

    return-object p0
.end method

.method private e()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->y()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->c()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->d()V

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method

.method private e(I)V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-gtz p1, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    return-void

    :cond_0
    const/4 v8, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ad:Ljava/util/List;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    check-cast p1, Lcom/tencent/thumbplayer/adapter/a/a/e$b;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->w:Lcom/tencent/thumbplayer/adapter/a/c$h;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-eqz v0, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    new-instance v6, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPAudioTrackInfo;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-direct {v6}, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPAudioTrackInfo;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    iget-object v1, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->b:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    iput-object v1, v6, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPAudioTrackInfo;->audioTrackUrl:Ljava/lang/String;

    const/4 v8, 0x5

    iget-object p1, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->c:Ljava/util/List;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    iput-object p1, v6, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPAudioTrackInfo;->paramData:Ljava/util/List;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const-string v2, "aela daoq rrrct:aeuouuTsDilSd,khn"

    const-string v2, "a:slotSru uah,Dor Tcikaludenareda"

    const-string/jumbo v2, "nusoaakuid r:aaleTcaeoluh c,rDSdr"

    const-string/jumbo v2, "handleDataSource, audioTrack url:"

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-object v2, v6, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPAudioTrackInfo;->audioTrackUrl:Ljava/lang/String;

    const/4 v8, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p1, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/16 v1, 0x3f3

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v8, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v8, 0x5

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-interface/range {v0 .. v6}, Lcom/tencent/thumbplayer/adapter/a/c$h;->a(IJJLjava/lang/Object;)V

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    return-void
.end method

.method private e(IJ)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v3, 0x1

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/a/a;->e()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ae:Ljava/util/List;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast p1, Lcom/tencent/thumbplayer/adapter/a/a/e$b;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v1, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->b:Ljava/lang/String;

    const/4 v3, 0x5

    iget-object p1, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->d:Ljava/util/Map;

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-interface {v0, v1, p1, p2, p3}, Lcom/tencent/thumbplayer/adapter/a/a/a;->a(Ljava/lang/String;Ljava/util/Map;J)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v3, 0x4

    invoke-interface {p1}, Lcom/tencent/thumbplayer/adapter/a/a/a;->a()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method

.method private f(I)I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-ne v0, p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    return v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-ne v0, p1, :cond_1

    const/4 v2, 0x3

    return v0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-ne v0, p1, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 p1, 0x3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return p1

    :cond_2
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return p1
.end method

.method static synthetic f(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/a/a;
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v0, 0x3

    move v1, v0

    return-object p0
.end method

.method private f(IJ)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string v2, "ecumdmd rSte:kIltTnekbcc,eara"

    const-string/jumbo v2, "nrbmxkt I:rake,eSlcutdeceadTc"

    const/4 v4, 0x0

    const-string v2, "TcrSondcrls,:Iakt eeuktbexcde"

    const-string v2, "deselectSubTrack, trackIndex:"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const-string/jumbo p1, "pqoeoau, "

    const-string/jumbo p1, "pqoeoau, "

    const/4 v4, 0x3

    const-string/jumbo p1, "p,qeuba: "

    const-string p1, ", opaque:"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-virtual {v1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-interface {p1}, Lcom/tencent/thumbplayer/adapter/a/a/a;->e()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-void
.end method

.method private static g(I)I
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-wide/32 v0, 0x989680

    const-wide/32 v0, 0x989680

    const/4 v5, 0x3

    const-wide/32 v0, 0x989680

    const-wide/32 v0, 0x989680

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    int-to-long v2, p0

    const/4 v5, 0x4

    const/4 v4, 0x6

    if-gez p0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    sub-long/2addr v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    add-long/2addr v0, v2

    :goto_0
    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-wide/32 v2, 0x7fffffff

    const-wide/32 v2, 0x7fffffff

    const/4 v5, 0x4

    const-wide/32 v2, 0x7fffffff

    const/4 v4, 0x5

    or-int/2addr v5, v4

    cmp-long p0, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-ltz p0, :cond_1

    move-wide v0, v2

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    long-to-int p0, v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    return p0
.end method

.method static synthetic g(Lcom/tencent/thumbplayer/adapter/a/a/e;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->e()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic h(Lcom/tencent/thumbplayer/adapter/a/a/e;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->A()V

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic i(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$f;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->x:Lcom/tencent/thumbplayer/adapter/a/c$f;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic j(Lcom/tencent/thumbplayer/adapter/a/a/e;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->D()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic k(Lcom/tencent/thumbplayer/adapter/a/a/e;)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    iget-boolean p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->X:Z

    return p0
.end method

.method static synthetic l(Lcom/tencent/thumbplayer/adapter/a/a/e;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->F()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic m(Lcom/tencent/thumbplayer/adapter/a/a/e;)Landroid/media/MediaPlayer;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v1, 0x6

    const/4 v0, 0x2

    return-object p0
.end method

.method static synthetic n(Lcom/tencent/thumbplayer/adapter/a/a/e;)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    iget p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->m:I

    const/4 v0, 0x0

    and-int/2addr v1, v0

    return p0
.end method

.method static synthetic o(Lcom/tencent/thumbplayer/adapter/a/a/e;)Z
    .locals 2

    const/4 v1, 0x0

    iget-boolean p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->o:Z

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic p(Lcom/tencent/thumbplayer/adapter/a/a/e;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->w()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic q(Lcom/tencent/thumbplayer/adapter/a/a/e;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->C()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic r(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$c;
    .locals 2

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->v:Lcom/tencent/thumbplayer/adapter/a/c$c;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic s(Lcom/tencent/thumbplayer/adapter/a/a/e;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->G()Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic t(Lcom/tencent/thumbplayer/adapter/a/a/e;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->E()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic u(Lcom/tencent/thumbplayer/adapter/a/a/e;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->W:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    return p0
.end method

.method static synthetic v(Lcom/tencent/thumbplayer/adapter/a/a/e;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->V:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    return p0
.end method

.method private v()V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->A()V

    const/4 v6, 0x4

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->C()V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->F()V

    const/4 v6, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->e()V

    const/4 v6, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/a/b;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-direct {v0}, Lcom/tencent/thumbplayer/adapter/a/a/b;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v5, 0x2

    shr-int/2addr v6, v5

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v5, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnInfoListener(Landroid/media/MediaPlayer$OnInfoListener;)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v6, 0x2

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnBufferingUpdateListener(Landroid/media/MediaPlayer$OnBufferingUpdateListener;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v6, 0x7

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnSeekCompleteListener(Landroid/media/MediaPlayer$OnSeekCompleteListener;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v5, 0x1

    xor-int/2addr v6, v5

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->D:Lcom/tencent/thumbplayer/adapter/a/a/e$d;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnVideoSizeChangedListener(Landroid/media/MediaPlayer$OnVideoSizeChangedListener;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ai:Landroid/media/MediaPlayer$OnTimedTextListener;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnTimedTextListener(Landroid/media/MediaPlayer$OnTimedTextListener;)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->i:Z

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v5, 0x3

    move v6, v5

    const/4 v1, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v0, v1, v1}, Landroid/media/MediaPlayer;->setVolume(FF)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_1

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->j:F

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    cmpl-float v0, v0, v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->j:F

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->k:F

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    float-to-double v1, v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    const/4 v6, 0x3

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    const/4 v5, 0x0

    const/4 v5, 0x0

    cmpl-double v1, v1, v3

    const/4 v6, 0x1

    if-eqz v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->b(F)V

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->c:Z

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-eqz v0, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-boolean v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->c:Z

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setLooping(Z)V

    :cond_3
    const/4 v6, 0x0

    return-void
.end method

.method static synthetic w(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$p;
    .locals 2

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->z:Lcom/tencent/thumbplayer/adapter/a/c$p;

    const/4 v0, 0x0

    move v1, v0

    return-object p0
.end method

.method private declared-synchronized w()V
    .locals 12

    const/4 v11, 0x3

    const/4 v10, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ah:Lcom/tencent/thumbplayer/adapter/a/a/e$f;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x2

    const-string/jumbo v3, "ibeyfeulEnc:o ons,aaItnrteR"

    const-string v3, "Ral,nbciIn eeftdoeysarnEto:"

    const/4 v11, 0x2

    const-string v3, "eaolendpfIe:nRa ,ipntotEryc"

    const-string/jumbo v3, "playerResetEnd, actionInfo:"

    const/4 v11, 0x4

    const/4 v10, 0x7

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    const-string/jumbo v3, "pdemnuuSs:,"

    const/4 v11, 0x2

    const-string/jumbo v3, "ud nsep,qm:"

    const-string v3, ", mSuspend:"

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    move v11, v10

    iget-boolean v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->S:Z

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {v1, v2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    if-eqz v0, :cond_b

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    iget-boolean v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->S:Z

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x5

    if-eqz v1, :cond_b

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->w:Lcom/tencent/thumbplayer/adapter/a/c$h;

    const/4 v10, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    iget v1, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->a:I

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x6

    const/4 v3, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-ne v1, v3, :cond_0

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    const/4 v1, 0x3

    const/4 v11, 0x1

    goto :goto_0

    :cond_0
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x3

    const/4 v1, 0x4

    :goto_0
    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x4

    move v3, v1

    move v3, v1

    const/4 v11, 0x0

    move v3, v1

    move v3, v1

    const/4 v10, 0x4

    const/4 v11, 0x7

    if-eqz v2, :cond_1

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x1

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v11, 0x3

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v11, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v10, 0x7

    const/4 v10, 0x6

    iget-wide v8, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->b:J

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v8

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-interface/range {v2 .. v8}, Lcom/tencent/thumbplayer/adapter/a/c$h;->a(IJJLjava/lang/Object;)V

    :cond_1
    iget v1, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->e:I

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    if-lez v1, :cond_2

    const/4 v11, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x1

    iget v2, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->e:I

    const/4 v10, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-virtual {v1, v2}, Landroid/media/MediaPlayer;->selectTrack(I)V

    :cond_2
    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    iget v1, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->f:I

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-lez v1, :cond_3

    const/4 v11, 0x3

    const/4 v10, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x0

    iget v2, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->f:I

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {v1, v2}, Landroid/media/MediaPlayer;->selectTrack(I)V

    :cond_3
    const/4 v11, 0x3

    const/4 v10, 0x5

    iget-wide v1, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->c:J

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x5

    const-wide/16 v3, 0x0

    const/4 v11, 0x5

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v11, 0x4

    cmp-long v1, v1, v3

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    if-lez v1, :cond_4

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x1

    iget-boolean v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->P:Z

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    if-nez v1, :cond_4

    const/4 v10, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x4

    const-string/jumbo v3, "pasEp,a pdn,eanrer:nseRtdoPe)srkoye  (d ee"

    const-string/jumbo v3, "re)lpPapsdra ned n k p,y,e:rdsoeERee(eaton"

    const-string v3, "(tsmR,kdep:eeEPdaelnrne  oeaead,yp)rs tn o"

    const-string/jumbo v3, "playerResetEnd, onPrepared(), and seek to:"

    const/4 v11, 0x4

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x6

    iget-wide v3, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->c:J

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    move v11, v10

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {v1, v2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v11, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    iget-wide v2, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->c:J

    const/4 v11, 0x6

    const/4 v10, 0x3

    long-to-int v2, v2

    const/4 v10, 0x7

    move v11, v10

    invoke-virtual {v1, v2}, Landroid/media/MediaPlayer;->seekTo(I)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x1

    goto :goto_1

    :catch_0
    move-exception v1

    :try_start_2
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x2

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v11, 0x5

    invoke-virtual {v2, v1}, Lcom/tencent/thumbplayer/e/a;->a(Ljava/lang/Exception;)V

    :cond_4
    :goto_1
    const/4 v10, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x3

    const-string v3, "dnysoesprsteaaerreRt : t,oeleq"

    const-string v3, ":errtetsqldotn,ate ae ryessepR"

    const/4 v11, 0x5

    const-string/jumbo v3, "playerResetEnd, restore state:"

    const/4 v11, 0x2

    const/4 v10, 0x2

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x1

    iget-object v3, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-virtual {v1, v2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x4

    iget-object v1, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v10, 0x6

    and-int/2addr v11, v10

    sget-object v2, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->a:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x3

    const/4 v10, 0x2

    if-eq v1, v2, :cond_9

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    sget-object v2, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->b:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    if-eq v1, v2, :cond_9

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x7

    sget-object v2, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->c:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x1

    const/4 v10, 0x1

    if-ne v1, v2, :cond_5

    const/4 v11, 0x2

    goto/16 :goto_3

    :cond_5
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    sget-object v2, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->d:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x5

    if-eq v1, v2, :cond_8

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x2

    sget-object v2, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->f:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-ne v1, v2, :cond_6

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    goto/16 :goto_2

    :cond_6
    const/4 v10, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    sget-object v2, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->e:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x0

    if-ne v1, v2, :cond_7

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    const-string/jumbo v3, "irdr b esp,aa.aPey(detatRsseylEn.tMre"

    const-string/jumbo v3, "resnp.ra(RattMEe,es .dteaeailP)syrd y"

    const-string v3, "e alpsulisteMa,ntRaay.ere.)erEP tdyr("

    const-string/jumbo v3, "playerResetEnd,  MediaPlayer.start()."

    const/4 v11, 0x0

    invoke-virtual {v1, v3}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v10, 0x1

    move v11, v10

    invoke-virtual {v1}, Landroid/media/MediaPlayer;->start()V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    iget-object v0, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    iput-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->B()V

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x5

    goto/16 :goto_4

    :cond_7
    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    const-string/jumbo v3, "telela patss:lmtg, at"

    const-string v3, " esmttae: tgaalls,lte"

    const/4 v11, 0x1

    const-string/jumbo v3, "tel e:tlqi lsaeas,att"

    const-string/jumbo v3, "illegal state, state:"

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    iget-object v0, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x1

    invoke-virtual {v1, v0}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->i:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->e()V

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->x:Lcom/tencent/thumbplayer/adapter/a/c$f;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-eqz v1, :cond_a

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/16 v2, 0x7d0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x3

    const/16 v0, -0x2714

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->g(I)I

    move-result v3

    const/4 v11, 0x3

    const/4 v10, 0x1

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v11, 0x3

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v11, 0x4

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x5

    invoke-interface/range {v1 .. v7}, Lcom/tencent/thumbplayer/adapter/a/c$f;->a(IIJJ)V

    const/4 v11, 0x0

    const/4 v10, 0x7

    goto :goto_4

    :cond_8
    :goto_2
    const/4 v11, 0x1

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    goto :goto_4

    :cond_9
    :goto_3
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->d:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->u:Lcom/tencent/thumbplayer/adapter/a/c$i;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x0

    if-eqz v0, :cond_a

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/c$i;->a()V

    :cond_a
    :goto_4
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x6

    const/4 v0, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->S:Z

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x2

    const/4 v0, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x2

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ah:Lcom/tencent/thumbplayer/adapter/a/a/e$f;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x5

    monitor-exit p0

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x5

    return-void

    :cond_b
    :try_start_3
    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x1

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->m:I

    const/4 v11, 0x2

    if-lez v0, :cond_c

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x1

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->P:Z

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x3

    if-nez v0, :cond_c

    const/4 v11, 0x2

    const/4 v10, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v10, 0x4

    const/4 v11, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    const-string v2, " dsrnko, n)esaeep:dreotaP"

    const-string/jumbo v2, "nensoro)Ped(:adeetpak,  r"

    const/4 v11, 0x0

    const-string/jumbo v2, "r,dmren:dt)(o n ekoeaPaps"

    const-string/jumbo v2, "onPrepared(), and seekto:"

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x2

    shl-int/2addr v11, v10

    iget v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->m:I

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    const/4 v11, 0x3

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->m:I

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->seekTo(I)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x2

    goto :goto_5

    :catch_1
    move-exception v0

    :try_start_5
    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v1, v0}, Lcom/tencent/thumbplayer/e/a;->a(Ljava/lang/Exception;)V

    :cond_c
    :goto_5
    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x0

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->d:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->u:Lcom/tencent/thumbplayer/adapter/a/c$i;

    const/4 v10, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x6

    if-eqz v0, :cond_d

    const/4 v11, 0x3

    const/4 v10, 0x5

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/c$i;->a()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :cond_d
    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    monitor-exit p0

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    return-void

    :catchall_0
    move-exception v0

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x6

    monitor-exit p0

    const/4 v11, 0x4

    throw v0
.end method

.method static synthetic x(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/a/e$e;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method private x()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->s:Lcom/tencent/thumbplayer/api/TPAudioAttributes;

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->a(Lcom/tencent/thumbplayer/api/TPAudioAttributes;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method static synthetic y(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$j;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->y:Lcom/tencent/thumbplayer/adapter/a/c$j;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method private y()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnInfoListener(Landroid/media/MediaPlayer$OnInfoListener;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnBufferingUpdateListener(Landroid/media/MediaPlayer$OnBufferingUpdateListener;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnSeekCompleteListener(Landroid/media/MediaPlayer$OnSeekCompleteListener;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnVideoSizeChangedListener(Landroid/media/MediaPlayer$OnVideoSizeChangedListener;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void
.end method

.method static synthetic z(Lcom/tencent/thumbplayer/adapter/a/a/e;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    iget p0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->r:I

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return p0
.end method

.method private z()V
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string v1, "TeotoaikusePtTtierrcermrapehC"

    const-string/jumbo v1, "startCheckPrepareTimeoutTimer"

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->H:Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->G:Ljava/util/concurrent/Future;

    const/4 v6, 0x3

    move v7, v6

    if-nez v1, :cond_0

    invoke-static {}, Lcom/tencent/thumbplayer/utils/o;->a()Lcom/tencent/thumbplayer/utils/o;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/utils/o;->e()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x3

    new-instance v2, Lcom/tencent/thumbplayer/adapter/a/a/e$5;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-direct {v2, p0}, Lcom/tencent/thumbplayer/adapter/a/a/e$5;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e;)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-wide v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->I:J

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    sget-object v5, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-interface {v1, v2, v3, v4, v5}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->G:Ljava/util/concurrent/Future;

    :cond_0
    const/4 v6, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    monitor-exit v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    return-void

    :catchall_0
    move-exception v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    throw v1
.end method


# virtual methods
.method public a(F)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string/jumbo v1, "otsG bi:RanAie,udb ta"

    const-string v1, "eaRGtbiA  soiantd,:ou"

    const/4 v4, 0x1

    const-string/jumbo v1, "ntiad u ae,Ri:AisGoto"

    const-string/jumbo v1, "setAudioGainRatio, : "

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {p1}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->j:F

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    xor-int/2addr v4, v3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->j:F

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v0}, Landroid/media/MediaPlayer;->setVolume(FF)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-void

    :catch_0
    move-exception p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v2, "n:sataepxRu tuGiA  doie"

    const-string/jumbo v2, "io  eduetiaG:tAu asixnR"

    const/4 v4, 0x7

    const-string/jumbo v2, "setAudioGainRatio ex : "

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void
.end method

.method public a(I)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v1, "eTit ekoqooss inpp"

    const-string/jumbo v1, "spntT epk, ioesooi"

    const/4 v4, 0x4

    const-string v1, " Ts:pnkosieo,siet "

    const-string/jumbo v1, "seekTo, position: "

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->P:Z

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v0, "dn mqeuiacsekbene rrr, eiotmnegl a st"

    const-string v0, "e kierrsqt naogbertn,luee nd msoce ai"

    const/4 v4, 0x3

    const-string/jumbo v0, "oagao ec,nit reoeu einne trblmdi rske"

    const-string v0, "current media is not seekable, ignore"

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->S:Z

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ah:Lcom/tencent/thumbplayer/adapter/a/a/e$f;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    int-to-long v1, p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput-wide v1, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->c:J

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x6

    const/4 v3, 0x5

    if-ne v0, v1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->e:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    :cond_3
    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Landroid/media/MediaPlayer;->seekTo(I)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-void
.end method

.method public a(II)V
    .locals 5
    .param p2    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSeekMode;
        .end annotation
    .end param
    .annotation build Landroid/annotation/TargetApi;
        value = 0x1a
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x2

    const/4 v3, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string v2, " eps,bnoTiet ooi:s"

    const-string/jumbo v2, "tos:oTs oiesn,ei p"

    const/4 v4, 0x4

    const-string/jumbo v2, "i ipsTuoeno,skt eo"

    const-string/jumbo v2, "seekTo, position: "

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string v2, ", mode: "

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->P:Z

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x1

    const-string/jumbo p2, "td,sbnspa i grormni i euertmeceolnea "

    const-string/jumbo p2, "reimdeb t ecgro ssiti ne,amerle aunon"

    const/4 v4, 0x5

    const-string p2, "current media is not seekable, ignore"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->S:Z

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v0, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ah:Lcom/tencent/thumbplayer/adapter/a/a/e$f;

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz p2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x7

    int-to-long v0, p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-wide v0, p2, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->c:J

    :cond_1
    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {p0, v0, p1, p2}, Lcom/tencent/thumbplayer/adapter/a/a/e;->a(Landroid/media/MediaPlayer;II)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-void
.end method

.method public a(IJ)V
    .locals 12

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, " arkeIctqstTec,ckaDrl"

    const-string/jumbo v2, "selectTrack, trackID:"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " peaouoq:"

    const-string/jumbo v2, "uose,:qa "

    const-string v2, ", opaque:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ad:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ae:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ad:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    iget-object v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->w:Lcom/tencent/thumbplayer/adapter/a/c$h;

    const/16 v2, -0x2710

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-ltz p1, :cond_1

    if-ge p1, v0, :cond_1

    :try_start_0
    invoke-direct {p0, p1, p2, p3}, Lcom/tencent/thumbplayer/adapter/a/a/e;->d(IJ)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ad:Ljava/util/List;

    iget p3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->aa:I

    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/tencent/thumbplayer/adapter/a/a/e$b;

    iget-object p2, p2, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->a:Lcom/tencent/thumbplayer/api/TPTrackInfo;

    iput-boolean v11, p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ad:Ljava/util/List;

    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/tencent/thumbplayer/adapter/a/a/e$b;

    iget-object p2, p2, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->a:Lcom/tencent/thumbplayer/api/TPTrackInfo;

    iput-boolean v10, p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->aa:I

    return-void

    :catch_0
    move-exception p1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->a(Ljava/lang/Exception;)V

    if-eqz v3, :cond_0

    const/4 v4, 0x4

    const-wide/16 v5, 0x7d0

    const-wide/16 v5, 0x7d0

    const-wide/16 v5, 0x7d0

    const-wide/16 v5, 0x7d0

    invoke-static {v2}, Lcom/tencent/thumbplayer/adapter/a/a/e;->g(I)I

    move-result p1

    int-to-long v7, p1

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    invoke-interface/range {v3 .. v9}, Lcom/tencent/thumbplayer/adapter/a/c$h;->a(IJJLjava/lang/Object;)V

    :cond_0
    return-void

    :cond_1
    if-lt p1, v0, :cond_4

    add-int v4, v0, v1

    if-ge p1, v4, :cond_4

    sub-int v0, p1, v0

    :try_start_1
    invoke-direct {p0, v0, p2, p3}, Lcom/tencent/thumbplayer/adapter/a/a/e;->e(IJ)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :catch_1
    move-exception v4

    iget-object v5, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    invoke-virtual {v5, v4}, Lcom/tencent/thumbplayer/e/a;->a(Ljava/lang/Exception;)V

    if-eqz v3, :cond_2

    const/4 v4, 0x4

    const-wide/16 v5, 0x7d0

    const-wide/16 v5, 0x7d0

    const-wide/16 v5, 0x7d0

    const-wide/16 v5, 0x7d0

    invoke-static {v2}, Lcom/tencent/thumbplayer/adapter/a/a/e;->g(I)I

    move-result v2

    int-to-long v7, v2

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    invoke-interface/range {v3 .. v9}, Lcom/tencent/thumbplayer/adapter/a/c$h;->a(IJJLjava/lang/Object;)V

    :cond_2
    :goto_0
    iget p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ab:I

    if-ltz p2, :cond_3

    if-ge p2, v1, :cond_3

    iget-object p3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ae:Ljava/util/List;

    invoke-interface {p3, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/tencent/thumbplayer/adapter/a/a/e$b;

    iget-object p2, p2, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->a:Lcom/tencent/thumbplayer/api/TPTrackInfo;

    iput-boolean v11, p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    :cond_3
    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ae:Ljava/util/List;

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/tencent/thumbplayer/adapter/a/a/e$b;

    iget-object p2, p2, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->a:Lcom/tencent/thumbplayer/api/TPTrackInfo;

    iput-boolean v10, p2, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ab:I

    return-void

    :cond_4
    add-int/2addr v0, v1

    sub-int/2addr p1, v0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->d:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    if-eq v0, v1, :cond_5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->e:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    if-eq v0, v1, :cond_5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->f:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    if-eq v0, v1, :cond_5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string p3, "asgmlctb  traleels:Ttielae,"

    const-string p3, ":cellbTee rttel ailscata,gs"

    const-string/jumbo p3, "gsreotelt sla:ckieecatla l,"

    const-string/jumbo p3, "selectTrack, illegal state:"

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    return-void

    :cond_5
    :try_start_2
    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->getTrackInfo()[Landroid/media/MediaPlayer$TrackInfo;

    move-result-object v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    goto :goto_1

    :catch_2
    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const-string/jumbo v1, "kIe inu Tocahfneg, IrTcoaodgtastnrdcarkr"

    const-string/jumbo v1, "n r fbgtacdri,rsoIhdgacocTkae rToknantIf"

    const-string/jumbo v1, "getTrackInfo, android getTrackInfo crash"

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v0, 0x0

    :goto_1
    if-eqz v0, :cond_b

    array-length v1, v0

    if-gt v1, p1, :cond_6

    goto :goto_3

    :cond_6
    aget-object v0, v0, p1

    invoke-virtual {v0}, Landroid/media/MediaPlayer$TrackInfo;->getTrackType()I

    move-result v1

    const/4 v2, 0x2

    if-ne v1, v2, :cond_7

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ac:I

    goto :goto_2

    :cond_7
    invoke-virtual {v0}, Landroid/media/MediaPlayer$TrackInfo;->getTrackType()I

    move-result v0

    const/4 v1, 0x4

    if-ne v0, v1, :cond_9

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Z:I

    :goto_2
    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    invoke-virtual {v0, p1}, Landroid/media/MediaPlayer;->selectTrack(I)V

    if-eqz v3, :cond_8

    const/4 v4, 0x4

    const-wide/16 v5, 0x3e8

    const-wide/16 v5, 0x3e8

    const-wide/16 v5, 0x3e8

    const-wide/16 v5, 0x3e8

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    invoke-interface/range {v3 .. v9}, Lcom/tencent/thumbplayer/adapter/a/c$h;->a(IJJLjava/lang/Object;)V

    :cond_8
    return-void

    :cond_9
    if-eqz v3, :cond_a

    const/4 v4, 0x4

    const-wide/16 v5, 0x7d0

    const-wide/16 v5, 0x7d0

    const-wide/16 v5, 0x7d0

    const-wide/16 v5, 0x7d0

    const/16 p1, -0x2713

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/a/e;->g(I)I

    move-result p1

    int-to-long v7, p1

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    invoke-interface/range {v3 .. v9}, Lcom/tencent/thumbplayer/adapter/a/c$h;->a(IJJLjava/lang/Object;)V

    :cond_a
    return-void

    :cond_b
    :goto_3
    if-eqz v3, :cond_c

    const/4 v4, 0x4

    const-wide/16 v5, 0x7d0

    const-wide/16 v5, 0x7d0

    const-wide/16 v5, 0x7d0

    const-wide/16 v5, 0x7d0

    const/16 p1, -0x2712

    invoke-static {p1}, Lcom/tencent/thumbplayer/adapter/a/a/e;->g(I)I

    move-result p1

    int-to-long v7, p1

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    invoke-interface/range {v3 .. v9}, Lcom/tencent/thumbplayer/adapter/a/c$h;->a(IJJLjava/lang/Object;)V

    :cond_c
    return-void
.end method

.method public a(Landroid/content/res/AssetFileDescriptor;)V
    .locals 5

    const/4 v4, 0x3

    if-eqz p1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string v2, " SfDufuaouep0f tedaa s:cdc/ft"

    const-string v2, "affD ffpaa/sued tScaoecdut :0"

    const/4 v4, 0x4

    const-string/jumbo v2, "fsfatt pf0DS/c:u due daecfora"

    const-string/jumbo v2, "setDataSource afd\uff0c afd: "

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/content/res/AssetFileDescriptor;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->h:Landroid/content/res/AssetFileDescriptor;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/e;->b(Landroid/content/res/AssetFileDescriptor;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/a/c;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v0, p1}, Lcom/tencent/thumbplayer/a/c;-><init>(Landroid/content/res/AssetFileDescriptor;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->E:Lcom/tencent/thumbplayer/a/c;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    sget-object p1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->b:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x7

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string/jumbo v0, "ol ste  qDisa erlSdanutacq"

    const-string/jumbo v0, "fDeuia nqtldsSa teasrc ol "

    const/4 v4, 0x0

    const-string/jumbo v0, "s saret uifuocSsleta d Dna"

    const-string/jumbo v0, "setDataSource afd is null "

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo v0, "ufsmnlidl a"

    const-string/jumbo v0, "ulsdlni asf"

    const/4 v4, 0x0

    const-string v0, "adsiol  lfn"

    const-string v0, "afd is null"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    throw p1
.end method

.method public a(Landroid/os/ParcelFileDescriptor;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz p1, :cond_0

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string/jumbo v2, "tudfpb/reD:Somupea a0t d fccs"

    const-string v2, " fSmf/tdp ser cufDa:tep0ocuad"

    const/4 v4, 0x5

    const-string v2, "Dfopf utf:e s ufcupect/aSdadr"

    const-string/jumbo v2, "setDataSource pfd\uff0c pfd: "

    const/4 v4, 0x6

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    shl-int/2addr v4, v3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->g:Ljava/io/FileDescriptor;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setDataSource(Ljava/io/FileDescriptor;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/a/c;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v0, p1}, Lcom/tencent/thumbplayer/a/c;-><init>(Ljava/io/FileDescriptor;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->E:Lcom/tencent/thumbplayer/a/c;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object p1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->b:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string/jumbo v0, "srpnaoupa f ot iescedt Dul"

    const-string/jumbo v0, "fnd osla  olsuteciauetpDr "

    const/4 v4, 0x1

    const-string/jumbo v0, "s otS daqesicpaluf  Dtnrle"

    const-string/jumbo v0, "setDataSource pfd is null "

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x2

    move v4, v3

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x4

    const-string/jumbo v0, "snsuiplflbd"

    const-string v0, "duilfbn lps"

    const/4 v4, 0x6

    const-string/jumbo v0, "pfd is null"

    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    throw p1
.end method

.method public a(Landroid/view/Surface;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string/jumbo v2, "s umaru:strc,affSece "

    const-string v2, "e sce:uacasrfrfu,tSu "

    const/4 v4, 0x4

    const-string/jumbo v2, "ssctouca aSe,:eeuf fr"

    const-string/jumbo v2, "setSurface, surface: "

    const/4 v4, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->F:Ljava/lang/Object;

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Landroid/media/MediaPlayer;->setSurface(Landroid/view/Surface;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x6

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string/jumbo v1, "uerS ,rpcrsavaf cfseet :oe"

    const-string/jumbo v1, "setSurface over, surface: "

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-void
.end method

.method public a(Landroid/view/SurfaceHolder;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v2, "SHo:rb,s uteefeqr cdls"

    const-string/jumbo v2, "te,od:HeqcSslaurrs e f"

    const/4 v4, 0x7

    const-string v2, "HslufsucSre erh:te doa"

    const-string/jumbo v2, "setSurfaceHolder, sh: "

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->F:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Landroid/media/MediaPlayer;->setDisplay(Landroid/view/SurfaceHolder;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const-string v1, ":v d eope ,asetrrsusrhfeScl"

    const-string/jumbo v1, "ohsr ecs:u fseodr eva,reltS"

    const/4 v4, 0x6

    const-string/jumbo v1, "tsoa: esqoerS vfHhleer, ruc"

    const-string/jumbo v1, "setSurfaceHolder over, sh: "

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$a;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-string/jumbo v0, "oes u ntitlynptcs oueasadpsaMrar redmou ytopaimef"

    const-string/jumbo v0, "spMmoarmy r eapoi et refun  tsdtcouapsultodeianya"

    const/4 v2, 0x7

    const-string v0, " ummnarayeatsdanm Mporc itipe osdy rtefp uoauosle"

    const-string/jumbo v0, "system Mediaplayer cannot support audio frame out"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$b;)V
    .locals 3

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string v0, "doetornrsue yliaamruasttpps occes npis aue ap drfooypmotosMet"

    const-string/jumbo v0, "iaraons cstmMpunsay opfelat u reiredo tsdyeeompoospptcsuotr a"

    const/4 v2, 0x4

    const-string/jumbo v0, "system Mediaplayer cannot support audio postprocess frame out"

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$c;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->v:Lcom/tencent/thumbplayer/adapter/a/c$c;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$d;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$e;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$f;)V
    .locals 2

    const/4 v0, 0x2

    move v1, v0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->x:Lcom/tencent/thumbplayer/adapter/a/c$f;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$g;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$h;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->w:Lcom/tencent/thumbplayer/adapter/a/c$h;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$i;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->u:Lcom/tencent/thumbplayer/adapter/a/c$i;

    const/4 v1, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$j;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->y:Lcom/tencent/thumbplayer/adapter/a/c$j;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$l;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->A:Lcom/tencent/thumbplayer/adapter/a/c$l;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$m;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->B:Lcom/tencent/thumbplayer/adapter/a/c$m;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$n;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string/jumbo v0, "uum nbbetsyldooriarsnsaeempttav ee ydtrp iM aocf "

    const-string/jumbo v0, "lyaatbet reiur otaeeuMmi snppasmy of c otnodesdrv"

    const/4 v2, 0x4

    const-string v0, " eurtoumatsr yemyrc  sne pa Moueiloapnedsovdiafpt"

    const-string/jumbo v0, "system Mediaplayer cannot support video frame out"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$o;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string v0, "drtotespiM ctsnoytope dlteymsrpppaumuceoionprvs a f auoeessr "

    const-string/jumbo v0, "ioyMeeuavostcsl ior ptepoormnp  dadctssmpfreo urtpesuaysen ta"

    const-string v0, " serelnvqyctss ptofode ma drt yopt s spopmaruaeMauoicnsoetipe"

    const-string/jumbo v0, "system Mediaplayer cannot support video postprocess frame out"

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$p;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->z:Lcom/tencent/thumbplayer/adapter/a/c$p;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPCaptureParams;Lcom/tencent/thumbplayer/api/TPCaptureCallBack;)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->E:Lcom/tencent/thumbplayer/a/c;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    new-instance v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget v1, p1, Lcom/tencent/thumbplayer/api/TPCaptureParams;->width:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput v1, v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->width:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v1, p1, Lcom/tencent/thumbplayer/api/TPCaptureParams;->height:I

    const/4 v3, 0x0

    move v4, v3

    iput v1, v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->height:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget v1, p1, Lcom/tencent/thumbplayer/api/TPCaptureParams;->format:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput v1, v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->format:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-wide v1, p1, Lcom/tencent/thumbplayer/api/TPCaptureParams;->requestedTimeMsToleranceBefore:J

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-wide v1, v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->requestedTimeMsToleranceBefore:J

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-wide v1, p1, Lcom/tencent/thumbplayer/api/TPCaptureParams;->requestedTimeMsToleranceAfter:J

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput-wide v1, v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->requestedTimeMsToleranceAfter:J

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->E:Lcom/tencent/thumbplayer/a/c;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->n()J

    move-result-wide v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1, v1, v2, v0, p2}, Lcom/tencent/thumbplayer/a/c;->a(JLcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;Lcom/tencent/thumbplayer/api/TPCaptureCallBack;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    const p1, 0xf424d

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {p2, p1}, Lcom/tencent/thumbplayer/api/TPCaptureCallBack;->onCaptureVideoFailed(I)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPOptionalParam;)V
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getKey()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 v1, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eq v0, v1, :cond_e

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eq v0, v2, :cond_d

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v2, 0x3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eq v0, v2, :cond_c

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/4 v2, 0x4

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eq v0, v2, :cond_b

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v1, 0x5

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eq v0, v1, :cond_a

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v1, 0x7

    const/4 v6, 0x0

    const-string/jumbo v2, "s)m("

    const-string v2, ")s(m"

    const/4 v6, 0x1

    const-string v2, ")s(m"

    const-string v2, "(ms)"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-wide/16 v3, 0x190

    const-wide/16 v3, 0x190

    const/4 v6, 0x5

    const-wide/16 v3, 0x190

    const-wide/16 v3, 0x190

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-eq v0, v1, :cond_9

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/16 v1, 0x64

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eq v0, v1, :cond_8

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/16 v1, 0x6b

    const/4 v6, 0x2

    if-eq v0, v1, :cond_7

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/16 v1, 0x80

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eq v0, v1, :cond_6

    const/4 v5, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/16 v1, 0x19e

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eq v0, v1, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/16 v1, 0x1c2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string v2, "PsseSeaiyyrPmdltMTa"

    const-string v2, "TPSystemMediaPlayer"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eq v0, v1, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/16 v1, 0x1f4

    const/4 v5, 0x5

    move v6, v5

    if-eq v0, v1, :cond_2

    const/4 v6, 0x4

    const/16 v1, 0x1fb

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eq v0, v1, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto/16 :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamObject()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object p1, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;->objectValue:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    check-cast p1, Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;

    const/4 v6, 0x1

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v0, :cond_1

    const/4 v5, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/a/a;->a(Lcom/tencent/thumbplayer/api/TPSubtitleRenderModel;)V

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string p1, "blamenup Orlneopyastemrliar  dmlePst,trteiaeP"

    const-string/jumbo p1, "lt,aplmpidndreiO aeouarlrtastteye ensb rPlPem"

    const/4 v6, 0x7

    const-string p1, "alstoonuemOatersyeo,ddPelereabmlPnr ltr pia t"

    const-string/jumbo p1, "setPlayerOptionalParam, subtitle render model"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    return-void

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    iget-wide v0, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    iput-wide v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->n:J

    const/4 v6, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const-string/jumbo v1, "ttppab s nPOyariqlsoPekao:oaelnni,redsiitp"

    const-string/jumbo v1, "yaasnpt qnidkpeeot:saeP,riPltlisnopO  oari"

    const-string/jumbo v1, "tyl a upeipaePsodnkamipOsr oin:talP,erntio"

    const-string/jumbo v1, "setPlayerOptionalParam, skip end position:"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-wide v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->n:J

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    return-void

    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-wide v0, v0, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v6, 0x3

    long-to-int v0, v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz v1, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-interface {v1, v0}, Lcom/tencent/thumbplayer/adapter/a/a/a;->a(I)V

    :cond_4
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const-string/jumbo v1, "p,ptnePp ye stobremtPlirlaaauOl:itetay"

    const-string/jumbo v1, "setPlayerOptionalParam, subtitle type:"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-wide v3, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {v2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    return-void

    :cond_5
    const/4 v6, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamObject()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object p1, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamObject;->objectValue:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    check-cast p1, Lcom/tencent/thumbplayer/api/TPAudioAttributes;

    const/4 v6, 0x0

    const/4 v5, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->s:Lcom/tencent/thumbplayer/api/TPAudioAttributes;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string/jumbo v1, "setPlayerOptionalParam, "

    const-string/jumbo v1, "setPlayerOptionalParam, "

    const/4 v6, 0x1

    const-string/jumbo v1, "setPlayerOptionalParam, "

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->s:Lcom/tencent/thumbplayer/api/TPAudioAttributes;

    const/4 v5, 0x4

    move v6, v5

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/api/TPAudioAttributes;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    return-void

    :cond_6
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-wide v0, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v5, 0x7

    or-int/2addr v6, v5

    iput-wide v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->I:J

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x6

    move v6, v5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string v1, " oraeauaqmoseismie lapPtteePypOrnal:rtrt"

    const-string v1, "ees tel tuOerpmratreroPnmo:tPapisalypaai"

    const/4 v6, 0x0

    const-string/jumbo v1, "setPlayerOptionalParam, prepare timeout:"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-wide v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->I:J

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    return-void

    :cond_7
    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-wide v0, v0, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    add-long/2addr v0, v3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    div-long/2addr v0, v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    long-to-int v0, v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->M:I

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string/jumbo v3, "tlsPmefieoufaant O eaPiayrtsubrteplr,m:"

    const-string/jumbo v3, "setPlayerOptionalParam, buffer timeout:"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x0

    iget-wide v3, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v1, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    move v6, v5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    return-void

    :cond_8
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-wide v0, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    long-to-int p1, v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->m:I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string/jumbo v1, "ioPmtsotiamep:nrt naOsl,ateP mlorrptiaa"

    const-string/jumbo v1, "etomar aiolsstr:PatoltipaOnpr,snmei tPa"

    const/4 v6, 0x4

    const-string/jumbo v1, "oatroitPyootlPpaOmstpi,nsrara n :lstaie"

    const-string/jumbo v1, "setPlayerOptionalParam, start position:"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    shl-int/2addr v6, v5

    iget v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->m:I

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    return-void

    :cond_9
    const/4 v6, 0x2

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-wide v0, v0, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v6, 0x5

    const/4 v5, 0x4

    div-long/2addr v0, v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    long-to-int v0, v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->L:I

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v6, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string v3, "btPtoPosa m:,oOalnfyeitupnearolrrta uf mie"

    const/4 v6, 0x4

    const-string/jumbo v3, "etit bsnfrutlPfoaaPpeu,ytm iralmOeoobre an"

    const-string/jumbo v3, "setPlayerOptionalParam, on buffer timeout:"

    const/4 v6, 0x0

    const/4 v5, 0x4

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-wide v3, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    invoke-virtual {v1, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v6, 0x6

    return-void

    :cond_a
    const/4 v6, 0x3

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamBoolean()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-boolean p1, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;->value:Z

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput-boolean p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->t:Z

    const/4 v6, 0x2

    return-void

    :cond_b
    const/4 v6, 0x3

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamBoolean()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-boolean p1, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamBoolean;->value:Z

    const/4 v6, 0x5

    iput-boolean p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->o:Z

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    iput-boolean v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->P:Z

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string v1, ",alv iuyale eeros:ntPsapitrPOimb"

    const-string v1, "aili,bminrvPat:seetaplsOPoel  ry"

    const/4 v6, 0x1

    const-string/jumbo v1, "li mPPOpirll,:say aetrepovasiaen"

    const-string/jumbo v1, "setPlayerOptionalParam, is live:"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x7

    iget-boolean v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->o:Z

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-void

    :cond_c
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x0

    iget-wide v0, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    long-to-int p1, v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->q:I

    const/4 v6, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v6, 0x3

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string v1, " Pmiyei qaeu,aharPtsdlotOotveihael:rn"

    const-string/jumbo v1, "yorerauOPadsnat ht,eeiil l:ogtmPhvaie"

    const/4 v6, 0x6

    const-string v1, " hsl,oeae:lPgnatvOtei Paamirdoseythri"

    const-string/jumbo v1, "setPlayerOptionalParam, video height:"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    iget v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->q:I

    const/4 v5, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    return-void

    :cond_d
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-wide v0, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    long-to-int p1, v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->r:I

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string v1, ":tvmplOiwaaymotes, pPtrPed aeolnhiir"

    const-string/jumbo v1, "oaropttpwea nsdllatmeOvryePi ih:P,di"

    const/4 v6, 0x3

    const-string/jumbo v1, "oelPohvttmadradOpr,etPsae:wi  aiioyl"

    const-string/jumbo v1, "setPlayerOptionalParam, video width:"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->r:I

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-void

    :cond_e
    const/4 v6, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-wide v0, p1, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    iput-wide v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->p:J

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string v0, "dotylbbans reeuacass utdD tmetapeqSpedaoiraroir,on typ "

    const-string/jumbo v0, "pntybidaqeoinm ra ,ptyluerdar D esa ttrusoSecsseoptdaao"

    const/4 v2, 0x6

    const-string/jumbo v0, "y,p utudrdaoaeemn iayaSor s atsinDoastploeetpusdrb et r"

    const-string/jumbo v0, "setDataSource by asset, android mediaplayer not support"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;IJ)V
    .locals 2
    .param p2    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSwitchDefMode;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/e/b;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x5

    const/4 v3, 0x2

    new-instance v1, Lcom/tencent/thumbplayer/e/b;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string/jumbo v2, "yaesydmpsMPleterSiT"

    const-string v2, "edstPymieSreyslTMPa"

    const/4 v4, 0x5

    const-string/jumbo v2, "eysiydaPqlMtmeTaeSP"

    const-string v2, "TPSystemMediaPlayer"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v1, p1, v2}, Lcom/tencent/thumbplayer/e/b;-><init>(Lcom/tencent/thumbplayer/e/b;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->a(Lcom/tencent/thumbplayer/e/b;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string/jumbo v0, "tPsroreo ezm.aemaanloAutiiolspdm pNsmsuVrude"

    const-string v0, "PlampriimNeedsa tpaznludtmsemeooourAourVs .o"

    const/4 v2, 0x4

    const-string/jumbo v0, "uommmA oszotnompore.uPsutlaardae VseiNirpdlt"

    const-string/jumbo v0, "setAudioNormalizeVolumeParams not supported."

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public a(Ljava/lang/String;IJ)V
    .locals 4
    .param p2    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSwitchDefMode;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo v1, "o,rtodt Dwinlc sineeoffUih"

    const-string v1, ":, loietfdsthnnrDii ecowUf"

    const/4 v3, 0x1

    const-string v1, "eDcnUb t:n,efo liihtiwsrfd"

    const-string/jumbo v1, "switchDefinition, defUrl: "

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    invoke-virtual {p2, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v2, 0x4

    move v3, v2

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string/jumbo p2, "onlhfiuctessnl ,r Dwfib liUietdu"

    const-string p2, "UiD  berdfoninfulsth lit,iwslcen"

    const/4 v3, 0x6

    const-string/jumbo p2, "sfDUnitpel l  dscfiniehitru,niwo"

    const-string/jumbo p2, "switchDefinition, defUrl is null"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->f:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance p2, Lcom/tencent/thumbplayer/adapter/a/a/e$f;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {p2, v0}, Lcom/tencent/thumbplayer/adapter/a/a/e$f;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e$1;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-wide p3, p2, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->b:J

    const/4 v3, 0x1

    iget p3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->aa:I

    const/4 v3, 0x0

    iput p3, p2, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->d:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 p3, 0x1

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput p3, p2, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->a:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object p1, p2, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->g:Ljava/lang/String;

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {p0, p2}, Lcom/tencent/thumbplayer/adapter/a/a/e;->a(Lcom/tencent/thumbplayer/adapter/a/a/e$f;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void

    :catch_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo p2, "lstepayuqatreeSR"

    const-string/jumbo p2, "selyrSuRtreteaap"

    const/4 v3, 0x5

    const-string p2, "SssetprttylRarae"

    const-string/jumbo p2, "playerResetStart"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    throw p1
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string/jumbo v2, "tppmHt,telao dtaserr:u rauceeDh"

    const-string/jumbo v2, "p ulastpt:rueco, rahDetr atdeHe"

    const/4 v4, 0x5

    const-string v2, "a haoeleDt eaeu:rru d,tttrcsSoH"

    const-string/jumbo v2, "setDataSource httpHeader, url: "

    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->f:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->l:Ljava/util/Map;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->b:Landroid/content/Context;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->l:Ljava/util/Map;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1, p2, v2}, Landroid/media/MediaPlayer;->setDataSource(Landroid/content/Context;Landroid/net/Uri;Ljava/util/Map;)V

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance p2, Lcom/tencent/thumbplayer/a/c;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {p2, p1}, Lcom/tencent/thumbplayer/a/c;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->E:Lcom/tencent/thumbplayer/a/c;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    sget-object p1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->b:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;IJ)V
    .locals 3
    .param p3    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSwitchDefMode;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;IJ)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string/jumbo v0, "qsUw bti nornhe:edltifDifc"

    const-string/jumbo v0, "tin eisfqUineftrDoci:d lwh"

    const/4 v2, 0x1

    const-string/jumbo v0, "fiw:n,utlhenrtUfi idesocDi"

    const-string/jumbo v0, "switchDefinition, defUrl: "

    const/4 v2, 0x0

    invoke-virtual {v0, p3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p2, p3}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz p2, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string/jumbo p2, "l sirneplsd wDtfho etuinfilU,sni"

    const-string/jumbo p2, "shser nDidlnsiie ll twno,uUftfic"

    const/4 v2, 0x2

    const-string/jumbo p2, "oun litDq wl ciefnsnhleisfdiUir,"

    const-string/jumbo p2, "switchDefinition, defUrl is null"

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->f:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance p2, Lcom/tencent/thumbplayer/adapter/a/a/e$f;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 p3, 0x0

    const/4 v2, 0x0

    invoke-direct {p2, p3}, Lcom/tencent/thumbplayer/adapter/a/a/e$f;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e$1;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-wide p4, p2, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->b:J

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget p3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->aa:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput p3, p2, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->d:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 p3, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput p3, p2, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->a:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object p1, p2, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->g:Ljava/lang/String;

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, p2}, Lcom/tencent/thumbplayer/adapter/a/a/e;->a(Lcom/tencent/thumbplayer/adapter/a/a/e$f;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void

    :catch_0
    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string p2, "aRsletayreetsmSr"

    const-string p2, "aRemeetaSrpsrlty"

    const-string p2, "aytmrespleteaRrS"

    const-string/jumbo p2, "playerResetStart"

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    throw p1
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p3

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez p3, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p3

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz p3, :cond_0

    const/4 v3, 0x3

    goto/16 :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance p3, Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {p3}, Lcom/tencent/thumbplayer/api/TPTrackInfo;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    iput-object p4, p3, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-boolean v0, p3, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isExclusive:Z

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-boolean v0, p3, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isInternal:Z

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-boolean v0, p3, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    const/4 v3, 0x1

    const/4 v0, 0x3

    and-int/2addr v2, v0

    const/4 v3, 0x6

    iput v0, p3, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/a/e$b;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Lcom/tencent/thumbplayer/adapter/a/a/e$b;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e$1;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object p3, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->a:Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object p1, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->b:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput-object p2, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->d:Ljava/util/Map;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    move v3, v2

    const-string/jumbo v1, "onato,oudiSacu drSlebmee"

    const-string v1, "Soduoteirbande,lmSace: u"

    const/4 v3, 0x7

    const-string v1, "cenobblSdd ,aumuSaeit:rt"

    const-string v1, "addSubtitleSource, name:"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    iget-object p3, p3, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo p3, "u:r,lb"

    const-string p3, " ,:rlb"

    const/4 v3, 0x5

    const-string p3, ":p ,ru"

    const-string p3, ", url:"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p2, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ae:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    return-void

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string p2, "derrabcuqlelmuSS n,aoeatd.leugltti i"

    const-string p2, "addSubtitleSource, illegal argument."

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/TPOptionalParam;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    goto/16 :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPTrackInfo;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput-object p3, v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x1

    iput-boolean v1, v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isExclusive:Z

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x2

    iput-boolean v1, v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isInternal:Z

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-boolean v1, v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v1, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput v1, v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-instance v1, Lcom/tencent/thumbplayer/adapter/a/a/e$b;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v1, v2}, Lcom/tencent/thumbplayer/adapter/a/a/e$b;-><init>(Lcom/tencent/thumbplayer/adapter/a/a/e$1;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput-object v0, v1, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->a:Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v4, 0x5

    const/4 v3, 0x2

    iput-object p1, v1, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->b:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput-object p2, v1, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->d:Ljava/util/Map;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object p4, v1, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->c:Ljava/util/List;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo p4, "uus,Aaro:daoTreac dudkcnim"

    const-string p4, "ca ,oiudeacurTndrAko:umdaS"

    const/4 v4, 0x4

    const-string/jumbo p4, "roomerSauaTkAc ,d:uidemand"

    const-string p4, "addAudioTrackSource, name:"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {p2, p4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object p4, v0, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p2, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string p4, " rplo:"

    const-string p4, " pr:lu"

    const/4 v4, 0x4

    const-string p4, ", url:"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p2, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ad:Ljava/util/List;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void

    :cond_1
    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string/jumbo p2, "lSieebe gducolkad.ulromqatrarnaTu i,Ag"

    const-string p2, "aSegrclgqTnaimcrtal,Ae.da dloueiou ruk"

    const/4 v4, 0x2

    const-string p2, "addAudioTrackSource, illegal argument."

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void
.end method

.method public a(Z)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x3

    const-string/jumbo v1, "u:t tuuset ,MtuOp"

    const-string/jumbo v1, "uus t ,eOttts:Mpu"

    const/4 v4, 0x4

    const-string v1, "Oute :tppu set,ut"

    const-string/jumbo v1, "setOutputMute, : "

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    iput-boolean p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->i:Z

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz p1, :cond_0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v0}, Landroid/media/MediaPlayer;->setVolume(FF)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v0, ", ettueuqtMsupuOter"

    const-string/jumbo v0, "setOutputMute, true"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->j:F

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v0}, Landroid/media/MediaPlayer;->setVolume(FF)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string/jumbo v1, "eus timMAt s n,uueOsG,afoiu:mdplet"

    const-string/jumbo v1, "i,um  aes ntue:tmldutuMptGAeiof,sO"

    const/4 v4, 0x4

    const-string/jumbo v1, "u nmletttOeiiuaAum, pftsoaG,Mue :d"

    const-string/jumbo v1, "setOutputMute, false, mAudioGain: "

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->j:F

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void

    :catch_0
    move-exception p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string v2, " eououOis:tnuetEx poectpt,"

    const-string/jumbo v2, "ptsco,eptxt eeEinOut uuto:"

    const-string v2, ",:Ouubnptttcpxett MuesiEeo"

    const-string/jumbo v2, "setOutputMute, Exception: "

    const/4 v4, 0x1

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x2

    move v4, v3

    return-void
.end method

.method public a(ZJJ)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string/jumbo v2, "teo: bs ko,pbcL"

    const/4 v4, 0x7

    const-string/jumbo v2, "setLoopback, : "

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo v2, "opu:,lu  oSrt"

    const-string/jumbo v2, "rp:,otu Solt "

    const/4 v4, 0x5

    const-string/jumbo v2, "tS, l ppo:art"

    const-string v2, ", loopStart: "

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const-string/jumbo v2, "ld,n:  pqoE"

    const-string v2, ", oln :pdEo"

    const/4 v4, 0x3

    const-string/jumbo v2, "ods o,:nlpE"

    const-string v2, ", loopEnd: "

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    invoke-virtual {v1, p4, p5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    cmp-long v0, p2, v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-ltz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-wide v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->T:J

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    cmp-long v2, p2, v0

    const/4 v4, 0x3

    if-gtz v2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    cmp-long v0, p4, v0

    const/4 v4, 0x5

    if-gtz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-boolean p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->c:Z

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput-wide p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->d:J

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput-wide p4, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->e:J

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p2, p1}, Landroid/media/MediaPlayer;->setLooping(Z)V

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const-string/jumbo p2, "hlemirru0npiuoo arsdnonan,  ath i mo tdeor tmntssqase t"

    const-string p2, "detiaonnqnpotsohrasrr,an mo0sra l et u  dusiehm  tntrio"

    const/4 v4, 0x1

    const-string p2, "dthoonemriaptm0n ostrs uldna  ah  ,aur iset ernorosn it"

    const-string/jumbo p2, "position error, must more than 0 and less than duration"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    throw p1
.end method

.method public b(I)J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-wide v0
.end method

.method public b(F)V
    .locals 5
    .annotation build Landroid/annotation/TargetApi;
        value = 0x17
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const-string v1, "RdisebtloystPe a,aSp "

    const-string/jumbo v1, "eysa,doaePRit:p S tls"

    const/4 v4, 0x6

    const-string v1, ",eo yeuPta epaSdis:Rl"

    const-string/jumbo v1, "setPlaySpeedRatio, : "

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {p1}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->k:F

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string v1, "ae:deitpyeSsaplRymdetpp s oae"

    const-string/jumbo v1, "lsRmyldapteS e:dtea poyeseipa"

    const-string/jumbo v1, "yeeeasytqaedPoeaptipsR : lSpl"

    const-string/jumbo v1, "setPlaySpeedRatio play speed:"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {p1}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->getPlaybackParams()Landroid/media/PlaybackParams;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/media/PlaybackParams;->getSpeed()F

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    cmpl-float v1, v1, p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Landroid/media/PlaybackParams;->setSpeed(F)Landroid/media/PlaybackParams;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Landroid/media/MediaPlayer;->setPlaybackParams(Landroid/media/PlaybackParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void

    :catch_0
    move-exception p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->a(Ljava/lang/Exception;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void
.end method

.method public b(IJ)V
    .locals 5
    .annotation build Landroid/annotation/TargetApi;
        value = 0x10
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo v1, "kIs deaTce s,rrtacloDck"

    const-string v1, "esdcokI cDlrcttra ,eTka"

    const/4 v4, 0x3

    const-string/jumbo v1, "kclm ecacsrtIaeteTDd,rk"

    const-string v1, "deselectTrack, trackID "

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ad:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ae:Ljava/util/List;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-lt p1, v0, :cond_0

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    add-int/2addr v1, v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-ge p1, v1, :cond_0

    const/4 v4, 0x2

    sub-int/2addr p1, v0

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p0, p1, p2, p3}, Lcom/tencent/thumbplayer/adapter/a/a/e;->f(IJ)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :catch_0
    move-exception p2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object p3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p3, p2}, Lcom/tencent/thumbplayer/e/a;->a(Ljava/lang/Exception;)V

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ae:Ljava/util/List;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    check-cast p1, Lcom/tencent/thumbplayer/adapter/a/a/e$b;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object p1, p1, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->a:Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 p2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput-boolean p2, p1, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 p1, -0x1

    const/4 v4, 0x2

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ab:I

    const/4 v4, 0x7

    return-void

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p2, p1}, Landroid/media/MediaPlayer;->deselectTrack(I)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void
.end method

.method public b(Z)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const-string v1, "cstaopoL obb:, "

    const-string v1, "apso:bte ,Lcbo "

    const/4 v4, 0x7

    const-string/jumbo v1, "pek,tbLosoc ba "

    const-string/jumbo v1, "setLoopback, : "

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-boolean p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->c:Z

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Landroid/media/MediaPlayer;->setLooping(Z)V

    const/4 v4, 0x7

    return-void
.end method

.method public c(Z)Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x5

    return-object p1
.end method

.method public c(I)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x0

    move v0, p1

    move v0, p1

    return-object p1
.end method

.method public c(IJ)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const-string/jumbo p2, "gteyiuumdomradp, tPeeelosrtaocpnnrpori lsauard"

    const-string p2, "dyriraumucre tot laPoanneemrgdsa do,psppotirle"

    const/4 v1, 0x0

    const-string p2, "Ppuottrpidia  drsomet, alpdmyo nrsgareneeoplar"

    const-string/jumbo p2, "selectProgram, android mediaplayer not support"

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public f()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string v1, "ee)ratoPqcmel aiPrtM=rELepS(MaCOae=yplpa lndE"

    const-string/jumbo v1, "oeOatyPpdM=TcEnrrMep EeeatlPpi (aCm=)reSLaall"

    const/4 v3, 0x3

    const-string v1, "call prepare() on mMediaPlayerState==COMPLETE"

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->x()V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v1, "e saeprr"

    const-string/jumbo v1, "prepare "

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->c:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->prepare()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public g()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->x()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const-string/jumbo v1, "ppam ncesrqrA"

    const-string v1, "Ayacppreq snr"

    const/4 v3, 0x5

    const-string/jumbo v1, "pyrcos aenApe"

    const-string/jumbo v1, "prepareAsync "

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->c:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->prepareAsync()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->z()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public h()V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string/jumbo v1, "stt rb"

    const-string/jumbo v1, "trsat "

    const/4 v6, 0x7

    const-string/jumbo v1, "ut rst"

    const-string/jumbo v1, "start "

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v6, 0x2

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->S:Z

    const/4 v5, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ah:Lcom/tencent/thumbplayer/adapter/a/a/e$f;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->e:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    iput-object v1, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const-string/jumbo v1, "seyyse pysbaiur.lpm s "

    const-string/jumbo v1, "system player is busy."

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    return-void

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->d:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v6, 0x2

    const/4 v5, 0x0

    if-eq v0, v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->f:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v6, 0x7

    const/4 v5, 0x2

    if-eq v0, v1, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string v2, ":eti)(,lqslreeam atatss t,tg t"

    const-string/jumbo v2, "tgsmaeet t la:i,r,)s llattset("

    const/4 v6, 0x4

    const-string/jumbo v2, "t saralsttaislg e)t:esltea,t, "

    const-string/jumbo v2, "start(), illegal state, state:"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    shr-int/2addr v6, v5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    goto :goto_0

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eqz v0, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/a/a;->b()V

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->start()V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->e:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->k:F

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    float-to-double v1, v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    const/4 v6, 0x7

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    const/4 v5, 0x4

    const/4 v5, 0x5

    cmpl-double v1, v1, v3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz v1, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->b(F)V

    :cond_4
    const/4 v6, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->B()V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-void
.end method

.method public declared-synchronized i()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo v1, "ousma "

    const-string v1, "aupso "

    const/4 v3, 0x2

    const-string/jumbo v1, "uep os"

    const-string/jumbo v1, "pause "

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->S:Z

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ah:Lcom/tencent/thumbplayer/adapter/a/a/e$f;

    const/4 v2, 0x6

    move v3, v2

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->f:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object v1, v0, Lcom/tencent/thumbplayer/adapter/a/a/e$f;->h:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const-string v1, "bly.rbm yisase yseptus"

    const-string v1, ".u psb tssirbysyeemlay"

    const/4 v3, 0x6

    const-string/jumbo v1, "msui yues seyrb.syalt "

    const-string/jumbo v1, "system player is busy."

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    monitor-exit p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void

    :cond_1
    :try_start_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/a/a;->c()V

    :cond_2
    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->pause()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->f:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    monitor-exit p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    monitor-exit p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    throw v0
.end method

.method public declared-synchronized j()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo v1, "u ppo"

    const-string v1, " upot"

    const-string/jumbo v1, "tpsq "

    const-string/jumbo v1, "stop "

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->A()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->C()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->F()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->g:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->c()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->aa:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ab:I

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x5

    move v2, v1

    move v2, v1

    const/4 v3, 0x7

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ah:Lcom/tencent/thumbplayer/adapter/a/a/e$f;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Z:I

    const/4 v3, 0x4

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ac:I

    const/4 v2, 0x0

    move v3, v2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/a/a;->d()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-wide v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ag:J

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v2, 0x4

    move v3, v2

    const-string/jumbo v1, "p.seorpst "

    const-string v1, "eot. spprv"

    const/4 v3, 0x5

    const-string/jumbo v1, "t.ompr ves"

    const-string/jumbo v1, "stop over."

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    monitor-exit p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    monitor-exit p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    throw v0
.end method

.method public declared-synchronized k()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string/jumbo v1, "rt qoe"

    const-string v1, " eqsrt"

    const/4 v4, 0x4

    const-string/jumbo v1, "ts reb"

    const-string/jumbo v1, "reset "

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->a:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->R:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v4, 0x0

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/a/a;->e()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->reset()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->m:I

    const/4 v4, 0x7

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x0

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x3

    iput-wide v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->n:J

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->o:Z

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput-wide v1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->p:J

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    const/4 v0, -0x1

    or-int/2addr v4, v0

    const/4 v3, 0x0

    move v4, v3

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->q:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->r:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->s:Lcom/tencent/thumbplayer/api/TPAudioAttributes;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->A()V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->C()V

    const/4 v3, 0x2

    move v4, v3

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->F()V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const-string v1, "e.s rvurtos"

    const-string/jumbo v1, "vtso es.err"

    const/4 v4, 0x0

    const-string v1, "eer.srepo t"

    const-string/jumbo v1, "reset over."

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    monitor-exit p0

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    return-void

    :catchall_0
    move-exception v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    monitor-exit p0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    throw v0
.end method

.method public declared-synchronized l()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string/jumbo v1, "qaeelre "

    const-string v1, " lemreae"

    const/4 v3, 0x7

    const-string v1, "eesa lsr"

    const-string/jumbo v1, "release "

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->af:Lcom/tencent/thumbplayer/adapter/a/a/a;

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/a/a;->f()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->A()V

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->C()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->F()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->j:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->e()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->u:Lcom/tencent/thumbplayer/adapter/a/c$i;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->v:Lcom/tencent/thumbplayer/adapter/a/c$c;

    const/4 v3, 0x2

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->w:Lcom/tencent/thumbplayer/adapter/a/c$h;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->x:Lcom/tencent/thumbplayer/adapter/a/c$f;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->y:Lcom/tencent/thumbplayer/adapter/a/c$j;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->z:Lcom/tencent/thumbplayer/adapter/a/c$p;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->A:Lcom/tencent/thumbplayer/adapter/a/c$l;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->F:Ljava/lang/Object;

    const/4 v2, 0x3

    or-int/2addr v3, v2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x5

    const-string v1, "eeomvrer.leas"

    const-string/jumbo v1, "oelaoersrve.e"

    const/4 v3, 0x3

    const-string v1, "aleroeo. esev"

    const-string/jumbo v1, "release over."

    const/4 v3, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    monitor-exit p0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    monitor-exit p0

    const/4 v2, 0x3

    shl-int/2addr v3, v2

    throw v0
.end method

.method public m()J
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->o:Z

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v8, 0x5

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-eqz v0, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    return-wide v1

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->S:Z

    const/4 v8, 0x1

    if-eqz v0, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x6

    iget-wide v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->T:J

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    return-wide v0

    :cond_1
    const/4 v7, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v7, 0x1

    const/4 v8, 0x0

    sget-object v3, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->d:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v8, 0x7

    if-eq v0, v3, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    sget-object v3, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->e:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-eq v0, v3, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    sget-object v3, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->f:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    if-eq v0, v3, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v8, 0x4

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    return-wide v0

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget-wide v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->T:J

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    cmp-long v0, v3, v1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-gtz v0, :cond_3

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->getDuration()I

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    int-to-long v3, v0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    iput-wide v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->T:J

    :cond_3
    const/4 v7, 0x1

    move v8, v7

    iget-wide v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->p:J

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    cmp-long v0, v3, v1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-lez v0, :cond_5

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    iget-wide v5, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->T:J

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    cmp-long v0, v5, v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-gtz v0, :cond_4

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    iput-wide v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->T:J

    const/4 v7, 0x3

    shr-int/2addr v8, v7

    goto :goto_0

    :cond_4
    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    sub-long/2addr v3, v5

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-static {v3, v4}, Ljava/lang/Math;->abs(J)J

    move-result-wide v0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-wide/16 v2, 0x64

    const-wide/16 v2, 0x64

    const/4 v8, 0x1

    const-wide/16 v2, 0x64

    const-wide/16 v2, 0x64

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    mul-long/2addr v0, v2

    const/4 v8, 0x2

    iget-wide v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->p:J

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    div-long/2addr v0, v2

    const/4 v7, 0x1

    move v8, v7

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v8, 0x2

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    cmp-long v0, v0, v4

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-lez v0, :cond_5

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    iput-wide v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->T:J

    :cond_5
    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    iget-wide v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->T:J

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    return-wide v0
.end method

.method public n()J
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->o:Z

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x4

    const-wide/16 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-wide v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->S:Z

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez v0, :cond_4

    const/4 v4, 0x1

    move v5, v4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->i:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-ne v0, v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_2

    :cond_1
    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->a:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v5, 0x0

    const/4 v4, 0x2

    if-eq v0, v1, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v4, 0x3

    and-int/2addr v5, v4

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->b:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eq v0, v1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->c:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eq v0, v1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->g:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eq v0, v1, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->d:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-ne v0, v1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_1

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->getCurrentPosition()I

    move-result v0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    int-to-long v0, v0

    const/4 v5, 0x2

    return-wide v0

    :cond_3
    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->m:I

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_0

    :cond_4
    :goto_2
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-wide v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->U:J

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x0

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    cmp-long v2, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-nez v2, :cond_5

    const/4 v5, 0x6

    goto :goto_1

    :cond_5
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-wide v0
.end method

.method public o()J
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-wide v0
.end method

.method public p()I
    .locals 5

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v2, "hwdWib:etVibg,dto idh"

    const-string v2, "edtw,bid htgi:ediWhVo"

    const/4 v4, 0x4

    const-string/jumbo v2, "ogtditu wt,VeeiihhdWd"

    const-string/jumbo v2, "getVideoWidth, width:"

    const/4 v4, 0x0

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->V:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->V:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    return v0
.end method

.method public q()I
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string v2, "Vhot:eepigH,gdtiie tehg"

    const-string/jumbo v2, "getVideoHeight, height:"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->W:I

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x1

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->W:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    return v0
.end method

.method public r()[Lcom/tencent/thumbplayer/api/TPTrackInfo;
    .locals 11
    .annotation build Landroid/annotation/TargetApi;
        value = 0x10
    .end annotation

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->d:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v9, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    if-eq v0, v1, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->e:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    if-eq v0, v1, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->Q:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/adapter/a/a/e$e;->f:Lcom/tencent/thumbplayer/adapter/a/a/e$e;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    if-ne v0, v1, :cond_1

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->SDK_INT:I

    const/4 v9, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/16 v1, 0x10

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    if-le v0, v1, :cond_1

    :try_start_0
    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->C:Landroid/media/MediaPlayer;

    const/4 v9, 0x2

    move v10, v9

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->getTrackInfo()[Landroid/media/MediaPlayer$TrackInfo;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    goto :goto_0

    :catch_0
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-string/jumbo v1, "fci I  kqgadTndeontnsgofTrreIaaracthcork"

    const-string v1, " InoaiuscIafhnc ekartefo kgTtgodarrTncrd"

    const/4 v10, 0x2

    const-string/jumbo v1, "rrsnnc o sTgrtTfcI ,erahackgadfoaidoInek"

    const-string/jumbo v1, "getTrackInfo, android getTrackInfo crash"

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    :cond_1
    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    const/4 v1, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-nez v0, :cond_2

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ad:Ljava/util/List;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v2

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    if-eqz v2, :cond_2

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ae:Ljava/util/List;

    const/4 v10, 0x5

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v2

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    if-eqz v2, :cond_2

    const/4 v9, 0x2

    shr-int/2addr v10, v9

    new-array v0, v1, [Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    return-object v0

    :cond_2
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ad:Ljava/util/List;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-object v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ae:Ljava/util/List;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x7

    add-int/2addr v2, v3

    const/4 v9, 0x1

    move v10, v9

    if-nez v0, :cond_3

    const/4 v9, 0x2

    move v10, v9

    move v3, v1

    move v3, v1

    const/4 v10, 0x2

    move v3, v1

    const/4 v10, 0x7

    goto :goto_1

    :cond_3
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    array-length v3, v0

    :goto_1
    const/4 v9, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    add-int/2addr v2, v3

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    new-array v2, v2, [Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v10, 0x7

    const/4 v9, 0x3

    iget-object v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ad:Ljava/util/List;

    const/4 v10, 0x1

    const/4 v9, 0x1

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    move v4, v1

    move v4, v1

    const/4 v10, 0x2

    move v4, v1

    move v4, v1

    :goto_2
    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    if-eqz v5, :cond_4

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    const/4 v10, 0x2

    const/4 v9, 0x3

    check-cast v5, Lcom/tencent/thumbplayer/adapter/a/a/e$b;

    const/4 v10, 0x2

    const/4 v9, 0x0

    add-int/lit8 v6, v4, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    iget-object v5, v5, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->a:Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x7

    aput-object v5, v2, v4

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    move v4, v6

    move v4, v6

    const/4 v10, 0x7

    move v4, v6

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    goto :goto_2

    :cond_4
    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget-object v3, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->ae:Ljava/util/List;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_3
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    if-eqz v5, :cond_5

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    check-cast v5, Lcom/tencent/thumbplayer/adapter/a/a/e$b;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    add-int/lit8 v6, v4, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget-object v5, v5, Lcom/tencent/thumbplayer/adapter/a/a/e$b;->a:Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    aput-object v5, v2, v4

    const/4 v10, 0x3

    const/4 v9, 0x1

    move v4, v6

    const/4 v10, 0x2

    move v4, v6

    move v4, v6

    const/4 v9, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x3

    goto :goto_3

    :cond_5
    const/4 v10, 0x4

    const/4 v9, 0x7

    if-eqz v0, :cond_7

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    array-length v3, v0

    const/4 v10, 0x2

    if-gtz v3, :cond_6

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x0

    goto/16 :goto_5

    :cond_6
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    array-length v3, v0

    :goto_4
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x3

    if-ge v1, v3, :cond_7

    const/4 v9, 0x2

    and-int/2addr v10, v9

    aget-object v5, v0, v1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    new-instance v6, Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-direct {v6}, Lcom/tencent/thumbplayer/api/TPTrackInfo;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {v5}, Landroid/media/MediaPlayer$TrackInfo;->getLanguage()Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    iput-object v7, v6, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {v5}, Landroid/media/MediaPlayer$TrackInfo;->getTrackType()I

    move-result v5

    const/4 v10, 0x3

    invoke-direct {p0, v5}, Lcom/tencent/thumbplayer/adapter/a/a/e;->f(I)I

    move-result v5

    const/4 v10, 0x6

    const/4 v9, 0x3

    iput v5, v6, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v10, 0x4

    iget-object v5, p0, Lcom/tencent/thumbplayer/adapter/a/a/e;->a:Lcom/tencent/thumbplayer/e/a;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    new-instance v7, Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    const-string/jumbo v8, "odtmegkxI:crannef i"

    const-string/jumbo v8, "getTrackInfo index:"

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    const-string/jumbo v8, "ype:o,p"

    const-string/jumbo v8, "p,y:pte"

    const/4 v10, 0x3

    const-string/jumbo v8, "tp yeb:"

    const-string v8, ", type:"

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget v8, v6, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-string/jumbo v8, "ic es:uet,qd"

    const-string v8, "eltds:e qc,i"

    const/4 v10, 0x6

    const-string v8, ":ts iespe,ld"

    const-string v8, ", isselcted:"

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget-boolean v8, v6, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const-string v8, ",qmnas:"

    const-string v8, "a,s:mne"

    const/4 v10, 0x1

    const-string/jumbo v8, "nas:m,e"

    const-string v8, ", name:"

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x7

    iget-object v8, v6, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v10, 0x7

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x2

    const/4 v9, 0x4

    invoke-virtual {v5, v7}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    add-int/lit8 v5, v4, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    aput-object v6, v2, v4

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v10, 0x5

    move v4, v5

    move v4, v5

    const/4 v10, 0x6

    move v4, v5

    move v4, v5

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    goto/16 :goto_4

    :cond_7
    :goto_5
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    return-object v2
.end method

.method public s()[Lcom/tencent/thumbplayer/api/TPProgramInfo;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    new-array v0, v0, [Lcom/tencent/thumbplayer/api/TPProgramInfo;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public t()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x3

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-wide v0
.end method

.method public u()Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v0, 0x0

    shl-int/2addr v2, v0

    const/4 v1, 0x7

    and-int/2addr v2, v1

    return-object v0
.end method
