.class Lcom/tencent/thumbplayer/adapter/a/a/e$4;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/adapter/a/a/a$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/adapter/a/a/e;-><init>(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/adapter/a/a/e;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/adapter/a/a/e;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$4;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(II)V
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "S~s~-b1s@Mc@i ~~@i@o~~@f/@@~~  ~~ o~ ~@@f@~l~t mo@  ~@b@ @4b~~ov@ ~ .ul@o~o /ty@ ~~d@ri@~ n  Ka@"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$4;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->d(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$h;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-eqz v0, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/a/e$4;->a:Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/a/a/e;->d(Lcom/tencent/thumbplayer/adapter/a/a/e;)Lcom/tencent/thumbplayer/adapter/a/c$h;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    const/16 v2, 0xfe

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    int-to-long v3, p1

    const/4 v9, 0x1

    int-to-long v5, p2

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    const/4 v7, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-interface/range {v1 .. v7}, Lcom/tencent/thumbplayer/adapter/a/c$h;->a(IJJLjava/lang/Object;)V

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x2

    return-void
.end method
