.class public Lcom/tencent/thumbplayer/adapter/a/e;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/lang/String;

.field private b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/e;->a:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/e;->b:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s d@~/@~ ~~@ nao lrt ~i~i4 m@~o /@yf @c@~~btv~ ~~ @ ~fo~@@S@ ~@~b1bo~~@  ~su il~@o@.M @-@ o@@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/e;->a:Ljava/lang/String;

    const/4 v1, 0x5

    move v2, v1

    return-object v0
.end method

.method public a(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/e;->a:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/a/e;->b:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public b(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/a/e;->b:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method
