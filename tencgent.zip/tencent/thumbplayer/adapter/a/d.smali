.class public final Lcom/tencent/thumbplayer/adapter/a/d;
.super Ljava/lang/Object;


# direct methods
.method public static a(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)Lcom/tencent/thumbplayer/adapter/a/b;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "i s@vo- ~fu @@   ~@ 1~@.~@@@4ti~/o ~ ~ ds@@~~@  flb@o@t ~ ~@o~@o~nr@la@~Si ~~  m~~yc~@~b~oKM@/b@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    new-instance v0, Lcom/tencent/thumbplayer/adapter/a/b/b;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0, p0, p1}, Lcom/tencent/thumbplayer/adapter/a/b/b;-><init>(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public static a(Landroid/content/Context;ZLcom/tencent/thumbplayer/e/b;)Lcom/tencent/thumbplayer/adapter/a/b;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    new-instance p1, Lcom/tencent/thumbplayer/adapter/a/a/d;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p1, p0, p2}, Lcom/tencent/thumbplayer/adapter/a/a/d;-><init>(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p1

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    new-instance p1, Lcom/tencent/thumbplayer/adapter/a/a/e;

    const/4 v0, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p1, p0, p2}, Lcom/tencent/thumbplayer/adapter/a/a/e;-><init>(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p1
.end method
