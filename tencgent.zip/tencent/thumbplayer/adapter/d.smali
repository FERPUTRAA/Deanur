.class public Lcom/tencent/thumbplayer/adapter/d;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/adapter/a;
.implements Lcom/tencent/thumbplayer/adapter/a/c$k;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/adapter/d$a;
    }
.end annotation


# instance fields
.field private a:Lcom/tencent/thumbplayer/e/b;

.field private b:Lcom/tencent/thumbplayer/e/a;

.field private c:Landroid/content/Context;

.field private d:Lcom/tencent/thumbplayer/adapter/a/b;

.field private e:Lcom/tencent/thumbplayer/api/TPPlayerState;

.field private f:Z

.field private g:Lcom/tencent/thumbplayer/adapter/g;

.field private h:Lcom/tencent/thumbplayer/adapter/d$a;

.field private i:Lcom/tencent/thumbplayer/adapter/c;

.field private j:Lcom/tencent/thumbplayer/adapter/i;

.field private k:Lcom/tencent/thumbplayer/adapter/strategy/a;

.field private l:Lcom/tencent/thumbplayer/adapter/b;

.field private m:I

.field private n:Lcom/tencent/thumbplayer/f/a;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)V
    .locals 4
    .param p2    # Lcom/tencent/thumbplayer/e/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Lcom/tencent/thumbplayer/e/b;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v1, "pTsrasedyPetrPa"

    const-string/jumbo v1, "pesaPdTrPlaeryt"

    const/4 v3, 0x6

    const-string v1, "arymerpelPadTPt"

    const-string v1, "TPPlayerAdapter"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v0, p2, v1}, Lcom/tencent/thumbplayer/e/b;-><init>(Lcom/tencent/thumbplayer/e/b;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->a:Lcom/tencent/thumbplayer/e/b;

    const/4 v3, 0x0

    const/4 v2, 0x6

    new-instance p2, Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p2, v0}, Lcom/tencent/thumbplayer/e/a;-><init>(Lcom/tencent/thumbplayer/e/b;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    iput-object p2, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x1

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->c:Landroid/content/Context;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance p1, Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPPlayerState;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x4

    invoke-virtual {p1, p0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->setOnPlayerStateChangeListener(Lcom/tencent/thumbplayer/adapter/a/c$k;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance p1, Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p1}, Lcom/tencent/thumbplayer/adapter/c;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x6

    new-instance p1, Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 p2, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {p1, p0, p2}, Lcom/tencent/thumbplayer/adapter/d$a;-><init>(Lcom/tencent/thumbplayer/adapter/d;Lcom/tencent/thumbplayer/adapter/d$1;)V

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance p1, Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/d;->a:Lcom/tencent/thumbplayer/e/b;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/e/b;->a()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {p1, p2}, Lcom/tencent/thumbplayer/adapter/g;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance p1, Lcom/tencent/thumbplayer/adapter/i;

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x5

    invoke-direct {p1, p2}, Lcom/tencent/thumbplayer/adapter/i;-><init>(Lcom/tencent/thumbplayer/api/TPPlayerState;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance p1, Lcom/tencent/thumbplayer/adapter/b;

    const/4 v3, 0x5

    invoke-direct {p1}, Lcom/tencent/thumbplayer/adapter/b;-><init>()V

    const/4 v2, 0x6

    or-int/2addr v3, v2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method private A()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/d;->m:I

    const/4 v3, 0x4

    const/4 v1, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eq v0, v1, :cond_1

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v3, 0x1

    move v2, v1

    move v2, v1

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    return v0

    :cond_1
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    return v0
.end method

.method private a(ILcom/tencent/thumbplayer/e/b;)Lcom/tencent/thumbplayer/adapter/a/b;
    .locals 6

    const/4 v4, 0x3

    move v5, v4

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-ne p1, v0, :cond_0

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string v2, "arciodP re ryalmoantoet"

    const-string/jumbo v2, "rdem tca dartyPaeoolnri"

    const/4 v5, 0x6

    const-string/jumbo v2, "eyorabttrldaorPdeeac ni"

    const-string/jumbo v2, "to create androidPlayer"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->c:Landroid/content/Context;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v2}, Lcom/tencent/thumbplayer/adapter/c;->p()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v0, v2, p2}, Lcom/tencent/thumbplayer/adapter/a/d;->a(Landroid/content/Context;ZLcom/tencent/thumbplayer/e/b;)Lcom/tencent/thumbplayer/adapter/a/b;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    goto/16 :goto_3

    :catch_0
    move-exception p2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v0, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-ne p1, v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v2, "hao t uyrtPrceaetuobl"

    const-string/jumbo v2, "th coruaemylPab etotr"

    const/4 v5, 0x1

    const-string/jumbo v2, "ruataPeprettl yo mech"

    const-string/jumbo v2, "to create thumbPlayer"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0, v2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->c:Landroid/content/Context;

    :goto_0
    const/4 v5, 0x7

    invoke-static {v0, p2}, Lcom/tencent/thumbplayer/adapter/a/d;->a(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)Lcom/tencent/thumbplayer/adapter/a/b;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto/16 :goto_3

    :cond_1
    const/4 v4, 0x6

    move v5, v4

    const/4 v0, 0x4

    const/4 v0, 0x3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-ne p1, v0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string v2, "eabmrce qa aoee ewhctudtsPtrrtflyb"

    const-string v2, "cttsbbouaedwetahP era  mfercreoytl"

    const/4 v5, 0x3

    const-string/jumbo v2, "fos tyr betlra wehe utomacrtcaesed"

    const-string/jumbo v2, "to create thumbPlayer software dec"

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {v0, v2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->c:Landroid/content/Context;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x1

    or-int/2addr v5, v4

    const-string v0, "Pr mec eo ouaneyttl"

    const-string v0, "cnaoe uor ye lterPt"

    const/4 v5, 0x7

    const-string v0, " Pr oelnarcotat yoe"

    const-string/jumbo v0, "to create no Player"

    const/4 v5, 0x4

    invoke-virtual {p2, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_2

    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string v3, ",rcrebateaPt ply "

    const-string/jumbo v3, "trl  oPpa,tceyera"

    const/4 v5, 0x1

    const-string v3, "c,rloeutPa er aye"

    const-string/jumbo v3, "to create Player,"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0, p2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    :goto_2
    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    :goto_3
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez p2, :cond_3

    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string p2, " qypls plla!i"

    const-string/jumbo p2, "pan !y lqslil"

    const/4 v5, 0x2

    const-string p2, "ap lnli!qs uy"

    const-string/jumbo p2, "play is null!"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v5, 0x7

    return-object v1

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x2

    iput p1, p0, Lcom/tencent/thumbplayer/adapter/d;->m:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {p0, p2}, Lcom/tencent/thumbplayer/adapter/d;->b(Lcom/tencent/thumbplayer/adapter/a/b;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    return-object p2
.end method

.method private a(Lcom/tencent/thumbplayer/adapter/c;)Lcom/tencent/thumbplayer/adapter/strategy/a;
    .locals 3

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    new-instance v0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {v0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/a/a;-><init>(Lcom/tencent/thumbplayer/adapter/c;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    goto :goto_0

    :catch_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/adapter/strategy/a/a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {v0, p1}, Lcom/tencent/thumbplayer/adapter/strategy/a/a;-><init>(Lcom/tencent/thumbplayer/adapter/c;)V

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/strategy/e;->a(Lcom/tencent/thumbplayer/adapter/strategy/a/a;)Lcom/tencent/thumbplayer/adapter/strategy/a;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object p1
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/d;Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/d;->a(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method private a(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p1
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/d;Ljava/lang/String;I)Lcom/tencent/thumbplayer/api/TPRemoteSdpInfo;
    .locals 2

    const/4 v0, 0x7

    invoke-direct {p0, p1, p2}, Lcom/tencent/thumbplayer/adapter/d;->a(Ljava/lang/String;I)Lcom/tencent/thumbplayer/api/TPRemoteSdpInfo;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p0
.end method

.method private a(Ljava/lang/String;I)Lcom/tencent/thumbplayer/api/TPRemoteSdpInfo;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p2}, Lcom/tencent/thumbplayer/adapter/g;->a(Ljava/lang/String;I)Lcom/tencent/thumbplayer/api/TPRemoteSdpInfo;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p1
.end method

.method private a(IIJJ)V
    .locals 9

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->k:Lcom/tencent/thumbplayer/adapter/strategy/a;

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    new-instance v2, Lcom/tencent/thumbplayer/adapter/strategy/a/b;

    iget v3, p0, Lcom/tencent/thumbplayer/adapter/d;->m:I

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/adapter/b;->d()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v3, p1, p2, v4}, Lcom/tencent/thumbplayer/adapter/strategy/a/b;-><init>(IIILjava/lang/String;)V

    invoke-interface {v0, v1, v2}, Lcom/tencent/thumbplayer/adapter/strategy/a;->a(Lcom/tencent/thumbplayer/adapter/b;Lcom/tencent/thumbplayer/adapter/strategy/a/b;)I

    move-result v0

    const/16 v1, 0xa

    if-nez v0, :cond_1

    :goto_0
    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    move v3, p1

    move v3, p1

    move v3, p1

    move v3, p1

    move v4, p2

    move v4, p2

    move v4, p2

    move-wide v5, p3

    move-wide v7, p5

    invoke-virtual/range {v2 .. v8}, Lcom/tencent/thumbplayer/adapter/g;->a(IIJJ)V

    return-void

    :cond_1
    :try_start_0
    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/adapter/d;->e(I)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    :goto_1
    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    invoke-virtual {v2, v0}, Lcom/tencent/thumbplayer/e/a;->a(Ljava/lang/Exception;)V

    goto :goto_0

    :catch_1
    move-exception v0

    goto :goto_1
.end method

.method private a(IJJLjava/lang/Object;)V
    .locals 9

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/d;->f:Z

    if-eqz v0, :cond_0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const-string/jumbo p2, "mislrseenyaftnhgRI nsodIO"

    const-string p2, " fstgaOn,IlnonRsyIeermidh"

    const-string p2, "e,lmny onitsfhmarnOgnIedI"

    const-string/jumbo p2, "handleOnInfo, mIsRetrying"

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    return-void

    :cond_0
    const/16 v0, 0x98

    if-ne p1, v0, :cond_1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    if-eqz v0, :cond_1

    long-to-int v1, p2

    add-int/lit8 v1, v1, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/b;->f(I)V

    :cond_1
    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    move v3, p1

    move v3, p1

    move v3, p1

    move v3, p1

    move-wide v4, p2

    move-wide v6, p4

    move-object v8, p6

    move-object v8, p6

    move-object v8, p6

    move-object v8, p6

    invoke-virtual/range {v2 .. v8}, Lcom/tencent/thumbplayer/adapter/g;->a(IJJLjava/lang/Object;)V

    return-void
.end method

.method private a(JJ)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x7

    const/4 v1, 0x6

    const/4 v3, 0x3

    or-int/2addr v2, v1

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string p2, "Vteeootin SnmaOdn,eenhCsiliia deaghval"

    const-string/jumbo p2, "ienml,lhdaetheaiSaOoegnV ndetv danisiC"

    const/4 v3, 0x2

    const-string/jumbo p2, "gViahbitdn aoanCd,Stevie endOnezelisal"

    const-string/jumbo p2, "handleOnVideoSizeChange, invalid state"

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, p3, p4}, Lcom/tencent/thumbplayer/adapter/b;->b(J)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, p1, p2}, Lcom/tencent/thumbplayer/adapter/b;->a(J)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/adapter/g;->a(JJ)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/adapter/a/b;)V
    .locals 7

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/d;->s()[Lcom/tencent/thumbplayer/api/TPProgramInfo;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/adapter/c;->l()Lcom/tencent/thumbplayer/api/TPProgramInfo;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz v1, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    array-length v3, v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-ge v2, v3, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v3, v1, Lcom/tencent/thumbplayer/api/TPProgramInfo;->url:Ljava/lang/String;

    const/4 v6, 0x6

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    if-nez v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    aget-object v3, v0, v2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz v3, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v4, v1, Lcom/tencent/thumbplayer/api/TPProgramInfo;->url:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v3, v3, Lcom/tencent/thumbplayer/api/TPProgramInfo;->url:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eqz v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-wide/16 v0, -0x1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-interface {p1, v2, v0, v1}, Lcom/tencent/thumbplayer/adapter/a/b;->c(IJ)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    return-void

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto :goto_0

    :cond_1
    const/4 v6, 0x5

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/d;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/d;->v()V

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/d;IIJJ)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct/range {p0 .. p6}, Lcom/tencent/thumbplayer/adapter/d;->a(IIJJ)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/d;IJJLjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct/range {p0 .. p6}, Lcom/tencent/thumbplayer/adapter/d;->a(IJJLjava/lang/Object;)V

    const/4 v0, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/d;JJ)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/adapter/d;->a(JJ)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/d;Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;)V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/d;->a(Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/d;Lcom/tencent/thumbplayer/api/TPDrmInfo;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/d;->a(Lcom/tencent/thumbplayer/api/TPDrmInfo;)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/d;Lcom/tencent/thumbplayer/api/TPPlayerDetailInfo;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/d;->a(Lcom/tencent/thumbplayer/api/TPPlayerDetailInfo;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/d;Lcom/tencent/thumbplayer/api/TPSubtitleData;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/d;->a(Lcom/tencent/thumbplayer/api/TPSubtitleData;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/d;Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/d;->a(Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/adapter/d;Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/d;->a(Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;)V

    const/4 v0, 0x5

    move v1, v0

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;)V
    .locals 4

    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x7

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPAudioFrameBuffer;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/api/TPDrmInfo;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPDrmInfo;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/api/TPPlayerDetailInfo;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPPlayerDetailInfo;)V

    const/4 v2, 0x4

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/api/TPSubtitleData;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x7

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v0, "ahti iunODvniudonSstdleta tl,eablea"

    const-string v0, "dnaSoeelsuet idta ivnitObltaha,Dlan"

    const/4 v3, 0x2

    const-string/jumbo v0, "l,ehniOptaSdtdt i ilaenabaeausltvnt"

    const-string/jumbo v0, "handleOnSubtitleData, invalid state"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPSubtitleData;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v1, 0x7

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v0, " bvmFtdeqtlSliaburnl ahiateuOieOt,sndae"

    const-string/jumbo v0, "nmt,lbhuisOFe dda btuanrelvOltiteitaaeS"

    const/4 v3, 0x2

    const-string v0, "aisaedhludt int eutnSitFlva,nltOsmrOaeb"

    const-string/jumbo v0, "handleOnSubtitleFrameOut, invalid state"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPSubtitleFrameBuffer;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x7

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo v0, "lOOmersnaaaVe l i,eudvtutiaimodnhdnF"

    const-string/jumbo v0, "ueVdohunl,asitaOmaidiFedalnnvt O ret"

    const/4 v3, 0x3

    const-string v0, "avlionenuleemaaniadesthdOVtrOi Fod,t"

    const-string/jumbo v0, "handleOnVideoFrameOut, invalid state"

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPVideoFrameBuffer;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/adapter/d;Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/d;->b(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p0
.end method

.method private b(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v1, 0x7

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 p1, 0x0

    xor-int/2addr v3, p1

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->b(Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;)Lcom/tencent/thumbplayer/api/TPPostProcessFrameBuffer;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p1
.end method

.method private b(Lcom/tencent/thumbplayer/adapter/a/b;)V
    .locals 11

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v10, 0x6

    const/4 v9, 0x2

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$h;)V

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$i;)V

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v10, 0x7

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$c;)V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$f;)V

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$j;)V

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$p;)V

    const/4 v10, 0x1

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v10, 0x6

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$l;)V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v10, 0x7

    const/4 v9, 0x1

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$m;)V

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$e;)V

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$g;)V

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$d;)V

    const/4 v10, 0x0

    const/4 v9, 0x3

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/d;->A()Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    if-eqz v0, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v10, 0x3

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$n;)V

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v10, 0x2

    const/4 v9, 0x6

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$a;)V

    const/4 v9, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$o;)V

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->h:Lcom/tencent/thumbplayer/adapter/d$a;

    const/4 v10, 0x2

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/adapter/a/c$b;)V

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->g()I

    move-result v0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/4 v1, 0x3

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    const/4 v2, 0x2

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    const/4 v3, 0x1

    const/4 v10, 0x6

    if-ne v3, v0, :cond_1

    const/4 v9, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v9, 0x4

    move v10, v9

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->c()Landroid/os/ParcelFileDescriptor;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Landroid/os/ParcelFileDescriptor;)V

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x3

    goto/16 :goto_1

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->g()I

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    const/4 v4, 0x4

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x6

    if-ne v4, v0, :cond_2

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x0

    const/4 v9, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->d()Landroid/content/res/AssetFileDescriptor;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Landroid/content/res/AssetFileDescriptor;)V

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    goto/16 :goto_1

    :cond_2
    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->g()I

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    if-ne v1, v0, :cond_4

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/d;->m:I

    const/4 v9, 0x7

    move v10, v9

    if-ne v0, v2, :cond_3

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->f()Lcom/tencent/thumbplayer/adapter/a/e;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/e;->b()Ljava/lang/String;

    move-result-object v0

    :goto_0
    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x5

    iget-object v3, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v3}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v3

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {v3}, Lcom/tencent/thumbplayer/adapter/h;->b()Ljava/util/Map;

    move-result-object v3

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-interface {p1, v0, v3}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Ljava/lang/String;Ljava/util/Map;)V

    goto :goto_1

    :cond_3
    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-ne v0, v3, :cond_5

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->f()Lcom/tencent/thumbplayer/adapter/a/e;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/a/e;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    goto :goto_0

    :cond_4
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->g()I

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-ne v2, v0, :cond_5

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->e()Lcom/tencent/thumbplayer/adapter/h;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/h;->e()Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)V

    :cond_5
    :goto_1
    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->o()Ljava/util/List;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_2
    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    if-eqz v3, :cond_6

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    check-cast v3, Lcom/tencent/thumbplayer/api/TPOptionalParam;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-interface {p1, v3}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/api/TPOptionalParam;)V

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x4

    goto :goto_2

    :cond_6
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    const/4 v0, 0x0

    const/4 v10, 0x6

    move v3, v0

    move v3, v0

    const/4 v10, 0x0

    move v3, v0

    :goto_3
    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    iget-object v4, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {v4}, Lcom/tencent/thumbplayer/adapter/c;->b()Ljava/util/ArrayList;

    move-result-object v4

    const/4 v10, 0x0

    const/4 v9, 0x7

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-ge v3, v4, :cond_b

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object v4, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v4}, Lcom/tencent/thumbplayer/adapter/c;->b()Ljava/util/ArrayList;

    move-result-object v4

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x6

    check-cast v4, Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget v5, v4, Lcom/tencent/thumbplayer/api/TPTrackInfo;->trackType:I

    const/4 v10, 0x5

    const/4 v9, 0x2

    if-ne v5, v1, :cond_8

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    iget-object v5, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/adapter/c;->m()Ljava/util/List;

    move-result-object v5

    const/4 v10, 0x2

    const/4 v9, 0x3

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_7
    const/4 v10, 0x5

    const/4 v9, 0x5

    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    if-eqz v6, :cond_a

    const/4 v10, 0x6

    const/4 v9, 0x4

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    check-cast v6, Lcom/tencent/thumbplayer/adapter/c$d;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget-object v7, v6, Lcom/tencent/thumbplayer/adapter/c$d;->c:Ljava/lang/String;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    if-nez v7, :cond_7

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x2

    iget-object v7, v6, Lcom/tencent/thumbplayer/adapter/c$d;->c:Ljava/lang/String;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-object v8, v4, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-eqz v7, :cond_7

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget-object v4, v6, Lcom/tencent/thumbplayer/adapter/c$d;->a:Ljava/lang/String;

    const/4 v10, 0x6

    iget-object v5, v6, Lcom/tencent/thumbplayer/adapter/c$d;->d:Ljava/util/Map;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    iget-object v7, v6, Lcom/tencent/thumbplayer/adapter/c$d;->b:Ljava/lang/String;

    const/4 v10, 0x2

    const/4 v9, 0x7

    iget-object v6, v6, Lcom/tencent/thumbplayer/adapter/c$d;->c:Ljava/lang/String;

    const/4 v10, 0x6

    invoke-interface {p1, v4, v5, v7, v6}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x7

    goto :goto_4

    :cond_8
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-ne v5, v2, :cond_a

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-object v5, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/adapter/c;->n()Ljava/util/List;

    move-result-object v5

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_9
    const/4 v10, 0x0

    const/4 v9, 0x6

    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    if-eqz v6, :cond_a

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    check-cast v6, Lcom/tencent/thumbplayer/adapter/c$a;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget-object v7, v6, Lcom/tencent/thumbplayer/adapter/c$a;->b:Ljava/lang/String;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-nez v7, :cond_9

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    iget-object v7, v6, Lcom/tencent/thumbplayer/adapter/c$a;->b:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-object v8, v4, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    if-eqz v7, :cond_9

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-object v4, v6, Lcom/tencent/thumbplayer/adapter/c$a;->a:Ljava/lang/String;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    iget-object v5, v6, Lcom/tencent/thumbplayer/adapter/c$a;->d:Ljava/util/Map;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    iget-object v7, v6, Lcom/tencent/thumbplayer/adapter/c$a;->b:Ljava/lang/String;

    const/4 v10, 0x4

    const/4 v9, 0x3

    iget-object v6, v6, Lcom/tencent/thumbplayer/adapter/c$a;->c:Ljava/util/List;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-interface {p1, v4, v5, v7, v6}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/List;)V

    :cond_a
    :goto_4
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    add-int/lit8 v3, v3, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    goto/16 :goto_3

    :cond_b
    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/adapter/c;->c()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_c
    :goto_5
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    if-eqz v2, :cond_f

    const/4 v10, 0x6

    const/4 v9, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    check-cast v2, Lcom/tencent/thumbplayer/adapter/c$c;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    iget-object v3, v2, Lcom/tencent/thumbplayer/adapter/c$c;->c:Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v10, 0x4

    const/4 v9, 0x6

    iget-boolean v3, v3, Lcom/tencent/thumbplayer/api/TPTrackInfo;->isSelected:Z

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    if-eqz v3, :cond_c

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-interface {p1}, Lcom/tencent/thumbplayer/adapter/a/b;->r()[Lcom/tencent/thumbplayer/api/TPTrackInfo;

    move-result-object v3

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-nez v3, :cond_d

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    const-string/jumbo v3, "urciTbI lLse.naal yrikpsptol"

    const-string/jumbo v3, "slT iInpicLp.rloseay ktlfura"

    const-string/jumbo v3, "r ountucesT.iaIyLislkfanpllr"

    const-string/jumbo v3, "playerTrackInfoList is null."

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {v2, v3}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    goto :goto_5

    :cond_d
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    move v4, v0

    move v4, v0

    const/4 v10, 0x5

    move v4, v0

    move v4, v0

    :goto_6
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    array-length v5, v3

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-ge v4, v5, :cond_c

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget-object v5, v2, Lcom/tencent/thumbplayer/adapter/c$c;->c:Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    iget-object v5, v5, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x2

    aget-object v6, v3, v4

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    iget-object v6, v6, Lcom/tencent/thumbplayer/api/TPTrackInfo;->name:Ljava/lang/String;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eqz v5, :cond_e

    const/4 v10, 0x0

    iget-wide v5, v2, Lcom/tencent/thumbplayer/adapter/c$c;->b:J

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-interface {p1, v4, v5, v6}, Lcom/tencent/thumbplayer/adapter/a/b;->a(IJ)V

    :cond_e
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    add-int/lit8 v4, v4, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    goto :goto_6

    :cond_f
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->k()Lcom/tencent/thumbplayer/adapter/c$b;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-eqz v0, :cond_10

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v9, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->k()Lcom/tencent/thumbplayer/adapter/c$b;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-boolean v2, v0, Lcom/tencent/thumbplayer/adapter/c$b;->a:Z

    const/4 v10, 0x1

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->k()Lcom/tencent/thumbplayer/adapter/c$b;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget-wide v3, v0, Lcom/tencent/thumbplayer/adapter/c$b;->b:J

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->k()Lcom/tencent/thumbplayer/adapter/c$b;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    iget-wide v5, v0, Lcom/tencent/thumbplayer/adapter/c$b;->c:J

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-interface/range {v1 .. v6}, Lcom/tencent/thumbplayer/adapter/a/b;->a(ZJJ)V

    :cond_10
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->g()Z

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x1

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Z)V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->h()F

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v1, 0x0

    move v10, v1

    const/4 v9, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x4

    cmpl-float v0, v0, v1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-eqz v0, :cond_11

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->h()F

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(F)V

    :cond_11
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->j()F

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    cmpl-float v0, v0, v1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    if-eqz v0, :cond_12

    const/4 v10, 0x0

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x2

    const/4 v9, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->j()F

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->b(F)V

    :cond_12
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x1

    const/4 v9, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->i()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-nez v0, :cond_13

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->i()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Ljava/lang/String;)V

    :cond_13
    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->d()Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x2

    instance-of v0, v0, Landroid/view/SurfaceHolder;

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-eqz v0, :cond_14

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->d()Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    check-cast v0, Landroid/view/SurfaceHolder;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Landroid/view/SurfaceHolder;)V

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    goto :goto_7

    :cond_14
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->d()Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    instance-of v0, v0, Landroid/view/Surface;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eqz v0, :cond_15

    const/4 v10, 0x2

    const/4 v9, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->d()Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    check-cast v0, Landroid/view/Surface;

    const/4 v9, 0x1

    xor-int/2addr v10, v9

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Landroid/view/Surface;)V

    :cond_15
    :goto_7
    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    new-instance v0, Lcom/tencent/thumbplayer/api/TPOptionalParam;

    const/4 v9, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPOptionalParam;-><init>()V

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->k:Lcom/tencent/thumbplayer/adapter/strategy/a;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-interface {v1}, Lcom/tencent/thumbplayer/adapter/strategy/a;->a()[I

    move-result-object v1

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    const/16 v2, 0xcc

    const/4 v10, 0x3

    const/4 v9, 0x0

    invoke-virtual {v0, v2, v1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->buildQueueInt(I[I)Lcom/tencent/thumbplayer/api/TPOptionalParam;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/api/TPOptionalParam;)V

    const/4 v10, 0x6

    return-void
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/adapter/d;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/d;->x()V

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic c(Lcom/tencent/thumbplayer/adapter/d;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/d;->y()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method private d(I)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x5

    const/4 v2, 0x5

    if-eq p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    :try_start_0
    const/4 v2, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {p1}, Lcom/tencent/thumbplayer/adapter/a/b;->h()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void

    :catch_0
    move-exception p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/e/a;->a(Ljava/lang/Exception;)V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method private e(I)V
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    const/16 v1, 0x3f5

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    int-to-long v2, p1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v8, 0x3

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v8, 0x3

    const/4 v6, 0x0

    const/4 v8, 0x5

    shl-int/2addr v7, v6

    const/4 v8, 0x5

    invoke-virtual/range {v0 .. v6}, Lcom/tencent/thumbplayer/adapter/g;->a(IJJLjava/lang/Object;)V

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->state()I

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->setLastState(I)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-eqz v0, :cond_0

    const/4 v7, 0x2

    move v8, v7

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->n()J

    move-result-wide v0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const-string/jumbo v3, "ueriP w,q:snoshtacicrentpy ilot"

    const-string/jumbo v3, "o,enirnpcautyssltwoi:h  eriPprc"

    const-string/jumbo v3, "switchPlayer, current position:"

    const/4 v8, 0x6

    const/4 v7, 0x5

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x5

    invoke-virtual {v2, v3}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v7, 0x5

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v2, v0, v1}, Lcom/tencent/thumbplayer/adapter/b;->f(J)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-interface {v1}, Lcom/tencent/thumbplayer/adapter/a/b;->o()J

    move-result-wide v1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/adapter/b;->i(J)V

    const/4 v7, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v7, 0x3

    xor-int/2addr v8, v7

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->k()V

    const/4 v7, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->l()V

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->a:Lcom/tencent/thumbplayer/e/b;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {p0, p1, v0}, Lcom/tencent/thumbplayer/adapter/d;->a(ILcom/tencent/thumbplayer/e/b;)Lcom/tencent/thumbplayer/adapter/a/b;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-eqz p1, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 p1, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    iput-boolean p1, p0, Lcom/tencent/thumbplayer/adapter/d;->f:Z

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string v1, "ecl pwirqhe: syaoytp s"

    const-string v1, " lsrcaowieytpyp: seh t"

    const/4 v8, 0x3

    const-string/jumbo v1, "tes :ystilrcawhpyot ep"

    const-string/jumbo v1, "switch player to type:"

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget v1, p0, Lcom/tencent/thumbplayer/adapter/d;->m:I

    const/4 v7, 0x1

    shl-int/2addr v8, v7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x6

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v7, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-eqz p1, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    new-instance p1, Lcom/tencent/thumbplayer/api/TPOptionalParam;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-direct {p1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->h()J

    move-result-wide v0

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/16 v2, 0x64

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {p1, v2, v0, v1}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->buildLong(IJ)Lcom/tencent/thumbplayer/api/TPOptionalParam;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/api/TPOptionalParam;)V

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    const/4 v0, 0x3

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->setInnerPlayStateState(I)V

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-interface {p1}, Lcom/tencent/thumbplayer/adapter/a/b;->g()V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    return-void

    :cond_2
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    const-string/jumbo v0, "rllmefad er  i,part oyacmrer"

    const-string v0, "d om aia rer,crareee frlylpt"

    const/4 v8, 0x7

    const-string v0, "epreof,l aar erre elyra diot"

    const-string v0, "error , create player failed"

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x3

    throw p1
.end method

.method private v()V
    .locals 11

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/16 v1, 0x3e8

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    iget v2, p0, Lcom/tencent/thumbplayer/adapter/d;->m:I

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x4

    int-to-long v2, v2

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v6, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual/range {v0 .. v6}, Lcom/tencent/thumbplayer/adapter/g;->a(IJJLjava/lang/Object;)V

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/d;->f:Z

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    const/4 v1, 0x3

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-eqz v0, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->innerPlayState()I

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-eq v0, v1, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    const-string/jumbo v1, "taPRebddsrOpi a,eeil gatvtenniaho.Irrds,lneym"

    const-string/jumbo v1, "ya roIsvee,iatdpntre,sidnieghO.l aRretldna Pm"

    const/4 v10, 0x3

    const-string/jumbo v1, "lid,IRuritnevaahnPrr,sdeleenOtgda.ympn at sie"

    const-string/jumbo v1, "handleOnPrepared, invalid state, mIsRetrying."

    const/4 v10, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v9, 0x1

    and-int/2addr v10, v9

    return-void

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    const/4 v2, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x6

    invoke-virtual {v0, v2}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x6

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    const-string v1, " ,PlapvphreairasdiOdtntld nnaee"

    const-string/jumbo v1, "handleOnPrepared, invalid state"

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x5

    return-void

    :cond_1
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/d;->w()V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/adapter/d;->a(Lcom/tencent/thumbplayer/adapter/a/b;)V

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x5

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/d;->f:Z

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x0

    const/4 v2, 0x4

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    if-eqz v0, :cond_3

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    const/4 v0, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/d;->f:Z

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    const-string v4, "c:S,enbgqetnta tyReveepPerl,ms Ororthrsan,dea radet"

    const-string/jumbo v4, "lsr,pbvs: Rgtrea htdItPatOrotennren,meerdaeeacyS, e"

    const/4 v10, 0x3

    const-string v4, ",ns peteantrPao tclIsaheeearrtytRrdedgminv Se,O:esr"

    const-string/jumbo v4, "handleOnPrepared, mIsRetrying, recoverState, state:"

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x5

    iget-object v4, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v9, 0x7

    or-int/2addr v10, v9

    invoke-virtual {v4}, Lcom/tencent/thumbplayer/api/TPPlayerState;->state()I

    move-result v4

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x6

    shl-int/2addr v10, v9

    invoke-virtual {v0, v3}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->state()I

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    iget-object v3, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v3, v2}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {v2}, Lcom/tencent/thumbplayer/api/TPPlayerState;->lastState()I

    move-result v2

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    if-ne v2, v1, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/adapter/g;->a()V

    :cond_2
    const/4 v10, 0x7

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    const/16 v3, 0x3f6

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v10, 0x1

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v10, 0x6

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/4 v8, 0x0

    invoke-virtual/range {v2 .. v8}, Lcom/tencent/thumbplayer/adapter/g;->a(IJJLjava/lang/Object;)V

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/adapter/d;->d(I)V

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    return-void

    :cond_3
    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v0, v2}, Lcom/tencent/thumbplayer/api/TPPlayerState;->setInnerPlayStateState(I)V

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {v0, v2}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/g;->a()V

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    return-void
.end method

.method private w()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/d;->A()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x4

    move v4, v0

    move v4, v0

    const/4 v5, 0x6

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/adapter/d;->c(I)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/b;->a(Ljava/lang/String;)Lcom/tencent/thumbplayer/adapter/b;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/16 v2, 0xcc

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-interface {v1, v2}, Lcom/tencent/thumbplayer/adapter/a/b;->b(I)J

    move-result-wide v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    long-to-int v1, v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/b;->e(I)V

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/16 v2, 0xcb

    const/4 v5, 0x4

    invoke-interface {v1, v2}, Lcom/tencent/thumbplayer/adapter/a/b;->b(I)J

    move-result-wide v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    long-to-int v1, v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/b;->a(I)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/16 v2, 0x66

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-interface {v1, v2}, Lcom/tencent/thumbplayer/adapter/a/b;->b(I)J

    move-result-wide v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    long-to-int v1, v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/b;->c(I)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/16 v2, 0xc9

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-interface {v1, v2}, Lcom/tencent/thumbplayer/adapter/a/b;->b(I)J

    move-result-wide v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    long-to-int v1, v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/b;->g(I)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v2, 0xd2

    const/4 v4, 0x5

    or-int/2addr v5, v4

    invoke-interface {v1, v2}, Lcom/tencent/thumbplayer/adapter/a/b;->b(I)J

    move-result-wide v1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    long-to-int v1, v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/b;->b(I)V

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x7

    if-nez v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x3

    invoke-direct {v0}, Lcom/tencent/thumbplayer/adapter/b;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-interface {v1}, Lcom/tencent/thumbplayer/adapter/a/b;->m()J

    move-result-wide v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/adapter/b;->h(J)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/16 v1, 0x64

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/c;->b(I)Lcom/tencent/thumbplayer/api/TPOptionalParam;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz v0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/TPOptionalParam;->getParamLong()Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-wide v2, v0, Lcom/tencent/thumbplayer/api/TPOptionalParam$OptionalParamLong;->value:J

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v1, v2, v3}, Lcom/tencent/thumbplayer/adapter/b;->f(J)V

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x2

    return-void
.end method

.method private x()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x5

    const-string/jumbo v1, "ht metispvtanle,lonui CadmdeaOe"

    const-string/jumbo v1, "plsimluaOettna  eenat,ednCvhdio"

    const/4 v3, 0x4

    const-string/jumbo v1, "neiaoslvOn tChlpiad,aeld etntme"

    const-string/jumbo v1, "handleOnComplete, invalid state"

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x7

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/g;->b()V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method private y()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x5

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->b(I)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/g;->c()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method

.method private z()I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->k:Lcom/tencent/thumbplayer/adapter/strategy/a;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/adapter/d;->a(Lcom/tencent/thumbplayer/adapter/c;)Lcom/tencent/thumbplayer/adapter/strategy/a;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->k:Lcom/tencent/thumbplayer/adapter/strategy/a;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->k:Lcom/tencent/thumbplayer/adapter/strategy/a;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Lcom/tencent/thumbplayer/adapter/strategy/a;->a(Lcom/tencent/thumbplayer/adapter/b;)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    return v0
.end method


# virtual methods
.method public a()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->l()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0

    :cond_0
    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public a(F)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x3

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(F)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo v1, "uBetobllsl!ai i=oA,yipansat reauePmndG"

    const-string v1, "ABeeotlpnilo ay!nsmausu Gai=iePt r,dal"

    const-string/jumbo v1, "u rRslusuGiPae=ol Aad !iya,tiaetomBnen"

    const-string/jumbo v1, "setAudioGainRatio, mPlayerBase = null!"

    const/4 v3, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(F)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const-string/jumbo v1, "ioioeaepaai rid:eAu nisttatn rt,re ertsc Gu ,  lovq trsdRan"

    const-string/jumbo v1, "ireistv q: ttuaratni  ,dRlaoic  traenniGA de soesrreot ,uat"

    const/4 v3, 0x7

    const-string v1, "eaeotdliq intuna srcrtrGt od:er A,ts o a,ii viRrese t ,uaat"

    const-string v1, "error , setAudioGainRatio , state invalid , current state :"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    throw p1
.end method

.method public a(I)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/16 v1, 0x9

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v0, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->state()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v1, 0x7

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-ne v0, v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v1, 0x5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(I)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->n:Lcom/tencent/thumbplayer/f/a;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    int-to-long v1, p1

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {v0, v1, v2}, Lcom/tencent/thumbplayer/f/a;->a(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void

    :catch_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v0, "sds.ee ksioch eoikreTec e r sp,rasesro"

    const-string v0, "a.see sTh sopker,kdcioeco  er rserersi"

    const/4 v4, 0x7

    const-string/jumbo v0, "ro,mkimph e o kosesieecrrTsceers.re a "

    const-string/jumbo v0, "seekTo, rich media processor seek err."

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-void

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v0, "euomelT= ,klPB !sslaee yanr"

    const/4 v4, 0x5

    const-string/jumbo v0, "sBasomel l koueTnPl,ar! =ye"

    const-string/jumbo v0, "seekTo, mPlayerBase = null!"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const-string/jumbo v1, "tdt oee ,st ,eot  letoaea sr tirkcsrrann:e  uivr,"

    const/4 v4, 0x2

    const-string v1, " adorbn,ssteu  ctksvnteei rt,ir: alt, re eae  tor"

    const-string v1, "error , seek to , state invalid , current state :"

    const/4 v3, 0x2

    shr-int/2addr v4, v3

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    throw p1
.end method

.method public a(II)V
    .locals 4
    .param p2    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSeekMode;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/16 v1, 0x9

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->state()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v1, 0x7

    move v3, v1

    const/4 v2, 0x3

    and-int/2addr v3, v2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x5

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/adapter/a/b;->a(II)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/d;->n:Lcom/tencent/thumbplayer/f/a;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz p2, :cond_1

    const/4 v2, 0x1

    move v3, v2

    int-to-long v0, p1

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {p2, v0, v1}, Lcom/tencent/thumbplayer/f/a;->a(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void

    :catch_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string p2, " rrsbcupshsoTemaeo,iekkeierec dre.rs  "

    const-string/jumbo p2, "rireibkereksdeoors  p.hs eeas mrcTe, c"

    const/4 v3, 0x5

    const-string p2, ",esre cprece eoT rsersisk k pmaohrio.e"

    const-string/jumbo p2, "seekTo, rich media processor seek err."

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string p2, ",Penu Baqky!esm e slloa=uTe"

    const-string/jumbo p2, "ksl o uenr, ueaamTPBes=y!le"

    const/4 v3, 0x3

    const-string p2, " eskea= orymT!us lllPasee,B"

    const-string/jumbo p2, "seekTo, mPlayerBase = null!"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string/jumbo v0, "t emt  ,lar ter  cstia  reip  vne,ortedouank:ts,e"

    const-string v0, "ea sv ap eer: lod  a eo,tskr nr,uit ttrenc,ei trt"

    const/4 v3, 0x6

    const-string v0, "ara oduntk rseneia,ev,se coetr  , tl ettrt  soi r"

    const-string v0, "error , seek to , state invalid , current state :"

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x3

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    throw p1
.end method

.method public a(IJ)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/d;->r()[Lcom/tencent/thumbplayer/api/TPTrackInfo;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo p2, "kit,r pcqrsatlafTlelnarInufo s "

    const/4 v3, 0x2

    const-string/jumbo p2, "uo,kebtsrcni f lalarf sItTr lan"

    const-string/jumbo p2, "fatal err, tpTrackInfos is null"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-ltz p1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    array-length v1, v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    add-int/lit8 v1, v1, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-gt p1, v1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {v1, p1, p2, p3}, Lcom/tencent/thumbplayer/adapter/a/b;->a(IJ)V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    aget-object v0, v0, p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v1, p1, p2, p3, v0}, Lcom/tencent/thumbplayer/adapter/c;->a(IJLcom/tencent/thumbplayer/api/TPTrackInfo;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo p2, "uracsoukr oftt ne d:nr "

    const-string/jumbo p2, "res:ra tof krnuo rnt dc"

    const/4 v3, 0x4

    const-string/jumbo p2, "urarnocpor dtrk :etof  "

    const-string p2, "error : track not found"

    const/4 v3, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    throw p1

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string p2, "e srmrteqaid el, :to cktranivcTsrea"

    const-string/jumbo p2, "le mreor,rat  :rt etn vasiccsdeakiT"

    const/4 v3, 0x6

    const-string/jumbo p2, "v,ss eikantrae:airTld co estrrc tl "

    const-string p2, "error : selectTrack , state invalid"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    throw p1
.end method

.method public a(Landroid/content/res/AssetFileDescriptor;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x0

    const/4 v1, 0x2

    const/4 v3, 0x7

    move v2, v1

    move v2, v1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Landroid/content/res/AssetFileDescriptor;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v0, " eamoeritroenrv  tu:a da r,sloacSdf"

    const-string/jumbo v0, "vaucod d ioro:iSsanar e,ear ftrle t"

    const/4 v3, 0x7

    const-string v0, " tr ooinca lD,s:ruoS rfdrea eetiada"

    const-string v0, "error : setDataSource , afd invalid"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    move v3, v2

    throw p1

    :cond_1
    const/4 v2, 0x0

    move v3, v2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x2

    move v3, v2

    const-string/jumbo v0, "oltneb a aaveii stutdseat,cSr:er rrD "

    const/4 v3, 0x5

    const-string/jumbo v0, "t: aebr aDutttsc  lasa,rSenvoird riee"

    const-string v0, "error : setDataSource , state invalid"

    const/4 v3, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    throw p1
.end method

.method public a(Landroid/os/ParcelFileDescriptor;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v1, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    if-eqz p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Landroid/os/ParcelFileDescriptor;)V

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v2, 0x6

    move v3, v2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v0, "idrseDuoeue:afa u  iaptonv ,Srtldc "

    const-string/jumbo v0, "s aedtuoid:lro ie,rranSD uec tfp av"

    const/4 v3, 0x3

    const-string v0, "error : setDataSource , pfd invalid"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    throw p1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v0, " tonelap t eDritr: iae tp,asdurarceov"

    const-string/jumbo v0, "tiaisv:plr s  aa,eu tetdarreon crteoD"

    const/4 v3, 0x6

    const-string v0, ",asenetaqoe d uS:trlatDca roiesi  vtr"

    const-string v0, "error : setDataSource , state invalid"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    throw p1
.end method

.method public a(Landroid/view/Surface;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Landroid/view/Surface;)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Landroid/view/Surface;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public a(Landroid/view/SurfaceHolder;)V
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Landroid/view/SurfaceHolder;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Landroid/view/SurfaceHolder;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$a;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$a;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$b;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$b;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$c;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$c;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$d;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$d;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$e;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$e;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$f;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$f;)V

    const/4 v2, 0x3

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$g;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$g;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$h;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$h;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$i;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$i;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$j;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$j;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$k;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$k;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$l;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$l;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$m;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v1, 0x5

    move v2, v1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$m;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$n;)V
    .locals 3

    const/4 v1, 0x6

    move v2, v1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$n;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$o;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$o;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/c$p;)V
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/adapter/a/c$p;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/e;)V
    .locals 3
    .param p1    # Lcom/tencent/thumbplayer/adapter/a/e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/tencent/thumbplayer/adapter/d;->a(Lcom/tencent/thumbplayer/adapter/a/e;Ljava/util/Map;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/e;IJ)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/16 v1, 0x11

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_3

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, p1, v1}, Lcom/tencent/thumbplayer/adapter/c;->a(Lcom/tencent/thumbplayer/adapter/a/e;Ljava/util/Map;)V

    const/4 v2, 0x3

    or-int/2addr v3, v2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/d;->m:I

    const/4 v3, 0x0

    const/4 v1, 0x2

    const/4 v3, 0x7

    move v2, v1

    move v2, v1

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/adapter/a/e;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-ne v0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/adapter/a/e;->a()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string p1, ""

    const-string p1, ""

    const-string p1, ""

    const-string p1, ""

    :goto_0
    const/4 v2, 0x3

    move v3, v2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x0

    invoke-interface {v0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Ljava/lang/String;IJ)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo p2, "sisyfn uonl!llm BiwseeeD Ph,taciqtn=i"

    const-string/jumbo p2, "nDwaniliq!fy onlu =,Bt ertPcsemleiish"

    const-string p2, "=ssmDewnBcnianPeufra,tehitl ly!i ilo "

    const-string/jumbo p2, "switchDefinition, mPlayerBase = null!"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void

    :cond_3
    const/4 v2, 0x1

    move v3, v2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string/jumbo p3, "ntaro rooi  asutei i stad eewilnsei,d rnf,,nec irsrh tt tcv"

    const-string p3, ", sii itte rrn ,ia twn  etfec e,v  snutit:hisodlrorsraadcen"

    const/4 v3, 0x0

    const-string/jumbo p3, "l idhb,nsii i:,r rt tae te rc tensasadru rie t,tcvwn ontfeo"

    const-string p3, "error , switch definition , state invalid , current state :"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    iget-object p3, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/e;Ljava/util/Map;)V
    .locals 4
    .param p1    # Lcom/tencent/thumbplayer/adapter/a/e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/tencent/thumbplayer/adapter/a/e;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    invoke-virtual {v0, p1, p2}, Lcom/tencent/thumbplayer/adapter/c;->a(Lcom/tencent/thumbplayer/adapter/a/e;Ljava/util/Map;)V

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string p2, "e Dc euotdrso nru:seaivaraSti,ter t l"

    const-string p2, "error : setDataSource , state invalid"

    const/4 v2, 0x4

    move v3, v2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/adapter/a/e;Ljava/util/Map;IJ)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/tencent/thumbplayer/adapter/a/e;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;IJ)V"
        }
    .end annotation

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v6, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/16 v1, 0x11

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-eqz v0, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0, p1, p2}, Lcom/tencent/thumbplayer/adapter/c;->a(Lcom/tencent/thumbplayer/adapter/a/e;Ljava/util/Map;)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz v0, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/d;->m:I

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/4 v1, 0x2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-ne v0, v1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/adapter/a/e;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    goto :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/4 v1, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-ne v0, v1, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/adapter/a/e;->a()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    goto :goto_0

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string p1, ""

    const-string p1, ""

    const/4 v7, 0x6

    const-string p1, ""

    const-string p1, ""

    :goto_0
    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    move v3, p3

    move v3, p3

    const/4 v7, 0x3

    move v3, p3

    move v3, p3

    move-wide v4, p4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-interface/range {v0 .. v5}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Ljava/lang/String;Ljava/util/Map;IJ)V

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    return-void

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string p2, " enosmepityciulta,rBa=hsmwieP D nllif"

    const-string/jumbo p2, "w sm=PsB,lhytieuDaeci!fnatl eio rinlm"

    const/4 v7, 0x4

    const-string p2, "DiPnaia!qlolnys c,e iBthlefsnwiu et=r"

    const-string/jumbo p2, "switchDefinition, mPlayerBase = null!"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v7, 0x6

    return-void

    :cond_3
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const-string/jumbo p3, "r saorn e e: idrnsi a e ra,wvtenhttntlcu,ds tr ici tesotiif"

    const-string/jumbo p3, "s flont tver  so id s t wnrceat,c,iauirtdi:ere, itntha inre"

    const/4 v7, 0x2

    const-string/jumbo p3, "tttmiai reeda:v,h,ls ef s nnocr citno ttewnraidri r s e, ui"

    const-string p3, "error , switch definition , state invalid , current state :"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget-object p3, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v6, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPCaptureParams;Lcom/tencent/thumbplayer/api/TPCaptureCallBack;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v1, 0x1

    move v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/api/TPCaptureParams;Lcom/tencent/thumbplayer/api/TPCaptureCallBack;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string/jumbo v0, "re ro r:pu pr cfltn,yoae ro oae"

    const-string v0, "error , no player for capture :"

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPOptionalParam;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x3

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/api/TPOptionalParam;)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Lcom/tencent/thumbplayer/api/TPOptionalParam;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string v0, "alpa bmseaPt,rntboeiilOerasdPi lnt avy"

    const-string v0, "eile bt ytaP aieO,riavnrdosaPtmnlasapl"

    const-string v0, ",ditlnuieePilPtranmsaatsa ovaOlyat e r"

    const-string/jumbo v0, "setPlayerOptionalParam , state invalid"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPVideoInfo;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string/jumbo v1, "ieIatduVlevn so etosfdanit"

    const/4 v4, 0x2

    const-string/jumbo v1, "siV lenpit eideotsnaIdtvfo"

    const-string/jumbo v1, "setVideoInfo state invalid"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x4

    move v4, v3

    if-eqz p1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPVideoInfo;->getHeight()J

    move-result-wide v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/adapter/b;->b(J)V

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPVideoInfo;->getWidth()J

    move-result-wide v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/adapter/b;->a(J)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPVideoInfo;->getDefinition()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/b;->c(Ljava/lang/String;)V

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPVideoInfo;->getVideoCodecId()I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/b;->g(I)V

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    move v3, v2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v0, "p ieraieqcSd eloD,oe dtar r: Asrvmatesiatu"

    const-string v0, "ers,Ad pastrsaiSurore:eeiDavm c  ttde olai"

    const/4 v3, 0x4

    const-string v0, " nsearcDeero ,duaeaAie idstStv sstmr a:lri"

    const-string v0, "error : setDataSource , mediaAsset invalid"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    throw p1

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo v0, "vi mdel, rrS toDatcuaarqrsetn  eiaets"

    const-string v0, " esisiavqtaceD detarrt eurnoortla , S"

    const/4 v3, 0x3

    const-string v0, "e o oiSttas,Daid:tetres rv l ceuanorr"

    const-string v0, "error : setDataSource , state invalid"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;IJ)V
    .locals 4
    .param p2    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSwitchDefMode;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/16 v1, 0x11

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {v0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;IJ)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string p2, "enhaebuysn!l,nwtfi=Bi alD siePti rlms"

    const-string/jumbo p2, "fnsna=Pl Bwince lareiiy ehsli,sut!mDt"

    const/4 v3, 0x0

    const-string/jumbo p2, "ss n,tuBreeiwyi!i= niaael utlDnoPlhmc"

    const-string/jumbo p2, "switchDefinition, mPlayerBase = null!"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    shr-int/2addr v3, v2

    const-string/jumbo p3, "ts rsrtprdu in tiociac: omi ,f ,neeetldiain wvt,te enrt r h"

    const-string p3, "cn m,ridhr ri,tasicen it  srt wlv t,i: trenfeued ootetaani "

    const/4 v3, 0x3

    const-string/jumbo p3, "wedn ,ioqnorae tlh,nect :nse eirt iitvst f,aticasr  irur dt"

    const-string p3, "error , switch definition , state invalid , current state :"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    move v3, v2

    iget-object p3, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    throw p1
.end method

.method public a(Lcom/tencent/thumbplayer/api/richmedia/ITPRichMediaSynchronizer;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-nez p1, :cond_1

    const/4 v1, 0x7

    move v2, v1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->n:Lcom/tencent/thumbplayer/f/a;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/f/a;->a(Lcom/tencent/thumbplayer/f/a$a;)V

    :cond_0
    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->n:Lcom/tencent/thumbplayer/f/a;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    instance-of v0, p1, Lcom/tencent/thumbplayer/f/a;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    check-cast p1, Lcom/tencent/thumbplayer/f/a;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->n:Lcom/tencent/thumbplayer/f/a;

    const/4 v2, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/adapter/d$1;

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lcom/tencent/thumbplayer/adapter/d$1;-><init>(Lcom/tencent/thumbplayer/adapter/d;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/f/a;->a(Lcom/tencent/thumbplayer/f/a$a;)V

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/e/b;)V
    .locals 4

    const/4 v2, 0x6

    move v3, v2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->a:Lcom/tencent/thumbplayer/e/b;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string v1, "PasrtTparPleoyd"

    const-string/jumbo v1, "retyopeaParldPT"

    const/4 v3, 0x2

    const-string v1, "elrmaAPPpyarTed"

    const-string v1, "TPPlayerAdapter"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, p1, v1}, Lcom/tencent/thumbplayer/e/b;->a(Lcom/tencent/thumbplayer/e/b;Ljava/lang/String;)V

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->a:Lcom/tencent/thumbplayer/e/b;

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->a(Lcom/tencent/thumbplayer/e/b;)V

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->a:Lcom/tencent/thumbplayer/e/b;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/e/b;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/adapter/g;->a(Ljava/lang/String;)V

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->a:Lcom/tencent/thumbplayer/e/b;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Lcom/tencent/thumbplayer/e/b;)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x1

    const/4 v1, 0x3

    const/4 v3, 0x7

    or-int/2addr v2, v1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo v1, "oPlsoai niba ,u=edlseourttRGma !eByAni"

    const-string v1, " o!GPb,deasotReAuBliyai lt=smnrnei aau"

    const/4 v3, 0x5

    const-string/jumbo v1, "neaGabds staiPBoel !tluyRil=nrm,Aui eo"

    const-string/jumbo v1, "setAudioGainRatio, mPlayerBase = null!"

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const-string v1, "NoevrVuaasP o,uaA  maii:orlosmir dtn,muencdteautrlers,ziasu  tl rtrt ee"

    const-string/jumbo v1, "s,estvuslretuPV:aoN ao amriu zte tdctsn  onlei aei,urtrAmr,d  araeolrim"

    const/4 v3, 0x7

    const-string v1, "eadsAlcpmaret,t  oda ,lNomnm otas  ss,vtuieouVirt ure rzleeira:atnrri e"

    const-string v1, "error , setAudioNormalizeVolumeParams , state invalid , current state :"

    const/4 v2, 0x2

    move v3, v2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    throw p1
.end method

.method public a(Ljava/lang/String;IJ)V
    .locals 2
    .param p2    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPSwitchDefMode;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;IJ)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;IJ)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-interface {v0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/adapter/c;->a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string p2, "aovae Sdqr rtr tdbeipt Silanrult:eseiuoc"

    const-string/jumbo p2, "u: tvorpbcn litorasalt eardt, uerieieSdS"

    const/4 v3, 0x7

    const-string p2, "Saslti  ebeodtot dSua,lricedrtva e:isurn"

    const-string p2, "error : addSubtitleSource, state invalid"

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    throw p1
.end method

.method public a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/List;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/TPOptionalParam;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {v0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/List;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x7

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/adapter/c;->a(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/List;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string p2, "ascmeoerd:rov tAauqad l,Tuindarkrreioi  dS"

    const-string p2, " idauicrqlAkcurndeSrts,irvTdode a aoao r:e"

    const/4 v3, 0x0

    const-string p2, "eTdroaedtdnukScraortiodloa r :a,ciAes iur "

    const-string p2, "error : addAudioTrackSource, state invalid"

    const/4 v3, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    throw p1
.end method

.method public a(Z)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x3

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v2, 0x2

    move v3, v2

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->a(Z)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string/jumbo v1, "etsntbla,eeuru= MulO !pusPmlB yeta"

    const-string/jumbo v1, "uaseprO!=lmtyMa etueeB ssPl,utul n"

    const/4 v3, 0x5

    const-string/jumbo v1, "pM!uruueB,emtePlaauly e= sOuttnl t"

    const-string/jumbo v1, "setOutputMute, mPlayerBase = null!"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Z)V

    const/4 v2, 0x4

    move v3, v2

    return-void

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string/jumbo v1, "tts t dpeMl rntu,  a  ierOtoie,tsuu: meae, cevtartrsrtu"

    const-string v1, "e tmse  lorcuettM:n,rtOtetru, s u r,dv i atttasuepia re"

    const/4 v3, 0x5

    const-string/jumbo v1, "t eaunvcqo rp ue t s Odtstuei ata, ttre,:ur rteMe,srntl"

    const-string v1, "error , setOutputMute , state invalid , current state :"

    const/4 v2, 0x0

    move v3, v2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    throw p1
.end method

.method public a(ZJJ)V
    .locals 10

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v1, 0x3

    and-int/2addr v9, v1

    const/4 v8, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x1

    if-eqz v0, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-eqz v1, :cond_0

    const/4 v8, 0x7

    and-int/2addr v9, v8

    move v2, p1

    move v2, p1

    const/4 v9, 0x3

    move v2, p1

    move v2, p1

    move-wide v3, p2

    move-wide v5, p4

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-interface/range {v1 .. v6}, Lcom/tencent/thumbplayer/adapter/a/b;->a(ZJJ)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    goto :goto_0

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-string/jumbo v1, "sasmueslbe loPa!Loct=Bnkry  p,ol"

    const-string/jumbo v1, "n lBocu La ks!beyoma=relPotlpas,"

    const/4 v9, 0x1

    const-string v1, "eLbmlPopcsaBklsan oeeym,=! al ru"

    const-string/jumbo v1, "setLoopback, mPlayerBase = null!"

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    move v3, p1

    move v3, p1

    move v3, p1

    move v3, p1

    move-wide v4, p2

    move-wide v6, p4

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual/range {v2 .. v7}, Lcom/tencent/thumbplayer/adapter/c;->a(ZJJ)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    return-void

    :cond_1
    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-string p3, "e,i oketvL oc  taro,trpb:sur nad ta ts eernoe,abs tci"

    const-string p3, " nv ebt irsottoert r,d,c ec,brrate kLasa aonsu t i:pe"

    const-string p3, "asriLb, rb,aeidte rv :pktctero olsn t ta e unesoctr,a"

    const-string p3, "error , setLoopback , state invalid , current state :"

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    iget-object p3, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v9, 0x7

    const/4 v8, 0x0

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x5

    const/4 v8, 0x7

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    throw p1
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->state()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public b(I)J
    .locals 4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->b(I)J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-wide v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v0, "=Ponalullye tPtto  eumnyBe!,e usprerrLg,nrar "

    const/4 v3, 0x0

    const-string/jumbo v0, "etuet uP=nrs!rngPrreyp  tme Bllyao,oLg ,lenur"

    const-string/jumbo v0, "getPropertyLong, mPlayerBase = null, return !"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x7

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-wide v0
.end method

.method public b(F)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->b(F)V

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string/jumbo v1, "eyusrBep a topa p=lPllltnSieeayed,am!s"

    const-string v1, " eS!yespeyBdpRneoa=i  ll,laureamltaPts"

    const/4 v3, 0x2

    const-string v1, "  ySRmtnqesalei ylueeBo=atlPpaPls!d,ea"

    const-string/jumbo v1, "setPlaySpeedRatio, mPlayerBase = null!"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->b(F)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->n:Lcom/tencent/thumbplayer/f/a;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    :try_start_0
    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/f/a;->a(F)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void

    :catch_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v2, 0x2

    move v3, v2

    const-string v0, "ahspeoe eRiRs ,qtooadseyrP priSmyads aSea.eptcilrPrctedritsole"

    const-string v0, "eor tRrcqs.oiaPmdhp,saapPeiyreaot ap dterySsie RoedicesreStl l"

    const/4 v3, 0x7

    const-string/jumbo v0, "setPlaySpeedRatio, rich media processor setPlaySpeedRatio err."

    const/4 v2, 0x0

    shl-int/2addr v3, v2

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const-string/jumbo v1, "scimld:rsittduSaoaevtoetl e ra,et n, RtrPtsr,a   e p iryaee"

    const-string/jumbo v1, "n sedr e tuplPcrt,eoleaS  e,i i :tt oa ,ttisRrdresysevataar"

    const/4 v3, 0x5

    const-string v1, "eey,oR,r, en u stpaodi t  noittsreaPe Srsaa ertacllitt v:re"

    const-string v1, "error , setPlaySpeedRatio , state invalid , current state :"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    throw p1
.end method

.method public b(II)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {v0, p1, p2}, Lcom/tencent/thumbplayer/adapter/g;->b(II)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public b(IJ)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x6

    const/4 v1, 0x3

    const/4 v3, 0x5

    move v2, v1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/d;->r()[Lcom/tencent/thumbplayer/api/TPTrackInfo;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string/jumbo p2, "rlilsbkfncomtalrrTp,tfs  u aenI"

    const-string p2, "asimkT rplr lrun,tIcf naaftosle"

    const/4 v3, 0x2

    const-string/jumbo p2, "oek atusIlnfrpTi,rsf lct  luaar"

    const-string/jumbo p2, "fatal err, tpTrackInfos is null"

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-ltz p1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    array-length v1, v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    add-int/lit8 v1, v1, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-gt p1, v1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {v1, p1, p2, p3}, Lcom/tencent/thumbplayer/adapter/a/b;->b(IJ)V

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    aget-object v0, v0, p1

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v1, p1, p2, p3, v0}, Lcom/tencent/thumbplayer/adapter/c;->b(IJLcom/tencent/thumbplayer/api/TPTrackInfo;)V

    const/4 v3, 0x0

    return-void

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo p2, "o eodtrpac krnrtonuo fr"

    const-string p2, " krrotoouto nr cfena rd"

    const/4 v3, 0x2

    const-string/jumbo p2, "o :knf rqcnertt o odaur"

    const-string p2, "error : track not found"

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    throw p1

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string/jumbo p2, "scset,nviaded l ak:reTrs lieb rtc aro"

    const-string/jumbo p2, "l  tvb i kdlese:aicrc s,rTredenatoart"

    const-string/jumbo p2, "teemiTsiandocetsat,k :vlerl cadre   r"

    const-string p2, "error : deselectTrack , state invalid"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    throw p1
.end method

.method public b(Lcom/tencent/thumbplayer/api/TPVideoInfo;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v1, 0x3

    const/4 v4, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string/jumbo v1, "su IoddV ofotldieenatitaeuavn"

    const-string/jumbo v1, "niuIeduesdtaoevftpd  Voilatan"

    const/4 v4, 0x6

    const-string v1, " dalibe nsetiatoeIfndtVidavuo"

    const-string/jumbo v1, "updateVideoInfo state invalid"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->e(Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz p1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPVideoInfo;->getHeight()J

    move-result-wide v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/adapter/b;->b(J)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPVideoInfo;->getWidth()J

    move-result-wide v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/adapter/b;->a(J)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPVideoInfo;->getDefinition()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/b;->c(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/TPVideoInfo;->getVideoCodecId()I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/b;->g(I)V

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-void
.end method

.method public b(Z)V
    .locals 4

    const/4 v2, 0x7

    move v3, v2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v1, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->b(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x3

    const-string v1, " nPmrpua !eouBk=a elsyoallcsetLb"

    const-string/jumbo v1, "setLoopback, mPlayerBase = null!"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/c;->b(Z)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v1, "ee,tootpston:tbdrcpsn ,api,rkurtevreia r  sLel t  ac "

    const-string v1, "eiav  op  istt errc tar dn,ct,kbltrre,anL o: stpsoeeu"

    const/4 v3, 0x7

    const-string v1, "bcrt,easqvt d ausr  ,oaLarte p t:ik r,er loeonectts n"

    const-string v1, "error , setLoopback , state invalid , current state :"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    throw p1
.end method

.method public c(Z)Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v1, 0x3

    shr-int/2addr v2, v1

    const/4 p1, 0x0

    xor-int/2addr v2, p1

    const/4 v1, 0x1

    move v2, v1

    return-object p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->c(Z)Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p1
.end method

.method public c(I)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->c(I)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p1

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string/jumbo v0, "raslpBltiS,megnu uP rl ore e!ePtgryrnsr,t aenyt"

    const-string/jumbo v0, "getPropertyString, mPlayerBase = null, return !"

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x7

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x7

    xor-int/2addr v2, v1

    return-object p1
.end method

.method public c(IJ)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/16 v1, 0x12

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz v0, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/d;->s()[Lcom/tencent/thumbplayer/api/TPProgramInfo;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x1

    new-array v0, v0, [Lcom/tencent/thumbplayer/api/TPProgramInfo;

    :cond_0
    const/4 v3, 0x0

    if-ltz p1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    array-length v1, v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    add-int/lit8 v1, v1, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-gt p1, v1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {v1, p1, p2, p3}, Lcom/tencent/thumbplayer/adapter/a/b;->c(IJ)V

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    aget-object p1, v0, p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/adapter/c;->a(Lcom/tencent/thumbplayer/api/TPProgramInfo;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo p2, "fdamnoe gru x  :qrrp mroednnioo"

    const-string p2, ": egu f qo rradonrdmr nxrneopio"

    const/4 v3, 0x0

    const-string/jumbo p2, "r d odaiopxomr nerog:foeturrnn "

    const-string p2, "error : program index not found"

    const/4 v3, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    throw p1

    :cond_3
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string p2, "egtsmbti  v:arerse ret, allasirrP onc"

    const-string p2, "  sriredsr:r,eleatP moaevtcia n slgrt"

    const/4 v3, 0x4

    const-string/jumbo p2, "tsr  rurlvraseetlaeecnito , o:aPgidmr"

    const-string p2, "error : selectProgram , state invalid"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    throw p1
.end method

.method public c()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->state()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    shl-int/2addr v3, v2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    return v0
.end method

.method public d()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/thumbplayer/adapter/d;->m:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public e()Lcom/tencent/thumbplayer/adapter/b;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public f()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->f()Z

    move-result v0

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/d;->z()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->a:Lcom/tencent/thumbplayer/e/b;

    const/4 v4, 0x4

    invoke-direct {p0, v0, v1}, Lcom/tencent/thumbplayer/adapter/d;->a(ILcom/tencent/thumbplayer/e/b;)Lcom/tencent/thumbplayer/adapter/a/b;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v1, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->setInnerPlayStateState(I)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->f()V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-void

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v1, "rledcropeeare tma rf,la  eyp"

    const-string/jumbo v1, "rpemr ca,rrae de laretolyfe "

    const/4 v4, 0x5

    const-string v1, ", re r rqcr eiaaederpelftalo"

    const-string v1, "error , create player failed"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    throw v0

    :cond_1
    const/4 v4, 0x3

    new-instance v0, Ljava/io/IOException;

    const/4 v4, 0x2

    const-string v1, "a s piolasraei,o,a ertoepd rreur r dc"

    const-string v1, "enirolsadaruo a redoer,e  rrc,p tpai "

    const/4 v4, 0x3

    const-string v1, "ernmrctrerial a ve  ourarda,i ppdo,se"

    const-string v1, "error , prepare , data source invalid"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    throw v0

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v2, "ro vod tpeetrans rsara  pre, iuttrcreiateb l :en,"

    const-string/jumbo v2, "o errbpp  ar  r ,ents surrdvt atea:,cnrei tetaeil"

    const/4 v4, 0x1

    const-string v2, "cteprbu  :eipa tr rastv  atn,le raeet eri,,osdn r"

    const-string v2, "error , prepare , state invalid , current state :"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    throw v0
.end method

.method public g()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x7

    move v4, v3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->f()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/adapter/d;->z()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->a:Lcom/tencent/thumbplayer/e/b;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {p0, v0, v1}, Lcom/tencent/thumbplayer/adapter/d;->a(ILcom/tencent/thumbplayer/e/b;)Lcom/tencent/thumbplayer/adapter/a/b;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v1, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->setInnerPlayStateState(I)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->g()V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v1, "fela euue rr ,ye raecloritra"

    const-string/jumbo v1, "rrlcdiueele aarer ,oya t ref"

    const/4 v4, 0x3

    const-string v1, " ryeicrpp erftalearae  ldeo,"

    const-string v1, "error , create player failed"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    throw v0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string/jumbo v1, "ls,  r parstdad n ie n,ip vloerpectvar daeoetraau iir"

    const/4 v4, 0x6

    const-string v1, "error , prepare , state invalid , data source invalid"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    throw v0

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string/jumbo v2, "rer ceeeqn ast,  tretio r npdralus,a,r :p reati v"

    const-string v2, "error , prepare , state invalid , current state :"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    throw v0
.end method

.method public h()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v1, 0x5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v3, 0x3

    move v4, v3

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->h()V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void

    :catch_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const-string/jumbo v1, "svs rd ,tnlqoeeattrati irsa "

    const-string v1, "d tatsasqrvlt itrero,ei,  an"

    const/4 v4, 0x7

    const-string v1, "a,,metir v sai osdlrtertrt n"

    const-string v1, "error , start ,state invalid"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    throw v0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string/jumbo v1, "rrp otlori e ul  ayr,lea, nrst"

    const-string v1, "error , start , player is null"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    throw v0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const-string v2, ":out bsrtrs r acnateei t,tedlsn,rietr  v ,r a s"

    const-string/jumbo v2, "sts,rie  nsntr, uo t t  i aedr rarv,:rlttaseetc"

    const/4 v4, 0x2

    const-string/jumbo v2, "tadneeusa  nur ,t ra evc i,r,tiorlstatrs r  t:t"

    const-string v2, "error , start , state invalid , current state :"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    throw v0
.end method

.method public i()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x6

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-boolean v2, p0, Lcom/tencent/thumbplayer/adapter/d;->f:Z

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v4, 0x7

    return-void

    :cond_0
    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->i()V

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-void

    :catch_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string v1, " vaameepprta,e,du inlrt oisr"

    const-string/jumbo v1, "sltma eri trnv,oie,rad pau e"

    const/4 v4, 0x7

    const-string/jumbo v1, "si srntrqpelev  ,,uae odtraa"

    const-string v1, "error , pause ,state invalid"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    throw v0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v1, "nlsrlyuer,rss ueo,ail    p per"

    const-string/jumbo v1, "p s oeyeiu rpr,   la,erarusnll"

    const/4 v4, 0x4

    const-string v1, "e emualrlry ilo  s,ru  pnpae,r"

    const-string v1, "error , pause , player is null"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    throw v0

    :cond_2
    const/4 v4, 0x6

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string v2, "bpiro ortasasiartsevl enute u e,t,rc r   t,:dna"

    const-string v2, "   n be: , nt retirespic,stoleatd,ateauvrrsu ar"

    const/4 v4, 0x5

    const-string/jumbo v2, "n,l sbscrrei,r teaadneusar u: t to e etr,piv t "

    const-string v2, "error , pause , state invalid , current state :"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    throw v0
.end method

.method public j()V
    .locals 5

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v1, 0x7

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/16 v0, 0x9

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/16 v2, 0x8

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-interface {v1}, Lcom/tencent/thumbplayer/adapter/a/b;->j()V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-void

    :catchall_0
    move-exception v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto :goto_0

    :catch_0
    :try_start_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v2, "eares uoi, tudrtnt vi,por a"

    const-string/jumbo v2, "ri pd ulv, nattoor,trae ies"

    const/4 v4, 0x4

    const-string v2, ",tli daprso rn,v tiast orep"

    const-string v2, "error , stop ,state invalid"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    throw v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v2, v0}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    throw v1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v1, ",  lti rqelsu,po  rno pyaespr"

    const-string v1, " op,ulaplt, rr oesrn yepr is "

    const/4 v4, 0x4

    const-string/jumbo v1, "pus,o nl lareyr poress,ir   t"

    const-string v1, "error , stop , player is null"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    throw v0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x2

    const/4 v3, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v2, "stlmet  ,,qde,oret:  a  a nesrrrir  cavtpsuott"

    const-string/jumbo v2, "trit ltrqs eae:apno ,,,srrcv ore  n a  tuedtst"

    const/4 v4, 0x5

    const-string/jumbo v2, "o: ,o suan i to res  at,rtaecpnsi,er  rttldter"

    const-string v2, "error , stop , state invalid , current state :"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    throw v0
.end method

.method public k()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string v2, "ees s e, urtrsrtneca:t"

    const/4 v4, 0x3

    const-string v2, "asretbesut ecn rt:r,te"

    const-string/jumbo v2, "reset, current state :"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->k()V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->l()V

    const/4 v4, 0x0

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->a()V

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->n()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->k:Lcom/tencent/thumbplayer/adapter/strategy/a;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/d;->f:Z

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->setLastState(I)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void
.end method

.method public l()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v3, 0x4

    or-int/2addr v4, v3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v2, "er trnusce t, tral:asuee"

    const-string v2, " nemlr:rst,  tsaueetreca"

    const/4 v4, 0x2

    const-string/jumbo v2, "re:et eplacrs, esettu an"

    const-string/jumbo v2, "release, current state :"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/e/a;->c(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->l()V

    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    :cond_0
    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v4, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->a()V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->g:Lcom/tencent/thumbplayer/adapter/g;

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/g;->d()V

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->k:Lcom/tencent/thumbplayer/adapter/strategy/a;

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/adapter/d;->f:Z

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->e:Lcom/tencent/thumbplayer/api/TPPlayerState;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/16 v1, 0xb

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/api/TPPlayerState;->changeState(I)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void
.end method

.method public m()J
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v6, 0x7

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    move v6, v5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->j()J

    move-result-wide v3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    cmp-long v0, v3, v1

    const/4 v5, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-lez v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v6, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->j()J

    move-result-wide v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    return-wide v0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v5, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/16 v3, 0xb

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v0, v3}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-nez v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    return-wide v1

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-nez v0, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string/jumbo v3, "rna t,reqB l0nelmM!,sly urgueDrtPots a ae=ni"

    const-string v3, "a, soetet=aslrgril munPaDtlnru  oy0eB,n r!Me"

    const/4 v6, 0x4

    const-string/jumbo v3, "l sr, t DnneuBeyeu rl!aPgsst0ano,uai=lm tMre"

    const-string/jumbo v3, "getDurationMs, mPlayerBase = null, return 0!"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v0, v3}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-wide v1

    :cond_2
    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->m()J

    move-result-wide v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v2, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v2, v0, v1}, Lcom/tencent/thumbplayer/adapter/b;->h(J)V

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-wide v0
.end method

.method public n()J
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/16 v1, 0xc

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v5, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->h()J

    move-result-wide v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-wide v0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-wide v1

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v5, 0x2

    const/4 v4, 0x2

    if-nez v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v3, "iyCmaMu!l mePrnsesreltbnursi,rBoannto=0  t  retuelP"

    const-string v3, "0r smbPPnur=n tCystre!iiuegnllrlt  toBo ,easeearMun"

    const/4 v5, 0x5

    const-string/jumbo v3, "nauPotel rrBnyi!se, ee,ra oll nue tnMtm0igutPCor=ss"

    const-string/jumbo v3, "getCurrentPositionMs, mPlayerBase = null, return 0!"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0, v3}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-wide v1

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->n()J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v2, :cond_3

    invoke-virtual {v2, v0, v1}, Lcom/tencent/thumbplayer/adapter/b;->f(J)V

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    return-wide v0
.end method

.method public o()J
    .locals 6

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/16 v1, 0xc

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-wide/16 v1, 0x0

    const/4 v5, 0x4

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-wide v1

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-nez v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string/jumbo v3, "nesBebt ,ur uPBtfllnngeeur=t, Drayfomruaia dMrue!es "

    const-string/jumbo v3, "soerrBun l t eumtrefear,la,e0duigen!yMDnPsr=uf t aBu"

    const-string v3, ",   rPuuifBuDerualeenanmraersBtlln,Ms t=d!ferg uyeo0"

    const-string/jumbo v3, "getBufferedDurationMs, mPlayerBase = null, return 0!"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0, v3}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-wide v1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->o()J

    move-result-wide v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v2, v0, v1}, Lcom/tencent/thumbplayer/adapter/b;->i(J)V

    :cond_2
    const/4 v4, 0x5

    const/4 v5, 0x2

    return-wide v0
.end method

.method public p()I
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    move v5, v4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->a()J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    cmp-long v0, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    if-lez v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->a()J

    move-result-wide v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    long-to-int v0, v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    return v0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/16 v1, 0xd

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v1, 0x0

    move v5, v1

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-nez v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo v2, "peaehs,piietVrdt W odgro!rt"

    const-string/jumbo v2, "tiaWdhVproer r!,s geetoiedt"

    const/4 v5, 0x3

    const-string v2, "dtreeVioqrehWti!t a,r godet"

    const-string/jumbo v2, "getVideoWidth, state error!"

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, v2}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v5, 0x6

    return v1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-nez v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string v2, "PestWi=B oa!a,ums trhendee  ltg uyirqn,eVdll"

    const-string/jumbo v2, "yera,ltuqohi rreeimPl,us t!Vedne tnWg= alB d"

    const/4 v5, 0x0

    const-string v2, "= em  tlrd  le,me!nrihu0sV,tatydBienealrPuWg"

    const-string/jumbo v2, "getVideoWidth, mPlayerBase = null, return 0!"

    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    const/4 v5, 0x2

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->p()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x1

    const/4 v4, 0x1

    if-eqz v1, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    int-to-long v2, v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1, v2, v3}, Lcom/tencent/thumbplayer/adapter/b;->a(J)V

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    return v0
.end method

.method public q()I
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    move v5, v4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->b()J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    cmp-long v0, v0, v2

    const/4 v5, 0x7

    if-lez v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->b()J

    move-result-wide v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    long-to-int v0, v0

    const/4 v4, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    return v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/16 v1, 0xd

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-nez v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v4, 0x4

    move v5, v4

    const-string v2, " d!toVigHroers stgeitearee,h"

    const-string/jumbo v2, "s!sehgaitrH eeVoodte gre,rit"

    const/4 v5, 0x3

    const-string v2, "dtg tbeoeitirgtVersa,eH!h er"

    const-string/jumbo v2, "getVideoHeight, state error!"

    :goto_0
    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0, v2}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    return v1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v4, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-nez v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x6

    const-string/jumbo v2, "rdgVe umeemilhueru yies t aon0=t! nPBrleH,g,t"

    const-string/jumbo v2, "ynomlle eti iBgu,!,en r=t 0geurdarhsPlVeHetm "

    const-string v2, ", g isVpohe B=a,l  iyetegmealnuHelrPtu0dr!ret"

    const-string/jumbo v2, "getVideoHeight, mPlayerBase = null, return 0!"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    goto :goto_0

    :cond_2
    const/4 v4, 0x5

    move v5, v4

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->q()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    int-to-long v2, v0

    const/4 v4, 0x5

    or-int/2addr v5, v4

    invoke-virtual {v1, v2, v3}, Lcom/tencent/thumbplayer/adapter/b;->b(J)V

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    return v0
.end method

.method public r()[Lcom/tencent/thumbplayer/api/TPTrackInfo;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->r()[Lcom/tencent/thumbplayer/api/TPTrackInfo;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->i:Lcom/tencent/thumbplayer/adapter/c;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/c;->b()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-array v1, v1, [Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    check-cast v0, [Lcom/tencent/thumbplayer/api/TPTrackInfo;

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0
.end method

.method public s()[Lcom/tencent/thumbplayer/api/TPProgramInfo;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->s()[Lcom/tencent/thumbplayer/api/TPProgramInfo;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->s()[Lcom/tencent/thumbplayer/api/TPProgramInfo;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-array v0, v0, [Lcom/tencent/thumbplayer/api/TPProgramInfo;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public t()J
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->j:Lcom/tencent/thumbplayer/adapter/i;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/16 v1, 0x13

    const/4 v4, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/adapter/i;->a(I)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v5, 0x3

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x3

    if-nez v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/b;->i()J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-wide v0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-wide v1

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-nez v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->b:Lcom/tencent/thumbplayer/e/a;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const-string v3, "eeI,otfD alueeumr!arB siFeOyesn,u  =lntr nxrllPeftme0"

    const-string v3, " enI0esfq!r, eesiglDnerl, FurtPnluOmt=eBlfxam tuerya "

    const-string/jumbo v3, "getDemuxerOffsetInFile, mPlayerBase = null, return 0!"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, v3}, Lcom/tencent/thumbplayer/e/a;->d(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-wide v1

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->t()J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/tencent/thumbplayer/adapter/d;->l:Lcom/tencent/thumbplayer/adapter/b;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v2, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v2, v0, v1}, Lcom/tencent/thumbplayer/adapter/b;->g(J)V

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    return-wide v0
.end method

.method public u()Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/d;->d:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->u()Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method
