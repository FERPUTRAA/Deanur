.class Lcom/tencent/thumbplayer/adapter/f$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/adapter/a/c$f;
.implements Lcom/tencent/thumbplayer/adapter/a/c$g;
.implements Lcom/tencent/thumbplayer/adapter/a/c$h;
.implements Lcom/tencent/thumbplayer/adapter/a/c$i;
.implements Lcom/tencent/thumbplayer/adapter/a/c$j;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/adapter/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "a"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/adapter/f;


# direct methods
.method private constructor <init>(Lcom/tencent/thumbplayer/adapter/f;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/thumbplayer/adapter/f;Lcom/tencent/thumbplayer/adapter/f$1;)V
    .locals 2

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/adapter/f$a;-><init>(Lcom/tencent/thumbplayer/adapter/f;)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method private a(JJLjava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~sM4@c  @~@ @v/ b@~~~@~uo@  ~ ~ f~@n@oo@~ml @~tl/~~i~S~@@@sb  f ~t@@  o~r~@aiy 1~-d~o.i@ ~K@@bo"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    new-instance p1, Lcom/tencent/thumbplayer/d/b$c;

    const/4 v1, 0x5

    invoke-direct {p1}, Lcom/tencent/thumbplayer/d/b$c;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p2}, Lcom/tencent/thumbplayer/adapter/f;->b(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/tplayer/a;

    move-result-object p2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object p2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    return-void
.end method

.method private b(JJLjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x2

    new-instance p1, Lcom/tencent/thumbplayer/d/b$b;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p1}, Lcom/tencent/thumbplayer/d/b$b;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p2}, Lcom/tencent/thumbplayer/adapter/f;->b(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/tplayer/a;

    move-result-object p2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object p2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method private c(JJLjava/lang/Object;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance p1, Lcom/tencent/thumbplayer/d/b$s;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {p1}, Lcom/tencent/thumbplayer/d/b$s;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast p5, Ljava/lang/Long;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p5}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1, v0, v1}, Lcom/tencent/thumbplayer/d/b$s;->a(J)V

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    long-to-int p2, p3

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/d/b$s;->b(I)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object p2, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p2}, Lcom/tencent/thumbplayer/adapter/f;->b(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/tplayer/a;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p2}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p2, p1}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v3, 0x5

    return-void
.end method


# virtual methods
.method public a()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-instance v0, Lcom/tencent/thumbplayer/d/b$o;

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v0}, Lcom/tencent/thumbplayer/d/b$o;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/f;->a(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/adapter/d;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/adapter/d;->d()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/d/b$o;->b(I)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v4, 0x7

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/f;->a(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/adapter/d;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/adapter/d;->m()J

    move-result-wide v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/d/b$o;->a(J)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v4, 0x4

    const/4 v3, 0x4

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/f;->b(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/tplayer/a;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v3, 0x3

    shl-int/2addr v4, v3

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/f;->c(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/adapter/g;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/g;->a()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-void
.end method

.method public a(IIJJ)V
    .locals 9
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TPErrorType;
        .end annotation
    .end param

    const/4 v8, 0x1

    new-instance v0, Lcom/tencent/thumbplayer/d/b$i;

    const/4 v8, 0x7

    invoke-direct {v0}, Lcom/tencent/thumbplayer/d/b$i;-><init>()V

    const/4 v8, 0x3

    invoke-virtual {v0, p2}, Lcom/tencent/thumbplayer/d/b$i;->c(I)V

    const/4 v8, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/d/b$i;->b(I)V

    const/4 v8, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/f;->a(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/adapter/d;

    move-result-object v1

    const/4 v8, 0x4

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/adapter/d;->u()Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;

    move-result-object v1

    const/4 v8, 0x4

    if-nez v1, :cond_0

    const/4 v8, 0x1

    new-instance v1, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;

    const/4 v8, 0x7

    invoke-direct {v1}, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;-><init>()V

    :cond_0
    const/4 v8, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/d/b$i;->a(Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;)V

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v8, 0x2

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/f;->a(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/adapter/d;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v2, 0x0

    const/4 v8, 0x7

    invoke-virtual {v1, v2}, Lcom/tencent/thumbplayer/adapter/d;->c(Z)Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;

    move-result-object v1

    const/4 v8, 0x2

    if-nez v1, :cond_1

    const/4 v8, 0x5

    new-instance v1, Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;

    const/4 v8, 0x6

    invoke-direct {v1}, Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;-><init>()V

    :cond_1
    const/4 v8, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/thumbplayer/d/b$i;->a(Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;)V

    const/4 v8, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v8, 0x5

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/f;->b(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/tplayer/a;

    move-result-object v1

    const/4 v8, 0x7

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object v1

    const/4 v8, 0x7

    invoke-virtual {v1, v0}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v8, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/f;->c(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/adapter/g;

    move-result-object v1

    const/4 v8, 0x7

    move v2, p1

    move v2, p1

    move v2, p1

    move v2, p1

    const/4 v8, 0x2

    move v3, p2

    move v3, p2

    move v3, p2

    move v3, p2

    move-wide v4, p3

    move-wide v6, p5

    const/4 v8, 0x1

    invoke-virtual/range {v1 .. v7}, Lcom/tencent/thumbplayer/adapter/g;->a(IIJJ)V

    const/4 v8, 0x6

    return-void
.end method

.method public a(IJJLjava/lang/Object;)V
    .locals 9

    const/4 v8, 0x3

    const/4 v0, 0x4

    if-eq p1, v0, :cond_2

    const/4 v8, 0x2

    const/16 v0, 0xc8

    const/4 v8, 0x4

    if-eq p1, v0, :cond_1

    const/4 v8, 0x1

    const/16 v0, 0xc9

    const/4 v8, 0x7

    if-eq p1, v0, :cond_0

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-wide v1, p2

    move-wide v3, p4

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    const/4 v8, 0x3

    invoke-direct/range {v0 .. v5}, Lcom/tencent/thumbplayer/adapter/f$a;->b(JJLjava/lang/Object;)V

    goto :goto_0

    :cond_1
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-wide v1, p2

    move-wide v3, p4

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    const/4 v8, 0x4

    invoke-direct/range {v0 .. v5}, Lcom/tencent/thumbplayer/adapter/f$a;->a(JJLjava/lang/Object;)V

    const/4 v8, 0x0

    goto :goto_0

    :cond_2
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-wide v1, p2

    move-wide v3, p4

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    const/4 v8, 0x2

    invoke-direct/range {v0 .. v5}, Lcom/tencent/thumbplayer/adapter/f$a;->c(JJLjava/lang/Object;)V

    :goto_0
    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v8, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/f;->c(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/adapter/g;

    move-result-object v1

    const/4 v8, 0x2

    move v2, p1

    move v2, p1

    move v2, p1

    move-wide v3, p2

    move-wide v5, p4

    move-object v7, p6

    move-object v7, p6

    move-object v7, p6

    const/4 v8, 0x7

    invoke-virtual/range {v1 .. v7}, Lcom/tencent/thumbplayer/adapter/g;->a(IJJLjava/lang/Object;)V

    const/4 v8, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/TPDrmInfo;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Lcom/tencent/thumbplayer/d/b$h;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0}, Lcom/tencent/thumbplayer/d/b$h;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/d/b$h;->a(Lcom/tencent/thumbplayer/api/TPDrmInfo;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/f;->b(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/tplayer/a;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v1, v0}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/f;->c(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/adapter/g;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/adapter/g;->a(Lcom/tencent/thumbplayer/api/TPDrmInfo;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method public c()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/d/b$q;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/tencent/thumbplayer/d/b$q;-><init>()V

    const/4 v2, 0x1

    move v3, v2

    iget-object v1, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v1}, Lcom/tencent/thumbplayer/adapter/f;->b(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/tplayer/a;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v1, v0}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/adapter/f$a;->a:Lcom/tencent/thumbplayer/adapter/f;

    const/4 v3, 0x7

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/adapter/f;->c(Lcom/tencent/thumbplayer/adapter/f;)Lcom/tencent/thumbplayer/adapter/g;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/adapter/g;->c()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    return-void
.end method
