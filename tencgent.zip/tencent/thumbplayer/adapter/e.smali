.class public Lcom/tencent/thumbplayer/adapter/e;
.super Ljava/lang/Object;


# direct methods
.method public static a(Lcom/tencent/thumbplayer/e/b;Lcom/tencent/thumbplayer/tplayer/a;)Lcom/tencent/thumbplayer/adapter/a;
    .locals 4
    .param p0    # Lcom/tencent/thumbplayer/e/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/tencent/thumbplayer/tplayer/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "los-va .@n@t~ ~~ ~@~@~@~~ f~~@~ i~~ S/4@y~@@f ~1u@@i   db@@~@c ~ ob @t/@@~oK~bls~~  @Mio ~o@@ rm"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getNewReportEnable()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/adapter/d;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/tplayer/a;->a()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {v0, v1, p0}, Lcom/tencent/thumbplayer/adapter/d;-><init>(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance p0, Lcom/tencent/thumbplayer/adapter/f;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/adapter/f;-><init>(Lcom/tencent/thumbplayer/adapter/d;Lcom/tencent/thumbplayer/tplayer/a;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/adapter/f;->a()Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    check-cast p0, Lcom/tencent/thumbplayer/adapter/a;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/adapter/d;

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/tplayer/a;->a()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v0, p1, p0}, Lcom/tencent/thumbplayer/adapter/d;-><init>(Landroid/content/Context;Lcom/tencent/thumbplayer/e/b;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0
.end method
