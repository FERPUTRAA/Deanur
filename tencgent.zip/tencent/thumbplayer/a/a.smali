.class public Lcom/tencent/thumbplayer/a/a;
.super Ljava/lang/Object;


# direct methods
.method public static a(Lcom/tencent/thumbplayer/core/common/TPVideoFrame;)Landroid/graphics/Bitmap;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "o@s ~n~@M @@c1~b ~/@ yml@f b ~~o~ @it~iu  ~~rd@~ @sSo~to@bo@~@.~ ~i f @o@  4@~~~K-@@~~va~@@/ ~ l"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->data:[[B

    const/4 v5, 0x3

    array-length v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-lez v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->height:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x1

    iget v2, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->width:I

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-nez v2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v3, 0x1

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x5

    aget-object v0, v0, v3

    const/4 v5, 0x3

    iget p0, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->rotation:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v0, v2, v1, p0}, Lcom/tencent/thumbplayer/a/a;->a([BIII)Landroid/graphics/Bitmap;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-object p0

    :cond_1
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 p0, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-object p0
.end method

.method private static a([BIII)Landroid/graphics/Bitmap;
    .locals 10

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static {p0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object p0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    sget-object v0, Landroid/graphics/Bitmap$Config;->RGB_565:Landroid/graphics/Bitmap$Config;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {p1, p2, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v1, p0}, Landroid/graphics/Bitmap;->copyPixelsFromBuffer(Ljava/nio/Buffer;)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    if-eqz p3, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    new-instance v6, Landroid/graphics/Matrix;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-direct {v6}, Landroid/graphics/Matrix;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    int-to-float p0, p3

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v6, p0}, Landroid/graphics/Matrix;->postRotate(F)Z

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    const/4 v2, 0x0

    const/4 v9, 0x2

    const/4 v3, 0x0

    const/4 v9, 0x5

    const/4 v3, 0x0

    const/4 v9, 0x2

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v4

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v5

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    const/4 v7, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static/range {v1 .. v7}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIIILandroid/graphics/Matrix;Z)Landroid/graphics/Bitmap;

    move-result-object v1

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    return-object v1
.end method

.method public static b(Lcom/tencent/thumbplayer/core/common/TPVideoFrame;)[Landroid/graphics/Bitmap;
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->data:[[B

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    array-length v1, v0

    const/4 v7, 0x5

    if-lez v1, :cond_2

    const/4 v6, 0x7

    move v7, v6

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->height:I

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz v1, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->width:I

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-nez v1, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    goto :goto_1

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    array-length v0, v0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    new-array v0, v0, [Landroid/graphics/Bitmap;

    const/4 v7, 0x3

    const/4 v1, 0x3

    const/4 v7, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object v2, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->data:[[B

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    array-length v3, v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    if-ge v1, v3, :cond_1

    const/4 v6, 0x6

    or-int/2addr v7, v6

    aget-object v2, v2, v1

    const/4 v6, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget v3, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->width:I

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget v4, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->height:I

    const/4 v7, 0x6

    const/4 v6, 0x1

    iget v5, p0, Lcom/tencent/thumbplayer/core/common/TPVideoFrame;->rotation:I

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {v2, v3, v4, v5}, Lcom/tencent/thumbplayer/a/a;->a([BIII)Landroid/graphics/Bitmap;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    aput-object v2, v0, v1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto :goto_0

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    return-object v0

    :cond_2
    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 p0, 0x0

    move v7, p0

    return-object p0
.end method
