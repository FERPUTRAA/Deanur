.class public Lcom/tencent/thumbplayer/a/d;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/adapter/a/a;
.implements Lcom/tencent/thumbplayer/core/imagegenerator/ITPImageGeneratorCallback;


# instance fields
.field private a:J

.field private b:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

.field private c:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Long;",
            "Lcom/tencent/thumbplayer/api/TPCaptureCallBack;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(I)V
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    move v1, p1

    move v1, p1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-direct/range {v0 .. v5}, Lcom/tencent/thumbplayer/a/d;-><init>(IJJ)V

    const/4 v6, 0x3

    const/4 v6, 0x3

    return-void
.end method

.method public constructor <init>(IJJ)V
    .locals 10

    const/4 v9, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v9, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v9, 0x3

    iput-wide v0, p0, Lcom/tencent/thumbplayer/a/d;->a:J

    const/4 v9, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v9, 0x5

    move v3, p1

    move v3, p1

    move v3, p1

    move v3, p1

    move-wide v4, p2

    move-wide v6, p4

    move-object v8, p0

    move-object v8, p0

    move-object v8, p0

    const/4 v9, 0x1

    invoke-direct/range {v2 .. v8}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;-><init>(IJJLcom/tencent/thumbplayer/core/imagegenerator/ITPImageGeneratorCallback;)V

    iput-object v0, p0, Lcom/tencent/thumbplayer/a/d;->b:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v9, 0x1

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/4 v9, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/a/d;->c:Ljava/util/Map;

    :try_start_0
    const/4 v9, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/a/d;->b:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v9, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;->init()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x7

    return-void

    :catch_0
    move-exception p1

    const/4 v9, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const-string/jumbo p3, "iis:s "

    const-string p3, ":is ni"

    const-string/jumbo p3, "tinmi:"

    const-string/jumbo p3, "init: "

    const/4 v9, 0x0

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x5

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x3

    const-string/jumbo p2, "yarmraletmuT.PTphTTPuCvumPhae[jba]"

    const-string/jumbo p2, "hmjloTypeCuTeuT]bt[v.PuTbahPaamaPr"

    const-string p2, "TPThumbPlayer[TPThumbCapture.java]"

    const/4 v9, 0x3

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 4

    const/4 v2, 0x0

    move v3, v2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/tencent/thumbplayer/a/d;->a:J

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v0, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v0, p1, p0}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;-><init>(Ljava/lang/String;Lcom/tencent/thumbplayer/core/imagegenerator/ITPImageGeneratorCallback;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/thumbplayer/a/d;->b:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance p1, Ljava/util/HashMap;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/a/d;->c:Ljava/util/Map;

    :try_start_0
    const/4 v3, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/a/d;->b:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;->init()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string/jumbo v1, "nii:tb"

    const-string/jumbo v1, "t:inoi"

    const/4 v3, 0x6

    const-string/jumbo v1, "uiint "

    const-string/jumbo v1, "init: "

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string v0, "bPhyabTerheTrjuTaCPavm]mt.TpuPuba["

    const/4 v3, 0x5

    const-string/jumbo v0, "l]TPmPTpPhpejyvrtTaa[m.CabeuuarTuh"

    const-string v0, "TPThumbPlayer[TPThumbCapture.java]"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method


# virtual methods
.method public a()V
    .locals 5

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "y~@ @S@/qi@@~@a@.@ti-o c@o@dbMu obl@o~~~~ @f~~ m@@@s1r ~@~ b~~~@~i4~K ~  ~nfv @~o  @~~/~~@ o   t"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/a/d;->b:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;->cancelAllImageGenerations()V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/a/d;->b:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;->unInit()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v2, "erseuael:"

    const-string/jumbo v2, "lar eeue:"

    const/4 v4, 0x5

    const-string/jumbo v2, "s emreela"

    const-string/jumbo v2, "release: "

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string/jumbo v1, "hajropueel]b[amvrPamTb.uhPTtaTpPyu"

    const-string/jumbo v1, "jtlhPurp[bemePPrauavpT].bTuaThmTay"

    const/4 v4, 0x7

    const-string v1, "PvTuebuTPmeabayhjTlaur[brTPam.tC]p"

    const-string v1, "TPThumbPlayer[TPThumbCapture.java]"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/a/d;->c:Ljava/util/Map;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/a/d;->b:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method

.method public a(JLcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;Lcom/tencent/thumbplayer/api/TPCaptureCallBack;)V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-nez p3, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    new-instance p3, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-direct {p3}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/16 v0, 0x25

    const/4 v7, 0x3

    move v8, v7

    iput v0, p3, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->format:I

    :cond_0
    move-object v6, p3

    move-object v6, p3

    move-object v6, p3

    move-object v6, p3

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    iget-wide v0, p0, Lcom/tencent/thumbplayer/a/d;->a:J

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v8, 0x2

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    add-long/2addr v0, v2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    iput-wide v0, p0, Lcom/tencent/thumbplayer/a/d;->a:J

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    iget-object p3, p0, Lcom/tencent/thumbplayer/a/d;->c:Ljava/util/Map;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-interface {p3, v0, p4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :try_start_0
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/a/d;->b:Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-wide v4, p0, Lcom/tencent/thumbplayer/a/d;->a:J

    move-wide v2, p1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual/range {v1 .. v6}, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGenerator;->generateImageAsyncAtTime(JJLcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    return-void

    :catch_0
    move-exception p1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-string p3, "aqgmneuigmtenIAcTst eyaAr:"

    const-string/jumbo p3, "see eigmqecaAImArTytt:agnn"

    const/4 v8, 0x2

    const-string p3, "em:gyIep TnsicmeareAtgAtne"

    const-string/jumbo p3, "generateImageAsyncAtTime: "

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    move v8, v7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    const-string p2, "eTsyPau[pbrT.PhC]hTulmravmtPjbeauT"

    const/4 v8, 0x0

    const-string p2, "bjuPaTbmqhTPhteu.auyvmPlarpe]TTra["

    const-string p2, "TPThumbPlayer[TPThumbCapture.java]"

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    return-void
.end method

.method public onImageGenerationCompleted(IJJJLcom/tencent/thumbplayer/core/common/TPVideoFrame;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget-object p2, p0, Lcom/tencent/thumbplayer/a/d;->c:Ljava/util/Map;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p6, p7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-interface {p2, p3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    check-cast p2, Lcom/tencent/thumbplayer/api/TPCaptureCallBack;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    if-eqz p2, :cond_2

    const/4 v1, 0x6

    const/4 v0, 0x0

    if-nez p1, :cond_1

    const/4 v0, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    if-eqz p8, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p8}, Lcom/tencent/thumbplayer/a/a;->a(Lcom/tencent/thumbplayer/core/common/TPVideoFrame;)Landroid/graphics/Bitmap;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-interface {p2, p1}, Lcom/tencent/thumbplayer/api/TPCaptureCallBack;->onCaptureVideoSuccess(Landroid/graphics/Bitmap;)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    const p1, 0xf4241

    :cond_1
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-interface {p2, p1}, Lcom/tencent/thumbplayer/api/TPCaptureCallBack;->onCaptureVideoFailed(I)V

    :cond_2
    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/a/d;->c:Ljava/util/Map;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p6, p7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-interface {p1, p2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method
