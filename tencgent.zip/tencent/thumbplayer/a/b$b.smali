.class Lcom/tencent/thumbplayer/a/b$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/a/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "b"
.end annotation


# instance fields
.field protected a:Lcom/tencent/thumbplayer/a/b$a;

.field private b:I

.field private c:Ljava/lang/String;

.field private d:Ljava/io/FileDescriptor;

.field private e:Landroid/content/res/AssetFileDescriptor;

.field private f:J

.field private g:I

.field private h:I


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/thumbplayer/a/b$1;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/thumbplayer/a/b$b;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/a/b$b;I)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~os@/-@@ o@@@~~l~ ~ b~~@ ~ @ob~i~om @ nMtt~~fK@@~bvc ~d ~ /i4@o ~  ~ ls@1 r @@uy@~@@ a~~~~.o@f@i"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iput p1, p0, Lcom/tencent/thumbplayer/a/b$b;->b:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    return p1
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/a/b$b;J)J
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-wide p1, p0, Lcom/tencent/thumbplayer/a/b$b;->f:J

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-wide p1
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/a/b$b;Landroid/content/res/AssetFileDescriptor;)Landroid/content/res/AssetFileDescriptor;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/a/b$b;->e:Landroid/content/res/AssetFileDescriptor;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p1
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/a/b$b;)Ljava/io/FileDescriptor;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/tencent/thumbplayer/a/b$b;->d:Ljava/io/FileDescriptor;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/a/b$b;Ljava/io/FileDescriptor;)Ljava/io/FileDescriptor;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/a/b$b;->d:Ljava/io/FileDescriptor;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p1
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/a/b$b;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/a/b$b;->c:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/a/b$b;I)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p1, p0, Lcom/tencent/thumbplayer/a/b$b;->g:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    return p1
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/a/b$b;)Landroid/content/res/AssetFileDescriptor;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/tencent/thumbplayer/a/b$b;->e:Landroid/content/res/AssetFileDescriptor;

    const/4 v1, 0x6

    const/4 v0, 0x4

    return-object p0
.end method

.method static synthetic c(Lcom/tencent/thumbplayer/a/b$b;I)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p1, p0, Lcom/tencent/thumbplayer/a/b$b;->h:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    return p1
.end method

.method static synthetic c(Lcom/tencent/thumbplayer/a/b$b;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/tencent/thumbplayer/a/b$b;->c:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic d(Lcom/tencent/thumbplayer/a/b$b;)J
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-wide v0, p0, Lcom/tencent/thumbplayer/a/b$b;->f:J

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-wide v0
.end method

.method static synthetic e(Lcom/tencent/thumbplayer/a/b$b;)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    iget p0, p0, Lcom/tencent/thumbplayer/a/b$b;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    return p0
.end method

.method static synthetic f(Lcom/tencent/thumbplayer/a/b$b;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    iget p0, p0, Lcom/tencent/thumbplayer/a/b$b;->g:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic g(Lcom/tencent/thumbplayer/a/b$b;)I
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    iget p0, p0, Lcom/tencent/thumbplayer/a/b$b;->h:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    return p0
.end method
