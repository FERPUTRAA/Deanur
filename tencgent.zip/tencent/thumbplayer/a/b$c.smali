.class Lcom/tencent/thumbplayer/a/b$c;
.super Landroid/os/Handler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/a/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "c"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/a/b;


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/a/b;Landroid/os/Looper;)V
    .locals 2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/a/b$c;->a:Lcom/tencent/thumbplayer/a/b;

    const/4 v1, 0x0

    const/4 v0, 0x2

    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "c~s~@lS~yoi@i.~fia o~l@~-s~@~ @/~~u~@b@m~ @tK @bn/  @v1o @ ~4oo b~ @f  @~~~ ~@  ~@@rM@@do~  @@t~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const-string/jumbo v2, "ssrmgyePyuCPIalSaeepmtT"

    const-string/jumbo v2, "mesgrsaPCTeSryetPaulIyp"

    const/4 v4, 0x3

    const-string/jumbo v2, "trlPoapygaSPrauseymeTeI"

    const-string v2, "TPSysPlayerImageCapture"

    const/4 v4, 0x1

    const/4 v3, 0x3

    if-eq v0, v1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 p1, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eq v0, p1, :cond_0

    const/4 v3, 0x5

    move v4, v3

    const-string/jumbo p1, "uonatbs  nrdwemnlmnHgve"

    const-string p1, "enlmeu a rvnsdHmonwgent"

    const/4 v4, 0x6

    const-string/jumbo p1, "rvldenukewHn sgmnnoauet"

    const-string/jumbo p1, "eventHandler unknow msg"

    const/4 v3, 0x5

    move v4, v3

    invoke-static {v2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo p1, "rASaoPGpHMP_veAE lVIEetTOC_nd_"

    const-string p1, "dnOCo vHeEGP_T_MElrt_aeVIAAePS"

    const-string/jumbo p1, "nAMEr OnqCeVAT_PePGlaEtHS_v_dI"

    const-string/jumbo p1, "eventHandler EV_STOP_CAP_IMAGE"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/a/b$c;->a:Lcom/tencent/thumbplayer/a/b;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {p1}, Lcom/tencent/thumbplayer/a/b;->a(Lcom/tencent/thumbplayer/a/b;)Landroid/media/MediaMetadataRetriever;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz p1, :cond_1

    const/4 v3, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/a/b$c;->a:Lcom/tencent/thumbplayer/a/b;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {p1}, Lcom/tencent/thumbplayer/a/b;->a(Lcom/tencent/thumbplayer/a/b;)Landroid/media/MediaMetadataRetriever;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/media/MediaMetadataRetriever;->release()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/a/b$c;->a:Lcom/tencent/thumbplayer/a/b;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/a/b;->a(Lcom/tencent/thumbplayer/a/b;Landroid/media/MediaMetadataRetriever;)Landroid/media/MediaMetadataRetriever;

    :cond_1
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v0, "lVsMedntGAv__EHaeIbnAre P"

    const-string v0, "eGVAMbEvAntrla_eHeIEPn d_"

    const/4 v4, 0x0

    const-string v0, "_HImE_VlneePtAnrGCdEaeAv "

    const-string/jumbo v0, "eventHandler EV_CAP_IMAGE"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v2, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    check-cast p1, Lcom/tencent/thumbplayer/a/b$b;

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/a/b$c;->a:Lcom/tencent/thumbplayer/a/b;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/a/b;->a(Lcom/tencent/thumbplayer/a/b;Lcom/tencent/thumbplayer/a/b$b;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void
.end method
