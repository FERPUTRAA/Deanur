.class public Lcom/tencent/thumbplayer/a/c;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/a/b$a;
.implements Lcom/tencent/thumbplayer/adapter/a/a;


# instance fields
.field private a:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Lcom/tencent/thumbplayer/api/TPCaptureCallBack;",
            ">;"
        }
    .end annotation
.end field

.field private b:Ljava/lang/String;

.field private c:Ljava/io/FileDescriptor;

.field private d:Landroid/content/res/AssetFileDescriptor;


# direct methods
.method public constructor <init>(Landroid/content/res/AssetFileDescriptor;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/a/c;->a:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/a/c;->d:Landroid/content/res/AssetFileDescriptor;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Ljava/io/FileDescriptor;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance v0, Ljava/util/HashMap;

    const/4 v1, 0x6

    move v2, v1

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/a/c;->a:Ljava/util/Map;

    const/4 v1, 0x7

    move v2, v1

    iput-object p1, p0, Lcom/tencent/thumbplayer/a/c;->c:Ljava/io/FileDescriptor;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/a/c;->a:Ljava/util/Map;

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/a/c;->b:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ sci4   o ~~ft@~b~@@~y@o~~il@ o~ @/m@-@@ ~~ @b~~Kbv~s@r ~ ~M@S~@@too  /i~@d  f~o~u~~ 1n@@~@a@l."

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/tencent/thumbplayer/a/c;->a:Ljava/util/Map;

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v2, 0x1

    return-void
.end method

.method public a(II)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/a/c;->a:Ljava/util/Map;

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    check-cast p1, Lcom/tencent/thumbplayer/api/TPCaptureCallBack;

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-interface {p1, p2}, Lcom/tencent/thumbplayer/api/TPCaptureCallBack;->onCaptureVideoFailed(I)V

    :cond_0
    const/4 v2, 0x5

    return-void
.end method

.method public a(IJIILandroid/graphics/Bitmap;J)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget-object p2, p0, Lcom/tencent/thumbplayer/a/c;->a:Ljava/util/Map;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    check-cast p1, Lcom/tencent/thumbplayer/api/TPCaptureCallBack;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-interface {p1, p6}, Lcom/tencent/thumbplayer/api/TPCaptureCallBack;->onCaptureVideoSuccess(Landroid/graphics/Bitmap;)V

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public a(JLcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;Lcom/tencent/thumbplayer/api/TPCaptureCallBack;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/a/b$d;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/tencent/thumbplayer/a/b$d;-><init>()V

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/a/c;->b:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object v1, v0, Lcom/tencent/thumbplayer/a/b$d;->a:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/a/c;->c:Ljava/io/FileDescriptor;

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-object v1, v0, Lcom/tencent/thumbplayer/a/b$d;->b:Ljava/io/FileDescriptor;

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/a/c;->d:Landroid/content/res/AssetFileDescriptor;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v1, v0, Lcom/tencent/thumbplayer/a/b$d;->c:Landroid/content/res/AssetFileDescriptor;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-wide p1, v0, Lcom/tencent/thumbplayer/a/b$d;->d:J

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget p1, p3, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->width:I

    const/4 v3, 0x0

    iput p1, v0, Lcom/tencent/thumbplayer/a/b$d;->e:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget p1, p3, Lcom/tencent/thumbplayer/core/imagegenerator/TPImageGeneratorParams;->height:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    iput p1, v0, Lcom/tencent/thumbplayer/a/b$d;->f:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/a/b;->a()Lcom/tencent/thumbplayer/a/b;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1, v0, p0}, Lcom/tencent/thumbplayer/a/b;->a(Lcom/tencent/thumbplayer/a/b$d;Lcom/tencent/thumbplayer/a/b$a;)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/tencent/thumbplayer/a/c;->a:Ljava/util/Map;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {p2, p1, p4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method
