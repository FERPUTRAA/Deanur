.class public Lcom/tencent/thumbplayer/config/TPPlayerConfig;
.super Ljava/lang/Object;


# static fields
.field private static DOT:Ljava/lang/String; = "\\."

.field public static final ISOTT:Z = false

.field private static final TAG:Ljava/lang/String; = "TPPlayerConfig"

.field public static final VERSION:Ljava/lang/String; = "2.31.0.134"

.field private static appVersion:Ljava/lang/String; = ""

.field private static appVersionName:Ljava/lang/String; = null

.field public static beacon_log_host:Ljava/lang/String; = ""

.field public static beacon_policy_host:Ljava/lang/String; = ""

.field private static buildNum:J = -0x1L

.field private static host_config:Ljava/lang/String; = ""

.field private static mAbUserId:Ljava/lang/String; = ""

.field private static mEnableDataReport:Z = false

.field private static mEnablePlayerReport:Z = true

.field private static mGuid:Ljava/lang/String; = ""

.field private static mOutNetIp:Ljava/lang/String; = ""

.field private static mPlatform:I = -0x1

.field private static mProxyCacheDir:Ljava/lang/String; = null

.field private static mProxyDataDir:Ljava/lang/String; = null

.field private static mProxyMaxStorageSizeMB:J = 0x0L

.field private static mProxyMaxUseMemoryMB:J = 0x0L

.field private static mProxyServiceType:I = -0x1

.field private static mUseP2P:Z = true

.field private static mUserIsVip:Z = false

.field private static mUserUin:Ljava/lang/String; = null

.field private static mUserUpc:Ljava/lang/String; = ""

.field private static mUserUpcState:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    return-void
.end method

.method public static getAbUserId()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mAbUserId:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x1

    return-object v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mAbUserId:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public static getAppBigVersion(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->appVersion:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget-object p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->appVersion:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getAppVersionName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x6

    sget-object v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->DOT:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_2

    const/4 v3, 0x5

    array-length v0, v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ne v0, v1, :cond_2

    const/4 v3, 0x0

    const-string v0, "."

    const-string v0, "."

    const/4 v3, 0x1

    const-string v0, "."

    const-string v0, "."

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string p0, ".0s.0"

    const-string p0, "0.0.0"

    :cond_2
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    sput-object p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->appVersion:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object p0
.end method

.method public static getAppVersionName(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    sget-object v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->appVersionName:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x5

    move v4, v3

    sget-object p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->appVersionName:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-object p0

    :cond_0
    const/4 v4, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-nez p0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-object v0

    :cond_1
    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1, p0, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object p0, p0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    sput-object p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->appVersionName:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez p0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto :goto_0

    :cond_2
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :catchall_0
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method public static getBuildNumber(Landroid/content/Context;)J
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    sget-wide v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->buildNum:J

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x4

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v4, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    cmp-long v2, v2, v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v2, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    return-wide v0

    :cond_0
    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, p0, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/appsflyer/internal/e;->a(Landroid/content/pm/PackageInfo;)J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    sput-wide v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->buildNum:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    return-wide v0

    :catchall_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string/jumbo p0, "fenmPsoiClrayP"

    const-string/jumbo p0, "yasCneiPolPrfT"

    const/4 v5, 0x2

    const-string p0, "CroaogPyfTelPn"

    const-string p0, "TPPlayerConfig"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v0, "oo mibe2s  8pelrosatgeesgnnCid"

    const-string v0, "  omdtre 8ensoplinLeeoCsgi2ags"

    const/4 v5, 0x5

    const-string/jumbo v0, "odoniVuo esg eestns8gLiCa2rlep"

    const-string/jumbo v0, "getLongVersionCode less api 28"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {p0, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    sget-wide v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->buildNum:J

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-wide v0
.end method

.method public static getGuid()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mGuid:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public static getMediaDrmReuseEnable()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/config/TPPlayerCoreConfig;->getMediaDrmReuseEnable()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public static getNewReportEnable()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/core/config/TPPlayerCoreConfig;->getCoreEventProcessEnable()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public static getOutNetIp()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mOutNetIp:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public static getPlatform()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mPlatform:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public static getProxyCacheDir()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    sget-object v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mProxyCacheDir:Ljava/lang/String;

    const/4 v1, 0x1

    move v2, v1

    return-object v0
.end method

.method public static getProxyConfigDir()Ljava/lang/String;
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string/jumbo v0, "gfrtixypoohopcpt"

    const-string/jumbo v0, "gpoxopiycntfhtor"

    const/4 v5, 0x2

    const-string/jumbo v0, "ingpforcqx_thypo"

    const-string/jumbo v0, "httpproxy_config"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->host_config:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x5

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    or-int/2addr v5, v4

    return-object v2

    :cond_0
    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance v1, Lorg/json/JSONObject;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    sget-object v3, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->host_config:Ljava/lang/String;

    const/4 v4, 0x5

    move v5, v4

    invoke-direct {v1, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez v3, :cond_1

    const/4 v5, 0x5

    return-object v2

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-object v0

    :catch_0
    move-exception v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const-string/jumbo v1, "fesiCTagyrblPo"

    const-string/jumbo v1, "igoeCbfPTrynal"

    const/4 v5, 0x3

    const-string v1, "PaemyrTCginlfP"

    const-string v1, "TPPlayerConfig"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-object v2
.end method

.method public static getProxyDataDir()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mProxyDataDir:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public static getProxyMaxStorageSizeMB()J
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-wide v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mProxyMaxStorageSizeMB:J

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-wide v0
.end method

.method public static getProxyMaxUseMemoryMB()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-wide v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mProxyMaxUseMemoryMB:J

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-wide v0
.end method

.method public static getProxyServiceType()I
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    sget v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mProxyServiceType:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v1, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-ne v0, v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    sget v2, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mPlatform:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eq v2, v1, :cond_0

    const/4 v4, 0x1

    return v2

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    return v0
.end method

.method public static getUserUin()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mUserUin:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public static getUserUpc()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mUserUpc:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public static getUserUpcState()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mUserUpcState:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method public static getVideoMediaCodecCoexistMaxCnt()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/config/TPPlayerCoreConfig;->getVideoMediaCodecCoexistMaxCnt()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public static getWidevineProvisioningServerUrl()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/core/config/TPPlayerCoreConfig;->getWidevineProvisioningServerUrl()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public static isDataReportEnable()Z
    .locals 3

    const/4 v2, 0x2

    sget-boolean v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mEnableDataReport:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method public static isPlayerReportEnable()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget-boolean v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mEnablePlayerReport:Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public static isUseP2P()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-boolean v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mUseP2P:Z

    const/4 v2, 0x4

    const/4 v1, 0x3

    return v0
.end method

.method public static isUserIsVip()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget-boolean v0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mUserIsVip:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public static parseHostConfig(Ljava/lang/String;)V
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string v0, "beontgus_loo_ca"

    const/4 v7, 0x0

    const-string/jumbo v0, "s_bootogleh_can"

    const-string v0, "beacon_log_host"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string/jumbo v1, "obcpcboih_ly_tsopn"

    const-string/jumbo v1, "pcs_yh_poinlotcbeo"

    const/4 v7, 0x2

    const-string/jumbo v1, "hnsbo_uayeoc_lcotp"

    const-string v1, "beacon_policy_host"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string/jumbo v2, "olhtnsip_rcoey_gfa"

    const-string/jumbo v2, "player_host_config"

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string/jumbo v4, "iyPnTCrgqfalqo"

    const-string/jumbo v4, "glariPnfqoTyPC"

    const/4 v7, 0x7

    const-string v4, "TPPlayerConfig"

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v3, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string/jumbo p0, "srst H  u,gafgCfipsnce.oonslnlos"

    const-string p0, "c st HrsCnipaf suoggnnliolsfe.,o"

    const/4 v7, 0x6

    const-string/jumbo p0, "llnmHnpc aoige.orfoi,ufsgsnst C "

    const-string/jumbo p0, "parseHostConfig, config is null."

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v4, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    return-void

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    sput-object p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->host_config:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string/jumbo v5, "fotoosa:CgrHnpie"

    const-string v5, "Hremst:npCagoifo"

    const/4 v7, 0x3

    const-string v5, "Hgtnsbrfeaoi:Cpo"

    const-string/jumbo v5, "parseHostConfig:"

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v5, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {v4, v3}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    new-instance v3, Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-direct {v3, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x6

    invoke-virtual {v3, v2}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result p0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz p0, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v3, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz v2, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    sput-object v1, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->beacon_policy_host:Ljava/lang/String;

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-eqz v1, :cond_2

    const/4 v6, 0x6

    move v7, v6

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    sput-object p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->beacon_log_host:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    return-void

    :catchall_0
    move-exception p0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string/jumbo v1, "fe ontuCpcs:giapxtn seoioHr"

    const-string/jumbo v1, "parseHostConfig exception: "

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto/16 :goto_0
.end method

.method public static setAbUserId(Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x5

    const/4 v1, 0x2

    sput-object p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mAbUserId:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public static setDataReportEnable(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    sput-boolean p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mEnableDataReport:Z

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public static setDebugEnable(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->setDebugEnable(Z)V

    const/4 v1, 0x4

    return-void
.end method

.method public static setGuid(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    sput-object p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mGuid:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public static setMediaDrmReuseEnable(Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/config/TPPlayerCoreConfig;->setMediaDrmReuseEnable(Z)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public static setNewReportEnable(Z)V
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/config/TPPlayerCoreConfig;->setCoreEventProcessEnable(Z)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public static setOutNetIp(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    sput-object p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mOutNetIp:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public static setP2PEnable(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    sput-boolean p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mUseP2P:Z

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public static setPlatform(I)V
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    sput p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mPlatform:I

    const/4 v1, 0x1

    return-void
.end method

.method public static setPlayerReportEnable(Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    sput-boolean p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mEnablePlayerReport:Z

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public static setProxyCacheDir(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    sput-object p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mProxyCacheDir:Ljava/lang/String;

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method

.method public static setProxyDataDir(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    sput-object p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mProxyDataDir:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public static setProxyMaxStorageSizeMB(J)V
    .locals 2

    const/4 v1, 0x0

    sput-wide p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mProxyMaxStorageSizeMB:J

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public static setProxyMaxUseMemoryMB(J)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    sput-wide p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mProxyMaxUseMemoryMB:J

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public static setProxyServiceType(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    sput p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mProxyServiceType:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public static setUserIsVip(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    sput-boolean p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mUserIsVip:Z

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public static setUserUin(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    sput-object p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mUserUin:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x6

    return-void
.end method

.method public static setUserUpc(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    sput-object p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mUserUpc:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public static setUserUpcState(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    sput p0, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->mUserUpcState:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public static setVideoMediaCodecCoexistMaxCnt(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/config/TPPlayerCoreConfig;->setVideoMediaCodecCoexistMaxCnt(I)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public static setWidevineProvisioningServerUrl(Ljava/lang/String;)V
    .locals 2
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x7

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/config/TPPlayerCoreConfig;->setWidevineProvisioningServerUrl(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method
