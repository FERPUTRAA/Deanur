.class Lcom/tencent/thumbplayer/c/d$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/c/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "a"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/c/d;


# direct methods
.method private constructor <init>(Lcom/tencent/thumbplayer/c/d;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/thumbplayer/c/d;Lcom/tencent/thumbplayer/c/d$1;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/c/d$a;-><init>(Lcom/tencent/thumbplayer/c/d;)V

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public getAdvRemainTime()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {v0}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getAdvRemainTime()J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-wide v0
.end method

.method public getContentType(ILjava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getContentType(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p1
.end method

.method public getCurrentPlayClipNo()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getCurrentPlayClipNo()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public getCurrentPlayOffset()J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {v0}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getCurrentPlayOffset()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-wide v0
.end method

.method public getCurrentPosition()J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {v0}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getCurrentPosition()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-wide v0
.end method

.method public getDataFilePath(ILjava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getDataFilePath(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    return-object p1
.end method

.method public getDataTotalSize(ILjava/lang/String;)J
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getDataTotalSize(ILjava/lang/String;)J

    move-result-wide p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-wide p1
.end method

.method public getPlayInfo(J)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getPlayInfo(J)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p1
.end method

.method public getPlayInfo(Ljava/lang/String;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getPlayInfo(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p1
.end method

.method public getPlayerBufferLength()J
    .locals 4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {v0}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getPlayerBufferLength()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-wide v0
.end method

.method public onDownloadCdnUrlExpired(Ljava/util/Map;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadCdnUrlExpired(Ljava/util/Map;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public onDownloadCdnUrlInfoUpdate(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/d/b$d;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v0}, Lcom/tencent/thumbplayer/d/b$d;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, p2}, Lcom/tencent/thumbplayer/d/b$d;->a(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, p3}, Lcom/tencent/thumbplayer/d/b$d;->b(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v1}, Lcom/tencent/thumbplayer/c/d;->a(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/tplayer/a;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v1, v0}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    invoke-interface {v0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadCdnUrlInfoUpdate(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x7

    move v3, v2

    return-void
.end method

.method public onDownloadCdnUrlUpdate(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadCdnUrlUpdate(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public onDownloadError(IILjava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2, p3}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadError(IILjava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public onDownloadFinish()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-interface {v0}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadFinish()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public onDownloadProgressUpdate(IIJJLjava/lang/String;)V
    .locals 10

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    new-instance v1, Lcom/tencent/thumbplayer/d/b$e;

    invoke-direct {v1}, Lcom/tencent/thumbplayer/d/b$e;-><init>()V

    mul-int/lit8 v2, p2, 0x8

    invoke-virtual {v1, v2}, Lcom/tencent/thumbplayer/d/b$e;->b(I)V

    iget-object v2, v0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    invoke-static {v2}, Lcom/tencent/thumbplayer/c/d;->a(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/tplayer/a;

    move-result-object v2

    invoke-virtual {v2}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    iget-object v1, v0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    invoke-static {v1}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v2

    move v3, p1

    move v3, p1

    move v3, p1

    move v4, p2

    move v4, p2

    move v4, p2

    move-wide v5, p3

    move-wide v7, p5

    move-object/from16 v9, p7

    move-object/from16 v9, p7

    move-object/from16 v9, p7

    move-object/from16 v9, p7

    invoke-interface/range {v2 .. v9}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadProgressUpdate(IIJJLjava/lang/String;)V

    return-void
.end method

.method public onDownloadProtocolUpdate(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/d/b$f;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v0}, Lcom/tencent/thumbplayer/d/b$f;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/d/b$f;->b(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, p2}, Lcom/tencent/thumbplayer/d/b$f;->a(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    invoke-static {v1}, Lcom/tencent/thumbplayer/c/d;->a(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/tplayer/a;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-virtual {v1}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v1, v0}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v2, 0x2

    move v3, v2

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadProtocolUpdate(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method public onDownloadStatusUpdate(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadStatusUpdate(I)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public onPlayCallback(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    move v2, p1

    move v2, p1

    const/4 v8, 0x6

    move v2, p1

    move v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-interface/range {v1 .. v6}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onPlayCallback(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x7

    return-object p1
.end method

.method public onReadData(ILjava/lang/String;JJ)I
    .locals 9

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v8, 0x1

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v1

    const/4 v8, 0x6

    move v2, p1

    move v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-wide v4, p3

    move-wide v6, p5

    const/4 v8, 0x1

    invoke-interface/range {v1 .. v7}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onReadData(ILjava/lang/String;JJ)I

    move-result p1

    const/4 v8, 0x7

    return p1
.end method

.method public onStartReadData(ILjava/lang/String;JJ)I
    .locals 9

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v8, 0x0

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v1

    const/4 v8, 0x3

    move v2, p1

    move v2, p1

    move v2, p1

    move v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-wide v4, p3

    move-wide v6, p5

    const/4 v8, 0x0

    invoke-interface/range {v1 .. v7}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onStartReadData(ILjava/lang/String;JJ)I

    move-result p1

    const/4 v8, 0x3

    return p1
.end method

.method public onStopReadData(ILjava/lang/String;I)I
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d$a;->a:Lcom/tencent/thumbplayer/c/d;

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/d;->b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {v0, p1, p2, p3}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onStopReadData(ILjava/lang/String;I)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return p1
.end method
