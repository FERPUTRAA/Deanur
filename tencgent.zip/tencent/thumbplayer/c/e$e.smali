.class Lcom/tencent/thumbplayer/c/e$e;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/c/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "e"
.end annotation


# instance fields
.field a:Ljava/lang/Object;

.field b:Lcom/tencent/thumbplayer/utils/e;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/thumbplayer/c/e$1;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/tencent/thumbplayer/c/e$e;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method
