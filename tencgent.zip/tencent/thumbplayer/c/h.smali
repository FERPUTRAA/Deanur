.class public Lcom/tencent/thumbplayer/c/h;
.super Ljava/lang/Object;


# direct methods
.method public static a(I)I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ s/rf~~v 1 @/cy~sK@u-d ~ @4~@ ~i~ ~@l~@@@~oan.~ @o ~imiM@@ol  ~b ~~ ~b@@~oo@f @~ @@t@~t@~@So~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    const/16 v0, 0xca

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eq p0, v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    packed-switch p0, :pswitch_data_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo v1, "selmvs eniadi: niv"

    const-string/jumbo v1, "nvsli:ina ivsd e e"

    const/4 v3, 0x7

    const-string/jumbo v1, "event is invalid: "

    const/4 v3, 0x6

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x1

    and-int/2addr v3, v2

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    throw v0

    :pswitch_0
    const/16 p0, 0x10

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    return p0

    :pswitch_1
    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/16 p0, 0xb

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    return p0

    :pswitch_2
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/16 p0, 0xa

    const/4 v3, 0x7

    const/4 v2, 0x4

    return p0

    :pswitch_3
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/16 p0, 0x9

    const/4 v2, 0x2

    move v3, v2

    return p0

    :pswitch_4
    const/4 v3, 0x2

    const/16 p0, 0x8

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    return p0

    :pswitch_5
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 p0, 0x7

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    return p0

    :pswitch_6
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 p0, 0x6

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    return p0

    :pswitch_7
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 p0, 0x5

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    return p0

    :pswitch_8
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 p0, 0x4

    const/4 v2, 0x1

    move v3, v2

    return p0

    :pswitch_9
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 p0, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    return p0

    :pswitch_a
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 p0, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x5

    return p0

    :pswitch_b
    const/4 v2, 0x6

    move v3, v2

    const/4 p0, 0x1

    or-int/2addr v3, p0

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    return p0

    :pswitch_c
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x5

    return p0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static b(I)I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x3

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eq p0, v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x4

    move v3, v0

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eq p0, v0, :cond_0

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    const/4 v0, 0x5

    move v3, v0

    const/4 v2, 0x4

    const/4 v2, 0x7

    if-eq p0, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x6

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eq p0, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    packed-switch p0, :pswitch_data_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string/jumbo v1, "m:nnoaitveei  ilvsd"

    const-string/jumbo v1, "itamed:v sin n ivle"

    const/4 v3, 0x3

    const-string v1, "disv benien :l  avi"

    const-string/jumbo v1, "event is invalid : "

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    throw v0

    :pswitch_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/16 p0, 0x15

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    return p0

    :pswitch_1
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/16 p0, 0x14

    const/4 v3, 0x1

    return p0

    :pswitch_2
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/16 p0, 0x13

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    return p0

    :pswitch_3
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/16 p0, 0x12

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    return p0

    :pswitch_4
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/16 p0, 0x11

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    return p0

    :pswitch_5
    const/4 v3, 0x5

    const/16 p0, 0x10

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return p0

    :pswitch_6
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/16 p0, 0xf

    const/4 v3, 0x3

    const/4 v2, 0x3

    return p0

    :pswitch_7
    const/4 v2, 0x1

    move v3, v2

    const/16 p0, 0xe

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    return p0

    :pswitch_8
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/16 p0, 0xd

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    return p0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    return v0

    :pswitch_data_0
    .packed-switch 0xd
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
