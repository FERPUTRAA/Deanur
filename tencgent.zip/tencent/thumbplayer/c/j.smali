.class public Lcom/tencent/thumbplayer/c/j;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/c/b;


# instance fields
.field private a:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/j;->a:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@cs@fvi@s~~o~f@bl~@S@~@~~ . @@ 4m@-1~~@ ~ y@ ~ @@o~/o~@ni~ ~@b~~o @/@Mil ~r~bt   @u~@~o d aK~ot "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/j;->a:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public a(I)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/j;->a:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->pushEvent(I)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method
