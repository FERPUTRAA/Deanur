.class Lcom/tencent/thumbplayer/c/e$a;
.super Landroid/os/Handler;


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "HandlerLeak"
    }
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/c/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "a"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/c/e;


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/c/e;Landroid/os/Looper;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/e$a;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$a;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x4

    if-nez v0, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    const-string p1, "ahsPesT.ePTal]lrPu[rgajmPMvbnymaaTaIp"

    const-string p1, "aasajnMlTP]Ple[PblvmeahrguIrmaTP.yapT"

    const/4 v10, 0x6

    const-string/jumbo p1, "rljmTu]TamrPnPmlbhTPIyagMpe[aPyelv.aa"

    const-string p1, "TPThumbPlayer[TPPlayManagerImpl.java]"

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-string/jumbo v0, "ie ho aPruiflliledsrntgmsedl n e au eseeaanMlaLty,rsdn"

    const-string/jumbo v0, "regmsehar etLn ansr uaidln nsstilMlaa eyul Peilf,emdde"

    const/4 v10, 0x2

    const-string v0, "era,nbnsud  mfensrddl nealusieMliestlrhLiteneaay l ga "

    const-string/jumbo v0, "handleMessage failed, mPlayListener is null and return"

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    return-void

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/16 v1, 0x1064

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    if-eq v0, v1, :cond_2

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    const/16 v1, 0x1065

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-eq v0, v1, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    packed-switch v0, :pswitch_data_0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    goto/16 :goto_0

    :pswitch_0
    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    check-cast p1, Lcom/tencent/thumbplayer/c/e$e;

    const/4 v10, 0x5

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$a;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-object v1, p1, Lcom/tencent/thumbplayer/c/e$e;->a:Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    check-cast v1, Ljava/lang/String;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-interface {v0, v1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getPlayInfo(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    iget-object p1, p1, Lcom/tencent/thumbplayer/c/e$e;->b:Lcom/tencent/thumbplayer/utils/e;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/utils/e;->a(Ljava/lang/Object;)V

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x1

    return-void

    :pswitch_1
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    check-cast p1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPDownLoadProgressInfo;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$a;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    iget-wide v2, p1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPDownLoadProgressInfo;->playableDurationMS:J

    const/4 v9, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    long-to-int v2, v2

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget v3, p1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPDownLoadProgressInfo;->downloadSpeedKBps:I

    const/4 v10, 0x3

    iget-wide v4, p1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPDownLoadProgressInfo;->currentDownloadSize:J

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget-wide v6, p1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPDownLoadProgressInfo;->totalFileSize:J

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-object v8, p1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPDownLoadProgressInfo;->extraInfo:Ljava/lang/String;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-interface/range {v1 .. v8}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadProgressUpdate(IIJJLjava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    return-void

    :pswitch_2
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x3

    check-cast p1, Lcom/tencent/thumbplayer/c/e$e;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$a;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-object v1, p1, Lcom/tencent/thumbplayer/c/e$e;->a:Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x5

    check-cast v1, Ljava/lang/Long;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-interface {v0, v1, v2}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getPlayInfo(J)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    iget-object p1, p1, Lcom/tencent/thumbplayer/c/e$e;->b:Lcom/tencent/thumbplayer/utils/e;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/utils/e;->a(Ljava/lang/Object;)V

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    return-void

    :pswitch_3
    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    check-cast p1, Lcom/tencent/thumbplayer/c/e$e;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object v0, p1, Lcom/tencent/thumbplayer/c/e$e;->a:Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    check-cast v0, Lcom/tencent/thumbplayer/c/e$f;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/c/e$a;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-static {v1}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v2

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    iget v3, v0, Lcom/tencent/thumbplayer/c/e$f;->a:I

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget-object v4, v0, Lcom/tencent/thumbplayer/c/e$f;->b:Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget-object v5, v0, Lcom/tencent/thumbplayer/c/e$f;->c:Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    iget-object v6, v0, Lcom/tencent/thumbplayer/c/e$f;->d:Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-object v7, v0, Lcom/tencent/thumbplayer/c/e$f;->e:Ljava/lang/Object;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-interface/range {v2 .. v7}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onPlayCallback(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x2

    iget-object p1, p1, Lcom/tencent/thumbplayer/c/e$e;->b:Lcom/tencent/thumbplayer/utils/e;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {p1, v0}, Lcom/tencent/thumbplayer/utils/e;->a(Ljava/lang/Object;)V

    const/4 v10, 0x2

    return-void

    :pswitch_4
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$a;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v9, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x5

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    check-cast p1, Ljava/util/Map;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadCdnUrlExpired(Ljava/util/Map;)V

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    return-void

    :pswitch_5
    const/4 v9, 0x7

    const/4 v10, 0x2

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x7

    check-cast p1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPProtocolInfo;

    const/4 v9, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$a;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v9, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-object v1, p1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPProtocolInfo;->protocolName:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    iget-object p1, p1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPProtocolInfo;->protocolVersion:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-interface {v0, v1, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadProtocolUpdate(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x1

    return-void

    :pswitch_6
    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$a;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x7

    iget p1, p1, Landroid/os/Message;->arg1:I

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadStatusUpdate(I)V

    const/4 v9, 0x4

    xor-int/2addr v10, v9

    return-void

    :pswitch_7
    const/4 v10, 0x5

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    check-cast p1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPCDNURLInfo;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$a;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-object v1, p1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPCDNURLInfo;->url:Ljava/lang/String;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    iget-object v2, p1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPCDNURLInfo;->cdnIp:Ljava/lang/String;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    iget-object v3, p1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPCDNURLInfo;->uIp:Ljava/lang/String;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget-object p1, p1, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPCDNURLInfo;->errorStr:Ljava/lang/String;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-interface {v0, v1, v2, v3, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadCdnUrlInfoUpdate(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    return-void

    :pswitch_8
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$a;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x4

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    check-cast p1, Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadCdnUrlUpdate(Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    return-void

    :pswitch_9
    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$a;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v10, 0x1

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget v1, p1, Landroid/os/Message;->arg1:I

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget v2, p1, Landroid/os/Message;->arg2:I

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x5

    check-cast p1, Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x3

    invoke-interface {v0, v1, v2, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadError(IILjava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    return-void

    :pswitch_a
    iget-object p1, p0, Lcom/tencent/thumbplayer/c/e$a;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-interface {p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onDownloadFinish()V

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    return-void

    :cond_1
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$a;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x1

    iget p1, p1, Landroid/os/Message;->arg1:I

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/c/e;->b(Lcom/tencent/thumbplayer/c/e;I)V

    :goto_0
    const/4 v10, 0x5

    return-void

    :cond_2
    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$a;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v10, 0x7

    iget p1, p1, Landroid/os/Message;->arg1:I

    const/4 v9, 0x5

    shr-int/2addr v10, v9

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;I)V

    const/4 v9, 0x3

    move v10, v9

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1001
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
