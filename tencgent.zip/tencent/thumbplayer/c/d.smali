.class public Lcom/tencent/thumbplayer/c/d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/reflect/InvocationHandler;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/c/d$a;
    }
.end annotation


# instance fields
.field private a:Lcom/tencent/thumbplayer/c/e;

.field private b:Lcom/tencent/thumbplayer/tplayer/a;

.field private c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

.field private d:Lcom/tencent/thumbplayer/c/d$a;

.field private e:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/c/e;Lcom/tencent/thumbplayer/tplayer/a;)V
    .locals 4
    .param p1    # Lcom/tencent/thumbplayer/c/e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/tencent/thumbplayer/tplayer/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/c/d$a;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, p0, v1}, Lcom/tencent/thumbplayer/c/d$a;-><init>(Lcom/tencent/thumbplayer/c/d;Lcom/tencent/thumbplayer/c/d$1;)V

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/d;->d:Lcom/tencent/thumbplayer/c/d$a;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/d;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object p2, p0, Lcom/tencent/thumbplayer/c/d;->b:Lcom/tencent/thumbplayer/tplayer/a;

    const/4 v3, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/tplayer/a;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "M@s.os~l u~o i@~~~o@of~~@     a~r~~~K@f@~S/@m~b@~ ~@b~@@ ~ c l~@t@o~ d tv@ 1~@b@oi@@ @~~/i4 n-y "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/tencent/thumbplayer/c/d;->b:Lcom/tencent/thumbplayer/tplayer/a;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p0
.end method

.method private static a(Ljava/lang/reflect/Method;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string/jumbo v0, "nsamoob"

    const-string/jumbo v0, "oosnbae"

    const/4 v3, 0x0

    const-string v0, "bneooal"

    const-string v0, "boolean"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v2, 0x2

    move v3, v2

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const-string/jumbo v0, "int"

    const-string/jumbo v0, "tin"

    const-string/jumbo v0, "nti"

    const-string/jumbo v0, "int"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v0, "nlog"

    const-string/jumbo v0, "gnol"

    const/4 v3, 0x2

    const-string/jumbo v0, "ngol"

    const-string/jumbo v0, "long"

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object p0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string v0, "bflom"

    const-string/jumbo v0, "ftlmo"

    const/4 v3, 0x6

    const-string/jumbo v0, "lutao"

    const-string/jumbo v0, "float"

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz p0, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x0

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p0

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x5

    return-object p0
.end method

.method private a(Ljava/lang/reflect/Method;[Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string/jumbo v0, "sarlBawpsontsAoadytlyPoD"

    const-string v0, "PsBsoAaDataelorlwynsdyot"

    const/4 v2, 0x7

    const-string v0, "BPDwnoorqtlltetsAydsayaa"

    const-string/jumbo v0, "startDownloadPlayByAsset"

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string v0, "DlstyloPbwadsnora"

    const-string v0, "PslrtbyDwantdloao"

    const/4 v2, 0x7

    const-string/jumbo v0, "oynmdwatlDalParos"

    const-string/jumbo v0, "startDownloadPlay"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0, p2}, Lcom/tencent/thumbplayer/c/d;->a([Ljava/lang/Object;)V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method private a([Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance p1, Lcom/tencent/thumbplayer/d/b$g;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p1}, Lcom/tencent/thumbplayer/d/b$g;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d;->b:Lcom/tencent/thumbplayer/tplayer/a;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/tplayer/a;->b()Lcom/tencent/thumbplayer/d/c;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/d/c;->a(Lcom/tencent/thumbplayer/d/b$a;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/c/d;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/tencent/thumbplayer/c/d;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    const/4 v1, 0x5

    return-object p0
.end method

.method private b(Ljava/lang/reflect/Method;[Ljava/lang/Object;)V
    .locals 3
    .param p1    # Ljava/lang/reflect/Method;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string v0, "PatsonyreuitLle"

    const-string v0, "atrlPiueeetnsLy"

    const/4 v2, 0x0

    const-string/jumbo v0, "yanilbeetPsters"

    const-string/jumbo v0, "setPlayListener"

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    aget-object v0, p2, p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    check-cast v0, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/d;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d;->d:Lcom/tencent/thumbplayer/c/d$a;

    const/4 v2, 0x2

    aput-object v0, p2, p1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public declared-synchronized a()Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d;->e:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/c/d;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/Class;->getInterfaces()[Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0, v1, p0}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/d;->e:Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/d;->e:Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    monitor-exit p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    monitor-exit p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    throw v0
.end method

.method public invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x4

    const-string p1, "aipox u ecetnhs c"

    const-string/jumbo p1, "secpn  phe axtcio"

    const/4 v4, 0x7

    const-string/jumbo p1, "nahstpcp ci: exoe"

    const-string p1, " has excecption: "

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v0, "kv Meidhqoonq"

    const-string v0, "eMoeovniqdk h"

    const/4 v4, 0x1

    const-string/jumbo v0, "invokeMethod "

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v1, "TpstaxyoerrgronrasDaaPTntaM"

    const-string v1, "TPDataTransportManagerProxy"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {p0, p2, p3}, Lcom/tencent/thumbplayer/c/d;->b(Ljava/lang/reflect/Method;[Ljava/lang/Object;)V

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/d;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p2, v2, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {p0, p2, p3}, Lcom/tencent/thumbplayer/c/d;->a(Ljava/lang/reflect/Method;[Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    return-object v2

    :catchall_0
    move-exception p3

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p3}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v1, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {p2}, Lcom/tencent/thumbplayer/c/d;->a(Ljava/lang/reflect/Method;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object p1

    :catch_0
    move-exception p3

    const/4 v4, 0x1

    const/4 v3, 0x6

    invoke-virtual {p3}, Ljava/lang/reflect/InvocationTargetException;->getTargetException()Ljava/lang/Throwable;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-nez v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p3}, Ljava/lang/reflect/InvocationTargetException;->getTargetException()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    throw p1
.end method
