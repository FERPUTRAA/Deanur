.class Lcom/tencent/thumbplayer/c/e$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/c/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "c"
.end annotation


# instance fields
.field a:J

.field b:I


# direct methods
.method constructor <init>(JI)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-wide p1, p0, Lcom/tencent/thumbplayer/c/e$c;->a:J

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p3, p0, Lcom/tencent/thumbplayer/c/e$c;->b:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method
