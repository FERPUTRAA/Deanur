.class public Lcom/tencent/thumbplayer/c/g;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/api/proxy/ITPPreloadProxy;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/c/g$a;
    }
.end annotation


# instance fields
.field private a:Landroid/content/Context;

.field private b:I

.field private c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

.field private d:Lcom/tencent/thumbplayer/c/g$a;

.field private e:Lcom/tencent/thumbplayer/api/proxy/ITPPreloadProxy$IPreloadListener;

.field private f:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/c/g;->f:Z

    const/4 v3, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/c/g$a;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0, p0, v1}, Lcom/tencent/thumbplayer/c/g$a;-><init>(Lcom/tencent/thumbplayer/c/g;Lcom/tencent/thumbplayer/c/g$1;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/g;->d:Lcom/tencent/thumbplayer/c/g$a;

    const/4 v3, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/c/f;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const-string v1, "PosIlPrdmeaosryPxl"

    const-string v1, "TIsdrmlPPexoPyroal"

    const/4 v3, 0x7

    const-string v1, "darmlpIPmolxyroPeT"

    const-string v1, "TPPreloadProxyImpl"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Lcom/tencent/thumbplayer/c/f;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/g;->e:Lcom/tencent/thumbplayer/api/proxy/ITPPreloadProxy$IPreloadListener;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/g;->a:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput p2, p0, Lcom/tencent/thumbplayer/c/g;->b:I

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/tencent/thumbplayer/c/g;->a()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/c/g;)Lcom/tencent/thumbplayer/api/proxy/ITPPreloadProxy$IPreloadListener;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "/~1~o@  lob~@ Sc@ts~ @ @/i~M@@y@o @~a @f~ o ~ .~~~i~n@u t f@~@ ~r~bK4 v@@@~@l-@ oom~ o~~~@ @i~~b"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/tencent/thumbplayer/c/g;->e:Lcom/tencent/thumbplayer/api/proxy/ITPPreloadProxy$IPreloadListener;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p0
.end method

.method private a()V
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x0

    const-string/jumbo v0, "mrPxlbpPeaooTIPrld"

    const-string v0, "ellmdxropoPTIPPyar"

    const/4 v7, 0x7

    const-string v0, "IdTloPuxlPPepyrmoa"

    const-string v0, "TPPreloadProxyImpl"

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/4 v1, 0x3

    :goto_0
    const/4 v7, 0x3

    if-lez v1, :cond_4

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-boolean v2, p0, Lcom/tencent/thumbplayer/c/g;->f:Z

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-nez v2, :cond_4

    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/c/i;->a()Lcom/tencent/thumbplayer/c/i;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget v3, p0, Lcom/tencent/thumbplayer/c/g;->b:I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v2, v3}, Lcom/tencent/thumbplayer/c/i;->a(I)Lcom/tencent/thumbplayer/c/b;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eqz v2, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-interface {v2}, Lcom/tencent/thumbplayer/c/b;->a()Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz v3, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-interface {v2}, Lcom/tencent/thumbplayer/c/b;->a()Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    iput-object v2, p0, Lcom/tencent/thumbplayer/c/g;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v3, p0, Lcom/tencent/thumbplayer/c/g;->d:Lcom/tencent/thumbplayer/c/g$a;

    const/4 v6, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-interface {v2, v3}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setLogListener(Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDLProxyLogListener;)V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/g;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string/jumbo v3, "i_qqvsip_"

    const-string/jumbo v3, "vsi_oi_qq"

    const/4 v7, 0x2

    const-string/jumbo v3, "vpiqsq__q"

    const-string/jumbo v3, "qq_is_vip"

    const/4 v7, 0x1

    const/4 v6, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->isUserIsVip()Z

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-interface {v2, v3, v4}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setUserData(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getUserUin()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-nez v2, :cond_0

    const/4 v6, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/g;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string v3, "_nsiuurb"

    const-string/jumbo v3, "inu_ebru"

    const/4 v7, 0x6

    const-string/jumbo v3, "reimnusu"

    const-string/jumbo v3, "user_uin"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getUserUin()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-interface {v2, v3, v4}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setUserData(Ljava/lang/String;Ljava/lang/Object;)V

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/g;->a:Landroid/content/Context;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {v2}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getAppVersionName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-nez v2, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/g;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v7, 0x5

    const-string/jumbo v3, "o_msoeavpr_iaunn"

    const-string/jumbo v3, "vempa_u_rionspna"

    const/4 v7, 0x0

    const-string/jumbo v3, "nenaobspvmae_p_i"

    const-string v3, "app_version_name"

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object v4, p0, Lcom/tencent/thumbplayer/c/g;->a:Landroid/content/Context;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v4}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getAppVersionName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-interface {v2, v3, v4}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setUserData(Ljava/lang/String;Ljava/lang/Object;)V

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/g;->a:Landroid/content/Context;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {v2}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getBuildNumber(Landroid/content/Context;)J

    move-result-wide v2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    cmp-long v2, v2, v4

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-eqz v2, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/g;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-string/jumbo v3, "pve_anuopesocird"

    const-string/jumbo v3, "soie_oapcnppvred"

    const/4 v7, 0x3

    const-string/jumbo v3, "s_repe_pcdvnpoia"

    const-string v3, "app_version_code"

    const/4 v6, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v4, p0, Lcom/tencent/thumbplayer/c/g;->a:Landroid/content/Context;

    const/4 v7, 0x7

    invoke-static {v4}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getBuildNumber(Landroid/content/Context;)J

    move-result-wide v4

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v4, v5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-interface {v2, v3, v4}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setUserData(Ljava/lang/String;Ljava/lang/Object;)V

    :cond_2
    const/4 v6, 0x6

    move v7, v6

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/g;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string/jumbo v3, "udcdqieoqe__roprrca"

    const-string v3, "_cd_oipeqcerraosurd"

    const/4 v7, 0x7

    const-string v3, "aosp_r_edrsecerocui"

    const-string v3, "carrier_pesudo_code"

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getUserUpc()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-interface {v2, v3, v4}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setUserData(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/g;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string v3, "a_umesidprresat_cetr"

    const-string/jumbo v3, "roste_ceerpauitd_sra"

    const/4 v7, 0x1

    const-string/jumbo v3, "ratpoecs_euisrdr_eot"

    const-string v3, "carrier_pesudo_state"

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getUserUpcState()I

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-interface {v2, v3, v4}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setUserData(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v7, 0x3

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/g;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string/jumbo v3, "tem_nbplkienraewo_t"

    const-string v3, "_nemnlitrapkteorw_e"

    const/4 v7, 0x6

    const-string v3, "epx_enu_rtlnkateiro"

    const-string/jumbo v3, "external_network_ip"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getOutNetIp()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-interface {v2, v3, v4}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setUserData(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v2, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput-boolean v2, p0, Lcom/tencent/thumbplayer/c/g;->f:Z

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    return-void

    :cond_3
    const/4 v6, 0x3

    add-int/lit8 v1, v1, -0x1

    const/4 v6, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string/jumbo v2, "odipfaople ospld 2"

    const-string v2, " p2eo alafdopsdilo"

    const/4 v7, 0x3

    const-string/jumbo v2, "fdpooi aqs2 lapel "

    const-string/jumbo v2, "p2p so load failed"

    const/4 v6, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {v0, v2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    goto/16 :goto_0

    :catch_0
    move-exception v2

    const/4 v7, 0x3

    const/4 v6, 0x7

    add-int/lit8 v1, v1, -0x1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {v0, v2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    goto/16 :goto_0

    :cond_4
    const/4 v7, 0x1

    const/4 v6, 0x7

    return-void
.end method


# virtual methods
.method public getPlayErrorCodeStr(I)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p1
.end method

.method public isAvailable()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/g;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/c/g;->f:Z

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method public pushEvent(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/c/g;->isAvailable()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void

    :cond_0
    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/g;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->pushEvent(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string v0, "PPsrePllboTdomyaIx"

    const-string/jumbo v0, "omlPebIrlPraPxdoyT"

    const/4 v2, 0x6

    const-string/jumbo v0, "permTmldlPxorPoaPy"

    const-string v0, "TPPreloadProxyImpl"

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public setPreloadListener(Lcom/tencent/thumbplayer/api/proxy/ITPPreloadProxy$IPreloadListener;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance p1, Lcom/tencent/thumbplayer/c/f;

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string v0, "PmuxoPTeolaypPrrol"

    const-string v0, "PreIPoularoxPmlTyp"

    const/4 v2, 0x2

    const-string v0, "TPPreloadProxyImpl"

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p1, v0}, Lcom/tencent/thumbplayer/c/f;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/g;->e:Lcom/tencent/thumbplayer/api/proxy/ITPPreloadProxy$IPreloadListener;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/g;->e:Lcom/tencent/thumbplayer/api/proxy/ITPPreloadProxy$IPreloadListener;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public startClipPreload(Ljava/lang/String;Ljava/util/ArrayList;)I
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;",
            ">;)I"
        }
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string/jumbo v0, "odieabcrsnPelpCsPapgii[.prd arll]tt "

    const-string/jumbo v0, "ssntr gpPePrid aa[ld]Clpitelilcpoa.r"

    const/4 v7, 0x0

    const-string v0, "Pe.asauoarirllnttslogeicrp]lipC Pd d"

    const-string v0, "[startClipPreload] Preloading clips."

    const/4 v7, 0x6

    const-string v1, "dplrPxIpqmeTooPPar"

    const-string/jumbo v1, "oPodrTPrqeIPmlpyax"

    const/4 v7, 0x0

    const-string v1, "TPlPIorPqyxmeoalpr"

    const-string v1, "TPPreloadProxyImpl"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 v0, -0x1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-nez p2, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-string p1, "daspo cpF n oasaPt:noae lsor tlp dCrra.ltrlrua  liad [dswisetotil]tilrllmtee"

    const-string/jumbo p1, "p stredssarpmtow ioF lrtlPiu npitldralsdol Cicoa ao llaea]ael.ttdar  l:rnte["

    const/4 v7, 0x5

    const-string p1, " damretwpl]l.lotaCarPnnp cr as :[otaiaieirdtl ootalri emd atspstd prluo Flel"

    const-string p1, "[startClipPreload] Fail to start clip preload: null download parameter list."

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {v1, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    return v0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/c/g;->isAvailable()Z

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x1

    if-nez v2, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-direct {p0}, Lcom/tencent/thumbplayer/c/g;->a()V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/c/g;->isAvailable()Z

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-nez v2, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string p1, "ao iostyrrl]m.Ctixn rzat[ioeal dli PFiaeptpi"

    const-string/jumbo p1, "iptmdtFel r rlyntialtaPiolpCiezox aaiis. []r"

    const/4 v7, 0x0

    const-string/jumbo p1, "tCae]bi .ittaooPlpF idl eratyzpiolrr [iaxsln"

    const-string p1, "[startClipPreload] Fail to initialize proxy."

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-static {v1, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    return v0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/g;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v4, p0, Lcom/tencent/thumbplayer/c/g;->d:Lcom/tencent/thumbplayer/c/g$a;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-interface {v2, p1, v3, v4}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->startClipPreload(Ljava/lang/String;ILcom/tencent/thumbplayer/core/downloadproxy/api/ITPPreLoadListener;)I

    move-result p1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-gtz p1, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const-string/jumbo p2, "it.pInu opp[lile didpodaae lPt]corlsitlt   rC:aldas airFa otDvloae"

    const-string/jumbo p2, "idoeoep i Pnlo: ip.rsrttlDltlaF arasl]It loecaadi rtvdCpapia[od  l"

    const/4 v7, 0x4

    const-string p2, " eeaaloptpdpl[li:DCl iatop  rtv c osralFitaai. dIis rld]rtPdpnolar"

    const-string p2, "[startClipPreload] Fail to start clip preload: invalid preload ID."

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {v1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/c/g;->stopPreload(I)V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    return v0

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 v2, 0x1

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eqz v3, :cond_4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    check-cast v3, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v3}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getUrl()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {v4, v3, v5}, Lcom/tencent/thumbplayer/c/k;->a(Ljava/lang/String;Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;Ljava/util/Map;)Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadParam;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-object v5, p0, Lcom/tencent/thumbplayer/c/g;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v7, 0x2

    const/4 v6, 0x4

    invoke-virtual {v3}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getDownloadFileID()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-interface {v5, p1, v2, v3, v4}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setClipInfo(IILjava/lang/String;Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadParam;)Z

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-nez v3, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    const-string/jumbo p2, "ppP[l]ocqr fateFdl osttili i  b.rostaaCen"

    const-string/jumbo p2, "otf Pbitip rl [iape]rtlcFi n.aesosdlCaot "

    const/4 v7, 0x2

    const-string p2, "[startClipPreload] Fail to set clip info."

    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-static {v1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/c/g;->stopPreload(I)V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    return v0

    :cond_3
    const/4 v6, 0x0

    move v7, v6

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_4
    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget-object p2, p0, Lcom/tencent/thumbplayer/c/g;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-interface {p2, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->startTask(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x6

    return p1

    :catchall_0
    move-exception p2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string/jumbo v3, "lasePrastaiau titos :k o] t atCrst[dllp"

    const-string v3, " dk iaut]latt tCaarpsoos F[a:lPlt seitr"

    const/4 v7, 0x4

    const-string v3, "do mtoitalCtttrl i sa]a [splaetkasrF Pr"

    const-string v3, "[startClipPreload] Fail to start task: "

    const/4 v7, 0x5

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {p2}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {v1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {p0, p1}, Lcom/tencent/thumbplayer/c/g;->stopPreload(I)V

    const/4 v7, 0x6

    const/4 v6, 0x0

    return v0
.end method

.method public startPreload(Ljava/lang/String;Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2, v0}, Lcom/tencent/thumbplayer/c/g;->startPreload(Ljava/lang/String;Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;Ljava/util/Map;)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return p1
.end method

.method public startPreload(Ljava/lang/String;Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;Ljava/util/Map;)I
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)I"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/c/g;->isAvailable()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/tencent/thumbplayer/c/g;->a()V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/c/g;->isAvailable()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    return v1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz p2, :cond_1

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x7

    invoke-static {v0, p2, p3}, Lcom/tencent/thumbplayer/c/k;->a(Ljava/lang/String;Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;Ljava/util/Map;)Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadParam;

    move-result-object p2

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object p3, p0, Lcom/tencent/thumbplayer/c/g;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/g;->d:Lcom/tencent/thumbplayer/c/g$a;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {p3, p1, p2, v0}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->startPreload(Ljava/lang/String;Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadParam;Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPreLoadListener;)I

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    return p1

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string p2, "aeIdopyrPpllPTomrx"

    const-string/jumbo p2, "yTolrmopIexpdPParl"

    const/4 v3, 0x0

    const-string p2, "dmoPrbloxPpPyrTeIa"

    const-string p2, "TPPreloadProxyImpl"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    return v1
.end method

.method public stopPreload(I)V
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/g;->c:Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void

    :cond_0
    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->stopPreload(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string v0, "elmPqpuxoIPrlrodya"

    const-string/jumbo v0, "plloIramqPPrePoxyd"

    const/4 v2, 0x2

    const-string v0, "PTrPexIpldpPoalrmo"

    const-string v0, "TPPreloadProxyImpl"

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method
