.class public Lcom/tencent/thumbplayer/c/c;
.super Ljava/lang/Object;


# direct methods
.method public static a(Landroid/os/Looper;Lcom/tencent/thumbplayer/tplayer/a;)Lcom/tencent/thumbplayer/c/a;
    .locals 4
    .param p0    # Landroid/os/Looper;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/tencent/thumbplayer/tplayer/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o~so~@ @.f@~@t@ ~ @@~~d~@~~ l ci@ @@s / @  ~~b  i4~@f  @b M~t~@mo@o@~u S1o~@yKi-rn~~@l ~ao~/@bv~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getNewReportEnable()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Lcom/tencent/thumbplayer/c/e;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/tplayer/a;->a()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {v0, v1, p0}, Lcom/tencent/thumbplayer/c/e;-><init>(Landroid/content/Context;Landroid/os/Looper;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance p0, Lcom/tencent/thumbplayer/c/d;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/c/d;-><init>(Lcom/tencent/thumbplayer/c/e;Lcom/tencent/thumbplayer/tplayer/a;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/c/d;->a()Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    check-cast p0, Lcom/tencent/thumbplayer/c/a;

    const/4 v3, 0x4

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/c/e;

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/tplayer/a;->a()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, p1, p0}, Lcom/tencent/thumbplayer/c/e;-><init>(Landroid/content/Context;Landroid/os/Looper;)V

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    return-object v0
.end method
