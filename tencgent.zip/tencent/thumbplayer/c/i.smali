.class public Lcom/tencent/thumbplayer/c/i;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/utils/f$a;
.implements Lcom/tencent/thumbplayer/utils/i$b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/c/i$a;
    }
.end annotation


# instance fields
.field private a:I

.field private b:Ljava/lang/String;

.field private c:I

.field private d:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/Integer;",
            "Lcom/tencent/thumbplayer/c/b;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x3

    move v3, v2

    iput v0, p0, Lcom/tencent/thumbplayer/c/i;->a:I

    const/4 v3, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/tencent/thumbplayer/c/i;->b:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/c/i;->c:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/i;->d:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x0

    move v3, v2

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/i;->d:Ljava/util/concurrent/ConcurrentHashMap;

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p0}, Lcom/tencent/thumbplayer/utils/f;->a(Lcom/tencent/thumbplayer/utils/f$a;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/utils/i;->a()Lcom/tencent/thumbplayer/utils/i;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, p0}, Lcom/tencent/thumbplayer/utils/i;->a(Lcom/tencent/thumbplayer/utils/i$b;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/thumbplayer/c/i$1;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/c/i;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public static a()Lcom/tencent/thumbplayer/c/i;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "t sm~@1 f~~@~~@   ~ y~oo ~lof  @o nb c@~~@ ~Kr4@@a ud~@ivl~~~i@~~~@ -@@t@o/i@ ~b@bs~ o@.M@@~~/S "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/c/i$a;->a()Lcom/tencent/thumbplayer/c/i;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method private static a(Landroid/content/Context;)Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDLProxyInitParam;
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    new-instance v7, Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDLProxyInitParam;

    const/4 v9, 0x7

    const/4 v8, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getPlatform()I

    move-result v1

    const/4 v9, 0x4

    const/4 v8, 0x6

    invoke-static {p0}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getAppVersionName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getGuid()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getProxyCacheDir()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getProxyDataDir()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getProxyConfigDir()Ljava/lang/String;

    move-result-object v6

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-direct/range {v0 .. v6}, Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDLProxyInitParam;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    return-object v7
.end method

.method private a(Ljava/lang/String;I)V
    .locals 6

    const/4 v4, 0x7

    const/4 v5, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/i;->b:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput p2, p0, Lcom/tencent/thumbplayer/c/i;->c:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/i;->d:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    check-cast v1, Lcom/tencent/thumbplayer/c/b;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {v1}, Lcom/tencent/thumbplayer/c/b;->a()Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v3, "diomudprsee_coserc_"

    const-string v3, "e_srpcodoedi_uscrer"

    const/4 v5, 0x0

    const-string/jumbo v3, "oce_orspe_rureicoad"

    const-string v3, "carrier_pesudo_code"

    const/4 v5, 0x4

    invoke-interface {v2, v3, p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setUserData(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {v1}, Lcom/tencent/thumbplayer/c/b;->a()Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string/jumbo v2, "s_daobtiraee_screrup"

    const-string/jumbo v2, "rusmpad_ecoati_reres"

    const/4 v5, 0x4

    const-string v2, "astsiducrapre_o_eeur"

    const-string v2, "carrier_pesudo_state"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-interface {v1, v2, v3}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setUserData(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v5, 0x6

    return-void
.end method

.method private b(Z)Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Lorg/json/JSONObject;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string/jumbo v1, "oetaorRpepbl"

    const-string/jumbo v1, "pbReoreonlat"

    const/4 v3, 0x1

    const-string v1, "eobtlarEqepn"

    const-string v1, "EnableReport"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p1

    :catch_0
    move-exception p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string/jumbo v0, "rasbaMeynPgTlPxbaGro"

    const-string v0, "TranlbeoarbyPxPgGMla"

    const/4 v3, 0x4

    const-string/jumbo v0, "rngmPyMaxlToearPobal"

    const-string v0, "TPProxyGlobalManager"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string p1, ""

    const-string p1, ""

    const/4 v3, 0x0

    const-string p1, ""

    const-string p1, ""

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p1
.end method

.method private b(I)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/i;->d:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    check-cast v1, Lcom/tencent/thumbplayer/c/b;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {v1, p1}, Lcom/tencent/thumbplayer/c/b;->a(I)V

    const/4 v2, 0x5

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method

.method private c(J)Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Lorg/json/JSONObject;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v2, 0x7

    move v3, v2

    const-string v1, "eUyeo1oLMBraMvmexluM"

    const-string v1, "aB1MyLuUevxolMeeMmre"

    const/4 v3, 0x6

    const-string/jumbo v1, "ymsLBbxeoee1UMevMMlr"

    const-string v1, "MaxUseMemoryLevel1MB"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string v1, "LMyeovueB2laepMxrmUs"

    const-string v1, "e2roUMlpmLxevByasMee"

    const/4 v3, 0x0

    const-string/jumbo v1, "rUsBeolpeeeyMMLvxMam"

    const-string v1, "MaxUseMemoryLevel2MB"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, v1, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string v1, "BsaqMeyUqrxmoe"

    const-string v1, "UsmBxoaMqeryeM"

    const/4 v3, 0x0

    const-string/jumbo v1, "yMsorUamseMxeB"

    const-string v1, "MaxUseMemoryMB"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    return-object p1

    :catch_0
    move-exception p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo p2, "nPsebrlToyGMralagPox"

    const/4 v3, 0x3

    const-string p2, "bGTmaPoearxlloyrPMag"

    const-string p2, "TPProxyGlobalManager"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string p1, ""

    const-string p1, ""

    const/4 v3, 0x4

    const-string p1, ""

    const-string p1, ""

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object p1
.end method


# virtual methods
.method public a(I)Lcom/tencent/thumbplayer/c/b;
    .locals 10

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-string/jumbo v0, "n_ooopcxyrfg"

    const-string/jumbo v0, "ofnmgcryx_po"

    const/4 v9, 0x7

    const-string/jumbo v0, "yifxpbncgoor"

    const-string/jumbo v0, "proxy_config"

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    const-string/jumbo v1, "ooalnPuyTGxMrbPgaear"

    const-string v1, "PoyaonarorGaxlMPTbge"

    const/4 v9, 0x1

    const-string v1, "ebolaxMpGlgyroanPTaP"

    const-string v1, "TPProxyGlobalManager"

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    const/4 v2, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-gez p1, :cond_0

    const/4 v8, 0x5

    and-int/2addr v9, v8

    return-object v2

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget-object v3, p0, Lcom/tencent/thumbplayer/c/i;->d:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v8, 0x5

    xor-int/2addr v9, v8

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    if-eqz v3, :cond_1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/i;->d:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v0, p1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    check-cast p1, Lcom/tencent/thumbplayer/c/b;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    return-object p1

    :cond_1
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-static {p1}, Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadProxyFactory;->getTPDownloadProxy(I)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    move-result-object v3

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    if-eqz v3, :cond_8

    :try_start_0
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->getAppContext()Landroid/content/Context;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/api/TPPlayerMgr;->getAppContext()Landroid/content/Context;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {v5}, Lcom/tencent/thumbplayer/c/i;->a(Landroid/content/Context;)Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDLProxyInitParam;

    move-result-object v5

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-interface {v3, v4, v5}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->init(Landroid/content/Context;Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDLProxyInitParam;)I

    move-result v4

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-gez v4, :cond_2

    const/4 v8, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-string/jumbo p1, "ilPhrfboql:w sexnaotndi  t dosyawaidit"

    const-string/jumbo p1, "tawitbot w:sdflohPd r nosaiy nixeiladt"

    const/4 v9, 0x4

    const-string p1, "downloadProxy init failed with status:"

    const/4 v8, 0x7

    move v9, v8

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-static {v1, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    return-object v2

    :cond_2
    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x5

    new-instance v4, Lcom/tencent/thumbplayer/c/i$1;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-direct {v4, p0}, Lcom/tencent/thumbplayer/c/i$1;-><init>(Lcom/tencent/thumbplayer/c/i;)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-interface {v3, v4}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setLogListener(Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDLProxyLogListener;)V

    const/4 v8, 0x3

    xor-int/2addr v9, v8

    invoke-static {}, Lcom/tencent/thumbplayer/utils/i;->c()I

    move-result v4

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/16 v5, 0xa

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    const/4 v6, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-ne v4, v6, :cond_3

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-interface {v3, v6}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->pushEvent(I)V

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-interface {v3, v5}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->pushEvent(I)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    goto :goto_1

    :cond_3
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    const/4 v6, 0x2

    const/4 v8, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-ne v4, v6, :cond_4

    const/4 v9, 0x2

    const/4 v8, 0x5

    invoke-interface {v3, v6}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->pushEvent(I)V

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    const/16 v4, 0x9

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-interface {v3, v4}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->pushEvent(I)V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    goto :goto_1

    :cond_4
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    const/4 v7, 0x3

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-ne v4, v7, :cond_5

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-interface {v3, v6}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->pushEvent(I)V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    goto :goto_0

    :cond_5
    :goto_1
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget v4, p0, Lcom/tencent/thumbplayer/c/i;->a:I

    const/4 v9, 0x2

    invoke-interface {v3, v4}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->pushEvent(I)V

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-string v4, "csso_idcrurpuoreeed"

    const-string/jumbo v4, "oeparru_ioecdrdscue"

    const/4 v9, 0x3

    const-string v4, "cc_mroerosp_edrdeau"

    const-string v4, "carrier_pesudo_code"

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v5, p0, Lcom/tencent/thumbplayer/c/i;->b:Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-interface {v3, v4, v5}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setUserData(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    const-string/jumbo v4, "o_caureptsedperirs_a"

    const/4 v9, 0x5

    const-string v4, "ecptorrdie_teoau_ssr"

    const-string v4, "carrier_pesudo_state"

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    iget v5, p0, Lcom/tencent/thumbplayer/c/i;->c:I

    const/4 v9, 0x5

    const/4 v8, 0x4

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-interface {v3, v4, v5}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setUserData(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v9, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->isDataReportEnable()Z

    move-result v4

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-direct {p0, v4}, Lcom/tencent/thumbplayer/c/i;->b(Z)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-interface {v3, v0, v4}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setUserData(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getProxyMaxUseMemoryMB()J

    move-result-wide v4

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    const-wide/16 v6, 0x0

    const/4 v9, 0x6

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v9, 0x4

    cmp-long v4, v4, v6

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-lez v4, :cond_6

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getProxyMaxUseMemoryMB()J

    move-result-wide v4

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-direct {p0, v4, v5}, Lcom/tencent/thumbplayer/c/i;->c(J)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-eqz v4, :cond_6

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-lez v5, :cond_6

    const/4 v9, 0x3

    invoke-interface {v3, v0, v4}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setUserData(Ljava/lang/String;Ljava/lang/Object;)V

    :cond_6
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getProxyMaxStorageSizeMB()J

    move-result-wide v4

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    cmp-long v0, v4, v6

    const/4 v8, 0x6

    shr-int/2addr v9, v8

    if-lez v0, :cond_7

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getProxyMaxStorageSizeMB()J

    move-result-wide v4

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-interface {v3, v4, v5}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setMaxStorageSizeMB(J)V

    :cond_7
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/c/j;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-direct {v0, v3}, Lcom/tencent/thumbplayer/c/j;-><init>(Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;)V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v3, p0, Lcom/tencent/thumbplayer/c/i;->d:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v3, v4, v0}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    const-string v3, "eplgebpoec xdPtdyctery: T,r,Pvruncasisxy  ioyeieer"

    const-string/jumbo v3, "getPlayerProxy, init proxy succeeded, serviceType:"

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v3, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {v1, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    return-object v0

    :catchall_0
    move-exception p1

    const/4 v9, 0x1

    const/4 v8, 0x3

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-string/jumbo v0, "x:  nfuiaeqrypidot"

    const-string/jumbo v0, "x inrioeqa ipd:tfy"

    const/4 v9, 0x2

    const-string/jumbo v0, "rd ipiipt: afolyne"

    const-string/jumbo v0, "init proxy failed:"

    const/4 v8, 0x1

    or-int/2addr v9, v8

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {v1, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_8
    const/4 v9, 0x2

    return-object v2
.end method

.method public a(IIII)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    const/16 p1, 0xa

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p3, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    if-ne p2, p3, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0, p3}, Lcom/tencent/thumbplayer/c/i;->b(I)V

    :goto_0
    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/c/i;->b(I)V

    const/4 v0, 0x5

    move v1, v0

    return-void

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 p3, 0x3

    const/4 p3, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    if-ne p2, p3, :cond_1

    const/4 v1, 0x3

    invoke-direct {p0, p3}, Lcom/tencent/thumbplayer/c/i;->b(I)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/16 p1, 0x9

    const/4 v1, 0x4

    goto :goto_0

    :cond_1
    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 p4, 0x3

    move v1, p4

    const/4 v0, 0x4

    const/4 v1, 0x2

    if-ne p2, p4, :cond_2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0, p3}, Lcom/tencent/thumbplayer/c/i;->b(I)V

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/c/i;->b(I)V

    :cond_2
    const/4 v1, 0x1

    return-void
.end method

.method public a(IIILjava/lang/Object;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const-string v1, "Eo  n:teqvsnvIned"

    const-string v1, " nsoed evnI:tntvE"

    const/4 v3, 0x4

    const-string v1, ":IsnveeEdv n teot"

    const-string/jumbo v1, "onEvent eventId: "

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v1, " r1m:, a"

    const-string v1, ", arg1: "

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string v1, "2 ,mor a"

    const-string/jumbo v1, "g  m,ar2"

    const/4 v3, 0x7

    const-string v1, ", arg2: "

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string/jumbo p3, "obtejbo,"

    const-string p3, ",eboojt "

    const/4 v3, 0x0

    const-string p3, "ebj,tcuo"

    const-string p3, ", object"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string v0, "TobagGbprlPryaMxPnae"

    const-string v0, "ayGPTboballrrMxnPeag"

    const/4 v3, 0x2

    const-string v0, "allnxrPoqPoagraGTbye"

    const-string v0, "TPProxyGlobalManager"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0, p3}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    packed-switch p1, :pswitch_data_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_1

    :pswitch_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    check-cast p4, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {p0, p4, p2}, Lcom/tencent/thumbplayer/c/i;->a(Ljava/lang/String;I)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_1

    :pswitch_1
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/16 p1, 0xe

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput p1, p0, Lcom/tencent/thumbplayer/c/i;->a:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/c/i;->b(I)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void

    :pswitch_2
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/16 p1, 0xd

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :goto_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x186a1
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public a(J)V
    .locals 6

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/i;->d:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    check-cast v1, Lcom/tencent/thumbplayer/c/b;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-interface {v1}, Lcom/tencent/thumbplayer/c/b;->a()Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    cmp-long v2, p1, v2

    const/4 v4, 0x7

    shr-int/2addr v5, v4

    if-lez v2, :cond_0

    invoke-interface {v1, p1, p2}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setMaxStorageSizeMB(J)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    return-void
.end method

.method public a(Z)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/i;->d:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    check-cast v1, Lcom/tencent/thumbplayer/c/b;

    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-interface {v1}, Lcom/tencent/thumbplayer/c/b;->a()Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v2, "n_sygrxcofpu"

    const-string/jumbo v2, "n_oyprucgofx"

    const/4 v5, 0x7

    const-string/jumbo v2, "girmoofx_ypc"

    const-string/jumbo v2, "proxy_config"

    const/4 v5, 0x1

    const/4 v4, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/c/i;->b(Z)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-interface {v1, v2, v3}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setUserData(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-void
.end method

.method public b(J)V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/i;->d:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    check-cast v1, Lcom/tencent/thumbplayer/c/b;

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-interface {v1}, Lcom/tencent/thumbplayer/c/b;->a()Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v2, "pronooygfci_"

    const-string/jumbo v2, "rnpf_oipygoc"

    const/4 v5, 0x0

    const-string/jumbo v2, "icfgybpon_xo"

    const-string/jumbo v2, "proxy_config"

    const/4 v5, 0x0

    invoke-direct {p0, p1, p2}, Lcom/tencent/thumbplayer/c/i;->c(J)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-interface {v1, v2, v3}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPDownloadProxy;->setUserData(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v5, 0x0

    return-void
.end method
