.class public Lcom/tencent/thumbplayer/c/k;
.super Ljava/lang/Object;


# direct methods
.method static a(Ljava/lang/String;Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;Ljava/util/Map;)Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadParam;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadParam;"
        }
    .end annotation

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, "@ s@ ~l~@@fio@c@o @v1~ ~io~ ~@ t~@aS~tr @@~~~4~~@ lb~~@~@ib@ o ~~@sM/byu /  ~@o~@@f -@K~n  . ~do"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x1

    const/4 v0, 0x0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    const/4 v2, 0x1

    const/4 v9, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-eqz p1, :cond_2c

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    new-instance v3, Ljava/util/ArrayList;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getUrlCdnidList()Ljava/util/ArrayList;

    move-result-object v4

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eqz v4, :cond_1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getUrlCdnidList()Ljava/util/ArrayList;

    move-result-object v4

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v4

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-eqz v4, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x0

    goto :goto_0

    :cond_0
    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getUrlCdnidList()Ljava/util/ArrayList;

    move-result-object v3

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getUrlCdnidHttpHeaderList()Ljava/util/ArrayList;

    move-result-object p0

    const/4 v10, 0x0

    const/4 v9, 0x6

    goto :goto_3

    :cond_1
    :goto_0
    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    if-nez v4, :cond_2

    const/4 v9, 0x7

    and-int/2addr v10, v9

    goto :goto_1

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget-object p0, p1, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->url:Ljava/lang/String;

    :goto_1
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v3, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getBakUrl()[Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-eqz p0, :cond_4

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    array-length v4, p0

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    if-lez v4, :cond_4

    const/4 v9, 0x2

    shl-int/2addr v10, v9

    move v4, v1

    move v4, v1

    const/4 v10, 0x5

    move v4, v1

    move v4, v1

    :goto_2
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    array-length v5, p0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x3

    if-ge v4, v5, :cond_4

    aget-object v5, p0, v4

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-nez v5, :cond_3

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    aget-object v5, p0, v4

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    add-int/lit8 v4, v4, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    goto :goto_2

    :cond_4
    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    if-eqz p2, :cond_5

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :goto_3
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    new-instance p2, Ljava/util/HashMap;

    const/4 v10, 0x4

    invoke-direct {p2}, Ljava/util/HashMap;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getFlowId()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    const-string/jumbo v4, "rlimUoyTPPxs"

    const-string/jumbo v4, "iosPslPxUTry"

    const/4 v10, 0x2

    const-string v4, "TPProxyUtils"

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-nez v0, :cond_6

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getFlowId()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-static {v4, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x7

    const-string/jumbo v0, "mdadoprpwimlayalf___"

    const-string v0, "_drmy_lapplwadmafil_"

    const/4 v10, 0x7

    const-string/jumbo v0, "llyifb_dwoplmaa_rad_"

    const-string v0, "dl_param_play_flowid"

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getFlowId()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-interface {p2, v0, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_6
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getUrlExpireTime()I

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-lez v0, :cond_7

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getUrlExpireTime()I

    move-result v0

    const/4 v9, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-string v5, "a_eeamutir_pedrlorp_lmui"

    const-string/jumbo v5, "mrpto_le_ae__meulpdrriia"

    const/4 v10, 0x7

    const-string/jumbo v5, "uxrraalpmri_epdml_e_pte_"

    const-string v5, "dl_param_url_expire_time"

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-interface {p2, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_7
    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getFileSize()J

    move-result-wide v5

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x7

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    cmp-long v0, v5, v7

    const/4 v10, 0x5

    const/4 v9, 0x5

    if-lez v0, :cond_8

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getFileSize()J

    move-result-wide v5

    const/4 v10, 0x1

    const/4 v9, 0x7

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    const-string/jumbo v5, "llzm_raeqsadifb_e_"

    const-string/jumbo v5, "li_e_beszia_mdlarf"

    const/4 v10, 0x6

    const-string v5, "dl_param_file_size"

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-interface {p2, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_8
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getFileDuration()J

    move-result-wide v5

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x3

    cmp-long v0, v5, v7

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-lez v0, :cond_9

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getFileDuration()J

    move-result-wide v5

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    const-string v5, "disealmnaauotfd__iurrl"

    const-string v5, "aiaerdurtm_ui_andfplol"

    const/4 v10, 0x3

    const-string v5, "ddomnrmipaeir_lfu__alt"

    const-string v5, "dl_param_file_duration"

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-interface {p2, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_9
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getDownloadFileID()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x6

    if-nez v0, :cond_a

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    const-string v0, "a_apo_akddlppeyli_r"

    const-string v0, "ddalarlppai___myepk"

    const/4 v10, 0x6

    const-string v0, "dl_param_play_keyid"

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getDownloadFileID()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-interface {p2, v0, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_a
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getVid()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    if-nez v0, :cond_b

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-string/jumbo v0, "m_aldbq_divp"

    const-string/jumbo v0, "vip_addaq_ml"

    const/4 v10, 0x2

    const-string v0, "ddp_avuam_rl"

    const-string v0, "dl_param_vid"

    const/4 v10, 0x3

    const/4 v9, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getVid()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-interface {p2, v0, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_b
    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getPlayDefinition()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    if-nez v0, :cond_c

    const/4 v10, 0x5

    const/4 v9, 0x1

    const-string/jumbo v0, "mnsddilpayrf__oat_eipnal"

    const/4 v10, 0x7

    const-string/jumbo v0, "iylpi_opndaifl_dnrtaeamp"

    const-string v0, "dl_param_play_definition"

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getPlayDefinition()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-interface {p2, v0, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_c
    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getCurrentFormat()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-nez v0, :cond_d

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-string v0, "__amoctu_rrtpeflnarammr"

    const/4 v10, 0x7

    const-string v0, "dl_param_current_format"

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getCurrentFormat()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-interface {p2, v0, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_d
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getCurrentFormatID()I

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-lez v0, :cond_e

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getCurrentFormatID()I

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    const-string v5, "aoretdf_qrmr_oalpudta_nmc"

    const-string v5, "ae__oam_nrruldfiatmpcdrto"

    const/4 v10, 0x6

    const-string v5, "casaurtnr_ol_ad_depfirtmr"

    const-string v5, "dl_param_current_formatid"

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-interface {p2, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_e
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getFormatInfo()Ljava/util/Map;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-static {v0}, Lcom/tencent/thumbplayer/utils/b;->a(Ljava/util/Map;)Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-nez v0, :cond_f

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    const-string/jumbo v0, "omam_nopdmftla_r_arb"

    const-string/jumbo v0, "r_maobftdnfaal_rpom_"

    const/4 v10, 0x3

    const-string v0, "dl_param_format_info"

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getFormatInfo()Ljava/util/Map;

    move-result-object v5

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-interface {p2, v0, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_f
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getBandwidthLevel()I

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x5

    if-lez v0, :cond_10

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getBandwidthLevel()I

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-string/jumbo v5, "ih_aowddleveln___pbtruada"

    const-string v5, "a_dnbrudiave_dmatl_p_hewl"

    const/4 v10, 0x5

    const-string/jumbo v5, "l_eapbn_bedtdlri_wmvladha"

    const-string v5, "dl_param_band_width_level"

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-interface {p2, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_10
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->isCharge()Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-string v5, "_saghdurcmlrrpsuo__aae_ep"

    const-string v5, "d_ssm__porcerah_lgrapecau"

    const/4 v10, 0x5

    const-string v5, "ecpc_rsprmg__adu_ealohrsi"

    const-string v5, "dl_param_source_is_charge"

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-interface {p2, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x3

    move v10, v9

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->isNeedEncryptCache()Z

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    const-string v5, "ac_dpaaeqeerptlyecr_cnnm__q"

    const-string v5, "_pea__alqeyprdchencec_rmtan"

    const/4 v10, 0x7

    const-string/jumbo v5, "restanlcde_caphneparc_yde__"

    const-string v5, "dl_param_cache_need_encrypt"

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-interface {p2, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->isOffline()Z

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    const-string/jumbo v5, "m_smea_solndilfraf_"

    const-string/jumbo v5, "neslsdil_f__fmaiora"

    const-string/jumbo v5, "mldro_pa_nolafe_isi"

    const-string v5, "dl_param_is_offline"

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-interface {p2, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->isExtraParam()Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    const-string/jumbo v5, "lalmobnlduwpean_eornmadxbe_pla___dr"

    const-string/jumbo v5, "n__mbxe_awnlauedr_olprld_lnoapadaem"

    const-string v5, "edllr_uaampln_duaxe_rdaben_d_oponaw"

    const-string v5, "dl_param_enable_expand_donwload_url"

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-interface {p2, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    if-eqz p0, :cond_11

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-nez v0, :cond_11

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    const-string v0, "derulorp_dhlp_eraa_"

    const-string/jumbo v0, "p_dhoer__radlerauml"

    const/4 v10, 0x5

    const-string/jumbo v0, "muldlahaqap_d_r_rer"

    const-string v0, "dl_param_url_header"

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-interface {p2, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_11
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getPreloadSize()J

    move-result-wide v5

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    cmp-long p0, v5, v7

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    if-lez p0, :cond_12

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getPreloadSize()J

    move-result-wide v5

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    const-string/jumbo v0, "salzob_p_ml_eripadrea"

    const/4 v10, 0x7

    const-string v0, "alsmrldeaa_zs_idor_pe"

    const-string v0, "dl_param_preload_size"

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-interface {p2, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_12
    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getPreloadDuration()J

    move-result-wide v5

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    cmp-long p0, v5, v7

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    if-lez p0, :cond_13

    const/4 v9, 0x5

    xor-int/2addr v10, v9

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getPreloadDuration()J

    move-result-wide v5

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-string v0, "adpmio__n_atpmullaouaderr"

    const-string/jumbo v0, "inp_e_urtldoaaauraolpm_dr"

    const-string v0, "_iadomlnord_partrpueado_l"

    const-string v0, "dl_param_preload_duration"

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-interface {p2, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_13
    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getSavePath()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-nez p0, :cond_14

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-string p0, "__msab_aarpaehvpld"

    const-string p0, "_hlprdapm_evsp_aaa"

    const/4 v10, 0x6

    const-string p0, "av_dteupra_lphmsa_"

    const-string p0, "dl_param_save_path"

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getSavePath()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-interface {p2, p0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_14
    const/4 v9, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getStarTimeMS()I

    move-result p0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-lez p0, :cond_15

    const/4 v9, 0x1

    shr-int/2addr v10, v9

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getStarTimeMS()I

    move-result p0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x2

    const-string v0, "elitmappl__myd_sa_rraaqp"

    const-string v0, "_tymtadmqilepsa_lrapr__a"

    const/4 v10, 0x3

    const-string/jumbo v0, "ta_taelaqmtr_yripmsla__d"

    const-string v0, "dl_param_play_start_time"

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-interface {p2, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_15
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getEndTimeMS()I

    move-result p0

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    if-lez p0, :cond_16

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getEndTimeMS()I

    move-result p0

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    const-string v0, "_tsleynerdlmi_a_dpaspa"

    const-string v0, "des_nl_applaimmeatryd_"

    const/4 v10, 0x4

    const-string v0, "dl_param_play_end_time"

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-interface {p2, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_16
    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getClipCount()I

    move-result p0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-lez p0, :cond_17

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getClipCount()I

    move-result p0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    const-string/jumbo v0, "lrpmc_lmpyoa__paaidcul_n"

    const-string v0, "dl_param_play_clip_count"

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-interface {p2, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_17
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getClipNo()I

    move-result p0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-lez p0, :cond_18

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getClipNo()I

    move-result p0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    const-string/jumbo v0, "pa_noppr_i_dyamlaol_l"

    const-string v0, "dl_param_play_clip_no"

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-interface {p2, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_18
    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getBase()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    if-nez p0, :cond_19

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    const-string p0, "_fonabdevmsmrbl_iap"

    const-string p0, "asammea_dlboprnfv_i"

    const/4 v10, 0x7

    const-string/jumbo p0, "lna_psuafr_m_dvaoib"

    const-string p0, "dl_param_vinfo_base"

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getBase()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-interface {p2, p0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_19
    const/4 v10, 0x2

    const/4 v9, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getLinkVid()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-nez p0, :cond_1a

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x3

    const-string/jumbo p0, "ikfdivopvrni_l_o_l_apdn"

    const-string/jumbo p0, "ivflokv_alnp_m_riido_nd"

    const/4 v10, 0x3

    const-string/jumbo p0, "m_ak_nr_qlianil_vfddvpi"

    const-string p0, "dl_param_vinfo_link_vid"

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getLinkVid()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-interface {p2, p0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1a
    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getFileMD5()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x7

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-nez p0, :cond_1b

    const/4 v10, 0x0

    const/4 v9, 0x3

    const-string/jumbo p0, "fdsll5_ammrpbde__"

    const-string p0, "d5rdab_l_lfm_pmae"

    const/4 v10, 0x2

    const-string/jumbo p0, "l_rmempmal__5dafd"

    const-string p0, "dl_param_file_md5"

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getFileMD5()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x6

    invoke-interface {p2, p0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1b
    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getM3u8()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x7

    const/4 v9, 0x0

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-nez p0, :cond_1c

    const/4 v10, 0x2

    const/4 v9, 0x6

    const-string p0, "_3m8oou_mp_fnadvuai"

    const-string p0, "8apaonuvr_if3dm__mu"

    const/4 v10, 0x2

    const-string p0, "38d_oba_rnlfmipumv_"

    const-string p0, "dl_param_vinfo_m3u8"

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getM3u8()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x5

    invoke-interface {p2, p0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1c
    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getTm()J

    move-result-wide v5

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    cmp-long p0, v5, v7

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-lez p0, :cond_1d

    const/4 v9, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getTm()J

    move-result-wide v5

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    const-string v0, "_dorilumfptnaam__"

    const-string v0, "_at_d_npflpamomri"

    const/4 v10, 0x7

    const-string/jumbo v0, "mnovf_ppdrlait__a"

    const-string v0, "dl_param_vinfo_tm"

    const/4 v10, 0x6

    const/4 v9, 0x0

    invoke-interface {p2, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1d
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getNonce()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-nez p0, :cond_1e

    const/4 v10, 0x6

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    const-string v0, "cqqoe:"

    const-string v0, "eoqcn:"

    const/4 v10, 0x1

    const-string/jumbo v0, "nesco:"

    const-string/jumbo v0, "nonce:"

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getNonce()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-static {v4, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-string p0, "anamend_m_clpr"

    const-string p0, "dl_param_nonce"

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getNonce()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-interface {p2, p0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1e
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getDecKey()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-nez p0, :cond_1f

    const/4 v10, 0x5

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    const-string v0, "encrypt stream key:"

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getDecKey()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-static {v4, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    const-string/jumbo p0, "mye_okeraatr_emdatpcyrss_n_"

    const-string/jumbo p0, "rtssyrak_temme_y_aneapprd_c"

    const-string/jumbo p0, "raeambdmta_r_prc_t_lyeepksn"

    const-string p0, "dl_param_encrypt_stream_key"

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getDecKey()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x7

    move v10, v9

    invoke-interface {p2, p0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1f
    const/4 v10, 0x1

    const/4 v9, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getRandoms()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-nez p0, :cond_20

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x3

    const-string/jumbo v0, "rmcnpauyont e:dr"

    const-string v0, "amnmdyrcn otp:re"

    const/4 v10, 0x0

    const-string v0, " rnesymptarponc:"

    const-string v0, "encrypt randoms:"

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getRandoms()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-static {v4, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x0

    const-string/jumbo p0, "r_nt_rs_qnacolaadmdsyp_rrotmeae"

    const-string p0, "ameaorstpcm_laye_r_dpts_randrno"

    const/4 v10, 0x5

    const-string/jumbo p0, "tespsrm_e__rnmnsrlcdap_adoraamt"

    const-string p0, "dl_param_encrypt_stream_randoms"

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getRandoms()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-interface {p2, p0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_20
    const/4 v9, 0x6

    move v10, v9

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getFp2p()I

    move-result p0

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    const-string/jumbo v0, "p__mfd_profinmbaapv"

    const-string v0, "afnfvba_dlimpp_r_po"

    const-string v0, "dm2noa__fprfoa_ippv"

    const-string v0, "dl_param_vinfo_fp2p"

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-interface {p2, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getTestid()I

    move-result p0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-lez p0, :cond_21

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getTestid()I

    move-result p0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    const-string/jumbo v0, "iaaslbmdutnitvrpo___d"

    const-string v0, "astft_uidn_oidvlrmap_"

    const/4 v10, 0x2

    const-string v0, "asavieuidnp_mtr_ft_do"

    const-string v0, "dl_param_vinfo_testid"

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-interface {p2, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_21
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getExceptDelay()I

    move-result p0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    if-lez p0, :cond_22

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getExceptDelay()I

    move-result p0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x5

    const-string/jumbo v0, "xycem_ap_dprtee_pdlaeiatlp"

    const-string/jumbo v0, "lxmr_iepde_dtmlpatceeyaap_"

    const/4 v10, 0x7

    const-string v0, "dl_param_expect_delay_time"

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-interface {p2, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_22
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getSecondaryM3u8List()Ljava/util/List;

    move-result-object p0

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x6

    if-eqz p0, :cond_23

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-string p0, "c_pmsquaqdoryeaaminlv_fndo8r_"

    const-string/jumbo p0, "s_a8vcdyq_urfiaaeod_olnnm_mrp"

    const/4 v10, 0x1

    const-string/jumbo p0, "mmsfrn_usac38lay_i_dnvd_apoor"

    const-string p0, "dl_param_vinfo_secondary_m3u8"

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getSecondaryM3u8List()Ljava/util/List;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-interface {p2, p0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_23
    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getExtInfoMap()Ljava/util/Map;

    move-result-object p0

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-static {p0}, Lcom/tencent/thumbplayer/utils/b;->a(Ljava/util/Map;)Z

    move-result p0

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    if-nez p0, :cond_24

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getExtInfoMap()Ljava/util/Map;

    move-result-object p0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-interface {p2, p0}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    :cond_24
    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getSelfAdaption()Z

    move-result p0

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    const-string/jumbo v0, "ldymaiatv_etd_aarp_pep"

    const-string v0, "dl_param_adaptive_type"

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-eqz p0, :cond_25

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 p0, 0x3

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    goto :goto_4

    :cond_25
    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    :goto_4
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-interface {p2, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x3

    const-string p0, "ao_lotaad_reodpmnmfss"

    const-string/jumbo p0, "oas_oml_sa_afdtenpdrm"

    const/4 v10, 0x7

    const-string p0, "_mdarbtmpsl_ofaad_ern"

    const-string p0, "dl_param_format_nodes"

    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getDefInfoList()Ljava/util/List;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-interface {p2, p0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getPcdnUrlList()Ljava/util/ArrayList;

    move-result-object p0

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    const-string v0, ";"

    const-string v0, ";"

    const/4 v10, 0x3

    const-string v0, ";"

    const-string v0, ";"

    const/4 v10, 0x7

    const/4 v9, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v10, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    if-eqz p0, :cond_28

    const/4 v10, 0x1

    const/4 v9, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getPcdnUrlList()Ljava/util/ArrayList;

    move-result-object p0

    const/4 v10, 0x5

    const/4 v9, 0x0

    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p0

    const/4 v10, 0x4

    const/4 v9, 0x3

    if-nez p0, :cond_28

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-direct {p0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x4

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getPcdnUrlList()Ljava/util/ArrayList;

    move-result-object v5

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_5
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    if-eqz v6, :cond_26

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    check-cast v6, Ljava/lang/String;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {p0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    goto :goto_5

    :cond_26
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->length()I

    move-result v5

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x0

    if-lez v5, :cond_27

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->length()I

    move-result v5

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    sub-int/2addr v5, v2

    const/4 v9, 0x3

    move v10, v9

    invoke-virtual {p0, v5}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    :cond_27
    const/4 v9, 0x6

    move v10, v9

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    const-string/jumbo v6, "s ul:puc  mlrnd"

    const-string v6, "c:rmpliul ns  d"

    const/4 v10, 0x7

    const-string v6, " n:cd rplt pisl"

    const-string/jumbo v6, "pcdn url list: "

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x0

    const/4 v9, 0x1

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x0

    const/4 v9, 0x3

    invoke-static {v4, v5}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    const-string v4, "__rppd_sqradanmluo"

    const-string/jumbo v4, "m_slopp_aadr_unrld"

    const/4 v10, 0x6

    const-string v4, "dl_param_pcdn_urls"

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-interface {p2, v4, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_28
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getPcdnVtList()Ljava/util/ArrayList;

    move-result-object p0

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    if-eqz p0, :cond_2b

    const/4 v10, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getPcdnVtList()Ljava/util/ArrayList;

    move-result-object p0

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p0

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-nez p0, :cond_2b

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-direct {p0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getPcdnVtList()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_6
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    if-eqz v4, :cond_29

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    check-cast v4, Ljava/lang/Integer;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const/4 v10, 0x5

    const/4 v9, 0x0

    invoke-virtual {p0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    goto :goto_6

    :cond_29
    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    if-lez v0, :cond_2a

    const/4 v10, 0x4

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    sub-int/2addr v0, v2

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    :cond_2a
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    const-string/jumbo v0, "tdsansp__avmdlrpc"

    const-string v0, "dl_param_pcdn_vts"

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-interface {p2, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2b
    const/4 v10, 0x1

    const/4 v9, 0x3

    new-instance p0, Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadParam;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/api/proxy/TPDownloadParamData;->getDlType()I

    move-result p1

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-static {p1}, Lcom/tencent/thumbplayer/c/h;->a(I)I

    move-result p1

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-direct {p0, v3, p1, p2}, Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadParam;-><init>(Ljava/util/ArrayList;ILjava/util/Map;)V

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    goto :goto_7

    :cond_2c
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x1

    new-instance p1, Ljava/util/ArrayList;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-direct {p1, v2}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    new-instance p0, Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadParam;

    const/4 v10, 0x5

    const/4 v9, 0x1

    invoke-direct {p0, p1, v1, v0}, Lcom/tencent/thumbplayer/core/downloadproxy/api/TPDownloadParam;-><init>(Ljava/util/ArrayList;ILjava/util/Map;)V

    :goto_7
    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    return-object p0
.end method
