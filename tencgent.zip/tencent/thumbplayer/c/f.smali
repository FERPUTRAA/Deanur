.class public Lcom/tencent/thumbplayer/c/f;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/api/proxy/ITPPreloadProxy$IPreloadListener;
.implements Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;


# instance fields
.field private a:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/f;->a:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public getAdvRemainTime()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o s~ @@fo~ u~~@oKm ib 4b@/ ~Sys Mi ~~~-~~~@~o@ @~ @r@.@ f~@o@@/~ v ~  ~@~@b@~ @1~~~@dlnio @@lcat"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/f;->a:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string v1, ",evm enltpRieigyT yi s rloys nn fipo,eettdrma  eptyamAxe"

    const-string/jumbo v1, "ntso tlieeiirayytmgvr lmase ndpRnxpye  TpfA,ye e,otmi e "

    const/4 v3, 0x3

    const-string/jumbo v1, "yi eoerpt iyfnxoyp  a,iolsaAgtr mepn ieye r,t vTlemnRdtm"

    const-string v1, " empty proxy player listener , notify , getAdvRemainTime"

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-wide v0
.end method

.method public getContentType(ILjava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x0

    return-object p1
.end method

.method public getCurrentPlayClipNo()I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/f;->a:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v1, "ft,trblileNetipol  rlnaPyrpyCnyygeCa ny,   rrsoeeepmp tu mix"

    const-string v1, " yCme ra oiyi pe,oyge tnap,C fyytxlpsenPuoNle ntmeirp rrlrlt"

    const/4 v3, 0x1

    const-string/jumbo v1, "yeleNtuyp,Crni rylpuo r ytar gte CximttPpf oea rnl nps,eoyei"

    const-string v1, " empty proxy player listener , notify , getCurrentPlayClipNo"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    return v0
.end method

.method public getCurrentPlayOffset()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/f;->a:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v1, "efelytepxttifOytnyr  r oCptrgposeeeoaa ,sy r Puytl, ne nlirf"

    const-string v1, "Olfao  rysx n, lpe Ptfrpgtlitpoote,tfy tsenrCyyue eyerne iar"

    const/4 v3, 0x1

    const-string/jumbo v1, "oeenrxnlqf  rspyy sruyCt ,Pfe ay eiy,lifrtgrptetmopnO ete lt"

    const-string v1, " empty proxy player listener , notify , getCurrentPlayOffset"

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    return-wide v0
.end method

.method public getCurrentPosition()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/f;->a:Ljava/lang/String;

    const/4 v2, 0x2

    move v3, v2

    const-string v1, " esa  sn toyse rxeninppemeleufon,tgrotiyrtt  ir yPboirCyl,"

    const-string/jumbo v1, "p oesbr rltC ou,g x ,t tpsrie fiiiynelooayrymnPee nrtnyept"

    const/4 v3, 0x3

    const-string/jumbo v1, "rCtmygnoxoetitpm poe nryirse spl,yetoyufteeinPn r,it r a l"

    const-string v1, " empty proxy player listener , notify , getCurrentPosition"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-wide v0
.end method

.method public getDataFilePath(ILjava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v0, 0x6

    shl-int/2addr v1, v0

    return-object p1
.end method

.method public getDataTotalSize(ILjava/lang/String;)J
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    const/4 v1, 0x1

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-wide p1
.end method

.method public getPlayInfo(J)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/f;->a:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string v1, " fe oteht,nxro ewnytinf l y: top Ipoyly tPyaae  , euip lsmgrerty"

    const-string/jumbo v1, "pewt  uyfy, ty o nIirl Pypaot rientp,hlil  stn xamg try:eef yeeo"

    const/4 v3, 0x3

    const-string/jumbo v1, "ynehyb sngxaappy n:rlee Pwi ir, tIo t p, poyoee  tf etyfltymlrit"

    const-string v1, " empty proxy player listener , notify , getPlayInfo with type : "

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x0

    return-object p1
.end method

.method public getPlayInfo(Ljava/lang/String;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/f;->a:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo v1, "teo rfu on pthwi pstxeng r,o eatyypelyfmayrn k  lePli:,yi  eI p"

    const-string v1, " fe rtIpa rmk nxif ly lert oee ,ptse tnnlo  aipPi:gwot yhyeyyp,"

    const/4 v3, 0x3

    const-string/jumbo v1, "krPlatep,i ypytt f   ealoyneifwromnlo eg , yt iy:ns expypt I hr"

    const-string v1, " empty proxy player listener , notify , getPlayInfo with key : "

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 p1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p1
.end method

.method public getPlayerBufferLength()J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/f;->a:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo v1, "ntn ry eqtl Lty  sugfxoeryerqPieanrpfiy ,lar,eB geftpe oylmet"

    const-string v1, ",ayeferoqlr ro ep x lt  segeeyityntuBrfrletnynpgmLyP, a ftpie"

    const/4 v3, 0x0

    const-string/jumbo v1, "ieseuortearoyfer nt, g pey  aePteBrmnflsyiy prytegl pxtLfhnl,"

    const-string v1, " empty proxy player listener , notify , getPlayerBufferLength"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-wide v0
.end method

.method public onDownloadCdnUrlExpired(Ljava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x5

    return-void
.end method

.method public onDownloadCdnUrlInfoUpdate(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public onDownloadCdnUrlUpdate(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public onDownloadError(IILjava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public onDownloadFinish()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public onDownloadProgressUpdate(IIJJLjava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/f;->a:Ljava/lang/String;

    const/4 v0, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    const-string/jumbo p7, "orem inni ,yytslt:,myPprsout,espen ygr rsrlny   eopfcoral Paxet  r"

    const-string p7, " osy:a,le ntl mpeet ir on rx ptrraPepsson ey,frsn ougrPrlytyyec,i "

    const-string/jumbo p7, "yenaoosro P,emlpu nl   r syert:nel  igrpf,ynPtroxo  e trcsair,pyte"

    const-string p7, " empty proxy player listener , notify , onPlayProgress, current : "

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p2, p7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p2, p3, p4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    const-string p3, ": matbt , "

    const-string p3, " :,mao  tt"

    const/4 v1, 0x4

    const-string p3, " to,alu  :"

    const-string p3, ", total : "

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p2, p5, p6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    return-void
.end method

.method public onDownloadProtocolUpdate(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public onDownloadStatusUpdate(I)V
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method

.method public onPlayCallback(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/f;->a:Ljava/lang/String;

    const/4 v3, 0x2

    or-int/2addr v4, v3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string/jumbo v2, "lyrsenpp f l,elaepe  ap To rtitmoesroayoxiayn:,k,sneb ecCg  yP tly ply"

    const-string/jumbo v2, "otaio ysmyy i f:lsaaxpo,t,l ryre lb ne ,sP yctgreep e lpleoenayn TmCkp"

    const/4 v4, 0x0

    const-string/jumbo v2, "p, eseysqn:nnaob,geyPolkfyrmyrei ,psprCylla xtte i yca  tae o plme Tal"

    const-string v2, " empty proxy player listener , notify , onPlayCallback, messageType : "

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string p1, ",bst:x"

    const-string p1, ",x:1tb"

    const/4 v4, 0x6

    const-string p1, ",ext1:"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const-string/jumbo p1, "u2,mxe"

    const-string/jumbo p1, "ue:,2x"

    const/4 v4, 0x5

    const-string p1, "e2,xot"

    const-string p1, ",ext2:"

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, "bp,ex"

    const-string p1, "e,ptx"

    const-string/jumbo p1, "tu,3x"

    const-string p1, ",ext3"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    invoke-virtual {v1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    move v4, v3

    const-string/jumbo p1, "x,p4e"

    const-string p1, ",ext4"

    const/4 v3, 0x6

    and-int/2addr v4, v3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 p1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-object p1
.end method

.method public onPrepareDownloadProgressUpdate(IIJJ)V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public onPrepareError()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/f;->a:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v1, "rrqys ooqnneormprla  e  :,tyraip  rE orPter,ilxppt fny ey"

    const-string/jumbo v1, "olr tpmeq,:paoope,srEfrp nenryera  iten lyro t xriyy  r P"

    const/4 v3, 0x3

    const-string v1, " ystneoertxeelt ympP,iyio er: y  forEp prrpnarso a ,rlen "

    const-string v1, " empty proxy player listener , notify , onPrepareError : "

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method

.method public onPrepareSuccess()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/f;->a:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v1, "c,emit , sonp rpe ny sxfrrmPaocstsrnalyuopiry :tp Seyeee e "

    const-string/jumbo v1, "irs e it  y  ato:ereSyly,arcss,ypmofnx ept nuPpceornlre pse"

    const/4 v3, 0x4

    const-string/jumbo v1, "rcs otolsnyeyppeneo em ,exoptrt,r  r  pSy y aiearlnePu fsci"

    const-string v1, " empty proxy player listener , notify , onPrepareSuccess : "

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method public onReadData(ILjava/lang/String;JJ)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return p1
.end method

.method public onStartReadData(ILjava/lang/String;JJ)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x7

    return p1
.end method

.method public onStopReadData(ILjava/lang/String;I)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    return p1
.end method
