.class Lcom/tencent/thumbplayer/c/a/b$a;
.super Landroid/os/Handler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/c/a/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "a"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/c/a/b;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/c/a/b;Landroid/os/Looper;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/a/b$a;->a:Lcom/tencent/thumbplayer/c/a/b;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method private a(JJLjava/lang/String;II)V
    .locals 8

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/c/a/b$a;->a(JJ)Z

    move-result v6

    new-instance v7, Lcom/tencent/thumbplayer/c/a/d;

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-wide v1, p1

    move-wide v3, p3

    move v5, p7

    move v5, p7

    move v5, p7

    move v5, p7

    invoke-direct/range {v0 .. v6}, Lcom/tencent/thumbplayer/c/a/d;-><init>(JJIZ)V

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/b$a;->a:Lcom/tencent/thumbplayer/c/a/b;

    invoke-static {p1}, Lcom/tencent/thumbplayer/c/a/b;->b(Lcom/tencent/thumbplayer/c/a/b;)Landroid/os/HandlerThread;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object p1

    invoke-virtual {v7, p1}, Lcom/tencent/thumbplayer/c/a/d;->a(Landroid/os/Looper;)V

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/b$a;->a:Lcom/tencent/thumbplayer/c/a/b;

    invoke-virtual {p1, p6, p5}, Lcom/tencent/thumbplayer/c/a/b;->b(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v7, p1}, Lcom/tencent/thumbplayer/c/a/d;->a(Ljava/lang/String;)V

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/b$a;->a:Lcom/tencent/thumbplayer/c/a/b;

    invoke-static {p1}, Lcom/tencent/thumbplayer/c/a/b;->c(Lcom/tencent/thumbplayer/c/a/b;)Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;

    move-result-object p1

    invoke-virtual {v7, p1}, Lcom/tencent/thumbplayer/c/a/d;->a(Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;)V

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/b$a;->a:Lcom/tencent/thumbplayer/c/a/b;

    invoke-static {p1}, Lcom/tencent/thumbplayer/c/a/b;->a(Lcom/tencent/thumbplayer/c/a/b;)Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;

    move-result-object p1

    invoke-interface {p1, v7}, Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;->shouldWaitForLoadingOfRequestedResource(Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoadingRequest;)Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/b$a;->a:Lcom/tencent/thumbplayer/c/a/b;

    invoke-static {p1, v7}, Lcom/tencent/thumbplayer/c/a/b;->a(Lcom/tencent/thumbplayer/c/a/b;Lcom/tencent/thumbplayer/c/a/d;)V

    invoke-static {}, Lcom/tencent/thumbplayer/c/a/b;->d()Ljava/lang/String;

    move-result-object p1

    const-string p2, "adsdg eqIne um,sitsooude: etrs daLRs"

    const-string/jumbo p2, "ots de meuLsedetRa Idgoutdinrs, q:sa"

    const-string/jumbo p2, "is:m eedge us,RtaotIuaqd rLo dsndetm"

    const-string p2, "add to mLoadingRequests, requestId: "

    invoke-static {p7}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method private a(JJ)Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "s /~o~@ ~a~y4l~~~obo~ ~tr/ l @@@ui@    o-o@K~ot@i~@~1 ofn~@@@Sb~ ~m@d@@~@~@@c~Mv.  ~  i @~ @bf~@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b$a;->a:Lcom/tencent/thumbplayer/c/a/b;

    const/4 v4, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/a/b;->d(Lcom/tencent/thumbplayer/c/a/b;)J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x6

    cmp-long v0, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-lez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    add-long/2addr p3, p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/b$a;->a:Lcom/tencent/thumbplayer/c/a/b;

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/c/a/b;->d(Lcom/tencent/thumbplayer/c/a/b;)J

    move-result-wide p1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    cmp-long p1, p3, p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-ltz p1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 p1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz p1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object p2, p0, Lcom/tencent/thumbplayer/c/a/b$a;->a:Lcom/tencent/thumbplayer/c/a/b;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {p2}, Lcom/tencent/thumbplayer/c/a/b;->e(Lcom/tencent/thumbplayer/c/a/b;)V

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    return p1
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 11

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/c/a/b;->d()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    const-string v2, " clmooCcserF ed noelaamasdrugaLbemlrRkr:"

    const/4 v10, 0x6

    const-string v2, "d RFebs:noermmucgaare laCdLe lcHaokborrs"

    const-string/jumbo v2, "mCallbackForResourceLoaderHandler msg : "

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x0

    iget v2, p1, Landroid/os/Message;->what:I

    const/4 v10, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b$a;->a:Lcom/tencent/thumbplayer/c/a/b;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/a/b;->a(Lcom/tencent/thumbplayer/c/a/b;)Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    if-nez v0, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    return-void

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/16 v1, 0x100

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-eq v0, v1, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    const/16 v1, 0x101

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-eq v0, v1, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    goto :goto_0

    :cond_1
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/c/a/b;->d()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-string/jumbo v1, "r s ttuooeaapd"

    const-string v1, " staodportea a"

    const/4 v10, 0x4

    const-string/jumbo v1, "tdedt opaasrp "

    const-string/jumbo v1, "stop read data"

    const/4 v9, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b$a;->a:Lcom/tencent/thumbplayer/c/a/b;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget p1, p1, Landroid/os/Message;->arg1:I

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/c/a/b;->a(Lcom/tencent/thumbplayer/c/a/b;I)V

    :goto_0
    const/4 v9, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    return-void

    :cond_2
    const/4 v10, 0x4

    const/4 v9, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/c/a/b;->d()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    const-string v1, "dtead tbqr rsaa"

    const-string/jumbo v1, "t tsabdrt edara"

    const/4 v10, 0x6

    const-string v1, "dds artataaetrs"

    const-string/jumbo v1, "start read data"

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    check-cast v0, Lcom/tencent/thumbplayer/c/a/b$b;

    const/4 v9, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    iget-wide v2, v0, Lcom/tencent/thumbplayer/c/a/b$b;->a:J

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-wide v4, v0, Lcom/tencent/thumbplayer/c/a/b$b;->b:J

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    iget-object v6, v0, Lcom/tencent/thumbplayer/c/a/b$b;->c:Ljava/lang/String;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    iget v7, p1, Landroid/os/Message;->arg1:I

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    iget v8, p1, Landroid/os/Message;->arg2:I

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/c/a/b;->d()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    const-string/jumbo v1, "rtrmaarsae:rt eut,Sattsd u qdt "

    const-string v1, "Saaa su uratrt,ea sdrtd :qtrett"

    const/4 v10, 0x0

    const-string v1, "aa eoSrsattsre, qt tttad:ardr e"

    const-string/jumbo v1, "start read data, requestStart: "

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const-string/jumbo v1, "n uEebtr:esd"

    const-string v1, " requestEnd:"

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v0, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const-string v1, " pdrIeuqseu"

    const-string v1, ":q sredpeIu"

    const/4 v10, 0x0

    const-string v1, "Iustrd:pe q"

    const-string v1, " requestId:"

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    move v10, v9

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/b$a;->a:Lcom/tencent/thumbplayer/c/a/b;

    const/4 v10, 0x4

    invoke-static {p1, v2, v3, v4, v5}, Lcom/tencent/thumbplayer/c/a/b;->a(Lcom/tencent/thumbplayer/c/a/b;JJ)J

    move-result-wide v4

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x6

    cmp-long p1, v4, v0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-gtz p1, :cond_3

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/c/a/b;->d()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-string/jumbo v0, "tcnhaigsqLldsqtatte re Srevquth Ene ue qksreieducna,qetn"

    const-string/jumbo v0, "rcsdlhqnqruq etitnheu Lucktdsgeetq arnEaesit, vda etSeen"

    const/4 v10, 0x6

    const-string v0, "cusvlstshitr qnk caLa eteqtenetsduqeSndeiegrr,thurn aE e"

    const-string/jumbo v0, "requestLength invalid, check requestStart and requestEnd"

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    return-void

    :cond_3
    move-object v1, p0

    move-object v1, p0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-direct/range {v1 .. v8}, Lcom/tencent/thumbplayer/c/a/b$a;->a(JJLjava/lang/String;II)V

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    return-void
.end method
