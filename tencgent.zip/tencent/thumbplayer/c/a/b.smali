.class public Lcom/tencent/thumbplayer/c/a/b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/c/a/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/c/a/b$b;,
        Lcom/tencent/thumbplayer/c/a/b$a;
    }
.end annotation


# static fields
.field private static a:Ljava/lang/String; = "TPAssetResourceLoader"


# instance fields
.field private b:Landroid/content/Context;

.field private c:Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;

.field private d:J

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/String;

.field private h:Ljava/lang/String;

.field private i:I

.field private j:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/tencent/thumbplayer/c/a/d;",
            ">;"
        }
    .end annotation
.end field

.field private k:Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;

.field private l:Landroid/os/HandlerThread;

.field private m:Landroid/os/HandlerThread;

.field private n:Lcom/tencent/thumbplayer/c/a/b$a;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/tencent/thumbplayer/c/a/b;->d:J

    const/4 v3, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->e:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->f:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->g:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string v0, "4.pm"

    const-string/jumbo v0, "p.m4"

    const/4 v3, 0x2

    const-string v0, ".pm4"

    const-string v0, ".mp4"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->h:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput v0, p0, Lcom/tencent/thumbplayer/c/a/b;->i:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/a/b;->b:Landroid/content/Context;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance p1, Ljava/util/ArrayList;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/a/b;->j:Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez p2, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/utils/o;->a()Lcom/tencent/thumbplayer/utils/o;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/utils/o;->b()Landroid/os/HandlerThread;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/a/b;->l:Landroid/os/HandlerThread;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object p2

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance p1, Lcom/tencent/thumbplayer/c/a/b$a;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p1, p0, p2}, Lcom/tencent/thumbplayer/c/a/b$a;-><init>(Lcom/tencent/thumbplayer/c/a/b;Landroid/os/Looper;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/a/b;->n:Lcom/tencent/thumbplayer/c/a/b$a;

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/utils/o;->a()Lcom/tencent/thumbplayer/utils/o;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo p2, "tostauTrRscedisdaoae-ePdrhesrtTsLraWe"

    const-string p2, "-RstWuatadroeTetePsrThdsLeeacseiardro"

    const-string p2, "LPdmetcrhaaddTsetrTAoaseaoeriRse-etur"

    const-string p2, "TPAssetResourceLoader-dataWriteThread"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/utils/o;->a(Ljava/lang/String;)Landroid/os/HandlerThread;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/a/b;->m:Landroid/os/HandlerThread;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method private declared-synchronized a(J)I
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@i ~o~m~@~@yb@@s @b~~@o@@ /c4@ ~l~ iaS no @ /~ ~oo-t~~~ ~@@ @o~@lt~if~ @  ~v@b@ ~1M~@u ~.r@d of~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->j:Ljava/util/ArrayList;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x0

    move v4, v1

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    monitor-exit p0

    const/4 v4, 0x0

    return v1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    move v0, v1

    move v0, v1

    const/4 v4, 0x6

    move v0, v1

    move v0, v1

    :goto_0
    :try_start_1
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/a/b;->j:Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-ge v1, v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/a/b;->j:Ljava/util/ArrayList;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    check-cast v2, Lcom/tencent/thumbplayer/c/a/d;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v2, p1, p2}, Lcom/tencent/thumbplayer/c/a/d;->a(J)I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x7

    monitor-exit p0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    return v0

    :catchall_0
    move-exception p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    monitor-exit p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    throw p1
.end method

.method private a(JJ)J
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    cmp-long v2, p3, v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-lez v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    sub-long/2addr p3, p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-wide p3

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-wide p3, p0, Lcom/tencent/thumbplayer/c/a/b;->d:J

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    cmp-long v0, p3, v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-gtz v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-wide/32 p1, 0x20000000

    const/4 v4, 0x2

    const-wide/32 p1, 0x20000000

    const-wide/32 p1, 0x20000000

    const/4 v3, 0x2

    shl-int/2addr v4, v3

    return-wide p1

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    sub-long/2addr p3, p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-wide p3
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/c/a/b;JJ)J
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/c/a/b;->a(JJ)J

    move-result-wide p0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-wide p0
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/c/a/b;)Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;
    .locals 2

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/tencent/thumbplayer/c/a/b;->c:Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method private declared-synchronized a(I)Lcom/tencent/thumbplayer/c/a/d;
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->j:Ljava/util/ArrayList;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-nez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    monitor-exit p0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-object v1

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v0, 0x0

    :goto_0
    :try_start_1
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/a/b;->j:Ljava/util/ArrayList;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-ge v0, v2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/a/b;->j:Ljava/util/ArrayList;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    check-cast v2, Lcom/tencent/thumbplayer/c/a/d;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v2}, Lcom/tencent/thumbplayer/c/a/d;->a()Lcom/tencent/thumbplayer/c/a/c;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v3}, Lcom/tencent/thumbplayer/c/a/c;->a()I

    move-result v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-ne v3, p1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    monitor-exit p0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    return-object v2

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_0

    :cond_2
    const/4 v4, 0x4

    const/4 v5, 0x7

    monitor-exit p0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-object v1

    :catchall_0
    move-exception p1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    monitor-exit p0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    throw p1
.end method

.method private a(Landroid/content/Context;I)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->g:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    const-string/jumbo v1, "ydMyMbdym-"

    const-string v1, "Myym-yMdyd"

    const/4 v3, 0x0

    const-string v1, "Myyd-Mudy-"

    const-string/jumbo v1, "yyyy-MM-dd"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v1, Ljava/util/Date;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string v0, "-"

    const-string v0, "-"

    const/4 v3, 0x0

    const-string v0, "-"

    const-string v0, "-"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object p2, p0, Lcom/tencent/thumbplayer/c/a/b;->h:Ljava/lang/String;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string/jumbo v0, "uLrdsoaporeeoe"

    const-string/jumbo v0, "orLuoesaredroe"

    const/4 v3, 0x7

    const-string/jumbo v0, "srecraerqooeuL"

    const-string/jumbo v0, "resourceLoader"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p1, v0, p2}, Lcom/tencent/thumbplayer/core/downloadproxy/utils/TPDLFileSystem;->getExternalCacheFile(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/core/downloadproxy/utils/TPDLIOUtil;->createFile(Ljava/io/File;)Z

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/a/b;->g:Ljava/lang/String;

    :cond_0
    const/4 v2, 0x6

    move v3, v2

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/b;->g:Ljava/lang/String;

    const/4 v3, 0x6

    return-object p1
.end method

.method private a(IIILjava/lang/Object;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->n:Lcom/tencent/thumbplayer/c/a/b$a;

    const/4 v1, 0x5

    move v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/os/Handler;->obtainMessage()Landroid/os/Message;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput p1, v0, Landroid/os/Message;->what:I

    const/4 v2, 0x1

    iput p2, v0, Landroid/os/Message;->arg1:I

    const/4 v2, 0x2

    iput p3, v0, Landroid/os/Message;->arg2:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object p4, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/b;->n:Lcom/tencent/thumbplayer/c/a/b$a;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/c/a/b;I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/c/a/b;->b(I)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/c/a/b;Lcom/tencent/thumbplayer/c/a/d;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/c/a/b;->a(Lcom/tencent/thumbplayer/c/a/d;)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method private declared-synchronized a(Lcom/tencent/thumbplayer/c/a/d;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->j:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    throw p1
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/c/a/b;)Landroid/os/HandlerThread;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/tencent/thumbplayer/c/a/b;->m:Landroid/os/HandlerThread;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p0
.end method

.method private b(I)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/c/a/b;->a(I)Lcom/tencent/thumbplayer/c/a/d;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x2

    sget-object v0, Lcom/tencent/thumbplayer/c/a/b;->a:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v2, "tfstAnbuh e Td sastri nL eoec/a/ePtsdr"

    const-string/jumbo v2, "r  s bTnaA / tsPertsfdueed/ntLeihectoa"

    const/4 v4, 0x3

    const-string/jumbo v2, "qTnmae   th/ot art eP/LsureniseAscdted"

    const-string v2, "TPAssetLoader can\'t find the request "

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    move v4, v3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const-string/jumbo p1, "rdluoneqiguetsw un rtcsortaeh "

    const-string/jumbo p1, "s htdqureeuncogsr eit rulwanti"

    const/4 v4, 0x7

    const-string p1, " with current loading requests"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/c/a/d;->b()V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/c/a/b;->a:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v2, " aaihbeh eRw i etea,ac thledpDiuranqoSdpgtlsdonedctalt "

    const-string v2, "R a d, pona eqeaiih  iucDterltgdeslalthh etwtSdcneoapda"

    const-string/jumbo v2, "ew slau,cdnndeeeiSRaotaaa idhocqeu ihellp nr dg att ttD"

    const-string/jumbo v2, "handleStopReadData, cancel the loading request with id "

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {v1, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/c/a/b;->b(Lcom/tencent/thumbplayer/c/a/d;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/b;->c:Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;->didCancelLoadingRequest(Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoadingRequest;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void
.end method

.method private declared-synchronized b(Lcom/tencent/thumbplayer/c/a/d;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->j:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    monitor-exit p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    throw p1
.end method

.method static synthetic c(Lcom/tencent/thumbplayer/c/a/b;)Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/tencent/thumbplayer/c/a/b;->k:Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic d(Lcom/tencent/thumbplayer/c/a/b;)J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-wide v0, p0, Lcom/tencent/thumbplayer/c/a/b;->d:J

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-wide v0
.end method

.method static synthetic d()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/c/a/b;->a:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x7

    return-object v0
.end method

.method private e()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->f:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method static synthetic e(Lcom/tencent/thumbplayer/c/a/b;)V
    .locals 2

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/thumbplayer/c/a/b;->f()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method private declared-synchronized f()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->j:Ljava/util/ArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    check-cast v1, Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoadingRequest;

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    check-cast v2, Lcom/tencent/thumbplayer/c/a/d;

    const/4 v4, 0x2

    invoke-virtual {v2}, Lcom/tencent/thumbplayer/c/a/d;->b()V

    const/4 v3, 0x7

    move v4, v3

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/a/b;->c:Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v2, v1}, Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;->didCancelLoadingRequest(Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoadingRequest;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->j:Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    monitor-exit p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void

    :catchall_0
    move-exception v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    monitor-exit p0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    throw v0
.end method


# virtual methods
.method public a(ILjava/lang/String;I)I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/b;->c:Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;

    const/4 v2, 0x2

    const/4 p2, 0x0

    const/4 v2, 0x0

    move v1, p2

    move v1, p2

    if-nez p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object p1, Lcom/tencent/thumbplayer/c/a/b;->a:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string/jumbo p3, "q roslepstn ette"

    const-string p3, "esstte lqornei t"

    const/4 v2, 0x1

    const-string/jumbo p3, "tnette iqr lnseo"

    const-string/jumbo p3, "listener not set"

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1, p3}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    return p2

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/16 p1, 0x101

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0, p1, p3, p2, v0}, Lcom/tencent/thumbplayer/c/a/b;->a(IIILjava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p2
.end method

.method public a(ILjava/lang/String;JJ)I
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->c:Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    sget-object p1, Lcom/tencent/thumbplayer/c/a/b;->a:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string/jumbo p2, "osstits teseer l"

    const-string p2, " iss toeltneters"

    const/4 v4, 0x1

    const-string/jumbo p2, "notmntlies erets"

    const-string/jumbo p2, "listener not set"

    const/4 v4, 0x4

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 p1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x2

    return p1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/c/a/b;->a:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string/jumbo v2, "niaeoDSma RletdoatIftr,a"

    const-string v2, "alImaaeRfSenotd:rt,tDia "

    const/4 v4, 0x3

    const-string/jumbo v2, "r:aatbtfSedliaIdteD, Rao"

    const-string/jumbo v2, "onStartReadData, fileId:"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v2, "Klef yue:,"

    const-string v2, ", fileKey:"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const-string/jumbo v2, "trttqS:puae sr,"

    const-string v2, ", requestStart:"

    const/4 v3, 0x0

    const/4 v3, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    invoke-virtual {v1, p3, p4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v2, "edu,:ntsqrqE "

    const-string v2, ", requestEnd:"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1, p5, p6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v3, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v0, p0, Lcom/tencent/thumbplayer/c/a/b;->i:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v1, Lcom/tencent/thumbplayer/c/a/b$b;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x2

    invoke-direct {v1, v2}, Lcom/tencent/thumbplayer/c/a/b$b;-><init>(Lcom/tencent/thumbplayer/c/a/b$1;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-wide p3, v1, Lcom/tencent/thumbplayer/c/a/b$b;->a:J

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-wide p5, v1, Lcom/tencent/thumbplayer/c/a/b$b;->b:J

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput-object p2, v1, Lcom/tencent/thumbplayer/c/a/b$b;->c:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/16 p2, 0x100

    const/4 v3, 0x5

    const/4 v3, 0x3

    invoke-direct {p0, p2, p1, v0, v1}, Lcom/tencent/thumbplayer/c/a/b;->a(IIILjava/lang/Object;)V

    const/4 v3, 0x0

    move v4, v3

    iput v0, p0, Lcom/tencent/thumbplayer/c/a/b;->i:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    return v0
.end method

.method public a(ILjava/lang/String;)J
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget-wide p1, p0, Lcom/tencent/thumbplayer/c/a/b;->d:J

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-wide p1
.end method

.method public a()V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->c:Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/c/a/b;->a:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v1, "listener not set"

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-void

    :cond_0
    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->k:Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/c/a/b;->c:Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {v1, v0}, Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;->fillInContentInformation(Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->k:Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;

    const/4 v5, 0x0

    iget-object v1, v0, Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;->contentType:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    iput-object v1, p0, Lcom/tencent/thumbplayer/c/a/b;->e:Ljava/lang/String;

    const/4 v4, 0x5

    shl-int/2addr v5, v4

    iget-wide v1, v0, Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;->dataTotalSize:J

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    iput-wide v1, p0, Lcom/tencent/thumbplayer/c/a/b;->d:J

    const/4 v5, 0x0

    iget-object v0, v0, Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;->dataFilePath:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->f:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/c/a/b;->a:Ljava/lang/String;

    const/4 v4, 0x7

    move v5, v4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string/jumbo v2, "t spt l:sttrrTzao aiam,aDSoxy"

    const-string/jumbo v2, "r,tTo syo:taxir pola SzaDamtt"

    const/4 v5, 0x1

    const-string v2, "Dp,mzxyaottTa rSl :oermatasti"

    const-string/jumbo v2, "proxy start, mDataTotalSize: "

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-wide v2, p0, Lcom/tencent/thumbplayer/c/a/b;->d:J

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string/jumbo v2, "utseob: issnbh"

    const-string v2, " uensbstiahb:s"

    const/4 v5, 0x5

    const-string/jumbo v2, "si :ebthnPbsus"

    const-string v2, " businessPath:"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/a/b;->f:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/a/b;->c:Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoaderListener;

    const/4 v1, 0x5

    const/4 v0, 0x4

    return-void
.end method

.method public b(ILjava/lang/String;JJ)I
    .locals 5

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    sget-object p2, Lcom/tencent/thumbplayer/c/a/b;->a:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string v1, "aet fsutf, adrouad"

    const-string v1, "aardetu,st ofafe d"

    const/4 v4, 0x0

    const-string/jumbo v1, "srtao, pdtaf:e fae"

    const-string/jumbo v1, "read data, offset:"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, p3, p4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const-string/jumbo v1, "g:n,te pq"

    const-string/jumbo v1, "hg,tn: pe"

    const/4 v4, 0x2

    const-string/jumbo v1, "l,s g:eth"

    const-string v1, ", length:"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, p5, p6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    move v4, v3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {p2, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {p0, p3, p4}, Lcom/tencent/thumbplayer/c/a/b;->a(J)I

    move-result p2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    int-to-long v0, p2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v0, v1, p5, p6}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    long-to-int p2, v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-gtz p2, :cond_0

    const/4 v4, 0x3

    const/4 p1, -0x7

    const/4 v4, 0x2

    const/4 p1, -0x1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    return p1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/c/a/b;->a:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const-string v2, " fqm ,itddadl: e nIeor"

    const-string v2, ",idr dalq: no dIeef ta"

    const/4 v4, 0x0

    const-string v2, "eatIor  lfa ae,idd:n o"

    const-string/jumbo v2, "on read data, fileId: "

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    const-string/jumbo p1, "ss aebfOd efr"

    const-string p1, "Ossr: fdfee a"

    const/4 v4, 0x4

    const-string p1, " readOffset: "

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1, p3, p4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    move v4, v3

    const-string/jumbo p1, "hdeLmruntega"

    const-string p1, " Ltmrgendhae"

    const/4 v4, 0x3

    const-string p1, ":ngLtehpder "

    const-string p1, " readLength:"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1, p5, p6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const-string/jumbo p1, "taedo:e qLrny"

    const-string/jumbo p1, "ete or:ndhayL"

    const/4 v4, 0x0

    const-string p1, "ensL:ydgtareh"

    const-string p1, " readyLength:"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    return p2
.end method

.method public b(ILjava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/tencent/thumbplayer/c/a/b;->e()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p2

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    iget-object p2, p0, Lcom/tencent/thumbplayer/c/a/b;->b:Landroid/content/Context;

    const/4 v2, 0x3

    invoke-direct {p0, p2, p1}, Lcom/tencent/thumbplayer/c/a/b;->a(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p1
.end method

.method public b()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/c/a/b;->a:Ljava/lang/String;

    const/4 v5, 0x0

    const-string/jumbo v1, "srtmtbstr a"

    const-string/jumbo v1, "rtsetbsr ta"

    const/4 v5, 0x7

    const-string v1, " srtosaerte"

    const-string/jumbo v1, "reset start"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/c/a/b;->f()V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput-wide v0, p0, Lcom/tencent/thumbplayer/c/a/b;->d:J

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x7

    const-string v0, ""

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->e:Ljava/lang/String;

    const/4 v5, 0x7

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->f:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/c/a/b;->g:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-nez v1, :cond_0

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v1, Ljava/io/File;

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/a/b;->g:Ljava/lang/String;

    const/4 v4, 0x2

    move v5, v4

    invoke-direct {v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/io/File;->deleteOnExit()V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->g:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/c/a/b;->a:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string v3, "ani xberus e sehted cce pl:tclfeei,etha"

    const-string v3, "e otheus plece iei,cclrs axnde:h tfatee"

    const/4 v5, 0x2

    const-string v3, "esdfohutta ee:,een hca t ecesieecplilx "

    const-string/jumbo v3, "reset, delete cache file has exception:"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/b;->n:Lcom/tencent/thumbplayer/c/a/b$a;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    :cond_1
    const/4 v5, 0x0

    return-void
.end method

.method public c(ILjava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/b;->e:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method public c()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    sget-object v0, Lcom/tencent/thumbplayer/c/a/b;->a:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo v1, "rssreetp elaa"

    const/4 v4, 0x6

    const-string v1, "els atsprarte"

    const-string/jumbo v1, "release start"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/c/a/b;->b()V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/utils/o;->a()Lcom/tencent/thumbplayer/utils/o;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/c/a/b;->l:Landroid/os/HandlerThread;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/a/b;->n:Lcom/tencent/thumbplayer/c/a/b$a;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/utils/o;->a(Landroid/os/HandlerThread;Landroid/os/Handler;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/utils/o;->a()Lcom/tencent/thumbplayer/utils/o;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/c/a/b;->m:Landroid/os/HandlerThread;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Lcom/tencent/thumbplayer/utils/o;->a(Landroid/os/HandlerThread;Landroid/os/Handler;)V

    const/4 v4, 0x6

    iput-object v2, p0, Lcom/tencent/thumbplayer/c/a/b;->l:Landroid/os/HandlerThread;

    const/4 v4, 0x2

    const/4 v3, 0x0

    iput-object v2, p0, Lcom/tencent/thumbplayer/c/a/b;->m:Landroid/os/HandlerThread;

    const/4 v4, 0x4

    const/4 v3, 0x2

    iput-object v2, p0, Lcom/tencent/thumbplayer/c/a/b;->n:Lcom/tencent/thumbplayer/c/a/b$a;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-object v2, p0, Lcom/tencent/thumbplayer/c/a/b;->j:Ljava/util/ArrayList;

    const/4 v3, 0x6

    move v4, v3

    return-void
.end method
