.class public Lcom/tencent/thumbplayer/c/a/c;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoadingDataRequest;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/c/a/c$a;,
        Lcom/tencent/thumbplayer/c/a/c$b;
    }
.end annotation


# static fields
.field private static a:Ljava/lang/String; = "TPAssetResourceLoadingDataRequest"


# instance fields
.field private b:J

.field private c:J

.field private d:Z

.field private e:J

.field private f:J

.field private g:J

.field private h:I

.field private i:Lcom/tencent/thumbplayer/c/a/c$b;

.field private j:Lcom/tencent/thumbplayer/utils/m;

.field private k:Ljava/lang/String;

.field private l:Ljava/io/RandomAccessFile;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>(JJZ)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-wide p1, p0, Lcom/tencent/thumbplayer/c/a/c;->b:J

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-wide p1, p0, Lcom/tencent/thumbplayer/c/a/c;->f:J

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-wide p1, p0, Lcom/tencent/thumbplayer/c/a/c;->e:J

    const/4 v1, 0x3

    const/4 v0, 0x1

    iput-wide p3, p0, Lcom/tencent/thumbplayer/c/a/c;->c:J

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-boolean p5, p0, Lcom/tencent/thumbplayer/c/a/c;->d:Z

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    new-instance p1, Lcom/tencent/thumbplayer/utils/m;

    const/4 v1, 0x2

    const/4 v0, 0x4

    invoke-direct {p1}, Lcom/tencent/thumbplayer/utils/m;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/a/c;->j:Lcom/tencent/thumbplayer/utils/m;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/c/a/c;J)J
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "mys@ @o~~ S  @//~ r ~ @tio~@bcafd.b~@ 1~o~o~  bf@lu~i@o@~~~~@~ s~ t~ ~@~ @@@oK@v-~@l~~ @@@nMi @ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iput-wide p1, p0, Lcom/tencent/thumbplayer/c/a/c;->e:J

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-wide p1
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/c/a/c;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/tencent/thumbplayer/c/a/c;->k:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p0
.end method

.method private a(IIILjava/lang/Object;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/c;->i:Lcom/tencent/thumbplayer/c/a/c$b;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/os/Handler;->obtainMessage()Landroid/os/Message;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput p1, v0, Landroid/os/Message;->what:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput p2, v0, Landroid/os/Message;->arg1:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput p3, v0, Landroid/os/Message;->arg2:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object p4, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/c;->i:Lcom/tencent/thumbplayer/c/a/c$b;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method private a(J[BLjava/lang/String;)Z
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string v0, "eetmoslssfcmlRnlei mAcaosia Fod"

    const-string/jumbo v0, "iosncsaeoeFliomdtlRa fecAms csl"

    const/4 v4, 0x2

    const-string/jumbo v0, "il Aos cfoa lcoisncRemeaFmsledo"

    const-string/jumbo v0, "fail to close mRandomAccessFile"

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v1, Ljava/io/RandomAccessFile;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string/jumbo v2, "rw"

    const-string/jumbo v2, "wr"

    const/4 v4, 0x2

    const-string/jumbo v2, "rw"

    const-string/jumbo v2, "rw"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {v1, p4, v2}, Ljava/io/RandomAccessFile;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/tencent/thumbplayer/c/a/c;->l:Ljava/io/RandomAccessFile;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v1, p1, p2}, Ljava/io/RandomAccessFile;->seek(J)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/c;->l:Ljava/io/RandomAccessFile;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p1, p3}, Ljava/io/RandomAccessFile;->write([B)V
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/c;->l:Ljava/io/RandomAccessFile;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz p1, :cond_0

    :try_start_1
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/io/RandomAccessFile;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v4, 0x4

    goto :goto_0

    :catch_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    sget-object p1, Lcom/tencent/thumbplayer/c/a/c;->a:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 p1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_3

    :catchall_0
    move-exception p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_4

    :catch_1
    :try_start_2
    const/4 v4, 0x3

    const/4 v3, 0x5

    sget-object p1, Lcom/tencent/thumbplayer/c/a/c;->a:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo p2, "terlabd  awamfito "

    const-string/jumbo p2, "f lmweidtiaaraot  "

    const/4 v4, 0x1

    const-string p2, "arfdiauta w l itto"

    const-string/jumbo p2, "fail to write data"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/c;->l:Ljava/io/RandomAccessFile;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz p1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto :goto_1

    :catch_2
    :try_start_3
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    sget-object p1, Lcom/tencent/thumbplayer/c/a/c;->a:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string/jumbo p2, "nfefo lptuiono"

    const-string/jumbo p2, "ieonoduntffol "

    const/4 v4, 0x0

    const-string/jumbo p2, "flufn i qdooet"

    const-string/jumbo p2, "file not found"

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/c;->l:Ljava/io/RandomAccessFile;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz p1, :cond_1

    :goto_1
    :try_start_4
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/io/RandomAccessFile;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_3

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto :goto_2

    :catch_3
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    sget-object p1, Lcom/tencent/thumbplayer/c/a/c;->a:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_2
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 p1, 0x0

    :goto_3
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    return p1

    :goto_4
    const/4 v4, 0x2

    const/4 v3, 0x1

    iget-object p2, p0, Lcom/tencent/thumbplayer/c/a/c;->l:Ljava/io/RandomAccessFile;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz p2, :cond_2

    :try_start_5
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p2}, Ljava/io/RandomAccessFile;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_4

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_5

    :catch_4
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    sget-object p2, Lcom/tencent/thumbplayer/c/a/c;->a:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {p2, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_5
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    throw p1
.end method

.method static synthetic a(Lcom/tencent/thumbplayer/c/a/c;J[BLjava/lang/String;)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/tencent/thumbplayer/c/a/c;->a(J[BLjava/lang/String;)Z

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic b(Lcom/tencent/thumbplayer/c/a/c;)Lcom/tencent/thumbplayer/utils/m;
    .locals 2

    const/4 v0, 0x5

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/tencent/thumbplayer/c/a/c;->j:Lcom/tencent/thumbplayer/utils/m;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/c/a/c;->a:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method public a()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/tencent/thumbplayer/c/a/c;->h:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method public a(J)I
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/c;->j:Lcom/tencent/thumbplayer/utils/m;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-wide v0, p0, Lcom/tencent/thumbplayer/c/a/c;->e:J

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/a/c;->j:Lcom/tencent/thumbplayer/utils/m;

    const/4 v7, 0x0

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    cmp-long v2, p1, v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v3, -0x1

    move v7, v3

    const/4 v6, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-ltz v2, :cond_0

    const/4 v6, 0x0

    and-int/2addr v7, v6

    return v3

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-wide v4, p0, Lcom/tencent/thumbplayer/c/a/c;->b:J

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    cmp-long v2, p1, v4

    const/4 v7, 0x4

    if-gez v2, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x5

    sget-object p1, Lcom/tencent/thumbplayer/c/a/c;->a:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const-string/jumbo p2, "stsqe etaefusssffedhlmO  eRtfOtns"

    const-string p2, " nsltbfteReefsftdthsqm  seaefuOsO"

    const/4 v7, 0x1

    const-string p2, "  fmn ttqROesaedhmestflOssefuesef"

    const-string p2, "Offset less than mRequestedOffset"

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    return v3

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    sub-long/2addr v0, p1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    long-to-int p1, v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    return p1
.end method

.method public a(I)V
    .locals 2

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/thumbplayer/c/a/c;->h:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public a(Landroid/os/Looper;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/c/a/c$b;

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {v0, p0, p1}, Lcom/tencent/thumbplayer/c/a/c$b;-><init>(Lcom/tencent/thumbplayer/c/a/c;Landroid/os/Looper;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/a/c;->i:Lcom/tencent/thumbplayer/c/a/c$b;

    const/4 v2, 0x2

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/a/c;->k:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public b()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/c;->i:Lcom/tencent/thumbplayer/c/a/c$b;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/tencent/thumbplayer/c/a/c;->i:Lcom/tencent/thumbplayer/c/a/c$b;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method public getCurrentOffset()J
    .locals 5

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/c;->j:Lcom/tencent/thumbplayer/utils/m;

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-wide v0, p0, Lcom/tencent/thumbplayer/c/a/c;->f:J

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/tencent/thumbplayer/c/a/c;->j:Lcom/tencent/thumbplayer/utils/m;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-wide v0
.end method

.method public getRequestedLength()J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/tencent/thumbplayer/c/a/c;->c:J

    const/4 v3, 0x6

    const/4 v2, 0x4

    return-wide v0
.end method

.method public getRequestedOffset()J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    iget-wide v0, p0, Lcom/tencent/thumbplayer/c/a/c;->b:J

    const/4 v3, 0x4

    return-wide v0
.end method

.method public notifyDataReady(JJ)V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    add-long/2addr p3, p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    iget-wide v0, p0, Lcom/tencent/thumbplayer/c/a/c;->b:J

    const/4 v5, 0x7

    iget-wide v2, p0, Lcom/tencent/thumbplayer/c/a/c;->c:J

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    add-long/2addr v2, v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    cmp-long v2, p3, v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-lez v2, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    sget-object p1, Lcom/tencent/thumbplayer/c/a/c;->a:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string p2, "c e h uafaesmfsudexqroetta txee ed"

    const/4 v5, 0x5

    const-string p2, "aetaoe herfudcmtxs xqe d fseae tet"

    const-string p2, "data exceed the max request offset"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-void

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    cmp-long p1, p1, v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-gez p1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    sget-object p1, Lcom/tencent/thumbplayer/c/a/c;->a:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string p2, "d esyb huitfotsenssaptlh ifr a qssfteoa fo  feetet"

    const-string p2, "dushe tpaaetot letf ieffe ey fq ssshifns  trottsao"

    const/4 v5, 0x6

    const-string/jumbo p2, "oe  t ut oysr fdeetuhfstfsfqltnesioi sefst taeaah "

    const-string/jumbo p2, "the notify data offset is less than request offset"

    const/4 v5, 0x5

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-wide p1, p0, Lcom/tencent/thumbplayer/c/a/c;->f:J

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    cmp-long p1, p3, p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-gez p1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x2

    sget-object p1, Lcom/tencent/thumbplayer/c/a/c;->a:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string/jumbo p2, "teaqatnpacr  ue fsofe ttrrohc"

    const-string/jumbo p2, "o rtof uqdtr reacetfacane sth"

    const/4 v5, 0x3

    const-string p2, " cfradtoqneuts cararenehft  o"

    const-string p2, "data not reach current offset"

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-void

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/c;->j:Lcom/tencent/thumbplayer/utils/m;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    iput-wide p3, p0, Lcom/tencent/thumbplayer/c/a/c;->f:J

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    iput-wide p3, p0, Lcom/tencent/thumbplayer/c/a/c;->e:J

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/c;->j:Lcom/tencent/thumbplayer/utils/m;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v5, 0x6

    return-void
.end method

.method public respondWithData([B)V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x0

    iget-wide v0, p0, Lcom/tencent/thumbplayer/c/a/c;->g:J

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-wide v2, p0, Lcom/tencent/thumbplayer/c/a/c;->c:J

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    cmp-long v0, v0, v2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-lez v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x2

    sget-object p1, Lcom/tencent/thumbplayer/c/a/c;->a:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string/jumbo v0, "onsldeta p asrusl"

    const-string/jumbo v0, "lds dslarn oaupet"

    const/4 v6, 0x0

    const-string/jumbo v0, "oulmdseald pfn at"

    const-string/jumbo v0, "respond full data"

    const/4 v6, 0x6

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    return-void

    :cond_0
    const/4 v6, 0x5

    array-length v0, p1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    new-instance v1, Lcom/tencent/thumbplayer/c/a/c$a;

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v5, 0x7

    or-int/2addr v6, v5

    invoke-direct {v1, v2}, Lcom/tencent/thumbplayer/c/a/c$a;-><init>(Lcom/tencent/thumbplayer/c/a/c$1;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    iget-wide v2, p0, Lcom/tencent/thumbplayer/c/a/c;->f:J

    const/4 v6, 0x4

    const/4 v5, 0x2

    iput-wide v2, v1, Lcom/tencent/thumbplayer/c/a/c$a;->a:J

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    iput-object p1, v1, Lcom/tencent/thumbplayer/c/a/c$a;->b:[B

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/16 p1, 0x100

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-direct {p0, p1, v0, v2, v1}, Lcom/tencent/thumbplayer/c/a/c;->a(IIILjava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    sget-object p1, Lcom/tencent/thumbplayer/c/a/c;->a:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string/jumbo v2, "mdmeonoaodsrprfa: "

    const-string/jumbo v2, "r am npdedsoaom:rf"

    const-string/jumbo v2, "om:otbfpr a dsnrda"

    const-string/jumbo v2, "respond data from:"

    const/4 v6, 0x6

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-wide v2, p0, Lcom/tencent/thumbplayer/c/a/c;->f:J

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string v2, "ae:hngut,aotd"

    const-string v2, ",tanohd:aeg t"

    const/4 v6, 0x5

    const-string/jumbo v2, "netgdtLpa:, h"

    const-string v2, ", dataLength:"

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {p1, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/c;->j:Lcom/tencent/thumbplayer/utils/m;

    const/4 v6, 0x5

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-wide v1, p0, Lcom/tencent/thumbplayer/c/a/c;->f:J

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    int-to-long v3, v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    add-long/2addr v1, v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    iput-wide v1, p0, Lcom/tencent/thumbplayer/c/a/c;->f:J

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-wide v0, p0, Lcom/tencent/thumbplayer/c/a/c;->g:J

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    add-long/2addr v0, v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    iput-wide v0, p0, Lcom/tencent/thumbplayer/c/a/c;->g:J

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/a/c;->j:Lcom/tencent/thumbplayer/utils/m;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    return-void
.end method
