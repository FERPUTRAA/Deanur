.class Lcom/tencent/thumbplayer/c/a/c$b;
.super Landroid/os/Handler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/c/a/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/c/a/c;


# direct methods
.method constructor <init>(Lcom/tencent/thumbplayer/c/a/c;Landroid/os/Looper;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/a/c$b;->a:Lcom/tencent/thumbplayer/c/a/c;

    const/4 v1, 0x4

    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@ts~ i@~idb ~n~ ~v@-@o~1~~~a~ o @@@  foK~ ~@@Sb@oMlb/f/~o @s~~~@o@@t ~@ 4@~y  ~@ .l~~ c@umr@i@~ "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/16 v1, 0x100

    const/4 v6, 0x5

    if-eq v0, v1, :cond_0

    const/4 v6, 0x6

    goto/16 :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x2

    check-cast v0, Lcom/tencent/thumbplayer/c/a/c$a;

    const/4 v6, 0x7

    iget-wide v1, v0, Lcom/tencent/thumbplayer/c/a/c$a;->a:J

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v0, v0, Lcom/tencent/thumbplayer/c/a/c$a;->b:[B

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget p1, p1, Landroid/os/Message;->arg1:I

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v3, p0, Lcom/tencent/thumbplayer/c/a/c$b;->a:Lcom/tencent/thumbplayer/c/a/c;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v3}, Lcom/tencent/thumbplayer/c/a/c;->a(Lcom/tencent/thumbplayer/c/a/c;)Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v3, v1, v2, v0, v4}, Lcom/tencent/thumbplayer/c/a/c;->a(Lcom/tencent/thumbplayer/c/a/c;J[BLjava/lang/String;)Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-nez v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/c/a/c;->c()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string v0, "airmdtfl eea wdas"

    const-string v0, " rsiweaftdld atae"

    const/4 v6, 0x4

    const-string/jumbo v0, "tideod aefwiaa tl"

    const-string/jumbo v0, "write data failed"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    move v6, v5

    return-void

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/c$b;->a:Lcom/tencent/thumbplayer/c/a/c;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/a/c;->b(Lcom/tencent/thumbplayer/c/a/c;)Lcom/tencent/thumbplayer/utils/m;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/c$b;->a:Lcom/tencent/thumbplayer/c/a/c;

    const/4 v6, 0x7

    int-to-long v3, p1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    add-long/2addr v3, v1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v0, v3, v4}, Lcom/tencent/thumbplayer/c/a/c;->a(Lcom/tencent/thumbplayer/c/a/c;J)J

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/c$b;->a:Lcom/tencent/thumbplayer/c/a/c;

    const/4 v6, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/a/c;->b(Lcom/tencent/thumbplayer/c/a/c;)Lcom/tencent/thumbplayer/utils/m;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/c/a/c;->c()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string/jumbo v4, "wratdbi  etofrmm"

    const-string v4, "datm  aemtfroirw"

    const/4 v6, 0x1

    const-string/jumbo v4, "fra moutdiaewr t"

    const-string/jumbo v4, "write data from "

    const/4 v6, 0x4

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const-string v1, "agh t,wponi ehtd a"

    const-string/jumbo v1, "wLahotndahi,et  g "

    const-string/jumbo v1, "t ,aihagq w Lehtdt"

    const-string v1, " , with dataLength"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v0, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-void
.end method
