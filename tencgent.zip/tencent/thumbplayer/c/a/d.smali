.class public Lcom/tencent/thumbplayer/c/a/d;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoadingRequest;


# instance fields
.field private a:I

.field private b:Lcom/tencent/thumbplayer/c/a/c;

.field private c:Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;

.field private d:Z

.field private e:Z


# direct methods
.method public constructor <init>(JJIZ)V
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    const/4 v0, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/c/a/d;->d:Z

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/c/a/d;->e:Z

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    iput p5, p0, Lcom/tencent/thumbplayer/c/a/d;->a:I

    const/4 v8, 0x6

    new-instance v0, Lcom/tencent/thumbplayer/c/a/c;

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-wide v2, p1

    move-wide v4, p3

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    move v6, p6

    move v6, p6

    const/4 v8, 0x6

    move v6, p6

    move v6, p6

    const/4 v8, 0x7

    const/4 v7, 0x6

    invoke-direct/range {v1 .. v6}, Lcom/tencent/thumbplayer/c/a/c;-><init>(JJZ)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/c/a/d;->b:Lcom/tencent/thumbplayer/c/a/c;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v0, p5}, Lcom/tencent/thumbplayer/c/a/c;->a(I)V

    const/4 v7, 0x3

    const/4 v7, 0x1

    return-void
.end method


# virtual methods
.method public a(J)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/d;->b:Lcom/tencent/thumbplayer/c/a/c;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p1, p2}, Lcom/tencent/thumbplayer/c/a/c;->a(J)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    return p1
.end method

.method public a()Lcom/tencent/thumbplayer/c/a/c;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/d;->b:Lcom/tencent/thumbplayer/c/a/c;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public a(Landroid/os/Looper;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/d;->b:Lcom/tencent/thumbplayer/c/a/c;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/c/a/c;->a(Landroid/os/Looper;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/a/d;->c:Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/d;->b:Lcom/tencent/thumbplayer/c/a/c;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/thumbplayer/c/a/c;->a(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public declared-synchronized b()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    monitor-enter p0

    const/4 v1, 0x7

    move v2, v1

    const/4 v0, 0x6

    const/4 v0, 0x1

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/c/a/d;->d:Z

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/d;->b:Lcom/tencent/thumbplayer/c/a/c;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/c/a/c;->b()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    throw v0
.end method

.method public declared-synchronized finishLoading()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    monitor-enter p0

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x3

    xor-int/2addr v1, v0

    :try_start_0
    const/4 v2, 0x3

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/c/a/d;->e:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    monitor-exit p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    throw v0
.end method

.method public getContentInformation()Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/a/d;->c:Lcom/tencent/thumbplayer/api/resourceloader/TPAssetResourceLoadingContentInformationRequest;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public synthetic getLoadingDataRequest()Lcom/tencent/thumbplayer/api/resourceloader/ITPAssetResourceLoadingDataRequest;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/c/a/d;->a()Lcom/tencent/thumbplayer/c/a/c;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public declared-synchronized isCancelled()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    monitor-enter p0

    :try_start_0
    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/c/a/d;->d:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized isFinished()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/c/a/d;->e:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x5

    const/4 v2, 0x4

    monitor-exit p0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    throw v0
.end method
