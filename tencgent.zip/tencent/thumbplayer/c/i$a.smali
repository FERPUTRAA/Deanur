.class Lcom/tencent/thumbplayer/c/i$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/c/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# static fields
.field private static a:Lcom/tencent/thumbplayer/c/i;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v0, Lcom/tencent/thumbplayer/c/i;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lcom/tencent/thumbplayer/c/i;-><init>(Lcom/tencent/thumbplayer/c/i$1;)V

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    sput-object v0, Lcom/tencent/thumbplayer/c/i$a;->a:Lcom/tencent/thumbplayer/c/i;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method

.method static synthetic a()Lcom/tencent/thumbplayer/c/i;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "viso~@    @@~@~@K~@@~  .d~~ o@@ @@lb@/f @ /~ ~~ ~~i@io~@ @@ut S ybm@tf~a4s~~~~~o l1b@~-r~n@coo M"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/tencent/thumbplayer/c/i$a;->a:Lcom/tencent/thumbplayer/c/i;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method
