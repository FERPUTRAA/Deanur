.class Lcom/tencent/thumbplayer/c/e$b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/c/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/thumbplayer/c/e;


# direct methods
.method private constructor <init>(Lcom/tencent/thumbplayer/c/e;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/thumbplayer/c/e;Lcom/tencent/thumbplayer/c/e$1;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/c/e$b;-><init>(Lcom/tencent/thumbplayer/c/e;)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    return-void
.end method


# virtual methods
.method public getAdvRemainTime()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@bst@o@K~m~  ~@4@-i@oso~1@o~cif@~ @ n @t@May~  ~ ~ ~ u~bS@~@~@  .@~~b id@ r~o~~@f@ll~ @/  ~~@~/v"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v2, 0x0

    shr-int/2addr v3, v2

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {v0}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getAdvRemainTime()J

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-wide v0
.end method

.method public getContentType(ILjava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getContentType(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p1
.end method

.method public getCurrentPlayClipNo()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-interface {v0}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getCurrentPlayClipNo()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public getCurrentPlayOffset()J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {v0}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getCurrentPlayOffset()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-wide v0
.end method

.method public getCurrentPosition()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-interface {v0}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getCurrentPosition()J

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-wide v0
.end method

.method public getDataFilePath(ILjava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getDataFilePath(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p1
.end method

.method public getDataTotalSize(ILjava/lang/String;)J
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-interface {v0, p1, p2}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getDataTotalSize(ILjava/lang/String;)J

    move-result-wide p1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-wide p1
.end method

.method public getPlayInfo(J)Ljava/lang/Object;
    .locals 5

    const/4 v3, 0x6

    move v4, v3

    new-instance v0, Lcom/tencent/thumbplayer/utils/e;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v0}, Lcom/tencent/thumbplayer/utils/e;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v1, Lcom/tencent/thumbplayer/c/e$e;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {v1, v2}, Lcom/tencent/thumbplayer/c/e$e;-><init>(Lcom/tencent/thumbplayer/c/e$1;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput-object p1, v1, Lcom/tencent/thumbplayer/c/e$e;->a:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput-object v0, v1, Lcom/tencent/thumbplayer/c/e$e;->b:Lcom/tencent/thumbplayer/utils/e;

    const/4 v4, 0x3

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/16 p2, 0x1009

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p1, p2, v1}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;ILjava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;Lcom/tencent/thumbplayer/utils/e;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object p1
.end method

.method public getPlayInfo(Ljava/lang/String;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/utils/e;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v0}, Lcom/tencent/thumbplayer/utils/e;-><init>()V

    const/4 v4, 0x3

    new-instance v1, Lcom/tencent/thumbplayer/c/e$e;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v1, v2}, Lcom/tencent/thumbplayer/c/e$e;-><init>(Lcom/tencent/thumbplayer/c/e$1;)V

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput-object p1, v1, Lcom/tencent/thumbplayer/c/e$e;->a:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    iput-object v0, v1, Lcom/tencent/thumbplayer/c/e$e;->b:Lcom/tencent/thumbplayer/utils/e;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/16 v2, 0x100b

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p1, v2, v1}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;ILjava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v4, 0x4

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;Lcom/tencent/thumbplayer/utils/e;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object p1
.end method

.method public getPlayerBufferLength()J
    .locals 4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {v0}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->getPlayerBufferLength()J

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    return-wide v0
.end method

.method public onDownloadCdnUrlExpired(Ljava/util/Map;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/16 v1, 0x1007

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0, v1, p1}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;ILjava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method

.method public onDownloadCdnUrlInfoUpdate(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPCDNURLInfo;

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPCDNURLInfo;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object p1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPCDNURLInfo;->url:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object p2, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPCDNURLInfo;->cdnIp:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object p3, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPCDNURLInfo;->uIp:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object p4, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPCDNURLInfo;->errorStr:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/16 p2, 0x1004

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p1, p2, v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;ILjava/lang/Object;)V

    const/4 v2, 0x7

    return-void
.end method

.method public onDownloadCdnUrlUpdate(Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/16 v1, 0x1003

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v0, v1, p1}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;ILjava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method

.method public onDownloadError(IILjava/lang/String;)V
    .locals 11

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    const/16 v1, 0x1002

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 v5, 0x0

    const/4 v10, 0x6

    const/4 v6, 0x0

    const/4 v10, 0x1

    move v9, v6

    move v9, v6

    const/4 v10, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    move v2, p1

    move v2, p1

    const/4 v10, 0x7

    move v2, p1

    move v2, p1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    move v3, p2

    move v3, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static/range {v0 .. v8}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;IIILjava/lang/Object;ZZJ)V

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    return-void
.end method

.method public onDownloadFinish()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/16 v1, 0x1001

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x6

    invoke-static {v0, v1, v2}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;ILjava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void
.end method

.method public onDownloadProgressUpdate(IIJJLjava/lang/String;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPDownLoadProgressInfo;

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPDownLoadProgressInfo;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    int-to-long v1, p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput-wide v1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPDownLoadProgressInfo;->playableDurationMS:J

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput p2, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPDownLoadProgressInfo;->downloadSpeedKBps:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput-wide p3, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPDownLoadProgressInfo;->currentDownloadSize:J

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    iput-wide p5, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPDownLoadProgressInfo;->totalFileSize:J

    const/4 v4, 0x4

    const/4 v3, 0x3

    iput-object p7, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPDownLoadProgressInfo;->extraInfo:Ljava/lang/String;

    const/4 v3, 0x3

    move v4, v3

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/16 p2, 0x100a

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {p1, p2, v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;ILjava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void
.end method

.method public onDownloadProtocolUpdate(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPProtocolInfo;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {v0}, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPProtocolInfo;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object p2, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPProtocolInfo;->protocolVersion:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    iput-object p1, v0, Lcom/tencent/thumbplayer/api/TPPlayerMsg$TPProtocolInfo;->protocolName:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/16 p2, 0x1006

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p1, p2, v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;ILjava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public onDownloadStatusUpdate(I)V
    .locals 11

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    const/16 v1, 0x1005

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v3, 0x0

    move v10, v3

    const/4 v9, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    const/4 v4, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v5, 0x0

    move v10, v5

    const/4 v9, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    const/4 v6, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x7

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    move v2, p1

    move v2, p1

    const/4 v10, 0x5

    move v2, p1

    move v2, p1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static/range {v0 .. v8}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;IIILjava/lang/Object;ZZJ)V

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    return-void
.end method

.method public onPlayCallback(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/c/e$f;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Lcom/tencent/thumbplayer/c/e$f;-><init>(Lcom/tencent/thumbplayer/c/e$1;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput p1, v0, Lcom/tencent/thumbplayer/c/e$f;->a:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object p2, v0, Lcom/tencent/thumbplayer/c/e$f;->b:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object p3, v0, Lcom/tencent/thumbplayer/c/e$f;->c:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object p4, v0, Lcom/tencent/thumbplayer/c/e$f;->d:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object p5, v0, Lcom/tencent/thumbplayer/c/e$f;->e:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance p1, Lcom/tencent/thumbplayer/utils/e;

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-direct {p1}, Lcom/tencent/thumbplayer/utils/e;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance p2, Lcom/tencent/thumbplayer/c/e$e;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p2, v1}, Lcom/tencent/thumbplayer/c/e$e;-><init>(Lcom/tencent/thumbplayer/c/e$1;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v0, p2, Lcom/tencent/thumbplayer/c/e$e;->a:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object p1, p2, Lcom/tencent/thumbplayer/c/e$e;->b:Lcom/tencent/thumbplayer/utils/e;

    const/4 v3, 0x5

    const/4 v2, 0x2

    iget-object p3, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/16 p4, 0x1008

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p3, p4, p2}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;ILjava/lang/Object;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;Lcom/tencent/thumbplayer/utils/e;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object p1
.end method

.method public onReadData(ILjava/lang/String;JJ)I
    .locals 9

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v8, 0x0

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v1

    const/4 v8, 0x6

    move v2, p1

    move v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-wide v4, p3

    move-wide v6, p5

    const/4 v8, 0x7

    invoke-interface/range {v1 .. v7}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onReadData(ILjava/lang/String;JJ)I

    move-result p1

    const/4 v8, 0x7

    return p1
.end method

.method public onStartReadData(ILjava/lang/String;JJ)I
    .locals 9

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v8, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v1

    const/4 v8, 0x3

    move v2, p1

    move v2, p1

    move v2, p1

    move v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-wide v4, p3

    move-wide v6, p5

    const/4 v8, 0x7

    invoke-interface/range {v1 .. v7}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onStartReadData(ILjava/lang/String;JJ)I

    move-result p1

    const/4 v8, 0x2

    return p1
.end method

.method public onStopReadData(ILjava/lang/String;I)I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/c/e$b;->a:Lcom/tencent/thumbplayer/c/e;

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/tencent/thumbplayer/c/e;->a(Lcom/tencent/thumbplayer/c/e;)Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {v0, p1, p2, p3}, Lcom/tencent/thumbplayer/core/downloadproxy/api/ITPPlayListener;->onStopReadData(ILjava/lang/String;I)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return p1
.end method
