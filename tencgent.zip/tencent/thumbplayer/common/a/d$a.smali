.class Lcom/tencent/thumbplayer/common/a/d$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/common/a/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "a"
.end annotation


# instance fields
.field public a:I

.field public b:I

.field final synthetic c:Lcom/tencent/thumbplayer/common/a/d;


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/common/a/d;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/common/a/d$a;->c:Lcom/tencent/thumbplayer/common/a/d;

    const/4 v0, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/common/a/d$a;->a()V

    const/4 v0, 0x7

    shr-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "lis@M ~~~dt@    @/~/t~@@ 4 S~ o@u@ib~@@f~@~~~ycs~1a~ o@ @ol v@@r~b~o~~- @~i@ ~~@mfo .  @b~K@ n@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const/4 v0, -0x1

    const/4 v2, 0x1

    iput v0, p0, Lcom/tencent/thumbplayer/common/a/d$a;->a:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput v0, p0, Lcom/tencent/thumbplayer/common/a/d$a;->b:I

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/common/a/a;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string/jumbo v0, "wdimhoravde1lefrceo"

    const-string v0, "elsdohw1ieecavrodrf"

    const/4 v3, 0x6

    const-string/jumbo v0, "fedooavedrroepichl1"

    const-string v0, "av1hwdecoderprofile"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/common/a/d$a;->a:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {p1, v0, v1}, Lcom/tencent/thumbplayer/common/a/a;->a(Ljava/lang/String;I)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string v0, "alrlebv1dcedwmeve"

    const-string/jumbo v0, "vlhm1vdceeawdleer"

    const/4 v3, 0x5

    const-string v0, "av1hwdecoderlevel"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v1, p0, Lcom/tencent/thumbplayer/common/a/d$a;->b:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {p1, v0, v1}, Lcom/tencent/thumbplayer/common/a/a;->a(Ljava/lang/String;I)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method
