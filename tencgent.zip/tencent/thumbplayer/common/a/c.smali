.class public Lcom/tencent/thumbplayer/common/a/c;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/common/a/d$a;Lcom/tencent/thumbplayer/common/a/a;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o~s~aKl/   but@io  /~~ @~d~@ c~so~~@@1~b b@~o~  ~ ~o@@yl@ft -o @@@fiM @@@m4~~~~@~ r~@ @@~S.n @vi"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {}, Lcom/tencent/thumbplayer/common/a/c;->b()Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->getMaxProfile()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput v1, p1, Lcom/tencent/thumbplayer/common/a/d$a;->a:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->getMaxLevel()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput v0, p1, Lcom/tencent/thumbplayer/common/a/d$a;->b:I

    :cond_0
    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/common/a/d$a;->a(Lcom/tencent/thumbplayer/common/a/a;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/common/a/d$b;Lcom/tencent/thumbplayer/common/a/a;)V
    .locals 6

    const/4 v4, 0x1

    move v5, v4

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->SDK_INT:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    iput v0, p1, Lcom/tencent/thumbplayer/common/a/d$b;->c:I

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string v1, "_"

    const-string v1, "_"

    const/4 v5, 0x0

    const-string v1, "_"

    const-string v1, "_"

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getPlatform()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    iput-object v0, p1, Lcom/tencent/thumbplayer/common/a/d$b;->a:Ljava/lang/String;

    const/4 v5, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getPlatform()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    iput v0, p1, Lcom/tencent/thumbplayer/common/a/d$b;->b:I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    new-array v1, v0, [Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getOsVersion()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    and-int/2addr v5, v4

    aput-object v2, v1, v3

    const/4 v5, 0x4

    const-string/jumbo v2, "idom%rA ns"

    const-string v2, "Android %s"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput-object v1, p1, Lcom/tencent/thumbplayer/common/a/d$b;->d:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v1, 0x2

    const/4 v5, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceManufacturer()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    aput-object v2, v1, v3

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    aput-object v2, v1, v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo v0, "ss%%o"

    const-string v0, "_ss%%"

    const/4 v5, 0x0

    const-string v0, "b%_%s"

    const-string v0, "%s_%s"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    iput-object v0, p1, Lcom/tencent/thumbplayer/common/a/d$b;->e:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuHarewareName()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-object v0, p1, Lcom/tencent/thumbplayer/common/a/d$b;->g:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/common/a/d$b;->a(Lcom/tencent/thumbplayer/common/a/a;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/common/a/d$c;Lcom/tencent/thumbplayer/common/a/a;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/common/a/c;->e()Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->getMaxProfile()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput v1, p1, Lcom/tencent/thumbplayer/common/a/d$c;->a:I

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->getMaxLevel()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    iput v0, p1, Lcom/tencent/thumbplayer/common/a/d$c;->b:I

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/common/a/d$c;->a(Lcom/tencent/thumbplayer/common/a/a;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/common/a/d$d;Lcom/tencent/thumbplayer/common/a/a;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/common/a/c;->d()Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->getMaxProfile()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput v1, p1, Lcom/tencent/thumbplayer/common/a/d$d;->a:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->getMaxLevel()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput v0, p1, Lcom/tencent/thumbplayer/common/a/d$d;->b:I

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/common/a/d$d;->a(Lcom/tencent/thumbplayer/common/a/a;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method private a(Lcom/tencent/thumbplayer/common/a/d$e;Lcom/tencent/thumbplayer/common/a/a;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/common/a/c;->c()Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->getMaxProfile()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    iput v1, p1, Lcom/tencent/thumbplayer/common/a/d$e;->a:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->getMaxLevel()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput v0, p1, Lcom/tencent/thumbplayer/common/a/d$e;->b:I

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Lcom/tencent/thumbplayer/common/a/d$e;->a(Lcom/tencent/thumbplayer/common/a/a;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method private static b()Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/16 v0, 0x405

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/16 v1, 0x66

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v2, 0x0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/api/capability/TPCapability;->getThumbPlayerVCodecTypeMaxCapability(II)Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    move-result-object v0
    :try_end_0
    .catch Lcom/tencent/thumbplayer/api/TPNativeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string/jumbo v1, "iMmapeueTgtvDncCaeypitPabieorRr"

    const-string/jumbo v1, "nacmleberPitiDyeaoarvtiMpgpRTCe"

    const/4 v4, 0x1

    const-string v1, "DegrliapMnCypeceatTibPraeatRiov"

    const-string v1, "TPDeviceCapabilityReportManager"

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->mDefaultVCodecCapability:Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-ne v0, v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object v2

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object v0
.end method

.method private static c()Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/16 v0, 0xa6

    const/4 v3, 0x3

    shl-int/2addr v4, v3

    const/16 v1, 0x66

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v2, 0x0

    move v4, v2

    :try_start_0
    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/api/capability/TPCapability;->getThumbPlayerVCodecTypeMaxCapability(II)Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    move-result-object v0
    :try_end_0
    .catch Lcom/tencent/thumbplayer/api/TPNativeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v1, "DcPiopMepvnriletRatoaabiTeeCgra"

    const-string v1, "TeitDRnaqpPariceryeoitpaveMCglb"

    const-string v1, "TPDeviceCapabilityReportManager"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->mDefaultVCodecCapability:Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-ne v0, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object v2

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-object v0
.end method

.method private static d()Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/16 v0, 0x8a

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/16 v1, 0x66

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v2, 0x0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/api/capability/TPCapability;->getThumbPlayerVCodecTypeMaxCapability(II)Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    move-result-object v0
    :try_end_0
    .catch Lcom/tencent/thumbplayer/api/TPNativeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v1, "MesvPDppatTnaatryeieclgbeCibRra"

    const-string/jumbo v1, "rvgetbaylaReneaitCaMiDTcborePpp"

    const/4 v4, 0x6

    const-string v1, "eMpmaotgiTPeDbverpyanRltaiaecCr"

    const-string v1, "TPDeviceCapabilityReportManager"

    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->mDefaultVCodecCapability:Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    move v4, v3

    return-object v2

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    return-object v0
.end method

.method private static e()Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/16 v0, 0xac

    const/4 v3, 0x0

    move v4, v3

    const/16 v1, 0x66

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v2, 0x0

    :try_start_0
    const/4 v4, 0x2

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/api/capability/TPCapability;->getThumbPlayerVCodecTypeMaxCapability(II)Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    move-result-object v0
    :try_end_0
    .catch Lcom/tencent/thumbplayer/api/TPNativeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string v1, "eaatoaTlPaeivCerpcyMuebgDtnorRi"

    const-string v1, "atyeacuaonrvbeireDpaMtPeTiCligR"

    const-string v1, "aeRpDbrvatgibyMaontPeeriiTplcea"

    const-string v1, "TPDeviceCapabilityReportManager"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;->mDefaultVCodecCapability:Lcom/tencent/thumbplayer/api/capability/TPVCodecCapabilityForGet;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-ne v0, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-object v2

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-object v0
.end method

.method private f()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/common/a/d;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {v0}, Lcom/tencent/thumbplayer/common/a/d;-><init>()V

    const/4 v4, 0x4

    new-instance v1, Lcom/tencent/thumbplayer/utils/l;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v1}, Lcom/tencent/thumbplayer/utils/l;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/common/a/d;->a()Lcom/tencent/thumbplayer/common/a/d$b;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {p0, v2, v1}, Lcom/tencent/thumbplayer/common/a/c;->a(Lcom/tencent/thumbplayer/common/a/d$b;Lcom/tencent/thumbplayer/common/a/a;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/common/a/d;->b()Lcom/tencent/thumbplayer/common/a/d$a;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {p0, v2, v1}, Lcom/tencent/thumbplayer/common/a/c;->a(Lcom/tencent/thumbplayer/common/a/d$a;Lcom/tencent/thumbplayer/common/a/a;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/common/a/d;->c()Lcom/tencent/thumbplayer/common/a/d$e;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-direct {p0, v2, v1}, Lcom/tencent/thumbplayer/common/a/c;->a(Lcom/tencent/thumbplayer/common/a/d$e;Lcom/tencent/thumbplayer/common/a/a;)V

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/common/a/d;->d()Lcom/tencent/thumbplayer/common/a/d$d;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {p0, v2, v1}, Lcom/tencent/thumbplayer/common/a/c;->a(Lcom/tencent/thumbplayer/common/a/d$d;Lcom/tencent/thumbplayer/common/a/a;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/common/a/d;->e()Lcom/tencent/thumbplayer/common/a/d$c;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-direct {p0, v0, v1}, Lcom/tencent/thumbplayer/common/a/c;->a(Lcom/tencent/thumbplayer/common/a/d$c;Lcom/tencent/thumbplayer/common/a/a;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v2, ": iavpupatdberloeci rtcie"

    const-string v2, "device capability report:"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string v2, "CeRcaoipDriypTibrepvageltanaPeM"

    const-string/jumbo v2, "goCnyPipiereDvMealreabppctaaiRT"

    const/4 v4, 0x4

    const-string/jumbo v2, "ocepiarMqaeetCRtTPyaevnilipaDgr"

    const-string v2, "TPDeviceCapabilityReportManager"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v2, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string v0, "cmscpedq_ooatevnimp_"

    const-string/jumbo v0, "tpocc_oaqveimmcp_ned"

    const/4 v4, 0x6

    const-string v0, "_pmmiodce_v_apcctmen"

    const-string/jumbo v0, "tp_common_device_cap"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/common/a/b;->a(Ljava/lang/String;Lcom/tencent/thumbplayer/common/a/a;)V

    const/4 v4, 0x6

    return-void
.end method


# virtual methods
.method public a()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    invoke-direct {p0}, Lcom/tencent/thumbplayer/common/a/c;->f()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method
