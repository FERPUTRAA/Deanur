.class Lcom/tencent/thumbplayer/common/a/d$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/common/a/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "b"
.end annotation


# instance fields
.field public a:Ljava/lang/String;

.field public b:I

.field public c:I

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/String;

.field public g:Ljava/lang/String;

.field final synthetic h:Lcom/tencent/thumbplayer/common/a/d;


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/common/a/d;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/common/a/d$b;->h:Lcom/tencent/thumbplayer/common/a/d;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/common/a/d$b;->a()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    return-void
.end method


# virtual methods
.method public a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ss~d~~~roM o1mo @ S~v  @o t@ ~o u@ @i@-~@ lfbb@ b@i~c ~.~a~@~ ~to@~@~~~/~/~@@4 K@@i@~ @~l@ fn@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x3

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/common/a/d$b;->a:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v1, -0x1

    move v3, v1

    const/4 v2, 0x0

    move v3, v2

    iput v1, p0, Lcom/tencent/thumbplayer/common/a/d$b;->b:I

    const/4 v3, 0x4

    iput v1, p0, Lcom/tencent/thumbplayer/common/a/d$b;->c:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/common/a/d$b;->d:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/common/a/d$b;->e:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/common/a/d$b;->f:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/common/a/d$b;->g:Ljava/lang/String;

    const/4 v2, 0x1

    and-int/2addr v3, v2

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/common/a/a;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string/jumbo v0, "lodmsi"

    const-string/jumbo v0, "ilsfod"

    const/4 v3, 0x2

    const-string/jumbo v0, "wfodol"

    const-string/jumbo v0, "flowid"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/common/a/d$b;->a:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-interface {p1, v0, v1}, Lcom/tencent/thumbplayer/common/a/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v0, "fmppmbaolap"

    const-string/jumbo v0, "ppmmoalapft"

    const/4 v3, 0x6

    const-string/jumbo v0, "oppmrpuatla"

    const-string v0, "appplatform"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/common/a/d$b;->b:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {p1, v0, v1}, Lcom/tencent/thumbplayer/common/a/a;->a(Ljava/lang/String;I)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const-string/jumbo v0, "vpelolie"

    const/4 v3, 0x2

    const-string v0, "allievep"

    const-string v0, "apilevel"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget v1, p0, Lcom/tencent/thumbplayer/common/a/d$b;->c:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-interface {p1, v0, v1}, Lcom/tencent/thumbplayer/common/a/a;->a(Ljava/lang/String;I)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string/jumbo v0, "verqs"

    const-string v0, "bervs"

    const/4 v3, 0x4

    const-string/jumbo v0, "sosvr"

    const-string/jumbo v0, "osver"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/common/a/d$b;->d:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {p1, v0, v1}, Lcom/tencent/thumbplayer/common/a/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v0, "deomu"

    const-string/jumbo v0, "luedo"

    const/4 v3, 0x0

    const-string/jumbo v0, "ldemo"

    const-string/jumbo v0, "model"

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/common/a/d$b;->e:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {p1, v0, v1}, Lcom/tencent/thumbplayer/common/a/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string v0, "alsroben"

    const-string/jumbo v0, "soaerlnp"

    const/4 v3, 0x0

    const-string/jumbo v0, "oeialnur"

    const-string/jumbo v0, "serialno"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/thumbplayer/common/a/d$b;->f:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {p1, v0, v1}, Lcom/tencent/thumbplayer/common/a/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string/jumbo v0, "pmaenup"

    const-string v0, "eqnmuap"

    const/4 v3, 0x6

    const-string/jumbo v0, "uqanmec"

    const-string v0, "cpuname"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/tencent/thumbplayer/common/a/d$b;->g:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {p1, v0, v1}, Lcom/tencent/thumbplayer/common/a/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method
