.class Lcom/tencent/thumbplayer/common/a/d$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/common/a/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "c"
.end annotation


# instance fields
.field public a:I

.field public b:I

.field final synthetic c:Lcom/tencent/thumbplayer/common/a/d;


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/common/a/d;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/common/a/d$c;->c:Lcom/tencent/thumbplayer/common/a/d;

    const/4 v0, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/common/a/d$c;->a()V

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s@@~ o@~~@oi~~4o @@~@ @@b~ to~  f~-l~~ 1@~@.s@  l~/   b~S@~ u@~~c@biMrin@/Ka@vfy@t~ @~ om~~@d "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    const/4 v0, -0x1

    const/4 v2, 0x0

    iput v0, p0, Lcom/tencent/thumbplayer/common/a/d$c;->a:I

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput v0, p0, Lcom/tencent/thumbplayer/common/a/d$c;->b:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/common/a/a;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v0, "lvsmdheecedwehforprc"

    const-string/jumbo v0, "lcswehdroeihervcfepd"

    const/4 v3, 0x1

    const-string/jumbo v0, "oceroedhvwoeceifldrp"

    const-string/jumbo v0, "hevchwdecoderprofile"

    const/4 v3, 0x2

    iget v1, p0, Lcom/tencent/thumbplayer/common/a/d$c;->a:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {p1, v0, v1}, Lcom/tencent/thumbplayer/common/a/a;->a(Ljava/lang/String;I)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v0, "eemwobcedldhrlhcev"

    const-string v0, "dlcmewlerhevocdhev"

    const/4 v3, 0x5

    const-string/jumbo v0, "oreelvuhdedhcewlce"

    const-string/jumbo v0, "hevchwdecoderlevel"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v1, p0, Lcom/tencent/thumbplayer/common/a/d$c;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {p1, v0, v1}, Lcom/tencent/thumbplayer/common/a/a;->a(Ljava/lang/String;I)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method
