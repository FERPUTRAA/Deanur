.class Lcom/tencent/thumbplayer/common/a/d$d;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/common/a/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "d"
.end annotation


# instance fields
.field public a:I

.field public b:I

.field final synthetic c:Lcom/tencent/thumbplayer/common/a/d;


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/common/a/d;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/common/a/d$d;->c:Lcom/tencent/thumbplayer/common/a/d;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/common/a/d$d;->a()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s m@1~@  s~-ob @@@~ ~  ir~ol~~@~o~yv @~~~nb@i  ~@@d/.@~~o of ti @ l @S~4/M ~bfo~@K@~@ta@@@c~@u"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const/4 v0, -0x1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput v0, p0, Lcom/tencent/thumbplayer/common/a/d$d;->a:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/common/a/d$d;->b:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public a(Lcom/tencent/thumbplayer/common/a/a;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string/jumbo v0, "lesmdocf8roevpehrwd"

    const-string/jumbo v0, "posoedihfcrewdve8rl"

    const-string v0, "dwvoophcr8relefdeop"

    const-string/jumbo v0, "vp8hwdecoderprofile"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget v1, p0, Lcom/tencent/thumbplayer/common/a/d$d;->a:I

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {p1, v0, v1}, Lcom/tencent/thumbplayer/common/a/a;->a(Ljava/lang/String;I)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string v0, "edvvebrw8emloelhd"

    const-string/jumbo v0, "wlemldpe8evevrhdo"

    const/4 v3, 0x4

    const-string v0, "ceh8dduweeloepvlv"

    const-string/jumbo v0, "vp8hwdecoderlevel"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget v1, p0, Lcom/tencent/thumbplayer/common/a/d$d;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {p1, v0, v1}, Lcom/tencent/thumbplayer/common/a/a;->a(Ljava/lang/String;I)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method
