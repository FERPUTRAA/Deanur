.class public Lcom/tencent/thumbplayer/common/a/b;
.super Ljava/lang/Object;


# static fields
.field private static a:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Landroid/content/Context;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "d@s~~~K@l/t  @o t~~@ f@af~~  i@~M v@@~~om @  @~  o~i~@o @.~@ir~1uSy o~ @~~@4b @bb~ c~~@so@@/l@n-"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    const-string/jumbo v0, "repmecertnrRoaBspWoTP"

    const-string v0, "aPsoTWrpeeprRnceBarto"

    const-string v0, "TPBeaconReportWrapper"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string/jumbo v1, "ncsBotan.traokd   mies"

    const-string v1, " kdmo at.tcr esnBastni"

    const/4 v5, 0x4

    const-string/jumbo v1, "t Benb.otri ikaanstds "

    const-string v1, "Beacon sdk init start."

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-boolean v0, Lcom/tencent/thumbplayer/common/a/b;->a:Z

    const/4 v5, 0x0

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-void

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {}, Lcom/tencent/tvkbeacon/event/open/BeaconConfig;->builder()Lcom/tencent/tvkbeacon/event/open/BeaconConfig$Builder;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v1, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/tvkbeacon/event/open/BeaconConfig$Builder;->auditEnable(Z)Lcom/tencent/tvkbeacon/event/open/BeaconConfig$Builder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-static {}, Lcom/tencent/tvkbeacon/event/open/BeaconReport;->getInstance()Lcom/tencent/tvkbeacon/event/open/BeaconReport;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Lcom/tencent/tvkbeacon/event/open/BeaconReport;->setModel(Ljava/lang/String;)V

    const/4 v4, 0x1

    move v5, v4

    sget-object v2, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->beacon_policy_host:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-nez v2, :cond_1

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    sget-object v2, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->beacon_log_host:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x7

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-nez v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x0

    sget-object v2, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->beacon_policy_host:Ljava/lang/String;

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    invoke-virtual {v0, v2}, Lcom/tencent/tvkbeacon/event/open/BeaconConfig$Builder;->setConfigHost(Ljava/lang/String;)Lcom/tencent/tvkbeacon/event/open/BeaconConfig$Builder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    sget-object v2, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->beacon_log_host:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v2}, Lcom/tencent/tvkbeacon/event/open/BeaconConfig$Builder;->setUploadHost(Ljava/lang/String;)Lcom/tencent/tvkbeacon/event/open/BeaconConfig$Builder;

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/tvkbeacon/event/open/BeaconReport;->getInstance()Lcom/tencent/tvkbeacon/event/open/BeaconReport;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v2, v1}, Lcom/tencent/tvkbeacon/event/open/BeaconReport;->setLogAble(Z)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {}, Lcom/tencent/tvkbeacon/event/open/BeaconReport;->getInstance()Lcom/tencent/tvkbeacon/event/open/BeaconReport;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->getGuid()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string v3, "0G00O1u37DY0020B"

    const-string v3, "00000GODBG3702Y1"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v1, v3, v2}, Lcom/tencent/tvkbeacon/event/open/BeaconReport;->setOstar(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {}, Lcom/tencent/tvkbeacon/event/open/BeaconReport;->getInstance()Lcom/tencent/tvkbeacon/event/open/BeaconReport;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/tencent/tvkbeacon/event/open/BeaconConfig$Builder;->build()Lcom/tencent/tvkbeacon/event/open/BeaconConfig;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v1, p0, v3, v0}, Lcom/tencent/tvkbeacon/event/open/BeaconReport;->start(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/tvkbeacon/event/open/BeaconConfig;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-void
.end method

.method public static a(Ljava/lang/String;Lcom/tencent/thumbplayer/common/a/a;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-interface {p1, v0}, Lcom/tencent/thumbplayer/common/a/a;->a(Ljava/util/Map;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const-string p1, "0Y37010pOD0G0Bo2"

    const-string p1, "0G0YoB020071D30O"

    const/4 v2, 0x6

    const-string p1, "G003B0Y2q00G7D1O"

    const-string p1, "00000GODBG3702Y1"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p0, p1, v0}, Lcom/tencent/thumbplayer/common/a/b;->a(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    const/4 v2, 0x4

    return-void
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-boolean v0, Lcom/tencent/thumbplayer/common/a/b;->a:Z

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->isDataReportEnable()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/config/TPPlayerConfig;->isPlayerReportEnable()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    goto/16 :goto_0

    :cond_0
    const/4 v2, 0x3

    move v3, v2

    invoke-static {}, Lcom/tencent/tvkbeacon/event/open/BeaconEvent;->builder()Lcom/tencent/tvkbeacon/event/open/BeaconEvent$Builder;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, p0}, Lcom/tencent/tvkbeacon/event/open/BeaconEvent$Builder;->withCode(Ljava/lang/String;)Lcom/tencent/tvkbeacon/event/open/BeaconEvent$Builder;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v0, Lcom/tencent/tvkbeacon/event/open/EventType;->NORMAL:Lcom/tencent/tvkbeacon/event/open/EventType;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Lcom/tencent/tvkbeacon/event/open/BeaconEvent$Builder;->withType(Lcom/tencent/tvkbeacon/event/open/EventType;)Lcom/tencent/tvkbeacon/event/open/BeaconEvent$Builder;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Lcom/tencent/tvkbeacon/event/open/BeaconEvent$Builder;->withAppKey(Ljava/lang/String;)Lcom/tencent/tvkbeacon/event/open/BeaconEvent$Builder;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0, p2}, Lcom/tencent/tvkbeacon/event/open/BeaconEvent$Builder;->withParams(Ljava/util/Map;)Lcom/tencent/tvkbeacon/event/open/BeaconEvent$Builder;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/tencent/tvkbeacon/event/open/BeaconEvent$Builder;->build()Lcom/tencent/tvkbeacon/event/open/BeaconEvent;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/tvkbeacon/event/open/BeaconReport;->getInstance()Lcom/tencent/tvkbeacon/event/open/BeaconReport;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1, p0}, Lcom/tencent/tvkbeacon/event/open/BeaconReport;->report(Lcom/tencent/tvkbeacon/event/open/BeaconEvent;)Lcom/tencent/tvkbeacon/event/open/EventResult;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget p1, p0, Lcom/tencent/tvkbeacon/event/open/EventResult;->errorCode:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz p1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string p2, "e sr:b efoe iEpear=Itlntentv vd"

    const-string/jumbo p2, "nvri=bv ntIdfor:e teptdela eeE "

    const/4 v3, 0x6

    const-string/jumbo p2, "reImndttpaied!nlvo:=fte rv e  e"

    const-string/jumbo p2, "reportEvent: failed! eventId = "

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    iget-wide v0, p0, Lcom/tencent/tvkbeacon/event/open/EventResult;->eventID:J

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string p2, "e =oourroedC"

    const-string/jumbo p2, "rCeooru= ,de"

    const/4 v3, 0x7

    const-string p2, " rerobCd=oer"

    const-string p2, ", errorCode="

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget p0, p0, Lcom/tencent/tvkbeacon/event/open/EventResult;->errorCode:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string p1, "PptpeauceBppWaoRTorne"

    const-string/jumbo p1, "oWepeapprrcTpRonBtPea"

    const/4 v3, 0x7

    const-string/jumbo p1, "poBroaepprPrTatpeRncW"

    const-string p1, "TPBeaconReportWrapper"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p1, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method public static a(Ljava/lang/String;Ljava/util/Map;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string v0, "1G023007q00OqDBY"

    const-string v0, "200B000YqD107OG3"

    const/4 v2, 0x1

    const-string v0, "37sD0001O20B0GY0"

    const-string v0, "00000GODBG3702Y1"

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p0, v0, p1}, Lcom/tencent/thumbplayer/common/a/b;->a(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method
