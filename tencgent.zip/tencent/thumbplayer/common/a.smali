.class public Lcom/tencent/thumbplayer/common/a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/tplayer/a/a/a;


# instance fields
.field private a:Lcom/tencent/thumbplayer/adapter/a/b;


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/adapter/a/b;)V
    .locals 2
    .param p1    # Lcom/tencent/thumbplayer/adapter/a/b;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/common/a;->a:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(Z)Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~s~~n~   @f @@iom.c@-@@t~~ u~~~o @~s@~d1 loKiv~aot  @~ 4@l~~b@ yo  @@@fi//~o~b~ @@~ M@ ~S@~ b~r"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/common/a;->a:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo v1, "snemPmyeferIlttlprPaoI"

    const-string/jumbo v1, "yrsloTaeepPrtfImItelPn"

    const/4 v3, 0x5

    const-string v1, "eaeloIpytePIoPlrTnrfmt"

    const-string v1, "TPPlayerInfoGetterImpl"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string p1, "a sarbfcitnl dynsl sra ieumcBnprtuaael,t atd airestlpmiyume"

    const-string/jumbo p1, "rlamaryyf suB ,eatr maeeeniisttailprusasnnm    cpuddactiltl"

    const/4 v3, 0x7

    const-string p1, "e s eluauycm u ptstapslalnunc ,deftmiaitiay Bsrne trlrsirda"

    const-string/jumbo p1, "playerBase is null, return default dynamic statistic params"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v1, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    new-instance p1, Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p1}, Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lcom/tencent/thumbplayer/adapter/a/b;->c(Z)Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez p1, :cond_1

    const/4 v3, 0x6

    const-string/jumbo p1, "salrp ypnm cnaemap ,c aeae dnsirtro utmootrrss mat tcfdtnitie crfauo"

    const-string/jumbo p1, "nroaoi  s rnir mipfaeertr mrctuatc dysfteont tmosea tmausa,l cdapcan"

    const-string p1, "a cetcmaqe  pdomutti ,mu sn froerterln taadssocf ciapttrnrnyim gasra"

    const-string p1, "cannot get params from core, return default dynamic statistic params"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v1, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance p1, Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;

    const/4 v3, 0x4

    invoke-direct {p1}, Lcom/tencent/thumbplayer/core/player/TPDynamicStatisticParams;-><init>()V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object p1
.end method

.method public a()Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/common/a;->a:Lcom/tencent/thumbplayer/adapter/a/b;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const-string/jumbo v1, "oesInrPlmreePftbIyGalt"

    const-string v1, "TtlmebIoItfnyPPralGere"

    const/4 v3, 0x2

    const-string/jumbo v1, "rmTmPypfeterPeltaInolI"

    const-string v1, "TPPlayerInfoGetterImpl"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string/jumbo v0, "oln ouelusrt waapeBlyusfleal aryrrpg,sip nder nafeaual em t"

    const-string/jumbo v0, "selro ut u,p Brernlaspnaayn pufa germ alfull alwreylteaides"

    const/4 v3, 0x1

    const-string v0, " ynurbdBplfwulnslt euar llr,smr sy ae ganta aeae eirfaplope"

    const-string/jumbo v0, "playerBase is null, return default general play flow params"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0

    :cond_0
    invoke-interface {v0}, Lcom/tencent/thumbplayer/adapter/a/b;->u()Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string/jumbo v0, "ft nopunrmua ml  ea,gtl  notamaaeprcwfealfdnype sgorar eoacprrlu ret"

    const-string/jumbo v0, "rrp atopaldnt , aano  lr sgpmrr rrape macetoenmewfgealofutuy cean lf"

    const/4 v3, 0x7

    const-string v0, "cncserrpnpsoot er  pmltf apgalteferawma d n nau rmy,tageuaalfro lero"

    const-string v0, "cannot get params from core, return default general play flow params"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/player/TPGeneralPlayFlowParams;-><init>()V

    :cond_1
    const/4 v3, 0x7

    return-object v0
.end method
