.class public Lcom/tencent/thumbplayer/common/TPInternalOptionalID;
.super Ljava/lang/Object;


# static fields
.field public static final OPTION_ID_EXTERNAL_DOWNLOAD_SETTING:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method
