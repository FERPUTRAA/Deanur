.class public Lcom/tencent/thumbplayer/core/common/TPNativeFeatureType;
.super Ljava/lang/Object;


# static fields
.field public static final TP_FEATURE_NONE:I = -0x1

.field public static final TP_SUBTITLE_RGBA_OUTPUT:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method
