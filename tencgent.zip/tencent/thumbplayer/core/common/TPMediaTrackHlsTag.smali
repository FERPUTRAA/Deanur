.class public Lcom/tencent/thumbplayer/core/common/TPMediaTrackHlsTag;
.super Ljava/lang/Object;


# instance fields
.field public bandwidth:J

.field public codecs:Ljava/lang/String;

.field public framerate:F

.field public groupId:Ljava/lang/String;

.field public language:Ljava/lang/String;

.field public name:Ljava/lang/String;

.field public resolution:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/high16 v0, -0x40800000    # -1.0f

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackHlsTag;->framerate:F

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x3

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-wide v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackHlsTag;->bandwidth:J

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method
