.class public final Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;
    }
.end annotation


# static fields
.field private static final DEFAULT_MAX_BITRATE:I = 0xea600

.field private static final DEFAULT_MAX_CHANNELNUM:I = 0x2

.field private static final DEFAULT_MAX_HEIGHT:I = 0x2d0

.field private static final DEFAULT_MAX_SAMPLERATE:I = 0xbb80

.field private static final DEFAULT_MAX_WIDTH:I = 0x500

.field private static final DEFAULT_MIN_BITRATE:I = 0x1f40

.field private static final TAG:Ljava/lang/String; = "TPCodecUtils"

.field private static final mAudioDecoderWhiteList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final mVideoSoftwareDecoderWhiteList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private adaptiveDec:Z

.field private colorFormats:[I

.field private decMimeType:Ljava/lang/String;

.field private decName:Ljava/lang/String;

.field private maxBitRate:I

.field private maxChannels:I

.field private maxFrameRate:I

.field private maxHeight:I

.field private maxLumaFrameRate:I

.field private maxLumaHeight:I

.field private maxLumaWidth:I

.field private maxSampleRate:I

.field private maxSupportedInstances:I

.field private maxWidth:I

.field private profileLevels:[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

.field private secureDec:Z

.field private softwareAudioDec:Z

.field private softwareVideoDec:Z

.field private tunnelingDec:Z


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->mVideoSoftwareDecoderWhiteList:Ljava/util/ArrayList;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v1, "cdsdpdscna.eervro.9io2"

    const-string v1, ".iscdoraencr.do2d9edvp"

    const/4 v3, 0x7

    const-string v1, "e9.mr2c..ovicapndddode"

    const-string v1, "c2.android.vp9.decoder"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string/jumbo v1, "l.dXov.gdmM9Oooocreepg"

    const-string v1, "dXomdeOpgglroM.9eoce.v"

    const/4 v3, 0x5

    const-string v1, "er9.gbeMeopcdl.gvdoOX."

    const-string v1, "OMX.google.vp9.decoder"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo v1, "nidraducr.d.8dpvcoee2o"

    const-string/jumbo v1, "rvoeoceicprdd2nod.8a.d"

    const/4 v3, 0x3

    const-string v1, "cpr.io.prcdd8.aevd2dno"

    const-string v1, "c2.android.vp8.decoder"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const-string v1, "dbclgeOrq.dv.ogp8oeeo."

    const-string v1, "ddevrbelXcoO8e.po..ggo"

    const/4 v3, 0x1

    const-string/jumbo v1, "gMsv.eO.codogle.pXreo8"

    const-string v1, "OMX.google.vp8.decoder"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v1, ".aomro.vrni2deducde.cd"

    const-string/jumbo v1, "o2creduniod.d.rda.e1cv"

    const/4 v3, 0x0

    const-string v1, "ao1.ocrd2are.voeci.ddd"

    const-string v1, "c2.android.av1.decoder"

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->mAudioDecoderWhiteList:Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Landroid/media/MediaCodecInfo$CodecCapabilities;)V
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x6

    invoke-direct {p0}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->reset()V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    iput-object p2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->decName:Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->decMimeType:Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isVideo()Z

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v7, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/4 v2, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-eqz v0, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {p0, p2}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isVideoSoftwareOnly(Ljava/lang/String;)Z

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-eqz v0, :cond_0

    const/4 v8, 0x7

    move v0, v1

    move v0, v1

    const/4 v8, 0x0

    move v0, v1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    move v0, v2

    move v0, v2

    const/4 v8, 0x0

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->softwareVideoDec:Z

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isAudio()Z

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-eqz v0, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {p0, p2}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isAudioSoftwareOnly(Ljava/lang/String;)Z

    move-result p2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-eqz p2, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x1

    move p2, v1

    move p2, v1

    const/4 v8, 0x3

    move p2, v1

    move p2, v1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    goto :goto_1

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    move p2, v2

    move p2, v2

    const/4 v8, 0x4

    move p2, v2

    move p2, v2

    :goto_1
    const/4 v8, 0x5

    iput-boolean p2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->softwareAudioDec:Z

    const/4 v8, 0x3

    if-eqz p3, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {p0, p3}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isAdaptive(Landroid/media/MediaCodecInfo$CodecCapabilities;)Z

    move-result p2

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-eqz p2, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    move p2, v1

    move p2, v1

    const/4 v8, 0x6

    move p2, v1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    goto :goto_2

    :cond_2
    const/4 v8, 0x3

    move p2, v2

    move p2, v2

    const/4 v8, 0x3

    move p2, v2

    move p2, v2

    :goto_2
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    iput-boolean p2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->adaptiveDec:Z

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-eqz p3, :cond_3

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-direct {p0, p3}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isTunneling(Landroid/media/MediaCodecInfo$CodecCapabilities;)Z

    move-result p2

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-eqz p2, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    move p2, v1

    move p2, v1

    const/4 v8, 0x3

    move p2, v1

    move p2, v1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    goto :goto_3

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x2

    move p2, v2

    move p2, v2

    const/4 v8, 0x6

    move p2, v2

    move p2, v2

    :goto_3
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    iput-boolean p2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->tunnelingDec:Z

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    if-eqz p3, :cond_4

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-direct {p0, p3}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isSecure(Landroid/media/MediaCodecInfo$CodecCapabilities;)Z

    move-result p2

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-eqz p2, :cond_4

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    goto :goto_4

    :cond_4
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    move v1, v2

    move v1, v2

    const/4 v8, 0x7

    move v1, v2

    move v1, v2

    :goto_4
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    iput-boolean v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->secureDec:Z

    const/4 v8, 0x1

    if-eqz p3, :cond_6

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    iget-object p2, p3, Landroid/media/MediaCodecInfo$CodecCapabilities;->profileLevels:[Landroid/media/MediaCodecInfo$CodecProfileLevel;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-eqz p2, :cond_6

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    array-length p2, p2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-lez p2, :cond_6

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    new-instance p2, Ljava/util/ArrayList;

    const/4 v7, 0x7

    move v8, v7

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x6

    iget-object v0, p3, Landroid/media/MediaCodecInfo$CodecCapabilities;->profileLevels:[Landroid/media/MediaCodecInfo$CodecProfileLevel;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    array-length v1, v0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    move v3, v2

    move v3, v2

    const/4 v8, 0x1

    move v3, v2

    move v3, v2

    :goto_5
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-ge v3, v1, :cond_5

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    aget-object v4, v0, v3

    const/4 v7, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    new-instance v5, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget v6, v4, Landroid/media/MediaCodecInfo$CodecProfileLevel;->profile:I

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x2

    iget v4, v4, Landroid/media/MediaCodecInfo$CodecProfileLevel;->level:I

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-direct {v5, p0, v6, v4}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;-><init>(Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;II)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    invoke-virtual {p2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    goto :goto_5

    :cond_5
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    new-array v0, v0, [Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

    const/4 v8, 0x4

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    check-cast p2, [Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    iput-object p2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->profileLevels:[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    goto :goto_6

    :cond_6
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    new-array p2, v2, [Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    iput-object p2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->profileLevels:[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

    :goto_6
    const/4 v8, 0x4

    if-eqz p3, :cond_7

    const/4 v8, 0x7

    iget-object p2, p3, Landroid/media/MediaCodecInfo$CodecCapabilities;->colorFormats:[I

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-eqz p2, :cond_7

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    array-length v0, p2

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-lez v0, :cond_7

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    array-length v0, p2

    const/4 v7, 0x3

    move v8, v7

    invoke-static {p2, v0}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    iput-object p2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->colorFormats:[I

    const/4 v8, 0x1

    goto :goto_7

    :cond_7
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    new-array p2, v2, [I

    const/4 v8, 0x6

    iput-object p2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->colorFormats:[I

    :goto_7
    const/4 v8, 0x6

    invoke-direct {p0, p3}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxSupportedInstances(Landroid/media/MediaCodecInfo$CodecCapabilities;)I

    move-result p2

    const/4 v8, 0x2

    const/4 v7, 0x5

    iput p2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxSupportedInstances:I

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string p2, "bpvod"

    const-string/jumbo p2, "ivpdo"

    const-string p2, "duive"

    const-string/jumbo p2, "video"

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-eqz p2, :cond_9

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-eqz p3, :cond_9

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {p3}, Landroid/media/MediaCodecInfo$CodecCapabilities;->getVideoCapabilities()Landroid/media/MediaCodecInfo$VideoCapabilities;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-eqz p1, :cond_8

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxWidth(Landroid/media/MediaCodecInfo$VideoCapabilities;)I

    move-result p2

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    iput p2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxWidth:I

    const/4 v8, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxHeight(Landroid/media/MediaCodecInfo$VideoCapabilities;)I

    move-result p2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    iput p2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxHeight:I

    const/4 v7, 0x4

    shl-int/2addr v8, v7

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxSupportedFrameRate(Landroid/media/MediaCodecInfo$VideoCapabilities;)I

    move-result p2

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    iput p2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxLumaFrameRate:I

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {p1}, Landroid/media/MediaCodecInfo$VideoCapabilities;->getSupportedFrameRates()Landroid/util/Range;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {p1}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    check-cast p1, Ljava/lang/Integer;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxFrameRate:I

    :cond_8
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    return-void

    :cond_9
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-string/jumbo p2, "oqpui"

    const-string/jumbo p2, "oduqi"

    const/4 v8, 0x4

    const-string/jumbo p2, "uoaqd"

    const-string p2, "audio"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-eqz p1, :cond_a

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-eqz p3, :cond_a

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {p3}, Landroid/media/MediaCodecInfo$CodecCapabilities;->getAudioCapabilities()Landroid/media/MediaCodecInfo$AudioCapabilities;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-eqz p1, :cond_a

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxSampleRate(Landroid/media/MediaCodecInfo$AudioCapabilities;)I

    move-result p2

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    iput p2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxSampleRate:I

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxBitRate(Landroid/media/MediaCodecInfo$AudioCapabilities;)I

    move-result p2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    iput p2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxBitRate:I

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxChannels(Landroid/media/MediaCodecInfo$AudioCapabilities;)I

    move-result p1

    const/4 v8, 0x6

    const/4 v7, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxChannels:I

    :cond_a
    const/4 v8, 0x5

    const/4 v7, 0x0

    return-void
.end method

.method private getMaxBitRate(Landroid/media/MediaCodecInfo$AudioCapabilities;)I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ s~~~~oti4@i/~ S1 ~~~fa~ ol@dt@ o~~ b@~@b ~l~@ @ i@~omKv@~@o@ n @ ~/~ @.~@@@~ @@@-rsoybMu  cf~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/media/MediaCodecInfo$AudioCapabilities;->getBitrateRange()Landroid/util/Range;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance p1, Landroid/util/Range;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/16 v0, 0x1f40

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    const v1, 0xea600

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p1, v0, v1}, Landroid/util/Range;-><init>(Ljava/lang/Comparable;Ljava/lang/Comparable;)V

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    check-cast p1, Ljava/lang/Integer;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    return p1
.end method

.method private getMaxChannels(Landroid/media/MediaCodecInfo$AudioCapabilities;)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    invoke-virtual {p1}, Landroid/media/MediaCodecInfo$AudioCapabilities;->getMaxInputChannelCount()I

    move-result p1

    const/4 v1, 0x5

    return p1

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    const/4 p1, 0x2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    return p1
.end method

.method private getMaxHeight(Landroid/media/MediaCodecInfo$VideoCapabilities;)I
    .locals 4

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/media/MediaCodecInfo$VideoCapabilities;->getSupportedHeights()Landroid/util/Range;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance p1, Landroid/util/Range;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/16 v1, 0x2d0

    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p1, v0, v1}, Landroid/util/Range;-><init>(Ljava/lang/Comparable;Ljava/lang/Comparable;)V

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    check-cast p1, Ljava/lang/Integer;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    return p1
.end method

.method private getMaxSampleRate(Landroid/media/MediaCodecInfo$AudioCapabilities;)I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/media/MediaCodecInfo$AudioCapabilities;->getSupportedSampleRateRanges()[Landroid/util/Range;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    move v2, v1

    const/4 p1, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz p1, :cond_1

    const/4 v2, 0x1

    array-length v0, p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-lez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    array-length v0, p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    aget-object p1, p1, v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    check-cast p1, Ljava/lang/Integer;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return p1

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    const p1, 0xbb80

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return p1
.end method

.method private final getMaxSupportedFrameRate(Landroid/media/MediaCodecInfo$VideoCapabilities;)I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/16 p1, 0x1e

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    return p1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxHeight:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Landroid/media/MediaCodecInfo$VideoCapabilities;->getSupportedWidthsFor(I)Landroid/util/Range;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxLumaWidth:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxWidth:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/media/MediaCodecInfo$VideoCapabilities;->getSupportedHeightsFor(I)Landroid/util/Range;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxLumaHeight:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxWidth:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-virtual {p1, v1, v0}, Landroid/media/MediaCodecInfo$VideoCapabilities;->getSupportedFrameRatesFor(II)Landroid/util/Range;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    check-cast p1, Ljava/lang/Double;

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/Double;->intValue()I

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    return p1
.end method

.method private getMaxSupportedInstances(Landroid/media/MediaCodecInfo$CodecCapabilities;)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p1}, Landroid/media/MediaCodecInfo$CodecCapabilities;->getMaxSupportedInstances()I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    return p1

    :cond_0
    const/4 v0, 0x1

    move v1, v0

    const/4 p1, 0x5

    const/4 p1, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x0

    return p1
.end method

.method private getMaxWidth(Landroid/media/MediaCodecInfo$VideoCapabilities;)I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/media/MediaCodecInfo$VideoCapabilities;->getSupportedWidths()Landroid/util/Range;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    new-instance p1, Landroid/util/Range;

    const/4 v3, 0x0

    const/4 v0, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/16 v1, 0x500

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {p1, v0, v1}, Landroid/util/Range;-><init>(Ljava/lang/Comparable;Ljava/lang/Comparable;)V

    :goto_0
    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    check-cast p1, Ljava/lang/Integer;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    return p1
.end method

.method private isAdaptive(Landroid/media/MediaCodecInfo$CodecCapabilities;)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    const-string/jumbo v0, "ikambel-yscvpadpt"

    const-string v0, "dlsackpaepi-bayvt"

    const/4 v2, 0x3

    const-string v0, "btyaokapeaadpcil-"

    const-string v0, "adaptive-playback"

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/media/MediaCodecInfo$CodecCapabilities;->isFeatureSupported(Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p1, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return p1
.end method

.method private isAudioSoftwareOnly(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x6

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const-string v0, ".xolobgmemo"

    const-string/jumbo v0, "oxommgo..le"

    const/4 v2, 0x5

    const-string/jumbo v0, "goxmo.ugo.e"

    const-string/jumbo v0, "omx.google."

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-nez v0, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string v0, "ai.roodp2.c"

    const-string/jumbo v0, "i.coo.ddra2"

    const/4 v2, 0x7

    const-string v0, "2aciddo.q.n"

    const-string v0, "c2.android."

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez v0, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    const-string/jumbo v0, "o2seogg.c."

    const-string v0, ".o.oebcg2g"

    const/4 v2, 0x4

    const-string/jumbo v0, "lc2m.geog."

    const-string v0, "c2.google."

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_1

    :cond_1
    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    goto :goto_2

    :cond_2
    :goto_1
    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 p1, 0x1

    :goto_2
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return p1
.end method

.method private isSecure(Landroid/media/MediaCodecInfo$CodecCapabilities;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string/jumbo v0, "lpucokeresyu-ab"

    const-string v0, "b-akeuupyalersc"

    const/4 v2, 0x1

    const-string v0, "eayaeb-puccsblk"

    const-string/jumbo v0, "secure-playback"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Landroid/media/MediaCodecInfo$CodecCapabilities;->isFeatureSupported(Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return p1
.end method

.method private isTunneling(Landroid/media/MediaCodecInfo$CodecCapabilities;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string/jumbo v0, "plnuapuelbek-nyad"

    const-string v0, "bnaednep-uaplytkl"

    const/4 v2, 0x6

    const-string/jumbo v0, "ynnduelpae-lcptak"

    const-string/jumbo v0, "tunneled-playback"

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/media/MediaCodecInfo$CodecCapabilities;->isFeatureSupported(Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    return p1
.end method

.method private isVideoSoftwareOnly(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x0

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x5

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-string/jumbo v0, "om.xoeqgqo."

    const-string/jumbo v0, "exg..gmoqoo"

    const-string/jumbo v0, "omx.google."

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-nez v0, :cond_4

    const-string/jumbo v0, "fmsg.oxpsef"

    const-string/jumbo v0, "gmsfx.f.epo"

    const/4 v2, 0x3

    const-string/jumbo v0, "ff.m.pmexmo"

    const-string/jumbo v0, "omx.ffmpeg."

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez v0, :cond_4

    const/4 v2, 0x5

    const-string v0, ".cexo.sm"

    const-string/jumbo v0, "omx.sec."

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string v0, ".s.w"

    const-string/jumbo v0, "w.s."

    const/4 v2, 0x7

    const-string v0, ".w.s"

    const-string v0, ".sw."

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-nez v0, :cond_4

    :cond_1
    const/4 v2, 0x2

    const-string v0, "ceodsbwde..dodc.moevvq.memvcihxro"

    const-string/jumbo v0, "msome.cevo..owdxehcvqedeom.cdvrdi"

    const/4 v2, 0x0

    const-string v0, "e.oxceu.dcri.cmdveweocomqevhods.v"

    const-string/jumbo v0, "omx.qcom.video.decoder.hevcswvdec"

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez v0, :cond_4

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-string/jumbo v0, "xto.eiepi.qmdvdood.or"

    const-string v0, "emcooidx..qotd.eidrov"

    const/4 v2, 0x3

    const-string/jumbo v0, "omx.qti.video.decoder"

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string/jumbo v0, "ws"

    const-string/jumbo v0, "sw"

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-nez v0, :cond_4

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string/jumbo v0, "ico2..naqdr"

    const-string/jumbo v0, "r.aodb2n.ic"

    const/4 v2, 0x3

    const-string v0, "2.sri.ocdad"

    const-string v0, "c2.android."

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez v0, :cond_4

    const/4 v2, 0x0

    const-string v0, "..emgo2lgc"

    const-string/jumbo v0, "ge..ogul2c"

    const/4 v2, 0x3

    const-string/jumbo v0, "lcogo.eg.o"

    const-string v0, "c2.google."

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz p1, :cond_3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    goto :goto_1

    :cond_3
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    goto :goto_2

    :cond_4
    :goto_1
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 p1, 0x5

    const/4 p1, 0x1

    :goto_2
    const/4 v2, 0x4

    const/4 v1, 0x4

    return p1
.end method

.method private reset()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v0, ""

    const/4 v3, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->decName:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->decMimeType:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->softwareVideoDec:Z

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->adaptiveDec:Z

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->tunnelingDec:Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->secureDec:Z

    const/4 v2, 0x2

    move v3, v2

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->profileLevels:[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->colorFormats:[I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxSupportedInstances:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v0, 0x1e

    const/4 v3, 0x6

    const/4 v2, 0x3

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxLumaFrameRate:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxFrameRate:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/16 v0, 0x500

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxWidth:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/16 v1, 0x2d0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxHeight:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxLumaWidth:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxLumaHeight:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const v0, 0xbb80

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxSampleRate:I

    const/4 v3, 0x5

    const v0, 0xea600

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxBitRate:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxChannels:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method


# virtual methods
.method public final getColorFormats()[I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->colorFormats:[I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method public final getDecoderLumaHeight()I
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxLumaHeight:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public final getDecoderLumaWidth()I
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxLumaWidth:I

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method public final getDecoderMaxFrameRate()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxFrameRate:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method public final getDecoderMaxFrameRateForMaxLuma()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxLumaFrameRate:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public final getDecoderMaxHeight()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxHeight:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method public final getDecoderMaxWidth()I
    .locals 3

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxWidth:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public final getDecoderMimeType()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->decMimeType:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public final getDecoderName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->decName:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public final getMaxAudioBitRate()I
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxBitRate:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public final getMaxAudioChannels()I
    .locals 3

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxChannels:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public final getMaxAudioSampleRate()I
    .locals 3

    const/4 v2, 0x6

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxSampleRate:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method public final getMaxProfileLevel()Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 v1, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-direct {v0, p0, v1, v1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;-><init>(Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;II)V

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    iget-object v2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->profileLevels:[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

    const/4 v7, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    array-length v3, v2

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    move v4, v1

    move v4, v1

    const/4 v8, 0x3

    move v4, v1

    move v4, v1

    :goto_0
    const/4 v8, 0x4

    if-ge v1, v3, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    aget-object v5, v2, v1

    const/4 v8, 0x4

    iget v6, v5, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->level:I

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-lt v6, v4, :cond_0

    move-object v0, v5

    move-object v0, v5

    move-object v0, v5

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    move v4, v6

    move v4, v6

    const/4 v8, 0x6

    move v4, v6

    move v4, v6

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x0

    or-int/2addr v8, v7

    goto :goto_0

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    return-object v0
.end method

.method public final getMaxSupportedInstances()I
    .locals 3

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->maxSupportedInstances:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0
.end method

.method public final getProfileLevels()[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->profileLevels:[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public final isAudio()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->decMimeType:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v0, 0x0

    move v2, v0

    move v2, v0

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v1, "d/paob"

    const-string v1, "/poiad"

    const/4 v3, 0x4

    const-string/jumbo v1, "u/idau"

    const-string v1, "audio/"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    return v0
.end method

.method public final isAudioSofwareDecoder()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->softwareAudioDec:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public final isSecureDecoder()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->secureDec:Z

    const/4 v2, 0x5

    const/4 v1, 0x2

    return v0
.end method

.method public final isValidDecoder()Z
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isVideo()Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v1, 0x1

    and-int/2addr v5, v1

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v0, :cond_2

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->softwareVideoDec:Z

    const/4 v5, 0x4

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->mVideoSoftwareDecoderWhiteList:Ljava/util/ArrayList;

    const/4 v5, 0x2

    const/4 v4, 0x6

    iget-object v3, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->decName:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    return v2

    :cond_1
    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    return v1

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isAudio()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v0, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->softwareAudioDec:Z

    const/4 v5, 0x2

    if-nez v0, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->mAudioDecoderWhiteList:Ljava/util/ArrayList;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v3, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->decName:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    if-eqz v0, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    goto :goto_1

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    return v2

    :cond_4
    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    return v1

    :cond_5
    const/4 v5, 0x5

    return v2
.end method

.method public final isVideo()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->decMimeType:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v1, "ipdeqv"

    const-string v1, "dvqei/"

    const/4 v3, 0x3

    const-string/jumbo v1, "video/"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    return v0
.end method

.method public final isVideoSofwareDecoder()Z
    .locals 3

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->softwareVideoDec:Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method
