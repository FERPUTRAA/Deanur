.class public Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginCallbackToNative;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$HeadsetPluginListener;


# static fields
.field private static final TAG:Ljava/lang/String; = "TPHeadsetPluginCallback"


# instance fields
.field private mNativeContext:J


# direct methods
.method private constructor <init>(J)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-wide p1, p0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginCallbackToNative;->mNativeContext:J

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method private native _onAudioRouteChanged(Ljava/util/Set;Ljava/util/Set;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation
.end method

.method private getNativeContext()J
    .locals 4
    .annotation build Lcom/tencent/thumbplayer/core/common/TPMethodCalledByNative;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ts  @s@~@ o 4f~~ orM@f.- ~@@~y ~i @S ~~~/~ mcbo@@~lo b/~o~i@ ~ on~t~@u @1bl@d@@@v~~a ~@i~@@@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginCallbackToNative;->mNativeContext:J

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-wide v0
.end method

.method private registerCallback()V
    .locals 2
    .annotation build Lcom/tencent/thumbplayer/core/common/TPMethodCalledByNative;
    .end annotation

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->addHeadsetPluginListener(Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$HeadsetPluginListener;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method private unregisterCallback()V
    .locals 2
    .annotation build Lcom/tencent/thumbplayer/core/common/TPMethodCalledByNative;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->removeHeadsetPluginListener(Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$HeadsetPluginListener;)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onHeadsetPlugin(Ljava/util/Set;Ljava/util/Set;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string/jumbo v1, "psum tulnuoPHdtdloeOtsea ::gn"

    const-string/jumbo v1, "uOsp utsndn:eoellHadPu go:tst"

    const-string/jumbo v1, "uet:o dOgls peoundontsPHlau:i"

    const-string/jumbo v1, "onHeadsetPlugin: oldOutputs: "

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v1, ":,umsbtew tnO "

    const-string/jumbo v1, "ew msu,tO:n pt"

    const/4 v4, 0x2

    const-string/jumbo v1, "ue :wnup Os,tt"

    const-string v1, ", newOutputs: "

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v1, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string/jumbo v2, "lnHTbalpCktiuesPceadPgo"

    const-string/jumbo v2, "kbnPoHgeulceiPsltadCaaT"

    const/4 v4, 0x2

    const-string v2, "PkPuTHdlqectaalesnalgCi"

    const-string v2, "TPHeadsetPluginCallback"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {v1, v2, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {p0, p1, p2}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginCallbackToNative;->_onAudioRouteChanged(Ljava/util/Set;Ljava/util/Set;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-void
.end method
