.class Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "Builder"
.end annotation


# instance fields
.field private mCpuProducerToAllDefinitionDecCapabilities:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Ljava/util/HashMap<",
            "Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance v0, Landroid/util/SparseArray;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;->mCpuProducerToAllDefinitionDecCapabilities:Landroid/util/SparseArray;

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method addVideoDecCap(ILcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;Ljava/lang/String;)Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;->mCpuProducerToAllDefinitionDecCapabilities:Landroid/util/SparseArray;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    check-cast v0, Ljava/util/HashMap;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x3

    const/4 v2, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;->mCpuProducerToAllDefinitionDecCapabilities:Landroid/util/SparseArray;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v1, p1, v0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, p2, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p0
.end method

.method build()Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel;-><init>(Lcom/tencent/thumbplayer/core/common/TPCodecUtils$1;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;->mCpuProducerToAllDefinitionDecCapabilities:Landroid/util/SparseArray;

    const/4 v3, 0x4

    iput-object v1, v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel;->mCpuProducerToAllDefinitionDecTable:Landroid/util/SparseArray;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0
.end method
