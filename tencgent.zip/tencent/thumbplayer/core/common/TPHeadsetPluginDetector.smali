.class public Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$HeadsetPluginReceiver;,
        Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$HeadsetPluginListener;
    }
.end annotation


# static fields
.field private static final AUDIO_TYPE_BLUETOOTH_A2DP:I = 0x2

.field private static final AUDIO_TYPE_BUILTIN_OTHERS:I = 0x63

.field private static final AUDIO_TYPE_BUILTIN_SPEAKER:I = 0x0

.field private static final AUDIO_TYPE_HEADPHONES:I = 0x1

.field private static final TAG:Ljava/lang/String; = "TPHeadsetPluginDetector"

.field private static hasRegisterReceiver:Z

.field private static isInitted:Z

.field private static listeners:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$HeadsetPluginListener;",
            ">;"
        }
    .end annotation
.end field

.field private static mContextRef:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/content/Context;",
            ">;"
        }
    .end annotation
.end field

.field private static mCurOutputs:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static mReceiver:Landroid/content/BroadcastReceiver;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    new-instance v0, Ljava/util/LinkedList;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->listeners:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->mCurOutputs:Ljava/util/Set;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic access$000()Ljava/util/Set;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l stv@ .o1o   @t@@ry-m~ @ @bKo o~iM@~ ~~o@~@@//i@@@ ~ @~@~~f@~sd~~b@~ ~i~ @ n~ub~l ~~So@ ~4f ac~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->mCurOutputs:Ljava/util/Set;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method static synthetic access$100()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->getAudioOutputs()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method static synthetic access$200(Ljava/util/Set;Ljava/util/Set;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->notifyAudioOutputStateChange(Ljava/util/Set;Ljava/util/Set;)V

    const/4 v1, 0x2

    return-void
.end method

.method public static addHeadsetPluginListener(Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$HeadsetPluginListener;)V
    .locals 4

    const/4 v3, 0x1

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const/4 v3, 0x6

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const/4 v2, 0x7

    xor-int/2addr v3, v2

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->listeners:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {v1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-boolean p0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->hasRegisterReceiver:Z

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v2, 0x4

    move v3, v2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->registerReceiver()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 p0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    sput-boolean p0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->hasRegisterReceiver:Z

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void

    :catchall_0
    move-exception p0

    const/4 v2, 0x0

    move v3, v2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public static deinit()V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const/4 v5, 0x1

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    sget-boolean v1, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->isInitted:Z

    const/4 v5, 0x7

    const/4 v4, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->mContextRef:Ljava/lang/ref/WeakReference;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-nez v1, :cond_0

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->clear()V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    sput-boolean v1, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->isInitted:Z

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string/jumbo v1, "rePmnstPutHecgaediDsoTl"

    const-string/jumbo v1, "losgeePtutrHcesidtDaPnT"

    const/4 v5, 0x7

    const-string v1, "eeueoDrdPgncoeHtTisaPtl"

    const-string v1, "TPHeadsetPluginDetector"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo v2, "tndeiblereePHogDtu cu isd!emdtcencais"

    const-string/jumbo v2, "netm PsiaceegtctiouiH!eren deldcDdesu"

    const/4 v5, 0x2

    const-string v2, "ceeg!nuiodicedutetutDensH r ctiPeelda"

    const-string v2, "HeadsetPluginDetector deinit succeed!"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v3, 0x2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v3, v1, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    monitor-exit v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-void

    :cond_1
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    monitor-exit v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-void

    :catchall_0
    move-exception v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    throw v1
.end method

.method private static getAudioManager()Landroid/media/AudioManager;
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x0

    sget-boolean v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->isInitted:Z

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v2, "dHrTaigpoPeteneclDtoPts"

    const-string/jumbo v2, "telgoTnDceeePirdtPoHtsa"

    const/4 v6, 0x4

    const-string/jumbo v2, "gertdtHDqePTcoeltnaiPus"

    const-string v2, "TPHeadsetPluginDetector"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v3, 0x4

    const/4 v6, 0x2

    if-eqz v0, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->mContextRef:Ljava/lang/ref/WeakReference;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-nez v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    goto :goto_1

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    check-cast v0, Landroid/content/Context;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-nez v0, :cond_1

    const/4 v5, 0x6

    move v6, v5

    const-string/jumbo v0, "lmsba tev  ner aA,isauolaidilgxgit!od eucila,bMetid n fysn"

    const-string v0, "dA , bicl gtay  nit!namv rdxfetul,anssiueoi lagdMiaoileenb"

    const/4 v6, 0x7

    const-string/jumbo v0, "igvmlm ait aexAanduft sbn dediy!sronl ,gacetiina oiell, uM"

    const-string/jumbo v0, "getAudioManager failed, context is null, maybe is invalid!"

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v3, v2, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-object v1

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string v4, "auuio"

    const/4 v6, 0x0

    const-string/jumbo v4, "oaduo"

    const-string v4, "audio"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v0, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast v0, Landroid/media/AudioManager;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-nez v0, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string v0, "ef Mdbgdluuireoaaidaianllupg iAne Mo,sr !"

    const-string v0, "M ieufgprnaaeigl  di ounoAdlelduiaMs!ag,r"

    const/4 v6, 0x3

    const-string/jumbo v0, "neriAiuuldeaito ldgdonarMegal!  us ,guiMa"

    const-string/jumbo v0, "getAudioManager failed, audioMgr is null!"

    const/4 v6, 0x7

    const/4 v5, 0x4

    goto :goto_0

    :cond_2
    const/4 v6, 0x6

    return-object v0

    :cond_3
    :goto_1
    const/4 v6, 0x3

    const-string/jumbo v0, "nnd latprDn ,etatoeeidsMielaegirdyos  iHeeu!iicuotaf PtttggnAe"

    const-string/jumbo v0, "getAudioManager failed, HeadsetPluginDetector is not init yet!"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_0
.end method

.method private static getAudioOutputs()Ljava/util/Set;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    new-instance v0, Ljava/util/HashSet;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->getAudioManager()Landroid/media/AudioManager;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-nez v1, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    return-object v0

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    const/4 v2, 0x2

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {v1, v2}, Landroid/media/AudioManager;->getDevices(I)[Landroid/media/AudioDeviceInfo;

    move-result-object v1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    if-eqz v1, :cond_4

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    array-length v3, v1

    const/4 v9, 0x6

    or-int/2addr v10, v9

    const/4 v4, 0x0

    move v10, v4

    const/4 v9, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    move v5, v4

    const/4 v10, 0x6

    move v5, v4

    move v5, v4

    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    if-ge v5, v3, :cond_4

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    aget-object v6, v1, v5

    const/4 v10, 0x7

    const/4 v9, 0x5

    invoke-virtual {v6}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result v7

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    if-ne v7, v2, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    :goto_1
    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-interface {v0, v6}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x4

    goto :goto_2

    :cond_1
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {v6}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result v7

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    const/16 v8, 0x8

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    if-ne v7, v8, :cond_2

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    goto :goto_1

    :cond_2
    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v6}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result v6

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    const/4 v7, 0x3

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-ne v6, v7, :cond_3

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/4 v6, 0x1

    const/4 v9, 0x4

    or-int/2addr v10, v9

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v10, 0x2

    const/4 v9, 0x0

    goto :goto_1

    :cond_3
    :goto_2
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    add-int/lit8 v5, v5, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    goto :goto_0

    :cond_4
    const/4 v9, 0x5

    move v10, v9

    return-object v0
.end method

.method public static getCurrentRoutes()Ljava/util/Set;
    .locals 3
    .annotation build Lcom/tencent/thumbplayer/core/common/TPMethodCalledByNative;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->mCurOutputs:Ljava/util/Set;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public static init(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x4

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const/4 v4, 0x1

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const/4 v3, 0x4

    const/4 v4, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    sget-boolean v1, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->isInitted:Z

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    monitor-exit v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/ref/WeakReference;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {v1, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    sput-object v1, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->mContextRef:Ljava/lang/ref/WeakReference;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 p0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    sput-boolean p0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->isInitted:Z

    const/4 v4, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->initCurrentOutputs()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string/jumbo p0, "stDPacetqPoeedrtquHnTgi"

    const-string p0, "DTetPeerqgHudttsnPecioa"

    const-string p0, "PesetdrciusteHneTPoDtga"

    const-string p0, "TPHeadsetPluginDetector"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v1, "estm!iu srttncHcdo eeniueegasiPedtl"

    const-string/jumbo v1, "u sseeHlrecsctdeaitgno cinu!itePdet"

    const/4 v4, 0x7

    const-string/jumbo v1, "ucPnol  etsiteeH!ddcaecgstnoiereiDu"

    const-string v1, "HeadsetPluginDetector init succeed!"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v2, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {v2, p0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void

    :catchall_0
    move-exception p0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    throw p0
.end method

.method private static initCurrentOutputs()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->getAudioOutputs()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->mCurOutputs:Ljava/util/Set;

    const/4 v2, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public static isAudioRouteTypeOn(I)Z
    .locals 3
    .annotation build Lcom/tencent/thumbplayer/core/common/TPMethodCalledByNative;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->mCurOutputs:Ljava/util/Set;

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 p0, 0x4

    const/4 v2, 0x0

    const/4 p0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {v0, p0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return p0
.end method

.method public static isBluetoothPlugin()Z
    .locals 3
    .annotation build Lcom/tencent/thumbplayer/core/common/TPMethodCalledByNative;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->getAudioManager()Landroid/media/AudioManager;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    or-int/2addr v2, v1

    return v0

    :cond_0
    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/media/AudioManager;->isBluetoothA2dpOn()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public static isHeadsetPlugin()Z
    .locals 3
    .annotation build Lcom/tencent/thumbplayer/core/common/TPMethodCalledByNative;
    .end annotation

    const/4 v1, 0x5

    const/4 v1, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->getAudioManager()Landroid/media/AudioManager;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    return v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroid/media/AudioManager;->isWiredHeadsetOn()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method private static notifyAudioOutputStateChange(Ljava/util/Set;Ljava/util/Set;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x3

    if-eqz p0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz p1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-interface {p0}, Ljava/util/Set;->size()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-interface {p1}, Ljava/util/Set;->size()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-ne v0, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {p1, p0}, Ljava/util/Set;->containsAll(Ljava/util/Collection;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v0, 0x1

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    sput-object p1, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->mCurOutputs:Ljava/util/Set;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const/4 v4, 0x3

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const/4 v3, 0x2

    move v4, v3

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->listeners:Ljava/util/List;

    const/4 v3, 0x3

    move v4, v3

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v2, :cond_2

    const/4 v3, 0x5

    shl-int/2addr v4, v3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    check-cast v2, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$HeadsetPluginListener;

    const/4 v3, 0x4

    move v4, v3

    invoke-interface {v2, p0, p1}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$HeadsetPluginListener;->onHeadsetPlugin(Ljava/util/Set;Ljava/util/Set;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    goto :goto_1

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void

    :catchall_0
    move-exception p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    throw p0
.end method

.method private static registerDeviceCallback()Z
    .locals 5
    .annotation build Landroidx/annotation/w0;
        api = 0x17
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->getAudioManager()Landroid/media/AudioManager;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    return v0

    :cond_0
    const/4 v4, 0x4

    new-instance v1, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$1;

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-direct {v1}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$1;-><init>()V

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/media/AudioManager;->registerAudioDeviceCallback(Landroid/media/AudioDeviceCallback;Landroid/os/Handler;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    return v0
.end method

.method private static registerReceiver()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->registerDeviceCallback()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->mReceiver:Landroid/content/BroadcastReceiver;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-nez v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$HeadsetPluginReceiver;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {v0, v1}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$HeadsetPluginReceiver;-><init>(Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$1;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->mReceiver:Landroid/content/BroadcastReceiver;

    :cond_1
    const/4 v3, 0x1

    const/4 v3, 0x2

    sget-boolean v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->isInitted:Z

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo v1, "uoPsPbncHtreDeTgidtelte"

    const-string v1, "TPHeadsetPluginDetector"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v2, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v0, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->mContextRef:Ljava/lang/ref/WeakReference;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-nez v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto :goto_0

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    check-cast v0, Landroid/content/Context;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez v0, :cond_3

    const/4 v4, 0x1

    const-string/jumbo v0, "irevr ugtlnyuencsia!tdcfaibRvsn elxr i li oatsed elem,e,mei"

    const-string v0, " s,mneditadrosi iiavtf!cieeur  laegvc lrmlibRteensee  ,ynlx"

    const/4 v4, 0x6

    const-string/jumbo v0, "lnfers patue,,e!ic iiRetrydnsiiov llaaitdbre eeinels gmcvx "

    const-string/jumbo v0, "registerReceiver failed, context is null, maybe is invalid!"

    const/4 v4, 0x2

    invoke-static {v2, v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    new-instance v1, Landroid/content/IntentFilter;

    const/4 v3, 0x7

    and-int/2addr v4, v3

    invoke-direct {v1}, Landroid/content/IntentFilter;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v2, "TEeDGHonqE_tcaUAtnLdnai.Po.in.Sotr"

    const-string v2, "P.EdonSo_EoUtnHG..rtitaiednDLnaATc"

    const/4 v4, 0x2

    const-string/jumbo v2, "nesiEoiUnPattdDi_SoLArTEc.Gand.Hnt"

    const-string v2, "android.intent.action.HEADSET_PLUG"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string v2, "OU.mmINESd_IroAOieaDGBbiY_dONCInd."

    const-string v2, "YA.OObCNMIIm_odBedrSda.OEGn_iIUNiD"

    const/4 v4, 0x1

    const-string/jumbo v2, "oNmSo.eDCANniIY_.daaGIdM_EdOOiOIUB"

    const-string v2, "android.media.AUDIO_BECOMING_NOISY"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v2, ".GNdfb.dioNnECDodACtue_2tl.TOclOETNSHCiaa.TotErpi_IuhoNbpea.on"

    const-string v2, "INlN.eub.SoNtdAnECoioToduat_arNOliEtOETac...G2ATopnehCpCDHfdi_"

    const/4 v4, 0x3

    const-string v2, "T.oSeouCpNdtuAirhnoONa.i_dGlENrT_E.aNbidI.tEDlTapHncoC2f.oCtAO"

    const-string v2, "android.bluetooth.a2dp.profile.action.CONNECTION_STATE_CHANGED"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    sget-object v2, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->mReceiver:Landroid/content/BroadcastReceiver;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v2, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void

    :cond_4
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const-string/jumbo v0, "ovseefepc r ritpPldeigeaePiDRttdeisrsTneiHe!ntei g  teaciylttr,nu"

    const-string v0, "efedgrnpttteosr T,eladDce t !ereniitt PitevcrHaeeile sngoRiiuPyis"

    const/4 v4, 0x5

    const-string v0, " ael estqogfdenrerlg,sPTen!Htc aeiiRyeie  vtrsnoiDtitettueeiiPcd "

    const-string/jumbo v0, "registerReceiver failed, TPHeadsetPluginDetector is not init yet!"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v2, v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method public static removeHeadsetPluginListener(Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$HeadsetPluginListener;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const/4 v3, 0x7

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;

    const/4 v3, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->listeners:Ljava/util/List;

    const/4 v3, 0x2

    invoke-interface {v1, p0}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object p0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->listeners:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-boolean p0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->hasRegisterReceiver:Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->unregisterReceiver()V

    const/4 p0, 0x4

    move v3, p0

    const/4 p0, 0x0

    move v3, p0

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    sput-boolean p0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->hasRegisterReceiver:Z

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    throw p0
.end method

.method private static unregisterReceiver()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    sget-boolean v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->isInitted:Z

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v1, "tPsqTesgtoalHutcDeeePir"

    const-string v1, "deDcHtPrqttiesoageuleTP"

    const/4 v4, 0x3

    const-string/jumbo v1, "sDgmuPloceaPedHTrittete"

    const-string v1, "TPHeadsetPluginDetector"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v2, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->mContextRef:Ljava/lang/ref/WeakReference;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    check-cast v0, Landroid/content/Context;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-nez v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string/jumbo v0, "uso o tryddieseeirvab,a !anf ismivct,lesrR enilxt geillie n"

    const-string/jumbo v0, "nesry nii !xinl Reetf,ga seeelviursbia vstireetioacddl m l,"

    const/4 v4, 0x3

    const-string v0, "a,u!rbssinedtinvxli,i Rt ree eaigbfeleicdest oc vni yelar l"

    const-string/jumbo v0, "registerReceiver failed, context is null, maybe is invalid!"

    const/4 v4, 0x7

    invoke-static {v2, v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->mReceiver:Landroid/content/BroadcastReceiver;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void

    :cond_2
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo v0, "imrl !ueseevaugtteid,sPtttrsiirecitoedialifD ey   ncnet ronRHeg"

    const-string/jumbo v0, "fi meeitcreeoetaogtlsuiein,rers sd !HPtRg eDiivdyetirteltn n ca"

    const/4 v4, 0x3

    const-string v0, "eeneH!eptrasceDtiRiieilet ci te adiletutdogifn Prosn egtvys ,er"

    const-string/jumbo v0, "registerReceiver failed, HeadsetPluginDetector is not init yet!"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v2, v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-void
.end method
