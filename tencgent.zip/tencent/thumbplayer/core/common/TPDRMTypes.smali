.class public Lcom/tencent/thumbplayer/core/common/TPDRMTypes;
.super Ljava/lang/Object;


# static fields
.field public static final NONE:I = -0x1

.field public static final UNITEND:I = 0x2

.field public static final WIDEVINE:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method
