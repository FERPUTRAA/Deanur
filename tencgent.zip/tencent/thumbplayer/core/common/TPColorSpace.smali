.class public Lcom/tencent/thumbplayer/core/common/TPColorSpace;
.super Ljava/lang/Object;


# static fields
.field public static final TP_COL_SPC_BT2020_CL:I = 0xa

.field public static final TP_COL_SPC_BT2020_NCL:I = 0x9

.field public static final TP_COL_SPC_BT470BG:I = 0x5

.field public static final TP_COL_SPC_BT709:I = 0x1

.field public static final TP_COL_SPC_CHROMA_DERIVED_CL:I = 0xd

.field public static final TP_COL_SPC_CHROMA_DERIVED_NCL:I = 0xc

.field public static final TP_COL_SPC_FCC:I = 0x4

.field public static final TP_COL_SPC_ICTCP:I = 0xe

.field public static final TP_COL_SPC_RESERVED:I = 0x3

.field public static final TP_COL_SPC_RGB:I = 0x0

.field public static final TP_COL_SPC_SMPTE170M:I = 0x6

.field public static final TP_COL_SPC_SMPTE2085:I = 0xb

.field public static final TP_COL_SPC_SMPTE240M:I = 0x7

.field public static final TP_COL_SPC_UNSPECIFIED:I = 0x2

.field public static final TP_COL_SPC_YCGCO:I = 0x8


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method
