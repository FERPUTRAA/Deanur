.class public Lcom/tencent/thumbplayer/core/common/TPPostProcessFrame;
.super Ljava/lang/Object;


# instance fields
.field public channelLayout:J

.field public channels:I

.field public data:[[B

.field public format:I

.field public height:I

.field public linesize:[I

.field public mediaType:I

.field public nbSamples:I

.field public perfData:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field public ptsUs:J

.field public rotation:I

.field public sampleAspectRatioDen:I

.field public sampleAspectRatioNum:I

.field public sampleRate:I

.field public width:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method
