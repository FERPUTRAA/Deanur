.class public Lcom/tencent/thumbplayer/core/common/TPBufferStrategy;
.super Ljava/lang/Object;


# static fields
.field public static final TP_BUFFER_STRATEGY_AUTO:I = -0x1

.field public static final TP_BUFFER_STRATEGY_JITTER:I = 0x2

.field public static final TP_BUFFER_STRATEGY_MIN:I = 0x3

.field public static final TP_BUFFER_STRATEGY_NORMAL:I = 0x1

.field public static final TP_BUFFER_STRATEGY_UNABLE:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method
