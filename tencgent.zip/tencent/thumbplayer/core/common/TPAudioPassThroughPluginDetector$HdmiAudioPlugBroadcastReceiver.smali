.class Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$HdmiAudioPlugBroadcastReceiver;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "HdmiAudioPlugBroadcastReceiver"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$1;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$HdmiAudioPlugBroadcastReceiver;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@@s   -o~. ~@@ ~b @~1 ~uMy~ bia b@S~@oo@@4n~~s@t/ @lcdK o~@ ~o@ii~@rv  m~@@~ l @~o~~~~t~@ /f@~f@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string/jumbo v0, "etvmscvoiH ueeiidaB :grrdlRoisoecPAumneedc"

    const-string/jumbo v0, "orsdRgBrediu:e vHcisden iocecAveiomuaRletP"

    const-string/jumbo v0, "oeinoeoB cuRAa tRlvrvdai:eodsiHeecdiegPcrm"

    const-string v0, "HdmiAudioPlugBroadcastReceiver onReceive: "

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v0, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string v1, "TssmlhgPoProeteDrduicTtAgnouuPih"

    const/4 v6, 0x2

    const-string/jumbo v1, "ircPAbhutoPtTueisPgdosDegnhluoTr"

    const-string v1, "TPAudioPassThroughPluginDetector"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v0, v1, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const-string p1, "AiAITeuSD.atd_eoPT.OrdUn_rE.GoaidmxU"

    const-string/jumbo p1, "iTdUoxUaO.er.eLa_.dAPEtAIoimGTrDn_dS"

    const/4 v6, 0x1

    const-string p1, "a.dmA_ipSePdndTIEoUeLaxTaGUr.rA.DitO"

    const-string p1, "android.media.extra.AUDIO_PLUG_STATE"

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x1

    or-int/2addr v5, v2

    const/4 v6, 0x2

    invoke-virtual {p2, p1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-nez p1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v3, 0x1

    const/4 v5, 0x5

    move v6, v5

    if-ne p1, v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    move v2, v3

    move v2, v3

    const/4 v6, 0x4

    move v2, v3

    move v2, v3

    :cond_1
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string/jumbo v4, "lhiddcteqHsPeu rsd:BhaAcutsRuiSuiemoaoaTgPaiedogrtoav"

    const-string v4, "HdmiAudioPlugBroadcastReceiver audioPassThroughState:"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    move v6, v5

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string p1, " nsP:iubg"

    const-string/jumbo p1, "i :nPbglu"

    const/4 v6, 0x1

    const-string/jumbo p1, "uglm Pb:n"

    const-string p1, " bPlugin:"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {v0, v1, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    new-instance p1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string/jumbo v0, "uaaCotmdxe.iNr.NdEI.OaeornSDd"

    const-string v0, "adtareuCa.dGISN..oinDeNExdmOr"

    const/4 v6, 0x7

    const-string v0, "dEa.abOdeCxDdnNrNS.eiioaGItmr"

    const-string v0, "android.media.extra.ENCODINGS"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getIntArrayExtra(Ljava/lang/String;)[I

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string v1, ".ULmeNuCeat_HAM.dxidEXiOdNaT.nNArrCao"

    const-string v1, "MrtEiLHpr_CnAUCx.aXNTaa.OieNoedd.mNdA"

    const/4 v6, 0x4

    const-string v1, "android.media.extra.MAX_CHANNEL_COUNT"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/16 v3, 0x8

    const/4 v6, 0x7

    invoke-virtual {p2, v1, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct {p1, v0, p2}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;-><init>([II)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {p1}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->access$100(Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v2}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->access$200(Z)V

    const/4 v6, 0x0

    return-void
.end method
