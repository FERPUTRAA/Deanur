.class public final Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk$LibraryBrokenHandler;
    }
.end annotation


# static fields
.field private static mContext:Landroid/content/Context;

.field private static final mLoadedLibs:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/ref/WeakReference<",
            "Ljava/lang/ClassLoader;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->mLoadedLibs:Ljava/util/HashMap;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->mContext:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic access$000()Landroid/content/Context;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "fbs@  @v@~@~i~4o@~r~ 1@ ob~@ @~ cb~i~a~  @@~ f / ~y~Sl/ ~~~~t@@ @ t~u .ol-i@do@@M@~@~ @nom@~os~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->mContext:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic access$100(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->extractAllLibraries(Landroid/content/Context;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method private static extractAllLibraries(Landroid/content/Context;)V
    .locals 11

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-nez p0, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    return-void

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->generateAbiList()Ljava/util/List;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x0

    const-string v1, "bilmosevrc_"

    const-string v1, "cesl_birvro"

    const/4 v10, 0x2

    const-string v1, "erc_orevbil"

    const-string/jumbo v1, "recover_lib"

    const/4 v2, 0x0

    const/4 v10, 0x4

    invoke-virtual {p0, v1, v2}, Landroid/content/Context;->getDir(Ljava/lang/String;I)Ljava/io/File;

    move-result-object v1

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x4

    iget-object p0, p0, Landroid/content/pm/ApplicationInfo;->sourceDir:Ljava/lang/String;

    const/4 v9, 0x6

    or-int/2addr v10, v9

    new-instance v2, Ljava/util/zip/ZipFile;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-direct {v2, p0}, Ljava/util/zip/ZipFile;-><init>(Ljava/lang/String;)V

    :try_start_0
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x5

    new-instance p0, Ljava/util/HashSet;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-direct {p0}, Ljava/util/HashSet;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x6

    const-string v3, "/[l]+b0_Z-Za_9o0-bsi-A-](-+/az-9=/=liAb[z.--/"

    const-string/jumbo v3, "lib/[A-Za-z0-9-_=]+/lib([A-Za-z0-9-_=]+)\\.so"

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-static {v3}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v2}, Ljava/util/zip/ZipFile;->entries()Ljava/util/Enumeration;

    move-result-object v4

    :cond_1
    :goto_0
    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-interface {v4}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v5

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    if-eqz v5, :cond_4

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-interface {v4}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v5

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    check-cast v5, Ljava/util/zip/ZipEntry;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {v5}, Ljava/util/zip/ZipEntry;->getName()Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-nez v7, :cond_3

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    const-string v7, "./."

    const-string v7, "../"

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {v6, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-nez v6, :cond_2

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    goto :goto_1

    :cond_2
    const/4 v10, 0x4

    new-instance p0, Ljava/lang/Exception;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const-string/jumbo v0, "o to,hu.nw c. tea/rnir"

    const-string v0, "contain ../, throw err"

    const/4 v10, 0x1

    const/4 v9, 0x1

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    :goto_1
    const/4 v9, 0x2

    const/4 v9, 0x2

    invoke-virtual {v5}, Ljava/util/zip/ZipEntry;->getName()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {v3, v5}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v5

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v5}, Ljava/util/regex/Matcher;->matches()Z

    move-result v6

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    if-eqz v6, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    const/4 v6, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {v5, v6}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p0, v5}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v6

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-nez v6, :cond_1

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    new-instance v6, Ljava/io/File;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    new-instance v7, Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    const-string/jumbo v8, "ibl"

    const-string v8, "bil"

    const/4 v10, 0x0

    const-string/jumbo v8, "lib"

    const-string/jumbo v8, "lib"

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    const-string v8, ".os"

    const-string/jumbo v8, "o.s"

    const/4 v10, 0x5

    const-string/jumbo v8, "so."

    const-string v8, ".so"

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-direct {v6, v1, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v10, 0x3

    invoke-static {v2, v5, v0, v6}, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->extractLibrary(Ljava/util/zip/ZipFile;Ljava/lang/String;Ljava/util/List;Ljava/io/File;)Z

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {p0, v5}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x4

    goto/16 :goto_0

    :cond_4
    const/4 v9, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v2}, Ljava/util/zip/ZipFile;->close()V

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    return-void

    :catchall_0
    move-exception p0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {v2}, Ljava/util/zip/ZipFile;->close()V

    const/4 v9, 0x7

    move v10, v9

    throw p0
.end method

.method private static extractLibrary(Ljava/util/zip/ZipFile;Ljava/lang/String;Ljava/util/List;Ljava/io/File;)Z
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/zip/ZipFile;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/io/File;",
            ")Z"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p3}, Ljava/io/File;->isFile()Z

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    return v1

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x5

    if-eqz v0, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    check-cast p2, Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string/jumbo v3, "lb/i"

    const-string/jumbo v3, "i/bl"

    const/4 v6, 0x7

    const-string v3, "/ibl"

    const-string/jumbo v3, "lib/"

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const-string p2, "/lbi"

    const-string/jumbo p2, "li/b"

    const/4 v6, 0x5

    const-string/jumbo p2, "l/ib"

    const-string p2, "/lib"

    const/4 v6, 0x4

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string/jumbo p1, "os."

    const-string/jumbo p1, "so."

    const/4 v6, 0x0

    const-string/jumbo p1, "os."

    const-string p1, ".so"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p0, p1}, Ljava/util/zip/ZipFile;->getEntry(Ljava/lang/String;)Ljava/util/zip/ZipEntry;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-nez p1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    return v2

    :cond_1
    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/util/zip/ZipEntry;->getName()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez v0, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string v0, "./."

    const-string v0, "../"

    const/4 v6, 0x5

    const-string v0, "../"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz p2, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    return v2

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p0, p1}, Ljava/util/zip/ZipFile;->getInputStream(Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    new-instance p1, Ljava/io/FileOutputStream;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-direct {p1, p3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/16 p2, 0x800

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-array v0, p2, [B

    :goto_0
    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0, v0, v2, p2}, Ljava/io/InputStream;->read([BII)I

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v4, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eq v3, v4, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p1, v0, v2, v3}, Ljava/io/FileOutputStream;->write([BII)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_0

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/io/FileOutputStream;->close()V

    :try_start_1
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p3}, Ljava/io/File;->setReadOnly()Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    return v1

    :catchall_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    return v2

    :catchall_1
    move-exception p2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/io/FileOutputStream;->close()V

    const/4 v6, 0x2

    throw p2

    :cond_4
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    return v2
.end method

.method public static find(Ljava/lang/String;Landroid/content/Context;)Ljava/lang/String;
    .locals 10

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v0, 0x0

    move v9, v0

    if-nez p1, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x7

    return-object v0

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    const/4 v1, 0x0

    :try_start_0
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-class v2, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;

    const-class v2, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;

    const/4 v9, 0x6

    const-class v2, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;

    const-class v2, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v2}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-class v3, Ljava/lang/ClassLoader;

    const-class v3, Ljava/lang/ClassLoader;

    const-class v3, Ljava/lang/ClassLoader;

    const-class v3, Ljava/lang/ClassLoader;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-string/jumbo v4, "nfydLimprba"

    const-string/jumbo v4, "ynfmibLadir"

    const/4 v9, 0x3

    const-string/jumbo v4, "fniriaybqrL"

    const-string/jumbo v4, "findLibrary"

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    const/4 v5, 0x1

    const/4 v8, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    new-array v6, v5, [Ljava/lang/Class;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    const-class v7, Ljava/lang/String;

    const-class v7, Ljava/lang/String;

    const/4 v9, 0x0

    const-class v7, Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    aput-object v7, v6, v1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v3, v4, v6}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v3, v5}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    new-array v4, v5, [Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    aput-object p0, v4, v1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v3, v2, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    check-cast v2, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :catch_0
    const/4 v9, 0x2

    const/4 v8, 0x5

    if-nez v0, :cond_1

    const/4 v8, 0x4

    move v9, v8

    const-string v2, "bosrvi_oerc"

    const-string v2, "c_rooierveb"

    const/4 v9, 0x3

    const-string v2, "coemrrbi_vl"

    const-string/jumbo v2, "recover_lib"

    const/4 v9, 0x6

    invoke-virtual {p1, v2, v1}, Landroid/content/Context;->getDir(Ljava/lang/String;I)Ljava/io/File;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x6

    new-instance v1, Ljava/io/File;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    const-string v3, "bli"

    const-string/jumbo v3, "ibl"

    const/4 v9, 0x1

    const-string/jumbo v3, "ibl"

    const-string/jumbo v3, "lib"

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x5

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-string/jumbo p0, "o.s"

    const-string p0, ".so"

    const/4 v8, 0x7

    move v9, v8

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    move v9, v8

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-direct {v1, p1, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v1}, Ljava/io/File;->canRead()Z

    move-result p0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-eqz p0, :cond_1

    const/4 v8, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    :cond_1
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    return-object v0
.end method

.method private static generateAbiList()Ljava/util/List;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    const/4 v1, 0x3

    const/4 v8, 0x0

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    const-string v1, "essoootrantsiyrpr.e.SibdodP"

    const-string/jumbo v1, "rrs.ebydsioonpadreoSe.tsitP"

    const/4 v8, 0x6

    const-string v1, ".eseobmPtispron.erytroSisdd"

    const-string v1, "android.os.SystemProperties"

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    const/4 v2, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    new-array v3, v2, [Ljava/lang/Class;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-class v4, Ljava/lang/String;

    const-class v4, Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v5, 0x5

    const/4 v8, 0x2

    const/4 v5, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    aput-object v4, v3, v5

    const/4 v7, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string/jumbo v4, "gte"

    const-string/jumbo v4, "get"

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v1, v4, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x4

    new-array v3, v2, [Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string/jumbo v4, "r.poaouipccd.ub.tu"

    const-string/jumbo v4, "ro.product.cpu.abi"

    const/4 v7, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    aput-object v4, v3, v5

    const/4 v7, 0x2

    move v8, v7

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x4

    invoke-virtual {v1, v4, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x5

    const/4 v7, 0x3

    check-cast v3, Ljava/lang/String;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-eqz v3, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v6

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-lez v6, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v7, 0x0

    const/4 v8, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string v3, ".pruc2opdu.ort.bpiu"

    const-string/jumbo v3, "uo.biruccot.dpu.r2p"

    const/4 v8, 0x6

    const-string/jumbo v3, "oc..iparqopduubt2c."

    const-string/jumbo v3, "ro.product.cpu.abi2"

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    aput-object v3, v2, v5

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {v1, v4, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    if-eqz v1, :cond_1

    const/4 v8, 0x4

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-lez v2, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string v1, "basimrp"

    const-string/jumbo v1, "prbieam"

    const/4 v8, 0x1

    const-string/jumbo v1, "irmmaba"

    const-string v1, "armeabi"

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    return-object v0
.end method

.method public static load(Ljava/lang/String;Ljava/lang/ClassLoader;Landroid/content/Context;)Z
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/4 v0, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz p0, :cond_6

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eqz v1, :cond_6

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-nez p1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    goto/16 :goto_1

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    sput-object p2, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->mContext:Landroid/content/Context;

    const/4 v5, 0x4

    or-int/2addr v6, v5

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->mLoadedLibs:Ljava/util/HashMap;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    monitor-enter v1

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v1, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    check-cast v2, Ljava/lang/ref/WeakReference;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz v2, :cond_1

    const/4 v5, 0x5

    move v6, v5

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    check-cast v2, Ljava/lang/ClassLoader;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v3, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v4, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v2, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-ne v2, p1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const-string/jumbo p1, "las=oydaerl saa oLslld en cm!qaaoarrlhaeCe"

    const-string p1, "aas rlrlq hes dcaaonllCaoe!Lmrly deadase=a"

    const/4 v6, 0x4

    const-string p1, "= esdbdaL asec!rnmayCeaalosr eolaaldr ahll"

    const-string p1, "callerClassLoader has already load ! name="

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v3, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    monitor-exit v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    return v4

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    new-instance p1, Ljava/lang/UnsatisfiedLinkError;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string v0, "asb//ruL i"

    const-string v0, "/bs yirLa/"

    const-string v0, "/rrb/aLpyi"

    const-string v0, "Library \'"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string p0, "eed adsaqaldnror.  o L/mfi tsfwedl/yasC e"

    const-string p0, " L.msew l daCfdsolyfesr edtebiaa/ an /ord"

    const/4 v6, 0x3

    const-string p0, "Lasad o  sbdldrewffnoe sClsity ./aaeea/d "

    const-string p0, "\' was loaded by a different ClassLoader."

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-direct {p1, p0}, Ljava/lang/UnsatisfiedLinkError;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    throw p1

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v6, 0x0

    const/4 v5, 0x1

    if-nez p2, :cond_4

    :try_start_1
    const/4 v6, 0x5

    const-string/jumbo p2, "ltnm rylx.nysaiaySaobneeblL,em o s,toait=u lmc dd"

    const-string p2, "context is null,load by System.loadLibrary,name= "

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p2, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v3, p2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->reflectSystemLoadLibrary(Ljava/lang/String;Ljava/lang/ClassLoader;)V

    const/4 v5, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    monitor-enter v1
    :try_end_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :try_start_2
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-instance p2, Ljava/lang/ref/WeakReference;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {p2, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v1, p0, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    monitor-exit v1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    return v4

    :catchall_0
    move-exception p1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    throw p1
    :try_end_3
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    :catch_0
    move-exception p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    new-instance p2, Ljava/lang/UnsatisfiedLinkError;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string/jumbo v0, "naaioo iblrFiyad d:lloer"

    const-string/jumbo v0, "liodoaaniigl Flrd:ya bre"

    const/4 v6, 0x2

    const-string/jumbo v0, "yiaglb rnlFl raiide :boa"

    const-string v0, "Failed loading library: "

    const/4 v6, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-direct {p2, p0}, Ljava/lang/UnsatisfiedLinkError;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x4

    check-cast p0, Ljava/lang/UnsatisfiedLinkError;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    throw p0

    :catch_1
    move-exception p1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-instance p2, Ljava/lang/UnsatisfiedLinkError;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string/jumbo v0, "r rna uigbiaa:boFil elly"

    const-string/jumbo v0, "ragllb ail abro ydi:Fnei"

    const/4 v6, 0x6

    const-string/jumbo v0, "iroidynpgablr laiFael : "

    const-string v0, "Failed loading library: "

    const/4 v6, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {p2, p0}, Ljava/lang/UnsatisfiedLinkError;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p2, p0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    check-cast p0, Ljava/lang/UnsatisfiedLinkError;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    throw p0

    :cond_4
    const/4 v5, 0x5

    const/4 v5, 0x5

    const-string/jumbo v1, "eub_ericqor"

    const-string v1, "erroc_uilbe"

    const/4 v6, 0x1

    const-string v1, "_esberriocv"

    const-string/jumbo v1, "recover_lib"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p2, v1, v0}, Landroid/content/Context;->getDir(Ljava/lang/String;I)Ljava/io/File;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    new-instance v1, Ljava/io/File;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    shr-int/2addr v6, v5

    const-string v3, "bli"

    const-string v3, "bli"

    const/4 v6, 0x4

    const-string v3, "bil"

    const-string/jumbo v3, "lib"

    const/4 v5, 0x7

    move v6, v5

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string/jumbo v3, "os."

    const-string v3, ".so"

    const/4 v6, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct {v1, v0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {p0, p1, p2, v1}, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->loadFromRecovery(Ljava/lang/String;Ljava/lang/ClassLoader;Landroid/content/Context;Ljava/io/File;)Ljava/lang/UnsatisfiedLinkError;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-nez v0, :cond_5

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    return v4

    :cond_5
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {p0, p1, p2, v1, v0}, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->loadFromApk(Ljava/lang/String;Ljava/lang/ClassLoader;Landroid/content/Context;Ljava/io/File;Ljava/lang/UnsatisfiedLinkError;)Z

    move-result p0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    return p0

    :catchall_1
    move-exception p0

    :try_start_4
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    monitor-exit v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    throw p0

    :cond_6
    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    return v0
.end method

.method private static loadFromApk(Ljava/lang/String;Ljava/lang/ClassLoader;Landroid/content/Context;Ljava/io/File;Ljava/lang/UnsatisfiedLinkError;)Z
    .locals 6

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x6

    move v4, v1

    :try_start_0
    const/4 v5, 0x6

    invoke-virtual {p2}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object p2, p2, Landroid/content/pm/ApplicationInfo;->sourceDir:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v2, Ljava/util/zip/ZipFile;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-direct {v2, p2}, Ljava/util/zip/ZipFile;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_4
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v3, "unzip apk,name= "

    const/4 v5, 0x7

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo v3, "hPpmakat"

    const-string/jumbo v3, "tkahPapp"

    const/4 v5, 0x6

    const-string/jumbo v3, "p=Phoaat"

    const-string v3, "apkPath="

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v1, 0x2

    const/4 v5, 0x2

    const/4 v4, 0x5

    invoke-static {v1, p2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->generateAbiList()Ljava/util/List;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x0

    invoke-static {v2, p0, p2, p3}, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->extractLibrary(Ljava/util/zip/ZipFile;Ljava/lang/String;Ljava/util/List;Ljava/io/File;)Z

    move-result p2
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_3
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz p2, :cond_2

    :try_start_2
    const/4 v4, 0x7

    move v5, v4

    invoke-virtual {v2}, Ljava/util/zip/ZipFile;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_2

    :try_start_3
    const-string/jumbo p2, "n ,zmbu r n oaopapieaf=dqk"

    const-string p2, "doi=foarqk   nlapzpuaen m,"

    const/4 v5, 0x3

    const-string/jumbo p2, "k a=imuazad ,uon epnpfolmr"

    const-string/jumbo p2, "load from unzip apk,name= "

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v1, p2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->reflectSystemLoad(Ljava/lang/String;Ljava/lang/ClassLoader;)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    sget-object p2, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->mLoadedLibs:Ljava/util/HashMap;

    const/4 v5, 0x0

    const/4 v4, 0x6

    monitor-enter p2
    :try_end_3
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    :try_start_4
    const/4 v4, 0x3

    const/4 v4, 0x2

    new-instance p3, Ljava/lang/ref/WeakReference;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {p3, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p2, p0, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    monitor-exit p2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 p0, 0x1

    const/4 v5, 0x6

    return p0

    :catchall_0
    move-exception p1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    monitor-exit p2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :try_start_5
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    throw p1
    :try_end_5
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_5 .. :try_end_5} :catch_1
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0

    :catch_0
    move-exception p0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-nez p4, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    new-instance p1, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string/jumbo p2, "ri birspvr  n.elgrinylaitdeaceveF"

    const-string/jumbo p2, "irsdete alvnbrlrayenvrc.ei i iFgo"

    const/4 v5, 0x1

    const-string p2, "aay ldreq.anFbivcir irteiloevnrg "

    const-string p2, "Failed recovering native library."

    const/4 v5, 0x3

    const/4 v4, 0x2

    invoke-direct {p1, p2}, Ljava/lang/UnsatisfiedLinkError;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p1, p0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    check-cast p0, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    throw p0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    throw p4

    :catch_1
    move-exception p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-nez p4, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance p2, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string/jumbo p3, "insie earc iy irnaeovdrbleglm:tv a"

    const-string p3, "  imner rrldi:eelncvtaoagraiie bvy"

    const/4 v5, 0x0

    const-string p3, "Fiemrie galtala  enircyr vvndeb:or"

    const-string p3, "Failed recovering native library: "

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p3, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {p2, p0}, Ljava/lang/UnsatisfiedLinkError;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    invoke-virtual {p1}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p2, p0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    check-cast p0, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    throw p0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    throw p4

    :catch_2
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    return v0

    :cond_2
    :try_start_6
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo p2, "ri/loenrbrva deonf C: cyo rat"

    const-string/jumbo p2, "oadvo ter yr cbrr anlf/:iCnei"

    const/4 v5, 0x3

    const-string/jumbo p2, "nyi /bbl  c tarr/Crrfnoe:davi"

    const-string p2, "Can\'t find recover library: "

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p2, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    throw p1
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_3
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    :catchall_1
    move-exception p0

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_1

    :catch_3
    move-exception p0

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :catchall_2
    move-exception p0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto :goto_1

    :catch_4
    move-exception p0

    :goto_0
    :try_start_7
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance p1, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const-string/jumbo p2, "ryFabnubg.ita av vrrilencie redil"

    const-string/jumbo p2, "ncetabevlagierirbvai. or idyr lnF"

    const/4 v5, 0x5

    const-string p2, "cerevrlpi nbair il igyavand.oerFt"

    const-string p2, "Failed recovering native library."

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {p1, p2}, Ljava/lang/UnsatisfiedLinkError;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p1, p0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    check-cast p0, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    throw p0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v1, :cond_3

    :try_start_8
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/util/zip/ZipFile;->close()V
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_5

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    goto :goto_2

    :catch_5
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    return v0

    :cond_3
    :goto_2
    const/4 v5, 0x7

    throw p0
.end method

.method private static loadFromRecovery(Ljava/lang/String;Ljava/lang/ClassLoader;Landroid/content/Context;Ljava/io/File;)Ljava/lang/UnsatisfiedLinkError;
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p3}, Ljava/io/File;->isFile()Z

    move-result p2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v0, 0x2

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    const/4 v1, 0x0

    move v5, v1

    if-eqz p2, :cond_1

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string v2, ",l =e uevc _birodbnaymalre"

    const/4 v5, 0x7

    const-string/jumbo v2, "load by recover_lib,name= "

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {p2, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string v2, "cpeoe=irqevf"

    const-string v2, "=refeorpeicv"

    const/4 v5, 0x2

    const-string v2, "=lsreiocefre"

    const-string/jumbo v2, "recoverfile="

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v0, p2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x7

    const/4 v4, 0x6

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->reflectSystemLoad(Ljava/lang/String;Ljava/lang/ClassLoader;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    sget-object p2, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->mLoadedLibs:Ljava/util/HashMap;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    monitor-enter p2
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    new-instance v2, Ljava/lang/ref/WeakReference;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {v2, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    invoke-virtual {p2, p0, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    monitor-exit p2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-object v1

    :catchall_0
    move-exception v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    throw v2
    :try_end_2
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :catchall_1
    move-exception p1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance p2, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string p3, "b Fmreviegaavoindy lrt:eir  inaecq"

    const-string p3, "avienen qy e: v reoagraFcrilriibdt"

    const/4 v5, 0x6

    const-string p3, "e  voa gncev tlirryloeiaribe:ndrFi"

    const-string p3, "Failed recovering native library: "

    const/4 v5, 0x7

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p3, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {p2, p0}, Ljava/lang/UnsatisfiedLinkError;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x0

    check-cast p0, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    throw p0

    :catch_0
    move-exception p2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p2}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    instance-of v2, v2, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x5

    if-eqz v2, :cond_0

    const/4 v4, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p2}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    check-cast p2, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-instance p1, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo p3, "niretbrF:rv v debcy  ganisolaeiaer"

    const-string/jumbo p3, "t:sea  cenenogavFilrr adiy irviber"

    const/4 v5, 0x6

    const-string p3, "e anriu reiielvFd i gar:lyrbnetcvo"

    const-string p3, "Failed recovering native library: "

    const/4 v5, 0x1

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p3, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x5

    invoke-direct {p1, p0}, Ljava/lang/UnsatisfiedLinkError;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    check-cast p0, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    throw p0

    :catch_1
    move-exception p2

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string/jumbo v2, "orbmea=myei bd, e alelalco_i!fnr v"

    const/4 v5, 0x6

    const-string v2, "eebd cnpllba aav ir edo=yrm!o,lf_e"

    const-string/jumbo v2, "load by recover_lib failed!,name= "

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {v0, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p3}, Ljava/io/File;->delete()Z

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_1

    :cond_1
    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    :goto_1
    :try_start_3
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->reflectSystemLoadLibrary(Ljava/lang/String;Ljava/lang/ClassLoader;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo p3, "lroeoednq aimabydb sStyrl,o =acaefryeLt"

    const-string p3, "defloettyoaiamorm=labdSy crsabrL ,ynee "

    const/4 v5, 0x2

    const-string/jumbo p3, "load by reflectSystemLoadLibrary,name= "

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    invoke-virtual {p3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0, p3}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    sget-object p3, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->mLoadedLibs:Ljava/util/HashMap;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    monitor-enter p3
    :try_end_3
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_3 .. :try_end_3} :catch_3
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    :try_start_4
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p3, p0, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    monitor-exit p3

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-object v1

    :catchall_2
    move-exception p1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    monitor-exit p3
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    :try_start_5
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    throw p1
    :try_end_5
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_5 .. :try_end_5} :catch_3
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_5 .. :try_end_5} :catch_2
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    :catchall_3
    move-exception p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance p2, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string p3, "easrrbeevablelyc: rri oiiFta dvgni"

    const-string/jumbo p3, "igarebcbe:alordinrvtvinF irley  ea"

    const/4 v5, 0x2

    const-string p3, " ivmnr: lygetoncFalri eba eardirev"

    const-string p3, "Failed recovering native library: "

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-virtual {p3, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-direct {p2, p0}, Ljava/lang/UnsatisfiedLinkError;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    check-cast p0, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    throw p0

    :catch_2
    move-exception p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    instance-of p3, p3, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz p3, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x2

    if-nez p2, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p1}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    move-object p2, p0

    move-object p2, p0

    move-object p2, p0

    move-object p2, p0

    const/4 v5, 0x5

    const/4 v4, 0x1

    check-cast p2, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_2

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-instance p2, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string p3, ":b  oidlF vv nuirynreeagaeilaoictr"

    const-string/jumbo p3, "re ry uelFnabv  iraetei:dogaviclin"

    const/4 v5, 0x4

    const-string p3, "aiov:beareiyrbcaln d  rF ervgeiitl"

    const-string p3, "Failed recovering native library: "

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p3, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-direct {p2, p0}, Ljava/lang/UnsatisfiedLinkError;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p1}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p2, p0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    check-cast p0, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    throw p0

    :catch_3
    move-exception p0

    const/4 v5, 0x6

    const/4 v4, 0x3

    if-nez p2, :cond_3

    move-object p2, p0

    move-object p2, p0

    move-object p2, p0

    move-object p2, p0

    :cond_3
    :goto_2
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    return-object p2
.end method

.method private static reflectSystemLoad(Ljava/lang/String;Ljava/lang/ClassLoader;)V
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/4 v2, 0x2

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    new-array v3, v2, [Ljava/lang/Class;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-class v4, Ljava/lang/String;

    const-class v4, Ljava/lang/String;

    const/4 v8, 0x6

    const-class v4, Ljava/lang/String;

    const-class v4, Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v5, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    aput-object v4, v3, v5

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-class v4, Ljava/lang/ClassLoader;

    const/4 v8, 0x5

    const-class v4, Ljava/lang/ClassLoader;

    const-class v4, Ljava/lang/ClassLoader;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/4 v6, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    aput-object v4, v3, v6

    const/4 v8, 0x3

    const-string v4, "aold"

    const-string v4, "doal"

    const/4 v8, 0x2

    const-string v4, "adol"

    const-string/jumbo v4, "load"

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {v1, v4, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v1, v6}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v7, 0x7

    move v8, v7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    aput-object p0, v2, v5

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    aput-object p1, v2, v6

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v1, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    return-void
.end method

.method private static reflectSystemLoadLibrary(Ljava/lang/String;Ljava/lang/ClassLoader;)V
    .locals 9

    const/4 v8, 0x0

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    const/4 v2, 0x2

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    new-array v3, v2, [Ljava/lang/Class;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-class v4, Ljava/lang/String;

    const-class v4, Ljava/lang/String;

    const/4 v8, 0x3

    const-class v4, Ljava/lang/String;

    const-class v4, Ljava/lang/String;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    const/4 v5, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x4

    aput-object v4, v3, v5

    const/4 v8, 0x7

    const-class v4, Ljava/lang/ClassLoader;

    const-class v4, Ljava/lang/ClassLoader;

    const/4 v8, 0x3

    const-class v4, Ljava/lang/ClassLoader;

    const-class v4, Ljava/lang/ClassLoader;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/4 v6, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    aput-object v4, v3, v6

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string v4, "airLolupdar"

    const-string/jumbo v4, "ladLiorpbra"

    const/4 v8, 0x0

    const-string v4, "aylariLpdbo"

    const-string/jumbo v4, "loadLibrary"

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v1, v4, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v1, v6}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v7, 0x2

    and-int/2addr v8, v7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    aput-object p0, v2, v5

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    aput-object p1, v2, v6

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v1, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    return-void
.end method

.method public static setupBrokenLibraryHandler()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {}, Ljava/lang/Thread;->getDefaultUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    new-instance v1, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk$LibraryBrokenHandler;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk$LibraryBrokenHandler;-><init>(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v1}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method
