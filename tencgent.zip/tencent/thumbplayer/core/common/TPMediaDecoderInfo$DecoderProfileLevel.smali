.class final Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "DecoderProfileLevel"
.end annotation


# instance fields
.field public level:I

.field public profile:I

.field final synthetic this$0:Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;


# direct methods
.method public constructor <init>(Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;II)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->this$0:Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput p2, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->profile:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p3, p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->level:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method
