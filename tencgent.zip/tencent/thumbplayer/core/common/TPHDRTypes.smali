.class public Lcom/tencent/thumbplayer/core/common/TPHDRTypes;
.super Ljava/lang/Object;


# static fields
.field public static final HDR10:I = 0x0

.field public static final HDR10PLUS:I = 0x1

.field public static final HDRDOLBYVISION:I = 0x2

.field public static final HDRHLG:I = 0x3

.field public static final HDRVIVID:I = 0x4


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    return-void
.end method
