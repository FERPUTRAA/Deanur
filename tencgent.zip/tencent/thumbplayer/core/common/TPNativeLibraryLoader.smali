.class public Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;
.super Ljava/lang/Object;


# static fields
.field private static final DEFAULT_LIB_PLAYER_CORE_VERSION:Ljava/lang/String; = "2.31.0.134.min"

.field private static final MAIN_PLAYER_CORE_VERSION:Ljava/lang/String; = "2.31.0"

.field private static mIsLibLoaded:Z = false

.field private static mIsLibLoadedLock:Ljava/lang/Object; = null

.field private static final mIsNeedLoadThirdPartiesAndFFmpeg:Z = true

.field private static final mLibIjkPrefix:Ljava/lang/String; = "ijkhlscache-master"

.field private static mLibLoader:Lcom/tencent/thumbplayer/core/common/ITPNativeLibraryExternalLoader; = null

.field private static final mLibNameHasArchSuffix:Z = false

.field private static final mLibPlayerCorePrefix:Ljava/lang/String; = "tpcore-master"

.field private static final mLibThirdPartiesPrefix:Ljava/lang/String; = "tpthirdparties-master"

.field private static final mPlayerCoreSupportMinAndroidAPILevel:I = 0xe


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->mIsLibLoadedLock:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method private static native _getPlayerCoreVersion()Ljava/lang/String;
.end method

.method public static getLibVersion()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~sc-@b~~~4 ~~~~  luo @@~. / 1~ @@@~vt@@~~foyii~  @@@t@ rM~@dfo~  @ @~K~/sl m@a@bi~@~b oo~ @o@Sn"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->getPlayerCoreVersion()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public static getPlayerCoreVersion()Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->_getPlayerCoreVersion()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0

    :catchall_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string v1, " gdm.nsi:Pead4d2ooordbee1i1so*um.hu:n  e oernreas 3.yVte3 ir htntrnrosct-ra. m.vt 0dee,eosrlnil e"

    const-string/jumbo v1, "r seetet.d:o orhiVeiehrnems.ou.31l2gCin- Pednrrtvusnlr*e0ae o 3,rood  .t4 ed dnso ay1inbmcas.etr:"

    const/4 v3, 0x1

    const-string v1, ":u norn ttn-voeoi.s,snmdd. o10eereaob: nc32 nr*suredeia.3yeti1t .mardoCl4iVge d.eooyrrPhs  ele tr"

    const-string/jumbo v1, "getPlayerCoreVersion: *.so is not loaded yet, return the hard-coded version number:2.31.0.134.min"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v3, 0x4

    const-string v0, "214.ib3n0.m3m."

    const-string v0, "3.3m.n.im14201"

    const/4 v3, 0x7

    const-string v0, "3i2.3mu14.1.n0"

    const-string v0, "2.31.0.134.min"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0
.end method

.method public static isLibLoaded()Z
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->loadLibIfNeeded(Landroid/content/Context;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo v2, "iyaae LpNLiTitbrPrddorerLsoabrvaLe: odoe"

    const-string v2, "batboaLery Lesrviorr ooared:aiTLPNdiderL"

    const/4 v4, 0x3

    const-string v2, "brrLatPsqNrey:evooeodraT radaei ibLiridL"

    const-string v2, "TPNativeLibraryLoader isLibLoaded error:"

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v1, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->mIsLibLoadedLock:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    monitor-enter v0

    :try_start_1
    const/4 v3, 0x1

    const/4 v4, 0x1

    sget-boolean v1, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->mIsLibLoaded:Z

    const/4 v3, 0x4

    move v4, v3

    monitor-exit v0

    const/4 v3, 0x4

    move v4, v3

    return v1

    :catchall_1
    move-exception v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    throw v1
.end method

.method private static isMatchJavaAndPlayerCore(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v1, "essVaa:obnji"

    const-string/jumbo v1, "jsonabiVav:e"

    const/4 v6, 0x7

    const-string v1, "aa:mrovsenjV"

    const-string/jumbo v1, "javaVersion:"

    const/4 v5, 0x2

    move v6, v5

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string/jumbo v1, "surroo oneeic,"

    const-string/jumbo v1, "r oecru,seionV"

    const/4 v6, 0x4

    const-string/jumbo v1, "nreicbos e,Vor"

    const-string v1, ", coreVersion:"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v1, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-nez v0, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    goto :goto_1

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string v0, ".//"

    const-string v0, "//."

    const/4 v6, 0x1

    const-string v0, "\\."

    const/4 v6, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    array-length v0, p0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v2, 0x3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-lt v0, v2, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    array-length v0, p1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-ge v0, v2, :cond_1

    const/4 v5, 0x3

    const/4 v5, 0x0

    goto :goto_1

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    move v0, v1

    move v0, v1

    const/4 v6, 0x0

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-ge v0, v2, :cond_3

    const/4 v6, 0x4

    aget-object v3, p0, v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    aget-object v4, p1, v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-nez v3, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto :goto_1

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x0

    goto :goto_0

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v1, 0x1

    :cond_4
    :goto_1
    const/4 v5, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    return v1
.end method

.method private static loadLib(Landroid/content/Context;)Z
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x4

    const-string v1, ":cchaduipu orplba"

    const-string/jumbo v1, "uc:l hcpaobad irp"

    const/4 v9, 0x0

    const-string v1, "aboi huppl: racLd"

    const-string/jumbo v1, "loadLib cpu arch:"

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuArchitecture()I

    move-result v1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/4 v1, 0x2

    const/4 v9, 0x1

    const/4 v8, 0x2

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v9, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getApiLevel()I

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    const/16 v2, 0xe

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    const/4 v3, 0x3

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    const/4 v4, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-ge v0, v2, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    const-string v0, " fuqdnopqiill e raerlvds ce aeto ,"

    const-string/jumbo v0, "scedrlunqil, pe air ae oao tf devl"

    const/4 v9, 0x6

    const-string v0, " lsa osor,pudlelnicfeverdal  it  e"

    const-string/jumbo v0, "so load failed, current api level "

    const/4 v9, 0x4

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getApiLevel()I

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-string v0, "  sm4iatsnsse l1"

    const-string v0, "  si l e4ssstn1a"

    const/4 v9, 0x7

    const-string/jumbo v0, "s4 eol nas1 itsh"

    const-string v0, " is less than 14"

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-static {v3, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    return v4

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuArchitecture()I

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-eq v0, v3, :cond_9

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuArchitecture()I

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    const/4 v2, 0x4

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-eq v0, v2, :cond_9

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuArchitecture()I

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    if-nez v0, :cond_1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    goto/16 :goto_4

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-string/jumbo v0, "ppsdmbaaimsrtee-irtht"

    const-string/jumbo v0, "srtmaedhe-ptrtiispmra"

    const/4 v9, 0x5

    const-string v0, "ahrtrrutt-msieieadpst"

    const-string/jumbo v0, "tpthirdparties-master"

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-string v3, ""

    const-string v3, ""

    const/4 v9, 0x7

    const-string v3, ""

    const-string v3, ""

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v0, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    sget-object v5, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->mLibLoader:Lcom/tencent/thumbplayer/core/common/ITPNativeLibraryExternalLoader;

    const/4 v9, 0x5

    const-string/jumbo v6, "on1m3.0p34.1.."

    const-string v6, "1310o4...m32n."

    const/4 v9, 0x3

    const-string v6, "1..233nmq.i10."

    const-string v6, "2.31.0.134.min"

    const/4 v9, 0x3

    if-eqz v5, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-interface {v5, v0, v6}, Lcom/tencent/thumbplayer/core/common/ITPNativeLibraryExternalLoader;->loadLib(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    goto :goto_0

    :cond_2
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->loadLibDefault(Ljava/lang/String;Landroid/content/Context;)Z

    move-result v5

    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    if-nez v5, :cond_3

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    const-string/jumbo v0, "l soe aiFa oltb"

    const-string v0, "Fl  obl aiatedo"

    const/4 v9, 0x4

    const-string/jumbo v0, "l imtF oeo ddla"

    const-string v0, "Failed to load "

    const/4 v9, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {v2, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x1

    return v4

    :cond_3
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-string v0, "eremotusa-ocp"

    const-string/jumbo v0, "etsorcu-apmer"

    const/4 v9, 0x7

    const-string/jumbo v0, "ta-embrsectpr"

    const-string/jumbo v0, "tpcore-master"

    const/4 v9, 0x6

    const/4 v8, 0x4

    invoke-virtual {v0, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    sget-object v4, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->mLibLoader:Lcom/tencent/thumbplayer/core/common/ITPNativeLibraryExternalLoader;

    const/4 v9, 0x6

    if-eqz v4, :cond_4

    const/4 v9, 0x0

    const/4 v8, 0x0

    invoke-interface {v4, v0, v6}, Lcom/tencent/thumbplayer/core/common/ITPNativeLibraryExternalLoader;->loadLib(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    goto :goto_1

    :cond_4
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->loadLibDefault(Ljava/lang/String;Landroid/content/Context;)Z

    move-result v0

    :goto_1
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x4

    if-eqz v0, :cond_6

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->getPlayerCoreVersion()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-string/jumbo v4, "u01..3"

    const-string v4, ".p310."

    const/4 v9, 0x0

    const-string v4, ".p21.0"

    const-string v4, "2.31.0"

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {v4, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->isMatchJavaAndPlayerCore(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-nez v4, :cond_5

    const/4 v9, 0x1

    const/4 v8, 0x0

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-string/jumbo v7, "oVP(iCerqnteylrvaear"

    const-string/jumbo v7, "nativePlayerCoreVer("

    const/4 v9, 0x0

    const/4 v8, 0x4

    invoke-direct {v5, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    const-string/jumbo v0, "hPse1/tj0rdmVt Cvo:aeaqe  ae/)s3ro.c2(r.yal"

    const-string v0, "ctd1m eeql)y t(/saCeo.:a2r/oha. aV3)Prvejr0"

    const/4 v9, 0x2

    const-string v0, ":eom2.y.rasca1 tr)er/h ovV)me/CPe0 nlt3(daj"

    const-string v0, ") doesn\'t match javaPlayerCoreVer:(2.31.0)"

    const/4 v9, 0x3

    const/4 v8, 0x5

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    or-int/2addr v9, v8

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {v2, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    :cond_5
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    move v0, v4

    move v0, v4

    const/4 v9, 0x6

    move v0, v4

    move v0, v4

    :cond_6
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x0

    const-string v4, "ahhkoecijrsetaslcm"

    const-string/jumbo v4, "ijkhlscache-master"

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v4, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    sget-object v4, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->mLibLoader:Lcom/tencent/thumbplayer/core/common/ITPNativeLibraryExternalLoader;

    const/4 v9, 0x7

    if-eqz v4, :cond_7

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-interface {v4, v3, v6}, Lcom/tencent/thumbplayer/core/common/ITPNativeLibraryExternalLoader;->loadLib(Ljava/lang/String;Ljava/lang/String;)Z

    const/4 v8, 0x4

    const/4 v8, 0x5

    goto :goto_2

    :cond_7
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-static {v3, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->loadLibDefault(Ljava/lang/String;Landroid/content/Context;)Z

    :goto_2
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    if-eqz v0, :cond_8

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    const-string p0, " ytsdbsosaalvliiccss luebdeelfN"

    const-string/jumbo p0, "iuslia ayfcbdsessu sedlolvletNc"

    const/4 v9, 0x5

    const-string p0, " elcdyuodlvuefilesaN ib cuslssa"

    const-string p0, "Native libs loaded successfully"

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-static {v1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    goto :goto_3

    :cond_8
    const/4 v8, 0x4

    move v9, v8

    const-string p0, " leon  pdil ibttdeoaFaiavs"

    const-string p0, "Failed to load native libs"

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {v2, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    :goto_3
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    return v0

    :cond_9
    :goto_4
    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    return v4
.end method

.method private static loadLibDefault(Ljava/lang/String;Landroid/content/Context;)Z
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string v0, "alouafDaqeedtlddLbo l "

    const-string/jumbo v0, "loadLibDefault loaded "

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v1, 0x4

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/4 v2, 0x2

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 v3, 0x0

    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string/jumbo v4, "igsdeuo lDad ltaoLbflia"

    const-string v4, "a gmdletiofadDaou bilLl"

    const/4 v8, 0x0

    const-string v4, "a dmdbL auoiaolteflnigD"

    const-string/jumbo v4, "loadLibDefault loading "

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v4, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x1

    invoke-static {v2, v4}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {p0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    const/4 v3, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string v5, "dfLboatalulei o"

    const-string v5, "ataiodelL bflou"

    const/4 v8, 0x0

    const-string/jumbo v5, "loadLibDefault "

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    const-string v5, "alsolbeefl usucydc s"

    const-string v5, " cyscbeosllafluueds "

    const/4 v8, 0x4

    const-string v5, " loaded successfully"

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {v2, v4}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    goto :goto_0

    :catchall_0
    move-exception v4

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const-string/jumbo v6, "ffao Lud o Dubaallutletde ioal"

    const-string/jumbo v6, "fd fadubLaaulool t i eltelDiao"

    const/4 v8, 0x2

    const-string v6, "a ltbiopDl du ot efelaaLaidodf"

    const-string/jumbo v6, "loadLibDefault failed to load "

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x0

    invoke-virtual {v5, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-string v6, ","

    const-string v6, ","

    const/4 v8, 0x3

    const-string v6, ","

    const-string v6, ","

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x2

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-static {v1, v4}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    :goto_0
    const/4 v8, 0x6

    if-nez v3, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-eqz p1, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuArchitecture()I

    move-result v4

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 v5, 0x6

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-lt v4, v5, :cond_1

    :try_start_1
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string/jumbo v5, "tD Latlaqrauo by loidltp ed"

    const-string v5, "Lladraip ettDo uytbdalol o "

    const/4 v8, 0x7

    const-string/jumbo v5, "oosolldfrt dti DLtay abu el"

    const-string/jumbo v5, "loadLibDefault try to load "

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    const-string/jumbo v5, "orP fKA q"

    const/4 v8, 0x6

    const-string v5, "Pf mo KrA"

    const-string v5, " from APK"

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {v2, v4}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-class v4, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;

    const-class v4, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;

    const/4 v8, 0x1

    const-class v4, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;

    const-class v4, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v4}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v4

    const/4 v7, 0x2

    shl-int/2addr v8, v7

    invoke-static {p0, v4, p1}, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->load(Ljava/lang/String;Ljava/lang/ClassLoader;Landroid/content/Context;)Z

    move-result v3

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-eqz v3, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string v4, " fK oueAscfosrsu lylsP"

    const-string v4, "KusP  fflsscym Arsleou"

    const/4 v8, 0x4

    const-string v4, " lscKbPAlosrufes cumy "

    const-string v4, " from APK successfully"

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-static {v2, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    goto :goto_1

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string/jumbo v2, "fKiAmmur dl aP f"

    const-string v2, "Pd mAK lirofmfa "

    const/4 v8, 0x1

    const-string/jumbo v2, "laeid  pfm KAPor"

    const-string v2, " from APK failed"

    const/4 v7, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-static {v1, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    goto :goto_1

    :catchall_1
    move-exception p1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string p0, "Koil,  dqmfPAoe f"

    const-string/jumbo p0, "oPieomaKA   ffl,d"

    const/4 v8, 0x0

    const-string p0, "drsP,of ami fKel "

    const-string p0, " from APK failed,"

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {v1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    :cond_1
    :goto_1
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    return v3
.end method

.method public static loadLibIfNeeded(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->mIsLibLoadedLock:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-boolean v1, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->mIsLibLoaded:Z

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-nez v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->loadLib(Landroid/content/Context;)Z

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    sput-boolean p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->mIsLibLoaded:Z

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    move v3, v2

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string/jumbo p0, "l ams olrrbaatriubycLbdLefilveTloieasuNscyP"

    const-string p0, " slfdbrieadrtrsvylTNbbaiyucicLoPaelsoL ulea"

    const/4 v3, 0x6

    const-string/jumbo p0, "fycLovtsralilNcodulluLiT sybb oseaereadi ra"

    const-string p0, "TPNativeLibraryLoader load lib successfully"

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v3, 0x0

    goto :goto_1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string p0, "dbaN b irTaelidulbdeaLaioearLorvyifl "

    const-string p0, "etaaLluTeoNi edfdblalb i iyvorLairard"

    const/4 v3, 0x0

    const-string p0, "TPNativeLibraryLoader load lib failed"

    const/4 v2, 0x7

    move v3, v2

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget-boolean p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->mIsLibLoaded:Z

    const/4 v3, 0x2

    if-eqz p0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v1, "alrvnaubiai ldFrdeyoot talep "

    const-string v1, "ardloblpieila  datienyvraoF t"

    const/4 v3, 0x5

    const-string v1, " bnidtopedaFloivrar a tilaely"

    const-string v1, "Failed to load native library"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    throw p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    throw p0
.end method

.method public static setLibLoader(Lcom/tencent/thumbplayer/core/common/ITPNativeLibraryExternalLoader;)V
    .locals 2

    const/4 v0, 0x6

    move v1, v0

    sput-object p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->mLibLoader:Lcom/tencent/thumbplayer/core/common/ITPNativeLibraryExternalLoader;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method
