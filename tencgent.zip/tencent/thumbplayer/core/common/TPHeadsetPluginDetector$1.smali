.class final Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$1;
.super Landroid/media/AudioDeviceCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->registerDeviceCallback()Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Landroid/media/AudioDeviceCallback;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final onAudioDevicesAdded([Landroid/media/AudioDeviceInfo;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "v~s~ of  S ~4i@@. a@obof/ b~~~@@~n rto~/t~ ~~ lo@m@ ~@l @i  ~Mb@1~s@~~~d~ yci~@uo-@@@ @@@~ ~@~ @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    const-string p1, "DedmPlsnttrPTiHeuocsetg"

    const-string/jumbo p1, "ocstTsrnePtgteuedHPeliD"

    const/4 v3, 0x3

    const-string/jumbo p1, "ulPPocetsTtaoetdegreiDn"

    const-string p1, "TPHeadsetPluginDetector"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo v0, "iAudmbdDsoeAeevd!ioc"

    const-string/jumbo v0, "iiAmedc!AsvudeoodedD"

    const/4 v3, 0x4

    const-string v0, "!nsddeuAuDeAdodoiive"

    const-string/jumbo v0, "onAudioDevicesAdded!"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v1, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v1, p1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->access$000()Ljava/util/Set;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->access$100()Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->access$200(Ljava/util/Set;Ljava/util/Set;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method public final onAudioDevicesRemoved([Landroid/media/AudioDeviceInfo;)V
    .locals 4

    const/4 v3, 0x2

    const-string/jumbo p1, "uelTsiopDetectrHPgodtaP"

    const-string p1, "egseoDldiuHetTtPPoartec"

    const/4 v3, 0x1

    const-string p1, "eePPTtinqHaedrutgcteolD"

    const-string p1, "TPHeadsetPluginDetector"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string/jumbo v0, "nusemRo!ebdovvoisdeAeD"

    const-string/jumbo v0, "evsvDbmnieeou!ddRoieoA"

    const/4 v3, 0x6

    const-string/jumbo v0, "euomiAdvimevdeesocn!Ro"

    const-string/jumbo v0, "onAudioDevicesRemoved!"

    const/4 v3, 0x4

    const/4 v1, 0x2

    const/4 v3, 0x5

    move v2, v1

    move v2, v1

    const/4 v3, 0x2

    invoke-static {v1, p1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->access$000()Ljava/util/Set;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->access$100()Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->access$200(Ljava/util/Set;Ljava/util/Set;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method
