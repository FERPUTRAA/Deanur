.class public Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;
.super Ljava/lang/Object;


# static fields
.field private static DolbyVisionProfileDvavPen:I = 0x1

.field private static DolbyVisionProfileDvavPer:I = 0x0

.field private static DolbyVisionProfileDvavSe:I = 0x9

.field private static DolbyVisionProfileDvheDen:I = 0x3

.field private static DolbyVisionProfileDvheDer:I = 0x2

.field private static DolbyVisionProfileDvheDtb:I = 0x7

.field private static DolbyVisionProfileDvheDth:I = 0x6

.field private static DolbyVisionProfileDvheDtr:I = 0x4

.field private static DolbyVisionProfileDvheSt:I = 0x8

.field private static DolbyVisionProfileDvheStn:I = 0x5

.field private static mSecureDecoderNameMaps:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public static convertOmxProfileToDolbyVision(I)I
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@@s ~~ /b~~@~4@i ~umi@@o.@b~@~~a f@ o@  f@@o~ rt~~ ctl 1@~Ml~@S~@ bn@ @ / ~ o~y@~-vK ~~~oi~d o@s"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v1, 0x2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eq p0, v0, :cond_9

    const/4 v4, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eq p0, v1, :cond_8

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v0, 0x4

    or-int/2addr v5, v0

    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eq p0, v0, :cond_7

    const/4 v5, 0x1

    const/16 v0, 0x8

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eq p0, v0, :cond_6

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/16 v0, 0x10

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eq p0, v0, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/16 v0, 0x20

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eq p0, v0, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/16 v0, 0x40

    const/4 v5, 0x0

    const/4 v4, 0x2

    if-eq p0, v0, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/16 v0, 0x80

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eq p0, v0, :cond_2

    const/4 v5, 0x5

    const/16 v0, 0x100

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eq p0, v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/16 v0, 0x200

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eq p0, v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    sget v0, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->DolbyVisionProfileDvavSe:I

    const/4 v5, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    sget v0, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->DolbyVisionProfileDvheSt:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    goto :goto_0

    :cond_2
    const/4 v5, 0x5

    sget v0, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->DolbyVisionProfileDvheDtb:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    goto :goto_0

    :cond_3
    const/4 v4, 0x1

    move v5, v4

    sget v0, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->DolbyVisionProfileDvheDth:I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto :goto_0

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    sget v0, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->DolbyVisionProfileDvheStn:I

    const/4 v4, 0x1

    move v5, v4

    goto :goto_0

    :cond_5
    const/4 v5, 0x3

    sget v0, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->DolbyVisionProfileDvheDtr:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_0

    :cond_6
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    sget v0, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->DolbyVisionProfileDvheDen:I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto :goto_0

    :cond_7
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    sget v0, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->DolbyVisionProfileDvheDer:I

    const/4 v5, 0x4

    const/4 v4, 0x6

    goto :goto_0

    :cond_8
    const/4 v5, 0x6

    sget v0, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->DolbyVisionProfileDvavPen:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_0

    :cond_9
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    sget v0, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->DolbyVisionProfileDvavPer:I

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo v3, "sbomrieefvll:rDxoxnoTynomtrifVioPc oOsoemP"

    const-string/jumbo v3, "oVsteonPco DPorOx:erbomfexnilrifimioysvolT"

    const/4 v5, 0x7

    const-string/jumbo v3, "oixoonTolmbsiy Veoc:iforOmnPDePfelrioxrlot"

    const-string v3, "convertOmxProfileToDolbyVision omxProfile:"

    const/4 v5, 0x4

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string p0, "b: fibiyrePoliosonlm"

    const-string/jumbo p0, "isnmo yblfoVl:ioirPe"

    const/4 v5, 0x5

    const-string p0, " dolbyVisionProfile:"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v2, "donescuntTUColedUii"

    const-string/jumbo v2, "iliooCUtdtsUTnendec"

    const/4 v5, 0x3

    const-string/jumbo v2, "ieTPUcdpsoeinndttCU"

    const-string v2, "TPUnitendCodecUtils"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v1, v2, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    return v0
.end method

.method public static declared-synchronized getDolbyVisionDecoderName(Ljava/lang/String;IIZ)Ljava/lang/String;
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v1, p1

    move/from16 v2, p3

    move/from16 v2, p3

    move/from16 v2, p3

    move/from16 v2, p3

    const-class v3, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;

    const-class v3, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;

    const-class v3, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;

    const-class v3, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;

    monitor-enter v3

    :try_start_0
    const-string/jumbo v4, "sbdi-eloqovvidoiyn"

    const-string/jumbo v4, "n-lsdbiiyodiobeovv"

    const-string/jumbo v4, "olse-biidvnisdvoyo"

    const-string/jumbo v4, "video/dolby-vision"

    invoke-static {v4, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    if-nez v4, :cond_0

    monitor-exit v3

    return-object v5

    :cond_0
    :try_start_1
    new-instance v4, Landroid/media/MediaCodecList;

    const/4 v6, 0x1

    invoke-direct {v4, v6}, Landroid/media/MediaCodecList;-><init>(I)V

    invoke-virtual {v4}, Landroid/media/MediaCodecList;->getCodecInfos()[Landroid/media/MediaCodecInfo;

    move-result-object v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-nez v4, :cond_1

    monitor-exit v3

    return-object v5

    :cond_1
    :try_start_2
    array-length v6, v4

    move-object v9, v5

    move-object v9, v5

    move-object v9, v5

    move-object v9, v5

    const/4 v8, 0x0

    :goto_0
    if-ge v8, v6, :cond_6

    aget-object v10, v4, v8

    const-string v11, "UPdmuttleisoCceiTdn"

    const-string/jumbo v11, "sdtcUiuCenPoeTndlit"

    const-string v11, "TUncotoeUdldPCitesn"

    const-string v11, "TPUnitendCodecUtils"

    new-instance v12, Ljava/lang/StringBuilder;

    const-string v13, "ebdDebNasnteonc Deimrmyo:iVolpe"

    const-string v13, " Dgoeieplr:nntamcedNVDeismboyoe"

    const-string/jumbo v13, "yNcnoluedmDoroaDtsnbae: Veiimee"

    const-string/jumbo v13, "getDolbyVisionDecoderName name:"

    invoke-direct {v12, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v10}, Landroid/media/MediaCodecInfo;->getName()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    const/4 v13, 0x2

    invoke-static {v13, v11, v12}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v10}, Landroid/media/MediaCodecInfo;->isEncoder()Z

    move-result v11
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    if-nez v11, :cond_5

    :try_start_3
    invoke-virtual {v10, v0}, Landroid/media/MediaCodecInfo;->getCapabilitiesForType(Ljava/lang/String;)Landroid/media/MediaCodecInfo$CodecCapabilities;

    move-result-object v11
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_1

    :catch_0
    move-object v11, v5

    move-object v11, v5

    move-object v11, v5

    move-object v11, v5

    :goto_1
    if-eqz v11, :cond_5

    :try_start_4
    iget-object v12, v11, Landroid/media/MediaCodecInfo$CodecCapabilities;->profileLevels:[Landroid/media/MediaCodecInfo$CodecProfileLevel;

    const/4 v14, 0x0

    :goto_2
    array-length v15, v12

    if-ge v14, v15, :cond_4

    aget-object v15, v12, v14

    iget v15, v15, Landroid/media/MediaCodecInfo$CodecProfileLevel;->profile:I

    invoke-static {v15}, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->convertOmxProfileToDolbyVision(I)I

    move-result v15

    if-ne v15, v1, :cond_3

    const-string/jumbo v5, "ndtsclepeqoUdiiPnUC"

    const-string/jumbo v5, "tndcoilCqdePUneTUis"

    const-string/jumbo v5, "oCiTnUntqeeitslUddP"

    const-string v5, "TPUnitendCodecUtils"

    new-instance v7, Ljava/lang/StringBuilder;

    const-string v13, ":esiilemsDosegVyoNtoDrbeca d"

    const-string v13, ":ysotbVe eodlemroseDagicDiNi"

    const-string v13, "csdmmDNebroe:oiiteelngDiVao "

    const-string/jumbo v13, "getDolbyVisionDecoderName i:"

    invoke-direct {v7, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v13, "f:elopi r"

    const-string/jumbo v13, "r: mflipe"

    const-string/jumbo v13, "p elibfr:"

    const-string v13, " profile:"

    invoke-virtual {v7, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v13, "lPor iuveo:"

    const-string/jumbo v13, "irP odelvo:"

    const-string/jumbo v13, "f lPvorpid:"

    const-string v13, " dvProfile:"

    invoke-virtual {v7, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v13, "b :ereScq"

    const-string v13, "er :bbSec"

    const-string/jumbo v13, "ucsr eeSb"

    const-string v13, " bSecure:"

    invoke-virtual {v7, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string/jumbo v13, "m nm:u"

    const-string/jumbo v13, "u:ne m"

    const-string v13, " nmao:"

    const-string v13, " name:"

    invoke-virtual {v7, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Landroid/media/MediaCodecInfo;->getName()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v7, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v13, 0x2

    invoke-static {v13, v5, v7}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    if-eqz v2, :cond_2

    const-string v5, "aauppbc-beekcyl"

    const-string v5, "ae-reycplpcubka"

    const-string v5, "clpabaurkecyuse"

    const-string/jumbo v5, "secure-playback"

    invoke-virtual {v11, v5}, Landroid/media/MediaCodecInfo$CodecCapabilities;->isFeatureSupported(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_3

    :cond_2
    invoke-virtual {v10}, Landroid/media/MediaCodecInfo;->getName()Ljava/lang/String;

    move-result-object v5

    move-object v9, v5

    move-object v9, v5

    move-object v9, v5

    move-object v9, v5

    goto :goto_3

    :cond_3
    add-int/lit8 v14, v14, 0x1

    const/4 v5, 0x0

    const/4 v13, 0x2

    goto/16 :goto_2

    :cond_4
    :goto_3
    if-eqz v9, :cond_5

    const-string/jumbo v0, "tntnqilpoCTdUUiePsc"

    const-string/jumbo v0, "nPUiesicqltnTeCoUtd"

    const-string v0, "CttUncenqTidlidUeso"

    const-string v0, "TPUnitendCodecUtils"

    const-string v1, "eNsmnectDyieeaeDsdoom:gnoriVasb"

    const-string/jumbo v1, "g:sieDcobsdoaotrnmNeDineyVae em"

    const-string/jumbo v1, "mogm eDdomiceil:eVbyaDntnsreNao"

    const-string/jumbo v1, "getDolbyVisionDecoderName name:"

    invoke-virtual {v1, v9}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x2

    invoke-static {v2, v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    goto :goto_4

    :cond_5
    add-int/lit8 v8, v8, 0x1

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_6
    :goto_4
    monitor-exit v3

    return-object v9

    :catchall_0
    move-exception v0

    monitor-exit v3

    throw v0
.end method

.method public static declared-synchronized getSecureDecoderName(Ljava/lang/String;)Ljava/lang/String;
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;

    const/4 v9, 0x6

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;

    const/4 v8, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string v1, "/ovmodvei"

    const-string v1, "/oimvaevd"

    const/4 v9, 0x4

    const-string/jumbo v1, "v/ceabovd"

    const-string/jumbo v1, "video/avc"

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-static {v1, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    const/4 v2, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-nez v1, :cond_0

    const/4 v8, 0x1

    move v9, v8

    const-string v1, "/vevooudeh"

    const-string/jumbo v1, "evceovoh/d"

    const/4 v9, 0x6

    const-string v1, "/oecvdvphe"

    const-string/jumbo v1, "video/hevc"

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {v1, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v9, 0x1

    const/4 v8, 0x7

    if-nez v1, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    const-string v1, "-idnbsolqb/iiovdoe"

    const-string/jumbo v1, "vnoddbvo/l-iobesii"

    const/4 v9, 0x3

    const-string v1, "-isnibdlovvoeis/dy"

    const-string/jumbo v1, "video/dolby-vision"

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {v1, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    if-nez v1, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    monitor-exit v0

    const/4 v9, 0x7

    return-object v2

    :cond_0
    :try_start_1
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->mSecureDecoderNameMaps:Ljava/util/HashMap;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    if-nez v1, :cond_1

    const/4 v9, 0x0

    new-instance v1, Ljava/util/HashMap;

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    sput-object v1, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->mSecureDecoderNameMaps:Ljava/util/HashMap;

    :cond_1
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->mSecureDecoderNameMaps:Ljava/util/HashMap;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v1, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-eqz v1, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->mSecureDecoderNameMaps:Ljava/util/HashMap;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v1, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    check-cast p0, Ljava/lang/String;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    monitor-exit v0

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    return-object p0

    :cond_2
    :try_start_2
    const/4 v9, 0x5

    new-instance v1, Landroid/media/MediaCodecList;

    const/4 v8, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v3, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-direct {v1, v3}, Landroid/media/MediaCodecList;-><init>(I)V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v1}, Landroid/media/MediaCodecList;->getCodecInfos()[Landroid/media/MediaCodecInfo;

    move-result-object v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-nez v1, :cond_3

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    monitor-exit v0

    const/4 v9, 0x3

    const/4 v8, 0x0

    return-object v2

    :cond_3
    :try_start_3
    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    array-length v3, v1

    const/4 v8, 0x0

    shl-int/2addr v9, v8

    const/4 v4, 0x0

    move v9, v4

    :goto_0
    const/4 v8, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-ge v4, v3, :cond_5

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    aget-object v5, v1, v4

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v5}, Landroid/media/MediaCodecInfo;->isEncoder()Z

    move-result v6
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x0

    if-nez v6, :cond_4

    :try_start_4
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {v5, p0}, Landroid/media/MediaCodecInfo;->getCapabilitiesForType(Ljava/lang/String;)Landroid/media/MediaCodecInfo$CodecCapabilities;

    move-result-object v6
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    goto :goto_1

    :catch_0
    move-object v6, v2

    move-object v6, v2

    :goto_1
    const/4 v9, 0x5

    const/4 v8, 0x6

    if-eqz v6, :cond_4

    :try_start_5
    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x1

    const-string/jumbo v7, "rkcmeslaueucpy-"

    const-string/jumbo v7, "lupcybuerse-kac"

    const/4 v9, 0x0

    const-string/jumbo v7, "uecaoeaprbl-csy"

    const-string/jumbo v7, "secure-playback"

    const/4 v9, 0x7

    invoke-virtual {v6, v7}, Landroid/media/MediaCodecInfo$CodecCapabilities;->isFeatureSupported(Ljava/lang/String;)Z

    move-result v6

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    if-eqz v6, :cond_4

    const/4 v9, 0x1

    const/4 v8, 0x0

    invoke-virtual {v5}, Landroid/media/MediaCodecInfo;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x2

    goto :goto_2

    :cond_4
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    goto :goto_0

    :cond_5
    :goto_2
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPUnitendCodecUtils;->mSecureDecoderNameMaps:Ljava/util/HashMap;

    const/4 v8, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v1, p0, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    monitor-exit v0

    const/4 v8, 0x5

    shl-int/2addr v9, v8

    return-object v2

    :catchall_0
    move-exception p0

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    monitor-exit v0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    throw p0
.end method
