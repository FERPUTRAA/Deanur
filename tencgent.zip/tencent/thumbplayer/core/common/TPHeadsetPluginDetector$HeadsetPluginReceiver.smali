.class Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$HeadsetPluginReceiver;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "HeadsetPluginReceiver"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$1;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector$HeadsetPluginReceiver;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "iosiK ~~ @o. us~~@~~ l~o@SM@ d@@~@o ~~ lrt~@@1i@ m @ @~b/ @vc@f f@n y~~~~@~a/b~~o @ ~t@o@ ~4-~@b"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string/jumbo v0, "snimee: eoR"

    const-string v0, "eis Reen:co"

    const/4 v7, 0x7

    const-string/jumbo v0, "oinco:Rvee "

    const-string/jumbo v0, "onReceive: "

    const/4 v6, 0x3

    and-int/2addr v7, v6

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/4 v0, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-string v2, "ecueHbreemoPgPstaTlintD"

    const-string/jumbo v2, "tHDmieeTPPstlauecrdegno"

    const/4 v7, 0x5

    const-string/jumbo v2, "tPosneuTueHtPeitDaecgrd"

    const-string v2, "TPHeadsetPluginDetector"

    const/4 v7, 0x1

    invoke-static {v0, v2, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->access$100()Ljava/util/Set;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string v2, "dEia.nGpraTU.tHo._nSidicnDoAtLtneo"

    const-string v2, "ceitoPa.LHSrndAdTainUi_EonDtGn.to."

    const/4 v7, 0x4

    const-string v2, "android.intent.action.HEADSET_PLUG"

    const/4 v7, 0x4

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v3, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v4, 0x1

    move v7, v4

    const/4 v6, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v2, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string v0, "estqa"

    const-string v0, "baste"

    const/4 v7, 0x3

    const-string v0, "atsst"

    const-string/jumbo v0, "state"

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p2, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {p2, v0, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v3

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x3

    if-eqz p1, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-nez v3, :cond_1

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-interface {p1, v5}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_1

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-ne v3, v4, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-interface {p1, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_2
    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->access$000()Ljava/util/Set;

    move-result-object p2

    const/4 v7, 0x2

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->access$200(Ljava/util/Set;Ljava/util/Set;)V

    const/4 v6, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-void

    :cond_3
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string/jumbo v2, "oDndImue_.IBMGa.N_dUNdAYCIEOSOairi"

    const/4 v7, 0x1

    const-string v2, "DoIm_I.i_dCeAmONYNMOOrdSaGdnB.aiUE"

    const-string v2, "android.media.AUDIO_BECOMING_NOISY"

    const/4 v6, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-eqz v2, :cond_4

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-eqz p1, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    goto :goto_0

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string/jumbo v2, "pAraoDT2bnaCEEpNnOdC.ptoNcETidoaSet.ThlidoG_o_NfueliI.rNtHoO.C"

    const-string v2, "SCilotdp.NOru.orOE__oaEo.dTdiTpnoTI2NhNi.GNabpDCcfHnaAtCteeEAl"

    const/4 v7, 0x6

    const-string v2, "android.bluetooth.a2dp.profile.action.CONNECTION_STATE_CHANGED"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eqz v2, :cond_7

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string v2, "epShlbEdbTrlfqeAaeod.u.otrT.xnttr.oio"

    const-string/jumbo v2, "lfhSrtp.qu.eeTdeoA.rotxTaEinrtbodoa.l"

    const/4 v7, 0x6

    const-string/jumbo v2, "rdiooluttiaflatTpoAexoer.en.TEhub.S.d"

    const-string v2, "android.bluetooth.profile.extra.STATE"

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p2, v2, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-eqz p1, :cond_6

    const/4 v6, 0x1

    shl-int/2addr v7, v6

    if-ne p2, v0, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-interface {p1, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    goto :goto_2

    :cond_5
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-nez p2, :cond_6

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-interface {p1, v1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    :cond_6
    :goto_2
    const/4 v6, 0x1

    move v7, v6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->access$000()Ljava/util/Set;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/core/common/TPHeadsetPluginDetector;->access$200(Ljava/util/Set;Ljava/util/Set;)V

    :cond_7
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    return-void
.end method
