.class Lcom/tencent/thumbplayer/core/common/TPSystemInfo$1CpuFilter;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/FileFilter;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getNumCores()I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "1CpuFilter"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public accept(Ljava/io/File;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s~~@~@@bv ~~~ri@~d@@1 b~4o~@M ~~ @fl/~ @~Ku~~o @l-tm~@ tS i o/a@ @s   .c~~~oo~@@b@ iy@no@  f~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const-string v0, "-c]m[0su"

    const-string v0, "]-s[ucp0"

    const/4 v2, 0x4

    const-string v0, "[-p0o]cu"

    const-string v0, "cpu[0-9]"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {v0, p1}, Ljava/util/regex/Pattern;->matches(Ljava/lang/String;Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p1
.end method
