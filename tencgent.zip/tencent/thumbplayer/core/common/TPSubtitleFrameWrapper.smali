.class public Lcom/tencent/thumbplayer/core/common/TPSubtitleFrameWrapper;
.super Ljava/lang/Object;


# instance fields
.field public needUpdate:Z

.field public subtitleFrame:Lcom/tencent/thumbplayer/core/common/TPSubtitleFrame;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method
