.class public Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateCallBackToNative;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector$ScreenRefreshRateChangedListener;


# static fields
.field private static final TAG:Ljava/lang/String; = "TPScreenRefreshRateCallBack"


# instance fields
.field private mNativeContext:J


# direct methods
.method private constructor <init>(J)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    iput-wide p1, p0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateCallBackToNative;->mNativeContext:J

    const/4 v1, 0x6

    const/4 v0, 0x6

    return-void
.end method

.method private native _onScreenRefreshRateChanged(F)V
.end method

.method private getNativeContext()J
    .locals 4
    .annotation build Lcom/tencent/thumbplayer/core/common/TPMethodCalledByNative;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "4asfn m @@ @~@by@ ob~voK t~@-~ ~~i@ ~l~o~@o@@ ~@   i@~~ ~@ ~@fio~~/@S ~s t@~@@Mcl ~/~@bd~@.1~uo "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateCallBackToNative;->mNativeContext:J

    const/4 v3, 0x4

    const/4 v2, 0x5

    return-wide v0
.end method

.method private registerCallback()V
    .locals 2
    .annotation build Lcom/tencent/thumbplayer/core/common/TPMethodCalledByNative;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->addListener(Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector$ScreenRefreshRateChangedListener;)V

    const/4 v0, 0x2

    move v1, v0

    return-void
.end method

.method private unregisterCallback()V
    .locals 2
    .annotation build Lcom/tencent/thumbplayer/core/common/TPMethodCalledByNative;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->removeListener(Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector$ScreenRefreshRateChangedListener;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onScreenRefreshRateChanged(F)V
    .locals 5

    const/4 v4, 0x3

    const-string/jumbo v0, "tremRedaenrRhfeeghnscohrSsseeaeaC ft:re"

    const-string/jumbo v0, "gnsfthtnheeraen:reorcfa eseShesRdeCaRer"

    const-string/jumbo v0, "rf:eoaCdegeretsrhneheRhrnaeaeRseRcnSfto"

    const-string/jumbo v0, "onScreenRefreshRateChanged refreshRate:"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p1}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v1, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string/jumbo v2, "haresbtClSBfRaercenelPmckRT"

    const-string/jumbo v2, "lTemceRasCShPrtneRkBcaerfal"

    const/4 v4, 0x2

    const-string v2, "cTsSaauhrBlReekanrCelectRPf"

    const-string v2, "TPScreenRefreshRateCallBack"

    const/4 v4, 0x4

    const/4 v3, 0x4

    invoke-static {v1, v2, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    move v4, v3

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateCallBackToNative;->_onScreenRefreshRateChanged(F)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void
.end method
