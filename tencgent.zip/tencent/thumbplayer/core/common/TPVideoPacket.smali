.class public Lcom/tencent/thumbplayer/core/common/TPVideoPacket;
.super Ljava/lang/Object;


# instance fields
.field public mData:[B

.field public mDolbyVisionInfo:Lcom/tencent/thumbplayer/core/player/TPNativePlayerSurfaceDolbyVisionInfo;

.field public mDtsUs:J

.field public mPtsUs:J

.field public mSize:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method
