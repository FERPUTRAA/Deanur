.class Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk$LibraryBrokenHandler;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Thread$UncaughtExceptionHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "LibraryBrokenHandler"
.end annotation


# instance fields
.field private mParent:Ljava/lang/Thread$UncaughtExceptionHandler;


# direct methods
.method constructor <init>(Ljava/lang/Thread$UncaughtExceptionHandler;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk$LibraryBrokenHandler;->mParent:Ljava/lang/Thread$UncaughtExceptionHandler;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public uncaughtException(Ljava/lang/Thread;Ljava/lang/Throwable;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~@s ~/@b vnt~ ~ @oy@o @~s@S~@-~t@~~~urlo~~f l@  b@~ Km/ @~do~4@ 1 ~~f .~aM@@ @@i@~ b@@ci~~o~ @io"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    instance-of v0, p2, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-nez v0, :cond_1

    const/4 v5, 0x1

    instance-of v0, p2, Ljava/lang/NoSuchMethodError;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const-string v3, "?..m[*e:it=]*sansu(r"

    const-string/jumbo v3, "u*s(a=.)*[ri:]stn?e."

    const/4 v5, 0x7

    const-string/jumbo v3, "s.neo[*)=a(:rt*].uig"

    const-string v3, ".*sig(nature)?[=:].*"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    move v0, v2

    move v0, v2

    const/4 v5, 0x1

    move v0, v2

    move v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    move v0, v1

    const/4 v5, 0x6

    move v0, v1

    move v0, v1

    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v0, :cond_2

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->access$000()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk;->access$100(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto :goto_2

    :catch_0
    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    move v1, v2

    move v1, v2

    const/4 v5, 0x3

    move v1, v2

    move v1, v2

    :goto_2
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v0, Ljava/lang/UnsatisfiedLinkError;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string v1, "e tv bdtmdaoe rcancseelvdoei.endIr"

    const-string/jumbo v1, "le mertt v dc de.snoIvecdridnaaeeo"

    const/4 v5, 0x2

    const-string v1, "   etruocen.oaInlarcdsvdd tveeedei"

    const-string v1, "Invalid so detected and recovered."

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {v0, v1}, Ljava/lang/UnsatisfiedLinkError;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {v0, p2}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p2

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPLoadLibFromApk$LibraryBrokenHandler;->mParent:Ljava/lang/Thread$UncaughtExceptionHandler;

    const/4 v5, 0x4

    invoke-interface {v0, p1, p2}, Ljava/lang/Thread$UncaughtExceptionHandler;->uncaughtException(Ljava/lang/Thread;Ljava/lang/Throwable;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-void
.end method
