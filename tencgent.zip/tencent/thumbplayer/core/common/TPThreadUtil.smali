.class public Lcom/tencent/thumbplayer/core/common/TPThreadUtil;
.super Ljava/lang/Object;


# static fields
.field private static final TAG:Ljava/lang/String; = "PlayerCore.TPThreadUtil"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public static setThreadName(Ljava/lang/String;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "r s~syo@@ ~@~@iof@ia~o~@ ~u@~f ~@-bcSv4 ~ b@@@K@/~t~d@l@1ti/@ ~b~~   n @~~@@~ ~@M~ ~l~o  o o. @~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public static setThreadPriority(I)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/16 v0, -0x13

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-lt p0, v0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/16 v0, 0x13

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-le p0, v0, :cond_0

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0}, Landroid/os/Process;->getThreadPriority(I)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eq v0, p0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p0}, Landroid/os/Process;->setThreadPriority(I)V

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string/jumbo v0, "taimthyy,Pietd:srrooier sTir"

    const-string/jumbo v0, "rrsire itrheToa:tiitsy,ordPy"

    const-string v0, "ahydooiyeriip:rre otPr,sttrT"

    const-string/jumbo v0, "setThreadPriority, priority:"

    const/4 v3, 0x3

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    :catch_0
    move-exception p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string/jumbo v0, "rtTh.blolemUaTadeyPePCr"

    const-string v0, "U.rmlPeTeCPrhoyaltdiTae"

    const/4 v3, 0x4

    const-string v0, "dPTe.ruCTtheiPaeyUlrora"

    const-string v0, "PlayerCore.TPThreadUtil"

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-static {v1, v0, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void

    :cond_2
    :goto_0
    const/4 v3, 0x0

    const-string v0, "ergy2n[prttityer0,rtii1Pr ii ,r,rrhTyia ]p :ooprdo9aeerro:-"

    const-string v0, ":onrohryar 2rr ti1yPyp0r itpr[:rri,geoa -ie,o]teerr9oii,Tdt"

    const/4 v3, 0x2

    const-string/jumbo v0, "setThreadPriority error, priority range:[-19,20], priority:"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method
