.class public Lcom/tencent/thumbplayer/core/common/TPGeneralError;
.super Ljava/lang/Object;


# static fields
.field public static final BASE:I = 0xf4240

.field public static final BUFFERING_TIMEOUT:I = 0xf425e

.field public static final EOF:I = 0xf4256

.field public static final FAILED:I = 0xf4241

.field public static final FILE_IO_FAILED:I = 0xf4260

.field public static final INTERNAL_RESET:I = 0xf4257

.field public static final INVALID_ARG:I = 0xf424c

.field public static final INVALID_STREAM:I = 0xf4261

.field public static final NOT_IMPL:I = 0xf424b

.field public static final NOT_INIT:I = 0xf424a

.field public static final OK:I = 0x0

.field public static final OUT_OF_MEMORY:I = 0xf425f

.field public static final TRY_AGAIN:I = 0xf4254

.field public static final UNMATCHED_STATE:I = 0xf424d

.field public static final USER_INTERRUPT:I = 0xf4255


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    return-void
.end method
