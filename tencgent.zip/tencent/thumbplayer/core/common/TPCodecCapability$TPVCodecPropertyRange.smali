.class public Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/core/common/TPCodecCapability;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "TPVCodecPropertyRange"
.end annotation


# instance fields
.field public level:I

.field public lowerboundHeight:I

.field public lowerboundWidth:I

.field public profile:I

.field public upperboundHeight:I

.field public upperboundWidth:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public set(IIIIII)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "/ sfb~@@ @~~S~lv@ ~~~uo@y~   @M~o @~ ~b@@r 4 n  @c.b~@t~t -~i~fK@/ ~o@@~s~ o @a@m~o d1@@~@o@~lii"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;->upperboundWidth:I

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p2, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;->upperboundHeight:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p3, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;->lowerboundWidth:I

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput p4, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;->lowerboundHeight:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p5, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;->profile:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p6, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;->level:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method
