.class public final Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;
.super Ljava/lang/Object;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x15
.end annotation


# static fields
.field public static final DEFAULT_AUDIO_CAPABILITIES:Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

.field private static final DEFAULT_MAX_CHANNEL_COUNT:I = 0x8

.field private static final EXTERNAL_SURROUND_SOUND_CAPABILITIES:Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

.field private static final EXTERNAL_SURROUND_SOUND_KEY:Ljava/lang/String; = "external_surround_sound_enabled"


# instance fields
.field private final maxChannelCount:I

.field private final supportedEncodings:[I


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v1, 0x2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    filled-new-array {v1}, [I

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/16 v3, 0x8

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-direct {v0, v2, v3}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;-><init>([II)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->DEFAULT_AUDIO_CAPABILITIES:Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v2, 0x5

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v4, 0x6

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    filled-new-array {v1, v2, v4}, [I

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-direct {v0, v1, v3}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;-><init>([II)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->EXTERNAL_SURROUND_SOUND_CAPABILITIES:Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    return-void
.end method

.method public constructor <init>([II)V
    .locals 3
    .param p1    # [I
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    array-length v0, p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->supportedEncodings:[I

    const/4 v2, 0x7

    invoke-static {p1}, Ljava/util/Arrays;->sort([I)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-array p1, p1, [I

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->supportedEncodings:[I

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput p2, p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->maxChannelCount:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public static getCapabilities(Landroid/content/Context;)Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    new-instance v0, Landroid/content/IntentFilter;

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string v1, "dis.e.AP.aDGUdocids_DOtL_MaoHnimIrUa"

    const-string/jumbo v1, "tes_aAUGrniDMc_LIPdd.UHaoDomidai.O.I"

    const/4 v3, 0x2

    const-string v1, "AanmMDIO.oredodiiPin.DI_H.GUadLacm_t"

    const-string v1, "android.media.action.HDMI_AUDIO_PLUG"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v1, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p0, v0}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->getCapabilities(Landroid/content/Context;Landroid/content/Intent;)Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object p0
.end method

.method static getCapabilities(Landroid/content/Context;Landroid/content/Intent;)Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;
    .locals 5
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "InlinedApi"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz p1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string/jumbo p0, "tIA_oGaETP_LemrOrdiDadAe.aUn.ximSdU."

    const-string/jumbo p0, "m_tmALdTda_x.IiadrDPAEU.n.rUSGaeiTOe"

    const/4 v4, 0x3

    const-string p0, "DeaoAbdiATUrTimOn.a._GdrPeLxt.EUdI_a"

    const-string p0, "android.media.extra.AUDIO_PLUG_STATE"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1, p0, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-nez p0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v0, ".Sdeitui.NCEaGdxnIm.NroerDaoa"

    const-string/jumbo v0, "nDNioo.riedIeGSmNd.datxCE.aar"

    const/4 v4, 0x0

    const-string/jumbo v0, "oOeDNxSpdCG.a.eniiaaEIdr.tmdN"

    const-string v0, "android.media.extra.ENCODINGS"

    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getIntArrayExtra(Ljava/lang/String;)[I

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string v1, "AMUANELeqoaCHiieXdOdnxTC_m.r.db.NtN_a"

    const-string v1, "edLdTbmXHC.NOMtoNa.dArinxENAa.iC_ae_U"

    const-string v1, "Aas.HrTiX.r_eUNC_LNNoaandMOetA.dCixmd"

    const-string v1, "android.media.extra.MAX_CHANNEL_COUNT"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/16 v2, 0x8

    const/4 v4, 0x5

    const/4 v3, 0x0

    invoke-virtual {p1, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {p0, v0, p1}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;-><init>([II)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object p0

    :cond_1
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    sget-object p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->DEFAULT_AUDIO_CAPABILITIES:Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    return-object p0
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-ne p0, p1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    instance-of v1, p1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-nez v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    return v2

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    check-cast p1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->supportedEncodings:[I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v3, p1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->supportedEncodings:[I

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {v1, v3}, Ljava/util/Arrays;->equals([I[I)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->maxChannelCount:I

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget p1, p1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->maxChannelCount:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-ne v1, p1, :cond_2

    return v0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    return v2
.end method

.method public final getMaxChannelCount()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->maxChannelCount:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public final hashCode()I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->maxChannelCount:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->supportedEncodings:[I

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v1}, Ljava/util/Arrays;->hashCode([I)I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x1f

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    add-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    return v0
.end method

.method public final supportsEncoding(I)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->supportedEncodings:[I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {v0, p1}, Ljava/util/Arrays;->binarySearch([II)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-ltz p1, :cond_0

    const/4 v2, 0x3

    const/4 p1, 0x3

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x3

    return p1

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 p1, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    return p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo v1, "pbimmAe=xltoCanuhi[aaotnasueCCidin"

    const-string v1, "CibesauhnnoaunlmtC[tpAexa=Caiuiiod"

    const/4 v3, 0x2

    const-string v1, "Ceaiotmnuelni[dbACiax=ltuosiCnapao"

    const-string v1, "AudioCapabilities[maxChannelCount="

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->maxChannelCount:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string/jumbo v1, "pscE benn,odpudr=sgtp"

    const-string v1, "e,pdrngpcnut =osEdosp"

    const/4 v3, 0x1

    const-string/jumbo v1, "pcitonuEo,ud=spsdnreg"

    const-string v1, ", supportedEncodings="

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->supportedEncodings:[I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v1}, Ljava/util/Arrays;->toString([I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string v1, "]"

    const-string v1, "]"

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v0
.end method
