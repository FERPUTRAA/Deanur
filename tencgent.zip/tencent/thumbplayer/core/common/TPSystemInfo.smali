.class public Lcom/tencent/thumbplayer/core/common/TPSystemInfo;
.super Ljava/lang/Object;


# static fields
.field public static final CHIP_ARM_AARCH64:I = 0x7

.field public static final CHIP_ARM_LATER:I = 0x32

.field public static final CHIP_ARM_V5:I = 0x3

.field public static final CHIP_ARM_V6:I = 0x4

.field public static final CHIP_ARM_V7_NENO:I = 0x6

.field public static final CHIP_ARM_V7_NO_NENO:I = 0x5

.field public static final CHIP_MIPS:I = 0x2

.field public static final CHIP_UNKNOW:I = 0x0

.field public static final CHIP_X86:I = 0x1

.field public static final CPU_HW_HISI:I = 0x2

.field public static final CPU_HW_MTK:I = 0x1

.field public static final CPU_HW_OTHER:I = -0x1

.field public static final CPU_HW_QUALCOMM:I = 0x0

.field public static final CPU_HW_SAMSUNG:I = 0x3

.field public static final KEY_PROPERTY_BOARD:Ljava/lang/String; = "ro.product.board"

.field public static final KEY_PROPERTY_DEVICE:Ljava/lang/String; = "ro.product.device"

.field public static final KEY_PROPERTY_MANUFACTURER:Ljava/lang/String; = "ro.product.manufacturer"

.field public static final KEY_PROPERTY_MODEL:Ljava/lang/String; = "ro.product.model"

.field public static final KEY_PROPERTY_VERSION_RELEASE:Ljava/lang/String; = "ro.build.version.release"

.field public static final SDK_INT:I

.field private static sAppInstallTime:J = 0x0L

.field private static sAudioBestFramesPerBust:I = 0x0

.field private static sAudioBestSampleRate:I = 0x0

.field private static sCpuArch:I = 0x0

.field private static sCpuArchitecture:I = 0x0

.field private static sCpuHWProductIdx:I = -0x1

.field private static sCpuHWProducter:I = -0x1

.field private static sCpuHardware:Ljava/lang/String; = ""

.field private static final sCpuPerfList:[[Ljava/lang/String;

.field private static sCurrentCpuFreq:J = 0x0L

.field private static sDeviceManufacturer:Ljava/lang/String; = ""

.field private static sDeviceName:Ljava/lang/String; = ""

.field private static sFeature:Ljava/lang/String; = ""

.field private static sMaxCpuFreq:J = 0x0L

.field private static sNumOfCores:I = 0x0

.field private static sOSVersion:Ljava/lang/String; = ""

.field private static sOpenGLVersion:I = 0x0

.field private static sProcessorName:Ljava/lang/String; = "N/A"

.field private static sProductBoard:Ljava/lang/String; = ""

.field private static sProductDevice:Ljava/lang/String; = ""

.field public static sScreenHeight:I

.field public static sScreenWidth:I


# direct methods
.method static constructor <clinit>()V
    .locals 67

    const/4 v0, 0x4

    new-array v0, v0, [[Ljava/lang/String;

    const-string v1, "7MsMSs7"

    const-string v1, "MMsS277"

    const-string v1, "2M7mMS7"

    const-string v1, "MSM7227"

    const-string v2, "S72m6M7"

    const-string v2, "7MM6o7S"

    const-string v2, "MSM7627"

    const-string v3, "TMS72b72"

    const-string v3, "T227oMS7"

    const-string v3, "T7M72MuS"

    const-string v3, "MSM7227T"

    const-string v4, "6T2S7b7p"

    const-string v4, "S277MbT6"

    const-string v4, "MSM7627T"

    const-string/jumbo v5, "q2M727uA"

    const-string v5, "2A7M2Mu7"

    const-string v5, "2MsMAS77"

    const-string v5, "MSM7227A"

    const-string v6, "Mp7m62AM"

    const-string v6, "M267MA7p"

    const-string v6, "76SAo27M"

    const-string v6, "MSM7627A"

    const-string v7, "DSQ25bq"

    const-string v7, "5q2QDS0"

    const-string v7, "QSD8250"

    const-string/jumbo v8, "s065S8u"

    const-string v8, "85sS6Q0"

    const-string/jumbo v8, "p065DQS"

    const-string v8, "QSD8650"

    const-string v9, "037mMM2"

    const-string v9, "Sq302MM"

    const-string v9, "MSM7230"

    const-string v10, "M3s7S0M"

    const-string v10, "MSM7630"

    const-string v11, "855mAPQ"

    const-string v11, "5A58oPQ"

    const-string v11, "Q5A0oP5"

    const-string v11, "APQ8055"

    const-string v12, "b25MSbM"

    const-string v12, "SM5M2b5"

    const-string v12, "8M55MSu"

    const-string v12, "MSM8255"

    const-string/jumbo v13, "p6M5uM5"

    const-string v13, "M685M5u"

    const-string v13, "MqS5M68"

    const-string v13, "MSM8655"

    const-string v14, "M5s285MT"

    const-string v14, "M2M5T85p"

    const-string v14, "M85m25MS"

    const-string v14, "MSM8255T"

    const-string v15, "8qS6o55M"

    const-string/jumbo v15, "q558SM6M"

    const-string v15, "68T5MbM5"

    const-string v15, "MSM8655T"

    const-string v16, "52Ss8Mu"

    const-string v16, "58sMMS2"

    const-string/jumbo v16, "p522M8M"

    const-string v16, "MSM8225"

    const-string v17, "5q8mSM6"

    const-string v17, "M68mS25"

    const-string v17, "M8sS2M5"

    const-string v17, "MSM8625"

    const-string v18, "M0Mm2So"

    const-string v18, "2SMMo06"

    const-string v18, "M60Mo2S"

    const-string v18, "MSM8260"

    const-string v19, "8S6b0b6"

    const-string v19, "680SMb6"

    const-string v19, "MSM8660"

    const-string v20, "8M5xSQuM"

    const-string v20, "8MMx5QuS"

    const-string v20, "MSM8x25Q"

    const-string/jumbo v21, "p26MxpM"

    const-string/jumbo v21, "p6M8Mx2"

    const-string v21, "MSM8x26"

    const-string v22, "Mq10qx8"

    const-string v22, "0qxM8S1"

    const-string v22, "8Ssx0MM"

    const-string v22, "MSM8x10"

    const-string v23, "Sxs8M1M"

    const-string v23, "1MMmS82"

    const-string v23, "MSM8x12"

    const-string/jumbo v24, "x8mSo0M"

    const-string v24, "M8Sm30x"

    const-string v24, "M8S0Mbx"

    const-string v24, "MSM8x30"

    const-string v25, "6oSM28uM"

    const-string v25, "8M26o0SM"

    const-string v25, "ASM62M8p"

    const-string v25, "MSM8260A"

    const-string/jumbo v26, "q0bA8M6S"

    const-string v26, "066SAbM8"

    const-string v26, "M6sSA6M8"

    const-string v26, "MSM8660A"

    const-string v27, "8MMm9S6"

    const-string v27, "MSM8960"

    const-string v28, "M828M0u"

    const-string v28, "88S0oMM"

    const-string v28, "MSM8208"

    const-string v29, "MS1pMb9"

    const-string/jumbo v29, "pS6MM91"

    const-string v29, "S8M96Mu"

    const-string v29, "MSM8916"

    const-string v30, "S9M68qMp"

    const-string/jumbo v30, "qM96M8ST"

    const-string/jumbo v30, "qTM9MS60"

    const-string v30, "MSM8960T"

    const-string v31, "M9ssM9S"

    const-string v31, "MMs90S9"

    const-string v31, "90Sm98M"

    const-string v31, "MSM8909"

    const-string v32, "12MSov9mM"

    const-string/jumbo v32, "vM8mMS912"

    const-string v32, "2v169b8MM"

    const-string v32, "MSM8916v2"

    const-string v33, "3o86MSu"

    const-string v33, "9M83oS6"

    const-string/jumbo v33, "pMM9836"

    const-string v33, "MSM8936"

    const-string v34, "2v09b89Sq"

    const-string/jumbo v34, "vM989bS02"

    const-string v34, "S8sMv920M"

    const-string v34, "MSM8909v2"

    const-string v35, "97umMM8"

    const-string v35, "SM7M89u"

    const-string v35, "S98MoM7"

    const-string v35, "MSM8917"

    const-string v36, "4p8A0bQ"

    const-string/jumbo v36, "pQ08AP4"

    const-string v36, "QPA048u"

    const-string v36, "APQ8064"

    const-string v37, "P648AQTp"

    const-string v37, "APQ8064T"

    const-string/jumbo v38, "qq089M2"

    const-string v38, "2q9M8M0"

    const-string v38, "8MsS9M0"

    const-string v38, "MSM8920"

    const-string v39, "M3sm99S"

    const-string v39, "8SsM993"

    const-string v39, "MS99o83"

    const-string v39, "MSM8939"

    const-string v40, "S879Mbm"

    const-string v40, "9SMm78M"

    const-string v40, "MM89S3u"

    const-string v40, "MSM8937"

    const-string v41, "8MS9o23vM"

    const-string v41, "S89M932pM"

    const-string v41, "MSM8939v2"

    const-string v42, "0SM48bM"

    const-string v42, "8qSM0M9"

    const-string v42, "MSM8940"

    const-string/jumbo v43, "u5sM9M8"

    const-string v43, "859MMSu"

    const-string v43, "5MMm2S8"

    const-string v43, "MSM8952"

    const-string v44, "9MS7o4M"

    const-string/jumbo v44, "pS794MM"

    const-string v44, "S7849bM"

    const-string v44, "MSM8974"

    const-string v45, "ASqMAxu84"

    const-string v45, "MAS4xA8Mq"

    const-string v45, "MA48xASpM"

    const-string v45, "MSM8x74AA"

    const-string v46, "BMsM7xA8q"

    const-string v46, "MAs7SMB8x"

    const-string v46, "B8sM47MxS"

    const-string v46, "MSM8x74AB"

    const-string v47, "Ax4mSmM87"

    const-string v47, "C8AmxSM47"

    const-string v47, "S4M8oxMA7"

    const-string v47, "MSM8x74AC"

    const-string v48, "Mo5SMb9"

    const-string v48, "59MMoS8"

    const-string v48, "M593SMu"

    const-string v48, "MSM8953"

    const-string/jumbo v49, "pQ4b8A8"

    const-string v49, "A48Q0b8"

    const-string v49, "Aq80P8Q"

    const-string v49, "APQ8084"

    const-string v50, "8usorM95P3"

    const-string v50, "83S9MruoP5"

    const-string v50, "MSM8953Pro"

    const-string v51, "9pMmSM2"

    const-string/jumbo v51, "p2MSM99"

    const-string v51, "MSM8992"

    const-string v52, "M859oS6"

    const-string v52, "6q859SM"

    const-string v52, "M68S9bM"

    const-string v52, "MSM8956"

    const-string v53, "MMs769u"

    const-string v53, "9MsMS67"

    const-string/jumbo v53, "pS897M6"

    const-string v53, "MSM8976"

    const-string v54, "6mMoP7S8qM"

    const-string v54, "S78mPMMro6"

    const-string v54, "76sP98oMrS"

    const-string v54, "MSM8976Pro"

    const-string v55, "SM9m9Mo"

    const-string v55, "M99Mo4S"

    const-string v55, "S8M9o94"

    const-string v55, "MSM8994"

    const-string v56, "bM986bS"

    const-string v56, "968MSb9"

    const-string v56, "869MM9u"

    const-string v56, "MSM8996"

    const-string v57, "9urM86SpM9"

    const-string v57, "S9rM9ouM68"

    const-string v57, "6roMS89Mq9"

    const-string v57, "MSM8996Pro"

    const-string v58, "MSsp899"

    const-string/jumbo v58, "pMS9M98"

    const-string v58, "9MSm88M"

    const-string v58, "MSM8998"

    const-string v59, "4qS5oM"

    const-string v59, "M5qD4S"

    const-string v59, "M8DS5b"

    const-string v59, "SDM845"

    const-string/jumbo v60, "u58sS1"

    const-string v60, "M8s51S"

    const-string v60, "5pSM01"

    const-string v60, "SM8150"

    const-string v61, "0SqmM8"

    const-string v61, "85Sm0M"

    const-string v61, "5Ss028"

    const-string v61, "SM8250"

    const-string v62, "MAomS528B"

    const-string v62, "SM20o8B5A"

    const-string v62, "2ABMoS58-"

    const-string v62, "SM8250-AB"

    const-string v63, "25CASbM-8"

    const-string v63, "SM8250-AC"

    const-string/jumbo v64, "uMb05S"

    const-string v64, "M5S08b"

    const-string v64, "0p8MS5"

    const-string v64, "SM8350"

    const-string v65, "5-uS8M0Aq"

    const-string v65, "0S58M-uCA"

    const-string v65, "5As0-8SM3"

    const-string v65, "SM8350-AC"

    const-string v66, "048mpM"

    const-string v66, "8pM045"

    const-string v66, "850MoS"

    const-string v66, "SM8450"

    filled-new-array/range {v1 .. v66}, [Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-string v3, "1T65qb"

    const-string v3, "51q6MT"

    const-string/jumbo v3, "u616MT"

    const-string v3, "MT6516"

    const-string v4, "3Ms6T5"

    const-string v4, "5pT163"

    const-string v4, "MT6513"

    const-string v5, "6mq37T"

    const-string v5, "365m7T"

    const-string v5, "3Ms7T5"

    const-string v5, "MT6573"

    const-string v6, "T5Mm561"

    const-string v6, "M655o1T"

    const-string v6, "65M1o5T"

    const-string v6, "MT6515M"

    const-string v7, "565T1b"

    const-string v7, "1T55Mb"

    const-string v7, "MT6515"

    const-string/jumbo v8, "uuTM76"

    const-string/jumbo v8, "u57TM6"

    const-string v8, "Mp5T57"

    const-string v8, "MT6575"

    const-string v9, "26qM5p"

    const-string v9, "Mp2756"

    const-string v9, "72s6T5"

    const-string v9, "MT6572"

    const-string v10, "77Tm6q"

    const-string v10, "T7qM67"

    const-string v10, "5M76o7"

    const-string v10, "MT6577"

    const-string v11, "T859sb"

    const-string v11, "M8s5T9"

    const-string/jumbo v11, "uM6598"

    const-string v11, "MT6589"

    const-string v12, "5pMT6m"

    const-string v12, "TM2m56"

    const-string v12, "52qT6M"

    const-string v12, "MT6582"

    const-string/jumbo v13, "o5s62T"

    const-string v13, "695To2"

    const-string v13, "M65mT2"

    const-string v13, "MT6592"

    const-string v14, "55bMo9"

    const-string v14, "55TM9b"

    const-string v14, "T955Mb"

    const-string v14, "MT6595"

    const-string/jumbo v15, "u657T3"

    const-string/jumbo v15, "u36T75"

    const-string v15, "MT6735"

    const-string/jumbo v16, "pp6507"

    const-string v16, "5p67T0"

    const-string v16, "75q0TM"

    const-string v16, "MT6750"

    const-string v17, "3MsT65"

    const-string v17, "35q6TM"

    const-string v17, "7T6mM5"

    const-string v17, "MT6753"

    const-string v18, "67Mso5"

    const-string v18, "6Ms257"

    const-string v18, "T567Mb"

    const-string v18, "MT6752"

    const-string/jumbo v19, "uMm55T"

    const-string v19, "5M5m7T"

    const-string v19, "MT6755"

    const-string v20, "5p6T7M"

    const-string v20, "MT6755"

    const-string v21, "MT6755T"

    const-string/jumbo v22, "o6qMT5"

    const-string v22, "M659oT"

    const-string v22, "MTs965"

    const-string v22, "MT6795"

    const-string v23, "756mb7"

    const-string v23, "576M7b"

    const-string v23, "M76To7"

    const-string v23, "MT6757"

    const-string v24, "5uT76b"

    const-string/jumbo v24, "u6xT75"

    const-string/jumbo v24, "u6M7Tx"

    const-string v24, "MT675x"

    const-string v25, "6pM797"

    const-string v25, "9p767M"

    const-string v25, "MT6797"

    const-string v26, "7q7TMT6"

    const-string v26, "6qT77TM"

    const-string v26, "67sM79T"

    const-string v26, "MT6797T"

    const-string v27, "X97ms76"

    const-string v27, "97sMX76"

    const-string v27, "MT6797X"

    const-string v28, "MVTmo17"

    const-string v28, "TV7mM61"

    const-string v28, "6VTM7b1"

    const-string v28, "MT6771V"

    const-string/jumbo v29, "u69To9"

    const-string v29, "T699oM"

    const-string v29, "7p699T"

    const-string v29, "MT6799"

    const-string v30, "69Z6Mb7"

    const-string v30, "Zq6T679"

    const-string v30, "MT6769Z"

    const-string v31, "TMs6Tu7"

    const-string v31, "678TMTu"

    const-string v31, "85Tm7MT"

    const-string v31, "MT6785T"

    const-string v32, "5M6VoT3"

    const-string v32, "MT6853V"

    const-string v33, "MTp8Vb6"

    const-string/jumbo v33, "pTM658V"

    const-string v33, "5VM3T8u"

    const-string v33, "MT6853V"

    const-string v34, "Mp7T3q"

    const-string v34, "78qMT3"

    const-string v34, "3Mq6T8"

    const-string v34, "MT6873"

    const-string/jumbo v35, "s8sM76"

    const-string v35, "78sT6M"

    const-string v35, "MT6874"

    const-string/jumbo v36, "m76m5T"

    const-string v36, "5TMm76"

    const-string v36, "87MTo6"

    const-string v36, "MT6875"

    const-string v37, "687MTb"

    const-string v37, "68M7oT"

    const-string/jumbo v37, "u76M87"

    const-string v37, "MT6877"

    const-string v38, "8M5T6b"

    const-string v38, "8p65T8"

    const-string v38, "MT6885"

    const-string v39, "Vq98uT8"

    const-string v39, "6T9V88u"

    const-string v39, "98s8VT6"

    const-string v39, "MT6889V"

    const-string v40, "Z68m9Mp"

    const-string/jumbo v40, "pZ8M689"

    const-string v40, "8TM9o86"

    const-string v40, "MT6889Z"

    const-string v41, "Z16M8bT"

    const-string v41, "MT6891Z"

    const-string/jumbo v42, "u9M3T8"

    const-string v42, "8MqT93"

    const-string v42, "Mp6T93"

    const-string v42, "MT6893"

    const-string v43, "38q9MT"

    const-string v43, "T8s39M"

    const-string v43, "6MsT38"

    const-string v43, "MT6983"

    filled-new-array/range {v3 .. v43}, [Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    aput-object v1, v0, v3

    const-string v4, "2KV3"

    const-string v4, "K3V2"

    const-string v4, "23KV"

    const-string v4, "K3V2"

    const-string v5, "KmVm3"

    const-string v5, "VK3m2"

    const-string v5, "3V2Ko"

    const-string v5, "K3V2E"

    const-string v6, "b2o+3"

    const-string v6, "V+23o"

    const-string v6, "Vu3+K"

    const-string v6, "K3V2+"

    const-string/jumbo v7, "r1nKi0bp"

    const-string/jumbo v7, "iKirnb10"

    const-string v7, "Kirin910"

    const-string/jumbo v8, "q2ui90ri"

    const-string/jumbo v8, "ir29iKu0"

    const-string/jumbo v8, "iKsni02r"

    const-string v8, "Kirin920"

    const-string/jumbo v9, "n2pm9iir"

    const-string/jumbo v9, "inr29i5p"

    const-string v9, "Kirin925"

    const-string/jumbo v10, "q2iio8rn"

    const-string/jumbo v10, "qinr928i"

    const-string v10, "K9rinbi8"

    const-string v10, "Kirin928"

    const-string v11, "K6rin2u0"

    const-string v11, "Kis0rn26"

    const-string/jumbo v11, "i620rinp"

    const-string v11, "Kirin620"

    const-string/jumbo v12, "qr0miiKn"

    const-string v12, "05imKinr"

    const-string/jumbo v12, "n6sii5Kr"

    const-string v12, "Kirin650"

    const-string v13, "56Kmo5in"

    const-string/jumbo v13, "n5r6oK5i"

    const-string v13, "55inoKi6"

    const-string v13, "Kirin655"

    const-string/jumbo v14, "rn3Kbbii"

    const-string/jumbo v14, "ir3nib0K"

    const-string/jumbo v14, "n0i9K3ur"

    const-string v14, "Kirin930"

    const-string v15, "9iKrun3p"

    const-string v15, "K9n35iur"

    const-string v15, "Kirin935"

    const-string/jumbo v16, "qiiKp0r5"

    const-string/jumbo v16, "n0iriK5p"

    const-string v16, "50s9inKi"

    const-string v16, "Kirin950"

    const-string/jumbo v17, "iq9m55nK"

    const-string/jumbo v17, "qin5i5K9"

    const-string v17, "5r5noiKi"

    const-string v17, "Kirin955"

    const-string/jumbo v18, "iis96b0r"

    const-string v18, "69sir0Ki"

    const-string/jumbo v18, "iK90nrui"

    const-string v18, "Kirin960"

    const-string v19, "7mni9irp"

    const-string/jumbo v19, "inKm9r7i"

    const-string v19, "Kirin970"

    const-string/jumbo v20, "q8iio1Kn"

    const-string v20, "1n0Ko8ii"

    const-string v20, "8isiK10n"

    const-string v20, "Kirin810"

    const-string/jumbo v21, "ib0m9iK8"

    const-string/jumbo v21, "iK89ib0n"

    const-string v21, "0rKio89i"

    const-string v21, "Kirin980"

    const-string/jumbo v22, "iuirKb20"

    const-string/jumbo v22, "rni2Kiu0"

    const-string v22, "Kn0ii2u8"

    const-string v22, "Kirin820"

    const-string/jumbo v23, "pin9r5Kp"

    const-string v23, "9Ki5nrip"

    const-string/jumbo v23, "qi89niKr"

    const-string v23, "Kirin985"

    const-string v24, "Kirin990"

    const-string v25, "0Ks00nEqr9"

    const-string v25, "E900iKrnq0"

    const-string v25, "EirmK0n090"

    const-string v25, "Kirin9000E"

    const-string/jumbo v26, "nisri00K9"

    const-string v26, "0Kiio0n09"

    const-string v26, "Kirin9000"

    filled-new-array/range {v4 .. v26}, [Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    aput-object v1, v0, v3

    const-string v4, "8S90mbL"

    const-string v4, "50Lm8S9"

    const-string v4, "089S0Lu"

    const-string v4, "S5L8900"

    const-string/jumbo v5, "p0oC1SP"

    const-string v5, "C1PSo05"

    const-string v5, "1qS0P0C"

    const-string v5, "S5PC100"

    const-string/jumbo v6, "y0sx1E1sbn"

    const-string/jumbo v6, "xysnEb0o11"

    const-string/jumbo v6, "oE0mxny1s3"

    const-string v6, "Exynos3110"

    const-string v7, "7xEno43syu"

    const-string/jumbo v7, "s37xnouy4E"

    const-string/jumbo v7, "n7o3sbExy4"

    const-string v7, "Exynos3475"

    const-string/jumbo v8, "p0xys4u2on"

    const-string v8, "2n4E0yspox"

    const-string/jumbo v8, "o0yxn14psE"

    const-string v8, "Exynos4210"

    const-string/jumbo v9, "y2o412Esqn"

    const-string v9, "Exynos4212"

    const-string v10, "Kqs1S42D"

    const-string/jumbo v10, "qK1xD4S2"

    const-string v10, "DS1mMx24"

    const-string v10, "SMDK4x12"

    const-string v11, "42soxy4nE1"

    const-string v11, "4yx4o2sE1n"

    const-string v11, "Exynos4412"

    const-string v12, "52n0xbymEo"

    const-string/jumbo v12, "x0Emyos52n"

    const-string v12, "Exynos5250"

    const-string v13, "2s0Eyouxon"

    const-string/jumbo v13, "ysnxoo20E6"

    const-string/jumbo v13, "nys5026poE"

    const-string v13, "Exynos5260"

    const-string/jumbo v14, "s10byExnq5"

    const-string/jumbo v14, "y4nx0bs5E1"

    const-string/jumbo v14, "s1snxy05E4"

    const-string v14, "Exynos5410"

    const-string v15, "5yum420Eon"

    const-string/jumbo v15, "yo4025usnE"

    const-string/jumbo v15, "sEyxo45on2"

    const-string v15, "Exynos5420"

    const-string v16, "252onbEsxp"

    const-string v16, "4n2o5s2pEx"

    const-string/jumbo v16, "y45xosu2E2"

    const-string v16, "Exynos5422"

    const-string/jumbo v17, "qnos3y5px4"

    const-string v17, "Exs5n43yqo"

    const-string/jumbo v17, "s35n04xEqy"

    const-string v17, "Exynos5430"

    const-string/jumbo v18, "x0s5s0nyEo"

    const-string/jumbo v18, "x5s0ns0oEy"

    const-string v18, "0nym5sxo08"

    const-string v18, "Exynos5800"

    const-string v19, "E3nyoxo354"

    const-string v19, "4x3mnEy35o"

    const-string v19, "34xn5boysE"

    const-string v19, "Exynos5433"

    const-string v20, "78s5o0uoxy"

    const-string v20, "7sy0oE85ox"

    const-string v20, "70yE8snpo5"

    const-string v20, "Exynos7580"

    const-string v21, "8E7sx7onq0"

    const-string/jumbo v21, "son77b0Ex8"

    const-string/jumbo v21, "o0s7nsy8E7"

    const-string v21, "Exynos7870"

    const-string v22, "8Esm07xyuo"

    const-string/jumbo v22, "oE087nusyx"

    const-string v22, "Eno8oxys07"

    const-string v22, "Exynos7870"

    const-string/jumbo v23, "p0274bsoyE"

    const-string v23, "40sy7Exp2o"

    const-string/jumbo v23, "sx2En4uo70"

    const-string v23, "Exynos7420"

    const-string/jumbo v24, "sx0q9yop8n"

    const-string v24, "8n08yos9qx"

    const-string v24, "Exynos8890"

    const-string/jumbo v25, "n9sEsx8y0"

    const-string/jumbo v25, "yon8sE9xq"

    const-string v25, "Exynos890"

    const-string/jumbo v26, "xEsm9snyo8"

    const-string/jumbo v26, "nE8mo8sxy9"

    const-string/jumbo v26, "n5sm8x8yoE"

    const-string v26, "Exynos8895"

    const-string v27, "8o91oxsyn0"

    const-string v27, "Exynos9810"

    const-string v28, "8Eonob2ys9"

    const-string/jumbo v28, "s8y9oxn2Eo"

    const-string/jumbo v28, "o8xn90us2y"

    const-string v28, "Exynos9820"

    const-string v29, "bs9x85Epoy"

    const-string v29, "9nE5oby8sx"

    const-string v29, "Exynos9825"

    const-string/jumbo v30, "yE990snoq"

    const-string v30, "0o9s9yunE"

    const-string/jumbo v30, "oxsy9n9sE"

    const-string v30, "Exynos990"

    const-string v31, "0s0mnEx81o"

    const-string v31, "8o0nxE1ps0"

    const-string v31, "0xnooy8Es1"

    const-string v31, "Exynos1080"

    const-string v32, "2xs0obyq01"

    const-string v32, "0o0xys1nq2"

    const-string v32, "2100yEuxon"

    const-string v32, "Exynos2100"

    const-string/jumbo v33, "s0snx2op2E"

    const-string v33, "0ssxE2n20o"

    const-string/jumbo v33, "os22n0xEq0"

    const-string v33, "Exynos2200"

    filled-new-array/range {v4 .. v33}, [Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    aput-object v1, v0, v3

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuPerfList:[[Ljava/lang/String;

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    sput-wide v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sMaxCpuFreq:J

    sput-wide v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCurrentCpuFreq:J

    const/4 v0, -0x1

    sput v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sNumOfCores:I

    sput v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArch:I

    sput v2, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sOpenGLVersion:I

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x19

    if-ne v0, v1, :cond_0

    sget-object v1, Landroid/os/Build$VERSION;->CODENAME:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_0

    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v2, 0x4f

    if-ne v1, v2, :cond_0

    const/16 v0, 0x1a

    :cond_0
    sput v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->SDK_INT:I

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method private static checkPermission(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "s~s~ oylt4o@~~d~  /@~~ao@~ .@@~ @i @ ~/ @bnoo@ ci b~@@~u @@@~M~bt~r@ @@ilSKo~- @~f  1@f~~v ~~@m "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->hasMarshmallow()Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    return v1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz p0, :cond_4

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x4

    if-eqz v2, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string v2, "aiemr.NdEnTEomSros.mISTRnTiWIipsd"

    const-string/jumbo v2, "pSomnNImErTWae.iEs_.doTsrIiTSRnid"

    const-string v2, "TEsooWS_o.iaTrinpIRSG.rmedEiITsnd"

    const-string v2, "android.permission.WRITE_SETTINGS"

    const/4 v4, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p0}, Landroid/provider/Settings$System;->canWrite(Landroid/content/Context;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_1

    :cond_2
    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p0, p1}, Landroidx/core/content/d;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-nez p0, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    move v1, v0

    move v1, v0

    const/4 v4, 0x7

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    move v0, v1

    move v0, v1

    const/4 v4, 0x1

    move v0, v1

    move v0, v1

    :catch_0
    :cond_4
    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    return v0
.end method

.method public static getApiLevel()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public static getBestAudioFramesPerBust()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sAudioBestFramesPerBust:I

    const/4 v2, 0x7

    return v0
.end method

.method public static getBestAudioSampleRate()I
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sAudioBestSampleRate:I

    const/4 v1, 0x2

    return v0
.end method

.method public static getCpuArchFromId(I)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/16 v0, 0x40

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eq p0, v0, :cond_0

    const/4 v1, 0x1

    const/4 v1, 0x6

    packed-switch p0, :pswitch_data_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 p0, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :pswitch_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 p0, 0x6

    const/4 v2, 0x6

    const/4 v1, 0x2

    goto :goto_0

    :pswitch_1
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 p0, 0x4

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_0

    :pswitch_2
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 p0, 0x3

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    :pswitch_3
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 p0, 0x7

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return p0

    nop

    :pswitch_data_0
    .packed-switch 0x5
        :pswitch_2
        :pswitch_1
        :pswitch_0
        :pswitch_3
        :pswitch_3
        :pswitch_3
    .end packed-switch
.end method

.method public static getCpuArchitecture()I
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArch:I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v1, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x6

    if-eq v1, v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    return v0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v1, "getCpuArchitecture Build.CPU_ABI: "

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    xor-int/2addr v5, v4

    sget-object v1, Landroid/os/Build;->CPU_ABI:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v2, 0x2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v2, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string v0, "8aom-bra4"

    const-string v0, "8-a6om4ra"

    const/4 v5, 0x6

    const-string v0, "8ra6amuv4"

    const-string v0, "arm64-v8a"

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v3, 0x7

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v0, :cond_1

    const/4 v5, 0x0

    sput v3, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArch:I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    return v3

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v1, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string/jumbo v0, "x68"

    const-string v0, "68x"

    const/4 v5, 0x5

    const-string/jumbo v0, "x86"

    const-string/jumbo v0, "x86"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    if-nez v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string v0, "68X"

    const-string v0, "86X"

    const/4 v5, 0x1

    const-string v0, "X86"

    const-string v0, "X86"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v0, :cond_3

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v0, 0x1

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    sput v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArch:I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto/16 :goto_1

    :cond_3
    if-eqz v1, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x5

    const-string/jumbo v0, "mspi"

    const-string/jumbo v0, "ipsm"

    const/4 v5, 0x7

    const-string/jumbo v0, "psim"

    const-string/jumbo v0, "mips"

    const/4 v5, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    if-nez v0, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v0, "sMpi"

    const-string/jumbo v0, "siMp"

    const/4 v5, 0x4

    const-string/jumbo v0, "sMpi"

    const-string v0, "Mips"

    const/4 v5, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v0, :cond_5

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    sput v2, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArch:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    goto/16 :goto_1

    :cond_5
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArchitecture:I

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez v0, :cond_6

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuInfo()V

    :cond_6
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v1, " tp:rphpmuuAcceihguArtCtereeicrtCbcu"

    const-string v1, "C:gAubAieehutpretcmp eeccrchuCittrru"

    const/4 v5, 0x7

    const-string v1, "ercphuttqhA AeecCecptCimicreu:guttur"

    const-string/jumbo v1, "getCpuArchitecture mCpuArchitecture:"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    sget v1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArchitecture:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v2, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHardware:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v0, :cond_7

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHardware:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string v1, "94suMS8"

    const-string v1, "94MS89u"

    const/4 v5, 0x1

    const-string v1, "MS8mM99"

    const-string v1, "MSM8994"

    const/4 v4, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v0, :cond_7

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    sput v3, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArch:I

    const/4 v5, 0x5

    return v3

    :cond_7
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->isARMV5Whitelist()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_8

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v0, 0x3

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    sput v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArch:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    return v0

    :cond_8
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sProcessorName:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 v1, 0x4

    const/4 v4, 0x0

    and-int/2addr v5, v4

    if-nez v0, :cond_9

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sProcessorName:Ljava/lang/String;

    const-string v2, "A6vMo"

    const-string v2, "Mvp6A"

    const-string v2, "bMAR6"

    const-string v2, "ARMv6"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v0, :cond_9

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    sput v1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArch:I

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    return v1

    :cond_9
    const/4 v4, 0x1

    const/4 v4, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sProcessorName:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x2

    and-int/2addr v5, v4

    if-nez v0, :cond_a

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sProcessorName:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v2, "AqhAr4u"

    const-string/jumbo v2, "hqcArA4"

    const/4 v5, 0x6

    const-string v2, "AArch64"

    const/4 v4, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v0, :cond_a

    const/4 v5, 0x0

    const/4 v4, 0x1

    sput v3, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArch:I

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    return v3

    :cond_a
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArchitecture:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-ne v0, v3, :cond_b

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sFeature:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez v0, :cond_b

    const/4 v4, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sFeature:Ljava/lang/String;

    const/4 v4, 0x4

    move v5, v4

    const-string/jumbo v2, "neno"

    const-string/jumbo v2, "none"

    const/4 v5, 0x6

    const-string v2, "enno"

    const-string/jumbo v2, "neon"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez v0, :cond_b

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sFeature:Ljava/lang/String;

    const/4 v4, 0x4

    const-string/jumbo v2, "ispsm"

    const-string/jumbo v2, "sdsim"

    const/4 v5, 0x7

    const-string v2, "amsqd"

    const-string v2, "asimd"

    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-nez v0, :cond_b

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    sput v1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArch:I

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    return v1

    :cond_b
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArchitecture:I

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuArchFromId(I)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    goto/16 :goto_0

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArch:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    return v0
.end method

.method private static getCpuHWProducer(Ljava/lang/String;)I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    return v1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string/jumbo v0, "nmsoxy"

    const-string/jumbo v0, "xsymon"

    const-string/jumbo v0, "soxmyE"

    const-string v0, "Exynos"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez v0, :cond_7

    const/4 v3, 0x6

    const-string v0, "DKMS"

    const-string v0, "KMDS"

    const/4 v3, 0x1

    const-string v0, "SKMD"

    const-string v0, "SMDK"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v0, :cond_7

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string v0, "098Soo0"

    const-string v0, "58S0o09"

    const/4 v3, 0x2

    const-string v0, "S0L58b9"

    const-string v0, "S5L8900"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez v0, :cond_7

    const/4 v3, 0x4

    const/4 v2, 0x0

    const-string v0, "0b5SC1u"

    const-string v0, "1PC5Sb0"

    const/4 v3, 0x0

    const-string/jumbo v0, "p0105CP"

    const-string v0, "S5PC100"

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto/16 :goto_2

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo v0, "iruqK"

    const-string/jumbo v0, "iuirK"

    const/4 v3, 0x7

    const-string/jumbo v0, "risKn"

    const-string v0, "Kirin"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-nez v0, :cond_6

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v0, "VK3"

    const-string v0, "3KV"

    const-string v0, "3VK"

    const-string v0, "K3V"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto/16 :goto_1

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x4

    const-string v0, "MMS"

    const-string v0, "MMS"

    const/4 v3, 0x0

    const-string v0, "MSM"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-nez v0, :cond_5

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string v0, "PAQ"

    const-string v0, "APQ"

    const/4 v3, 0x3

    const-string v0, "APQ"

    const-string v0, "APQ"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-nez v0, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string v0, "QSD"

    const/4 v3, 0x2

    const-string v0, "DQS"

    const-string v0, "QSD"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v0, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v0, "DMS"

    const-string v0, "SMD"

    const/4 v3, 0x5

    const-string v0, "DMS"

    const-string v0, "SDM"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v0, :cond_5

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string v0, "MS"

    const-string v0, "MS"

    const/4 v3, 0x3

    const-string v0, "SM"

    const-string v0, "SM"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v0, "6TM"

    const-string v0, "M6T"

    const-string v0, "MT6"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz p0, :cond_4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 p0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    return p0

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    return v1

    :cond_5
    :goto_0
    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    return p0

    :cond_6
    :goto_1
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 p0, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return p0

    :cond_7
    :goto_2
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 p0, 0x2

    const/4 p0, 0x3

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    return p0
.end method

.method public static getCpuHWProductIndex(ILjava/lang/String;)I
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v0, -0x1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-ltz p0, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuPerfList:[[Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x7

    array-length v2, v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-lt p0, v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto :goto_1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    return v0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    aget-object p0, v1, p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    array-length v2, p0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-ge v1, v2, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    aget-object v2, p0, v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v2, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    return v1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_0

    :cond_3
    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    return v0
.end method

.method public static getCpuHWProductIndex(Ljava/lang/String;)I
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHWProducter:I

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-gez v0, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuHWProducer(Ljava/lang/String;)I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    sput v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHWProducter:I

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHWProducter:I

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-ltz v0, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    sget v1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHWProductIdx:I

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-gez v1, :cond_4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuPerfList:[[Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    aget-object v0, v1, v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 v1, -0x1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    move v3, v1

    move v3, v1

    const/4 v7, 0x0

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    array-length v4, v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-ge v2, v4, :cond_3

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    aget-object v4, v0, v2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {p0, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-eqz v4, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-ne v1, v3, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    goto :goto_1

    :cond_1
    const/4 v7, 0x4

    aget-object v4, v0, v2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    aget-object v5, v0, v3

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-le v4, v5, :cond_2

    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    move v3, v2

    move v3, v2

    const/4 v7, 0x7

    move v3, v2

    move v3, v2

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    goto :goto_0

    :cond_3
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    sput v3, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHWProductIdx:I

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x5

    sget p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHWProductIdx:I

    const/4 v7, 0x7

    return p0
.end method

.method public static getCpuHWProducter(Ljava/lang/String;)I
    .locals 3

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHWProducter:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-gez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuHWProducer(Ljava/lang/String;)I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    sput p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHWProducter:I

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHWProducter:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    return p0
.end method

.method public static getCpuHarewareName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHardware:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuInfo()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHardware:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x6

    return-object v0
.end method

.method public static getCpuInfo()V
    .locals 7

    const/4 v6, 0x1

    const/4 v0, 0x4

    const/4 v6, 0x7

    move v5, v0

    move v5, v0

    const/4 v1, 0x6

    const/4 v1, 0x0

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    new-instance v2, Ljava/io/InputStreamReader;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    new-instance v3, Ljava/io/FileInputStream;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string/jumbo v4, "fpcmir/op/upc"

    const-string v4, "//pcnpiprfcuo"

    const/4 v6, 0x3

    const-string/jumbo v4, "u/crop/cinoof"

    const-string v4, "/proc/cpuinfo"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-direct {v3, v4}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string v4, "-8FqU"

    const/4 v6, 0x0

    const-string v4, "b-F8T"

    const-string v4, "UTF-8"

    const/4 v6, 0x4

    invoke-direct {v2, v3, v4}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v5, 0x2

    const/4 v6, 0x1

    new-instance v3, Ljava/io/BufferedReader;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {v3, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    :try_start_2
    const/4 v6, 0x5

    invoke-virtual {v3}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v1}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->parseCpuInfoLine(Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_0

    :cond_0
    :try_start_3
    const/4 v6, 0x3

    invoke-virtual {v2}, Ljava/io/InputStreamReader;->close()V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v3}, Ljava/io/BufferedReader;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-void

    :catch_0
    move-exception v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-void

    :catchall_0
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :catchall_1
    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    goto :goto_1

    :catchall_2
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :goto_1
    :try_start_4
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string/jumbo v2, "sonwknu"

    const-string/jumbo v2, "nnsonwk"

    const/4 v6, 0x0

    const-string/jumbo v2, "pUoknnn"

    const-string v2, "Unknown"

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    sput-object v2, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHardware:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/4 v2, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    sput v2, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArchitecture:I
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eqz v1, :cond_1

    :try_start_5
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/io/InputStreamReader;->close()V

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-eqz v3, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x3

    invoke-virtual {v3}, Ljava/io/BufferedReader;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_0

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-void

    :catchall_3
    move-exception v2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eqz v1, :cond_3

    :try_start_6
    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1}, Ljava/io/InputStreamReader;->close()V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    goto :goto_2

    :catch_1
    move-exception v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    goto :goto_3

    :cond_3
    :goto_2
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-eqz v3, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v3}, Ljava/io/BufferedReader;->close()V
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_1

    const/4 v5, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_4

    :goto_3
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    :cond_4
    :goto_4
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    throw v2
.end method

.method public static getCurrentCpuFreq()J
    .locals 12

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    sget-wide v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCurrentCpuFreq:J

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v11, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    cmp-long v4, v0, v2

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-lez v4, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    return-wide v0

    :cond_0
    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    const/4 v0, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x6

    const/4 v1, 0x4

    const/4 v11, 0x2

    const-wide/32 v4, 0xfa000

    const-wide/32 v4, 0xfa000

    const/4 v11, 0x7

    const-wide/32 v4, 0xfa000

    const-wide/32 v4, 0xfa000

    :try_start_0
    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x7

    const-string/jumbo v6, "ssseestuqmecc/yce/nv/rrsqci_c/sqpycuu_/le/d0fpauprg/f"

    const-string v6, "/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq"

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x7

    new-instance v7, Ljava/io/InputStreamReader;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x1

    new-instance v8, Ljava/io/FileInputStream;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-direct {v8, v6}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x6

    const-string v6, "TFs-8"

    const-string v6, "F-8mT"

    const/4 v11, 0x6

    const-string v6, "TU-m8"

    const-string v6, "UTF-8"

    const/4 v11, 0x1

    invoke-direct {v7, v8, v6}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_8
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_7
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_6
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    :try_start_1
    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    new-instance v6, Ljava/io/BufferedReader;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-direct {v6, v7}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_1
    .catch Ljava/io/FileNotFoundException; {:try_start_1 .. :try_end_1} :catch_5
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_4
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_3
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {v6}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-nez v0, :cond_1

    const/4 v10, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {v7}, Ljava/io/InputStreamReader;->close()V

    invoke-virtual {v6}, Ljava/io/BufferedReader;->close()V
    :try_end_2
    .catch Ljava/io/FileNotFoundException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {v7}, Ljava/io/InputStreamReader;->close()V

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-virtual {v6}, Ljava/io/BufferedReader;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    return-wide v2

    :catchall_0
    move-exception v0

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x6

    return-wide v2

    :cond_1
    :try_start_4
    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v8

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-lez v8, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    :cond_2
    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    sput-wide v4, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCurrentCpuFreq:J
    :try_end_4
    .catch Ljava/io/FileNotFoundException; {:try_start_4 .. :try_end_4} :catch_2
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_1
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :try_start_5
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {v7}, Ljava/io/InputStreamReader;->close()V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {v6}, Ljava/io/BufferedReader;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x7

    goto/16 :goto_4

    :catchall_1
    move-exception v0

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x1

    goto/16 :goto_1

    :catch_1
    move-exception v0

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    goto/16 :goto_2

    :catch_2
    move-exception v0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    goto/16 :goto_3

    :catchall_2
    move-exception v6

    move-object v9, v6

    move-object v9, v6

    move-object v9, v6

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v0, v9

    move-object v0, v9

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    goto :goto_0

    :catch_3
    move-exception v6

    move-object v9, v6

    move-object v9, v6

    move-object v9, v6

    move-object v9, v6

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x1

    goto :goto_1

    :catch_4
    move-exception v6

    move-object v9, v6

    move-object v9, v6

    move-object v9, v6

    move-object v9, v6

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    goto/16 :goto_2

    :catch_5
    move-exception v6

    move-object v9, v6

    move-object v9, v6

    move-object v9, v6

    move-object v9, v6

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    const/4 v11, 0x7

    const/4 v10, 0x7

    goto/16 :goto_3

    :catchall_3
    move-exception v6

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    :goto_0
    :try_start_6
    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x1

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    const/4 v11, 0x5

    if-eqz v7, :cond_3

    :try_start_7
    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {v7}, Ljava/io/InputStreamReader;->close()V

    :cond_3
    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x4

    if-eqz v6, :cond_7

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {v6}, Ljava/io/BufferedReader;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x7

    goto/16 :goto_4

    :catch_6
    move-exception v6

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    :goto_1
    :try_start_8
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    const/4 v11, 0x3

    const/4 v10, 0x4

    if-eqz v7, :cond_4

    :try_start_9
    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {v7}, Ljava/io/InputStreamReader;->close()V

    :cond_4
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x7

    if-eqz v6, :cond_7

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {v6}, Ljava/io/BufferedReader;->close()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_0

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    goto :goto_4

    :catch_7
    move-exception v6

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    :goto_2
    :try_start_a
    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_4

    const/4 v11, 0x1

    const/4 v10, 0x4

    if-eqz v7, :cond_5

    :try_start_b
    const/4 v10, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-virtual {v7}, Ljava/io/InputStreamReader;->close()V

    :cond_5
    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x0

    if-eqz v6, :cond_7

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-virtual {v6}, Ljava/io/BufferedReader;->close()V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_0

    const/4 v11, 0x7

    goto :goto_4

    :catch_8
    move-exception v6

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    :goto_3
    :try_start_c
    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_4

    const/4 v10, 0x5

    const/4 v11, 0x3

    if-eqz v7, :cond_6

    :try_start_d
    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-virtual {v7}, Ljava/io/InputStreamReader;->close()V

    :cond_6
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x4

    if-eqz v6, :cond_7

    const/4 v11, 0x4

    invoke-virtual {v6}, Ljava/io/BufferedReader;->close()V

    :cond_7
    :goto_4
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x0

    return-wide v4

    :catchall_4
    move-exception v0

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    if-eqz v7, :cond_8

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v7}, Ljava/io/InputStreamReader;->close()V

    :cond_8
    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x5

    if-eqz v6, :cond_9

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v6}, Ljava/io/BufferedReader;->close()V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_0

    :cond_9
    const/4 v10, 0x4

    const/4 v11, 0x5

    throw v0
.end method

.method public static getDeviceManufacturer()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sDeviceManufacturer:Ljava/lang/String;

    const/4 v2, 0x7

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sDeviceManufacturer:Ljava/lang/String;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sDeviceManufacturer:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public static declared-synchronized getDeviceName()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;

    const/4 v3, 0x5

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sDeviceName:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    sput-object v1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sDeviceName:Ljava/lang/String;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sDeviceName:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    throw v1
.end method

.method public static getMaxCpuFreq()J
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    sget-wide v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sMaxCpuFreq:J

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v8, 0x4

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    cmp-long v2, v2, v0

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-eqz v2, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    return-wide v0

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    const/4 v0, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 v1, 0x4

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v8, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    :try_start_0
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string/jumbo v4, "s0quooxrcmcniifyq_tpfyvuesaerp/e//pse/mcds/epuf/s_uoc"

    const-string v4, "_ifpomqcqsun/p/ocsatfipuruce/s_um//fcpceeeyys/vd0xesr"

    const/4 v8, 0x6

    const-string/jumbo v4, "se/r_bnuep/sifqcyerxdqspceupuamt0csip/sfy_uv/cc//fe/m"

    const-string v4, "/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq"

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    new-instance v5, Ljava/io/InputStreamReader;

    const/4 v8, 0x1

    const/4 v7, 0x7

    new-instance v6, Ljava/io/FileInputStream;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-direct {v6, v4}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    const-string v4, "bFU-8"

    const/4 v8, 0x6

    const-string v4, "UuFT-"

    const-string v4, "UTF-8"

    const/4 v8, 0x7

    invoke-direct {v5, v6, v4}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_4
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-instance v4, Ljava/io/BufferedReader;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-direct {v4, v5}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_2
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v4}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x6

    if-nez v0, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x5

    invoke-virtual {v5}, Ljava/io/InputStreamReader;->close()V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {v4}, Ljava/io/BufferedReader;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_3
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v5}, Ljava/io/InputStreamReader;->close()V

    const/4 v7, 0x2

    const/4 v7, 0x5

    invoke-virtual {v4}, Ljava/io/BufferedReader;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_0

    const/4 v8, 0x2

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    return-wide v2

    :cond_1
    :try_start_4
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v6

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-lez v6, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_3
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :cond_2
    :try_start_5
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v5}, Ljava/io/InputStreamReader;->close()V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v4}, Ljava/io/BufferedReader;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    goto :goto_3

    :catch_1
    move-exception v0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    goto :goto_3

    :catchall_0
    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    :catchall_1
    move-object v0, v5

    move-object v0, v5

    move-object v0, v5

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    goto :goto_1

    :catch_2
    move-object v4, v0

    move-object v4, v0

    :catch_3
    move-object v0, v5

    move-object v0, v5

    move-object v0, v5

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    goto :goto_2

    :catchall_2
    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    :goto_1
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    if-eqz v0, :cond_3

    :try_start_6
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v0}, Ljava/io/InputStreamReader;->close()V

    :cond_3
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-eqz v4, :cond_5

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v4}, Ljava/io/BufferedReader;->close()V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    goto :goto_3

    :catch_4
    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    :goto_2
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-eqz v0, :cond_4

    const/4 v8, 0x7

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/io/InputStreamReader;->close()V

    :cond_4
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-eqz v4, :cond_5

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v4}, Ljava/io/BufferedReader;->close()V
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_1

    :cond_5
    :goto_3
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    sput-wide v2, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sMaxCpuFreq:J

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const-string/jumbo v1, "xFCrpqap Me"

    const-string v1, "CMxFr uqpea"

    const/4 v8, 0x1

    const-string v1, "axFMpquCqre"

    const-string v1, "MaxCpuFreq "

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    sget-wide v4, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sMaxCpuFreq:J

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v0, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v1, 0x2

    const/4 v8, 0x2

    const/4 v7, 0x5

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    return-wide v2
.end method

.method public static getNumCores()I
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sNumOfCores:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v1, -0x1

    move v4, v1

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eq v1, v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    return v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v0, 0x1

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v1, Ljava/io/File;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo v2, "i/ssccsse/mdpesv/ysy//up"

    const-string/jumbo v2, "ispsseup/s/em/y/yccse/vd"

    const/4 v4, 0x5

    const-string/jumbo v2, "y/yme/mdsscsisves/c/uet/"

    const-string v2, "/sys/devices/system/cpu/"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v2, Lcom/tencent/thumbplayer/core/common/TPSystemInfo$1CpuFilter;

    const/4 v4, 0x2

    invoke-direct {v2}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo$1CpuFilter;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/io/File;->listFiles(Ljava/io/FileFilter;)[Ljava/io/File;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-nez v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    sput v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sNumOfCores:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    return v0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    array-length v1, v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    sput v1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sNumOfCores:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const-string/jumbo v2, "r cuoqm n"

    const-string v2, " roc umnq"

    const/4 v4, 0x3

    const-string v2, " c rnbuoe"

    const-string v2, "core num "

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget v2, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sNumOfCores:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v2, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v2, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sNumOfCores:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    return v0

    :catch_0
    move-exception v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v2, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    sput v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sNumOfCores:I

    return v0
.end method

.method public static getOpenGLSupportVersion(Landroid/content/Context;)I
    .locals 3

    const/4 v2, 0x1

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sOpenGLVersion:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_1

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const-string/jumbo v0, "iatiyvut"

    const-string v0, "activity"

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    check-cast p0, Landroid/app/ActivityManager;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez p0, :cond_0

    const/4 v2, 0x3

    sget p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sOpenGLVersion:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/app/ActivityManager;->getDeviceConfigurationInfo()Landroid/content/pm/ConfigurationInfo;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget p0, p0, Landroid/content/pm/ConfigurationInfo;->reqGlEsVersion:I

    const/4 v1, 0x7

    move v2, v1

    sput p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sOpenGLVersion:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x3

    move v2, v1

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sOpenGLVersion:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return p0
.end method

.method public static getOsVersion()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sOSVersion:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object v0, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sOSVersion:Ljava/lang/String;

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sOSVersion:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public static getProductBoard()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sProductBoard:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Landroid/os/Build;->BOARD:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sProductBoard:Ljava/lang/String;

    :cond_0
    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sProductBoard:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public static getProductDevice()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sProductDevice:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    sget-object v0, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sProductDevice:Ljava/lang/String;

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sProductDevice:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public static getScreenHeight(Landroid/content/Context;)I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    return v0

    :cond_0
    const/4 v2, 0x1

    move v3, v2

    sget v1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sScreenHeight:I

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    return v1

    :cond_1
    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    iget p0, p0, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    sput p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sScreenHeight:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :catchall_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    sput v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sScreenHeight:I

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    sget p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sScreenHeight:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return p0
.end method

.method public static getScreenWidth(Landroid/content/Context;)I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    return v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    sget v1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sScreenWidth:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    return v1

    :cond_1
    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget p0, p0, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    sput p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sScreenWidth:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    sput v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sScreenWidth:I

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sScreenWidth:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    return p0
.end method

.method public static getSystemCpuUsage(Ljava/lang/String;Ljava/lang/String;)I
    .locals 12

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x2

    const-string v0, "/+s/"

    const-string v0, "/s+/"

    const/4 v11, 0x5

    const-string v0, "+/s/"

    const-string v0, "\\s+"

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x3

    if-nez v1, :cond_2

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    if-eqz v1, :cond_0

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x4

    goto/16 :goto_1

    :cond_0
    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x7

    const/high16 v1, -0x40800000    # -1.0f

    :try_start_0
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getSystemIdleTime([Ljava/lang/String;)J

    move-result-wide v2

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getSystemUptime([Ljava/lang/String;)J

    move-result-wide v4

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getSystemIdleTime([Ljava/lang/String;)J

    move-result-wide v6

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getSystemUptime([Ljava/lang/String;)J

    move-result-wide p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v11, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x0

    cmp-long v0, v2, v8

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x6

    if-ltz v0, :cond_1

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    cmp-long v0, v4, v8

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-ltz v0, :cond_1

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    cmp-long v0, v6, v8

    const/4 v10, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    if-ltz v0, :cond_1

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    cmp-long v0, p0, v8

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    if-ltz v0, :cond_1

    add-long/2addr v6, p0

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x1

    add-long/2addr v2, v4

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x6

    cmp-long v0, v6, v2

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x4

    if-lez v0, :cond_1

    const/4 v11, 0x4

    cmp-long v0, p0, v4

    const/4 v11, 0x0

    const/4 v10, 0x4

    if-ltz v0, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x1

    sub-long/2addr p0, v4

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x5

    long-to-float p0, p0

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x4

    sub-long/2addr v6, v2

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    long-to-float p1, v6

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x2

    div-float/2addr p0, p1

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x2

    const/high16 p1, 0x42c80000    # 100.0f

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    mul-float v1, p0, p1

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x6

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x4

    const/4 p1, 0x4

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-static {p1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x0

    float-to-int p0, v1

    const/4 v11, 0x4

    return p0

    :cond_2
    :goto_1
    const/4 v11, 0x1

    const/4 p0, -0x1

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x6

    return p0
.end method

.method public static getSystemIdleTime([Ljava/lang/String;)J
    .locals 4

    const/4 v3, 0x4

    const/4 v0, 0x4

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    aget-object p0, p0, v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-wide v0

    :catchall_0
    move-exception p0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-wide/16 v0, -0x1

    const/4 v3, 0x4

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-wide v0
.end method

.method public static getSystemUptime([Ljava/lang/String;)J
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v6, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v2, 0x1

    :goto_0
    const/4 v5, 0x2

    const/4 v6, 0x0

    array-length v3, p0

    const/4 v5, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-ge v2, v3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v3, 0x4

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eq v3, v2, :cond_0

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    aget-object v3, p0, v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v3}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    add-long/2addr v0, v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    goto :goto_1

    :catchall_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v6, 0x5

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v6, 0x1

    return-wide v0

    :cond_0
    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    return-wide v0
.end method

.method private static hasMarshmallow()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method public static declared-synchronized initAudioBestSettings(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x1

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;

    const/4 v4, 0x4

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    monitor-enter v0

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz p0, :cond_1

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    sget v1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sAudioBestSampleRate:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-lez v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto/16 :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string v1, "dapos"

    const-string v1, "dasoi"

    const/4 v4, 0x6

    const-string/jumbo v1, "iudqa"

    const-string v1, "audio"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    check-cast p0, Landroid/media/AudioManager;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string v1, "drsmaPMo.AonLpm.RUp_ri_ePETAdtiraOEed.TyT"

    const-string/jumbo v1, "ioUmdpaRoOTAPyraedMEL_.PrUdTmpeA.r.n_EitT"

    const/4 v4, 0x3

    const-string v1, "UrAmi.PEm.aMapeT_oPELAd.r_RenoTrtpSidUOyd"

    const-string v1, "android.media.property.OUTPUT_SAMPLE_RATE"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0, v1}, Landroid/media/AudioManager;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v2, "BEopod_EUn_Oirda.FtET_RPeaomRoFAp.rUFMiPdy.ReTS"

    const-string v2, "ePUio.RdT_EFnepUtaMRo_.rArO_oaTEdEBUdF.SiRPFpmy"

    const/4 v4, 0x1

    const-string v2, ".UnrEbOFT_RPURaPeyrAUiddFEdMo__r..pTaeptRBESmiF"

    const-string v2, "android.media.property.OUTPUT_FRAMES_PER_BUFFER"

    const/4 v4, 0x2

    invoke-virtual {p0, v2}, Landroid/media/AudioManager;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    sput v1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sAudioBestSampleRate:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    sput p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sAudioBestFramesPerBust:I
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    monitor-exit v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    return-void

    :catch_0
    move-exception p0

    :try_start_2
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v1, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-void

    :catchall_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    throw p0

    :cond_1
    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method

.method public static isARMV5Whitelist()Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string v1, "buX2T"

    const-string v1, "b8X2T"

    const/4 v3, 0x6

    const-string v1, "8TpX8"

    const-string v1, "XT882"

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v1, "EM8q6"

    const-string v1, "8uE6M"

    const/4 v3, 0x6

    const-string v1, "0Es8M"

    const-string v1, "ME860"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v1, "8M0mB"

    const-string v1, "MB860"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    move v3, v2

    const-string/jumbo v1, "opePonL vo"

    const-string v1, "L v7Penpoo"

    const/4 v3, 0x2

    const-string v1, "eLnv7booP0"

    const-string v1, "Lenovo P70"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x3

    move v3, v2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const-string v1, "6on ALu0eo"

    const-string v1, "Lenovo A60"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo v1, "t3 q6Anpo6vL"

    const-string v1, "L3otA6o q6nv"

    const/4 v3, 0x1

    const-string v1, "Lenovo A366t"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    return v0

    :cond_1
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    return v0
.end method

.method private static parseCpuInfoLine(Ljava/lang/String;)V
    .locals 6

    const/4 v4, 0x2

    move v5, v4

    const-string/jumbo v0, "sqc4aa6"

    const-string v0, "a4shc6a"

    const/4 v5, 0x0

    const-string v0, "6as4rca"

    const-string v0, "aarch64"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string v0, "A4Amm6r"

    const-string v0, "A64mrAc"

    const/4 v5, 0x2

    const-string v0, "A4c6orA"

    const-string v0, "AArch64"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v0, :cond_1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/16 v0, 0x40

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    sput v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArchitecture:I

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x5

    const-string/jumbo v0, "rosscbPoe"

    const-string v0, "cosPoesro"

    const/4 v5, 0x6

    const-string v0, "Psorcouse"

    const-string v0, "Processor"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/16 v1, 0x3a

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v2, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p0, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-le v0, v2, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    add-int/2addr v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    sput-object p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sProcessorName:Ljava/lang/String;

    const/4 v5, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    sput-object p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sProcessorName:Ljava/lang/String;

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v0, "PuUrrcCpttbhciea"

    const-string/jumbo v0, "uU PibhcctetaCrr"

    const/4 v5, 0x2

    const-string/jumbo v0, "trhieue qrPctaCc"

    const-string v0, "CPU architecture"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v3, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eqz v0, :cond_6

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    sget v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArchitecture:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez v0, :cond_9

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-le v0, v2, :cond_5

    const/4 v5, 0x7

    const/4 v4, 0x0

    add-int/2addr v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-lez v0, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-ge v0, v3, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    long-to-int p0, v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    sput p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArchitecture:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    return-void

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-le v0, v2, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p0, v0, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    long-to-int p0, v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    sput p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuArchitecture:I

    :cond_5
    const/4 v5, 0x7

    const/4 v4, 0x3

    return-void

    :cond_6
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo v0, "sFsaetre"

    const-string v0, "aersFtue"

    const/4 v5, 0x1

    const-string v0, "Features"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v0, :cond_8

    const/4 v5, 0x4

    invoke-virtual {p0, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-le v0, v2, :cond_7

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    add-int/2addr v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    sput-object p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sFeature:Ljava/lang/String;

    :cond_7
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-void

    :cond_8
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string v0, "awdmepHr"

    const-string/jumbo v0, "rHdaawep"

    const/4 v5, 0x4

    const-string/jumbo v0, "raHaowde"

    const-string v0, "Hardware"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x1

    shr-int/2addr v5, v4

    if-eqz v0, :cond_9

    invoke-virtual {p0, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-le v0, v2, :cond_9

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    add-int/2addr v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v0, " "

    const-string v0, " "

    const/4 v5, 0x2

    const-string v0, " "

    const-string v0, " "

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    sput-object p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHardware:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo v0, "qred baah"

    const-string/jumbo v0, "hadaerr q"

    const/4 v5, 0x4

    const-string v0, " eaarwurd"

    const-string/jumbo v0, "hardware "

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHardware:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v3, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    sget-object p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sCpuHardware:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuHWProductIndex(Ljava/lang/String;)I

    :cond_9
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-void
.end method

.method private static readStringFromFile(Ljava/io/File;)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v0, 0x0

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    new-instance v1, Ljava/io/BufferedReader;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-instance v2, Ljava/io/FileReader;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-direct {v2, p0}, Ljava/io/FileReader;-><init>(Ljava/io/File;)V

    const/4 v7, 0x6

    invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v7, 0x6

    invoke-virtual {p0}, Ljava/io/File;->length()J

    move-result-wide v2

    const/4 v6, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-wide/32 v4, 0x7fffffff

    const-wide/32 v4, 0x7fffffff

    const/4 v7, 0x6

    const-wide/32 v4, 0x7fffffff

    const-wide/32 v4, 0x7fffffff

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    cmp-long v2, v2, v4

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-gtz v2, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {p0}, Ljava/io/File;->length()J

    move-result-wide v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    long-to-int v2, v2

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    new-array v2, v2, [C

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {p0}, Ljava/io/File;->length()J

    move-result-wide v3

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    long-to-int p0, v3

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v3, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v1, v2, v3, p0}, Ljava/io/BufferedReader;->read([CII)I

    move-result p0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-lez p0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    new-instance p0, Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-direct {p0, v2}, Ljava/lang/String;-><init>([C)V
    :try_end_1
    .catch Ljava/io/FileNotFoundException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :cond_0
    :try_start_2
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x4

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    goto :goto_1

    :catchall_1
    move-exception p0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_0

    :catch_0
    move-exception p0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto :goto_2

    :catchall_2
    move-exception p0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :goto_0
    :try_start_3
    const/4 v7, 0x3

    const/4 v6, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-eqz v1, :cond_1

    :try_start_4
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :cond_1
    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x1

    return-object v0

    :catchall_3
    move-exception p0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    goto :goto_3

    :catch_1
    move-exception p0

    :goto_2
    :try_start_5
    const/4 v6, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    throw p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    :catchall_4
    move-exception p0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :goto_3
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-eqz v1, :cond_2

    :try_start_6
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_5

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    goto :goto_4

    :catchall_5
    move-exception v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_2
    :goto_4
    const/4 v7, 0x5

    const/4 v6, 0x7

    throw p0
.end method

.method public static readSystemStat()Ljava/lang/String;
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v0, 0x4

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v1, 0x0

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    new-instance v2, Ljava/io/RandomAccessFile;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string/jumbo v3, "o/sp/sctar"

    const/4 v6, 0x6

    const-string/jumbo v3, "o/cpt/tpar"

    const-string v3, "/proc/stat"

    const/4 v6, 0x6

    const-string/jumbo v4, "r"

    const-string/jumbo v4, "r"

    const/4 v6, 0x1

    const-string/jumbo v4, "r"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-direct {v2, v3, v4}, Ljava/io/RandomAccessFile;-><init>(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v2}, Ljava/io/RandomAccessFile;->readLine()Ljava/lang/String;

    move-result-object v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/io/RandomAccessFile;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_1

    :catchall_0
    move-exception v2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v0, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto :goto_1

    :catchall_1
    move-exception v3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_0

    :catchall_2
    move-exception v3

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    :goto_0
    :try_start_3
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v3}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v2, :cond_0

    :try_start_4
    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/io/RandomAccessFile;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :cond_0
    :goto_1
    const/4 v6, 0x7

    return-object v1

    :catchall_3
    move-exception v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    if-eqz v2, :cond_1

    :try_start_5
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/io/RandomAccessFile;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    goto :goto_2

    :catchall_4
    move-exception v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v0, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    :cond_1
    :goto_2
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    throw v1
.end method

.method public static declared-synchronized setDeviceName(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;

    const/4 v2, 0x1

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    sput-object p0, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sDeviceName:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    monitor-exit v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void

    :catchall_0
    move-exception p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    monitor-exit v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    throw p0
.end method

.method public static setProperty(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string/jumbo v0, "etoru.dcq.moolpr"

    const-string/jumbo v0, "ro.product.model"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    sput-object p1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sDeviceName:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    const-string/jumbo v0, "mdsfcpcrnra..tuuamoteor"

    const-string/jumbo v0, "uoamncterupu.rfcatmord."

    const/4 v2, 0x7

    const-string/jumbo v0, "o.dmrrmaeruf.paucnttcou"

    const-string/jumbo v0, "ro.product.manufacturer"

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    sput-object p1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sDeviceManufacturer:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string/jumbo v0, "ssebol.iralorveou.eneroi"

    const-string/jumbo v0, "ln..orerseseiiolu.ravbeo"

    const/4 v2, 0x1

    const-string/jumbo v0, "nsel.bblo.oeev.iridrersu"

    const-string/jumbo v0, "ro.build.version.release"

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    sput-object p1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sOSVersion:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void

    :cond_2
    const/4 v1, 0x0

    move v2, v1

    const-string v0, "dcdevtuo.euprc.ib"

    const-string/jumbo v0, "o.prubiecdvcet.do"

    const/4 v2, 0x5

    const-string v0, "dr.civep.uotredcp"

    const-string/jumbo v0, "ro.product.device"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    sput-object p1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sProductDevice:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void

    :cond_3
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string/jumbo v0, "or.pooarqd.turub"

    const-string/jumbo v0, "pootrduabo.r.rcu"

    const/4 v2, 0x1

    const-string/jumbo v0, "ro.product.board"

    const/4 v1, 0x2

    and-int/2addr v2, v1

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz p0, :cond_4

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    sput-object p1, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->sProductBoard:Ljava/lang/String;

    :cond_4
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public static supportInDeviceDolbyAudioEffect()Z
    .locals 8

    const/4 v6, 0x1

    const/4 v7, 0x4

    const/4 v0, 0x0

    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {}, Landroid/media/audiofx/AudioEffect;->queryEffects()[Landroid/media/audiofx/AudioEffect$Descriptor;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    array-length v2, v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    move v3, v0

    move v3, v0

    const/4 v7, 0x1

    move v3, v0

    move v3, v0

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-ge v0, v2, :cond_1

    :try_start_1
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    aget-object v4, v1, v0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-object v4, v4, Landroid/media/audiofx/AudioEffect$Descriptor;->implementor:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string v5, " psboyosLirberalto"

    const-string/jumbo v5, "oiaolropLyrbt sabe"

    const/4 v7, 0x7

    const-string/jumbo v5, "rrimLeolo yaboDatb"

    const-string v5, "Dolby Laboratories"

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    if-eqz v4, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v3, 0x1

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    goto :goto_1

    :catch_1
    move-exception v1

    const/4 v7, 0x0

    const/4 v6, 0x3

    move v3, v0

    move v3, v0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/4 v1, 0x4

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x4

    return v3
.end method

.method private static writeStringToFile(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    :try_start_0
    const/4 v2, 0x0

    move v3, v2

    new-instance v0, Ljava/io/File;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/io/File;->createNewFile()Z

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance p0, Ljava/io/FileWriter;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v2, 0x5

    invoke-direct {p0, v0, v1}, Ljava/io/FileWriter;-><init>(Ljava/io/File;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/io/Writer;->flush()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Ljava/io/Writer;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void

    :catchall_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 p0, 0x0

    move v3, p0

    :catchall_1
    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz p0, :cond_1

    :try_start_2
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/io/Writer;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void

    :catch_0
    move-exception p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method
