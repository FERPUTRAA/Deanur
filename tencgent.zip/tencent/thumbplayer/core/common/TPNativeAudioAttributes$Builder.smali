.class public Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Builder"
.end annotation


# static fields
.field private static final mMapStreamTypeToContentType:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final mMapStreamTypeToUsage:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private mContentType:I

.field private mFlags:I

.field private mUsage:I


# direct methods
.method static constructor <clinit>()V
    .locals 11

    const/4 v10, 0x4

    const/4 v9, 0x1

    new-instance v0, Ljava/util/HashMap;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mMapStreamTypeToContentType:Ljava/util/HashMap;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    const/4 v1, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v2, 0x0

    const/4 v10, 0x5

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    const/4 v3, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x5

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    const/4 v4, 0x4

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {v0, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    const/4 v5, 0x2

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {v0, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/4 v6, 0x3

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {v0, v6, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x0

    invoke-virtual {v0, v4, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    const/4 v7, 0x5

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v0, v7, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/16 v8, 0x8

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {v0, v8, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    new-instance v0, Ljava/util/HashMap;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mMapStreamTypeToUsage:Ljava/util/HashMap;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x7

    invoke-virtual {v0, v2, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x7

    const/16 v1, 0xd

    const/4 v10, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {v0, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    const/4 v1, 0x6

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x5

    invoke-virtual {v0, v5, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {v0, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {v0, v4, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x0

    invoke-virtual {v0, v7, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x3

    invoke-virtual {v0, v8, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x3

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mUsage:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mContentType:I

    const/4 v1, 0x6

    move v2, v1

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mFlags:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public addFlags(I)Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "S@s ~dc@~ ~~fnlmaM~i4@o i t ~  ~.~~b @ -~~ ~u@b/@@ s ob@r~@@@@~@@t@1~ i ~o~@@~ l~@ ~ofo~/o@K vy~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    and-int/lit16 p1, p1, 0x111

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mFlags:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    or-int/2addr p1, v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mFlags:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p0
.end method

.method public build()Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-direct {v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;-><init>(Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$1;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mContentType:I

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->access$102(Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;I)I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mUsage:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->access$202(Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;I)I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mFlags:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->access$302(Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;I)I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0
.end method

.method public setContentType(I)Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;
    .locals 4
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$TPNativeAudioAttributeContentType;
        .end annotation
    .end param

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->access$500()Ljava/util/HashMap;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mContentType:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p0
.end method

.method public setFlags(I)Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    and-int/lit16 p1, p1, 0x111

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mFlags:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p0
.end method

.method public setLegacyStreamType(I)Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;
    .locals 5
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$TPNativeAudioAttributeStreamType;
        .end annotation
    .end param

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mMapStreamTypeToContentType:Ljava/util/HashMap;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x7

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    check-cast v0, Ljava/lang/Integer;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mContentType:I

    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput v2, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mContentType:I

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mMapStreamTypeToUsage:Ljava/util/HashMap;

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    check-cast p1, Ljava/lang/Integer;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mUsage:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto :goto_1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput v2, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mUsage:I

    :goto_1
    const/4 v4, 0x0

    return-object p0
.end method

.method public setUsage(I)Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;
    .locals 4
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$TPNativeAudioAttributeUsage;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->access$400()Ljava/util/HashMap;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;->mUsage:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    return-object p0
.end method
