.class public Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;
.super Ljava/lang/Object;


# static fields
.field private static TAG:Ljava/lang/String; = "TPPlayerDecoderCapability"

.field private static mIsLibLoaded:Z


# instance fields
.field private mNativeContext:J


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->loadLibIfNeeded(Landroid/content/Context;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x0

    move v3, v2

    sput-boolean v0, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->mIsLibLoaded:Z
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void

    :catch_0
    move-exception v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x4

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v3, 0x1

    const/4 v0, 0x3

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    sput-boolean v0, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->mIsLibLoaded:Z

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->mNativeContext:J

    const/4 v3, 0x6

    return-void
.end method

.method private static native _addACodecBlacklist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;)Z
.end method

.method private static native _addACodecWhitelist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;)Z
.end method

.method private static native _addVCodecBlacklist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;)Z
.end method

.method private static native _addVCodecWhitelist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;)Z
.end method

.method private static native _getDecoderMaxCapabilityMap(I)Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;",
            ">;"
        }
    .end annotation
.end method

.method private static native _isACodecCapabilitySupport(IIIIIII)Z
.end method

.method private static native _isVCodecCapabilitySupport(IIIIIII)Z
.end method

.method public static addACodecBlacklist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "/os/ b-l @~~o@o   @ Kl~m@@@~io @i@o~ Ms4@yrS~n~@ u @@~v@i t@ @b~~f~1@~d@~.~ ~c~~ f ~@@a @~b t~o~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->isLibLoaded()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p0, p1, p2}, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->_addACodecBlacklist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return p0

    :catchall_0
    move-exception p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 p1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const-string p1, "ad m ca_cslClecFdAoklalst iBdle.tda"

    const-string p1, " as.atd lsdCaltFlaBAilloo_edc ecdck"

    const/4 v2, 0x7

    const-string p1, "Aodcolo iCelcl. aaldseFt_dltaB kica"

    const-string p1, "Failed to call _addACodecBlacklist."

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    throw p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const-string p1, " iolabs  aidCABrydln: dtmocaol eidkvtrte.dlbaaFelc"

    const-string/jumbo p1, "lalmcioisadceaoa iCd A veBe:rlbdttnoaF a.lkdrdl ty"

    const/4 v2, 0x3

    const-string/jumbo p1, "ie.aiaudBclleotllAe iCoi:d dvakacdbdr oy tlaFnt as"

    const-string p1, "addACodecBlacklist: Failed to load native library."

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    throw p0
.end method

.method public static addACodecWhitelist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->isLibLoaded()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p0, p1, p2}, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->_addACodecWhitelist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    return p0

    :catchall_0
    move-exception p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 p1, 0x4

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const-string/jumbo p1, "oViaceapCtddeit.doelW dholFa s_ tci"

    const-string p1, " CacoaVdtcaFdieh lt.edoito_Wlidse l"

    const/4 v2, 0x2

    const-string/jumbo p1, "hdllad_CqVWttideFlldaeo isc.itca  e"

    const-string p1, "Failed to call _addVCodecWhitelist."

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    throw p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string/jumbo p1, "oheatbiA:idlvry.  tteF aordlidClsncedaielo iabdtW "

    const/4 v2, 0x4

    const-string p1, "easiah srl.Ct tivdr aAitlblaleiF y eodnoWaedit:odc"

    const-string p1, "addACodecWhitelist: Failed to load native library."

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    throw p0
.end method

.method public static addDRMLevel1Blacklist(I)Z
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->addDRMLevel1Blacklist(I)Z

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    return p0
.end method

.method public static addHDRBlackList(ILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    invoke-static {p0, v0, p1}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->addHDRBlackList(ILjava/lang/String;Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;)Z

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    return p0
.end method

.method public static addHDRVideoDecoderTypeWhiteList(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;)Z
    .locals 2
    .param p2    # Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x7

    invoke-static {p0, p1, p2}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->addHDRVideoDecoderTypeWhiteList(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;)Z

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return p0
.end method

.method public static addHDRWhiteList(ILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p0, v0, p1}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->addHDRWhiteList(ILjava/lang/String;Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;)Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return p0
.end method

.method public static addVCodecBlacklist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->isLibLoaded()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v2, 0x5

    invoke-static {p0, p1, p2}, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->_addVCodecBlacklist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    return p0

    :catchall_0
    move-exception p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 p1, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string p1, "dlomatdaeC lciu asVFaB_ldte .llkcod"

    const-string p1, "ald kBuiCddli eeoaatdaclVl.Ftso lc_"

    const/4 v2, 0x2

    const-string p1, "Failed to call _addVCodecBlacklist."

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    throw p0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string/jumbo p1, "p ddoti naollVaa tilCs evrdoedre :ibockaaiyl.BdcFt"

    const-string/jumbo p1, "irilo  pail ovlCt tslinkeBdV rc.ddaao:ebaFdaadecty"

    const/4 v2, 0x6

    const-string p1, "addVCodecBlacklist: Failed to load native library."

    const/4 v2, 0x1

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    throw p0
.end method

.method public static addVCodecWhitelist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->isLibLoaded()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p0, p1, p2}, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->_addVCodecWhitelist(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPVCodecPropertyRange;)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    return p0

    :catchall_0
    move-exception p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 p1, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string/jumbo p1, "li .Fb eheitqdstddatCeldaVlWio_c oc"

    const-string/jumbo p1, "tlaioldtqet Vocc ledFliieCW_asd.d h"

    const/4 v2, 0x5

    const-string p1, " laticu atldioedsiFela_hWoCl c.dVdt"

    const-string p1, "Failed to call _addVCodecWhitelist."

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    throw p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v1, 0x5

    move v2, v1

    const-string/jumbo p1, "id.y vlpnaaea aVitsCtddtirolills:odeiceroedFaW t  "

    const-string p1, "eesivaoyW liVlda.aiahtlcCFdid dtrleaior:n sot t ed"

    const/4 v2, 0x7

    const-string/jumbo p1, "olde rloqe i.vcedydVaie arioFatt:Cha ldWasbidltti "

    const-string p1, "addVCodecWhitelist :Failed to load native library."

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    throw p0
.end method

.method public static getVCodecDecoderMaxCapabilityMap(I)Ljava/util/HashMap;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x5

    move v2, v1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->isLibLoaded()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v1, 0x5

    move v2, v1

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->_getDecoderMaxCapabilityMap(I)Ljava/util/HashMap;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v1, 0x7

    and-int/2addr v2, v1

    const-string v0, "Mls  oFdtiaeaaaaaelDCccol._elmtptpMe irxbdi"

    const-string v0, ".Damtl  iarocyi pxt_oMaiadleltMCbeceaeadFpl"

    const/4 v2, 0x2

    const-string v0, "_xDmtoee gdMalteotciMap iplrdc .alayeFabaCi"

    const-string v0, "Failed to call _getDecoderMaxCapabilityMap."

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    throw p0

    :cond_0
    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    const-string/jumbo v0, "ioiroelir Fdo atnd llea.abytoa"

    const-string/jumbo v0, "vl.robaiFteod aay nailtoire ld"

    const/4 v2, 0x4

    const-string/jumbo v0, "oorabbetrt l i.a ln daivydilFa"

    const-string v0, "Failed to load native library."

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    throw p0
.end method

.method public static declared-synchronized init(Landroid/content/Context;Z)V
    .locals 3

    const/4 v2, 0x4

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;

    const/4 v2, 0x2

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->init(Landroid/content/Context;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    monitor-exit v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void

    :catchall_0
    move-exception p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    monitor-exit v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    throw p0
.end method

.method public static isACodecCapabilitySupport(IIIIIII)Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-ne v0, p0, :cond_4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/16 v0, 0x1394

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eq p1, v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/16 v0, 0x13b0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eq p1, v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    packed-switch p1, :pswitch_data_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x4

    const-string v0, ""

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :pswitch_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string v0, "dobi/auus"

    const-string v0, "/idutbsoa"

    const/4 v3, 0x1

    const-string v0, "/otsduipd"

    const-string v0, "audio/dts"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :pswitch_1
    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string v0, "3uaui/acq"

    const-string/jumbo v0, "u3id/auca"

    const/4 v3, 0x1

    const-string v0, "audio/ac3"

    const/4 v3, 0x2

    const/4 v2, 0x5

    goto :goto_0

    :pswitch_2
    const/4 v3, 0x5

    const-string v0, "dasaoi/ca"

    const-string/jumbo v0, "idac/oapa"

    const/4 v3, 0x6

    const-string/jumbo v0, "i/umaaoca"

    const-string v0, "audio/aac"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v0, "uaiaod3c/q"

    const-string/jumbo v0, "o/aduaicq3"

    const/4 v3, 0x1

    const-string v0, "audio/eac3"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const-string/jumbo v0, "sfa/ablcud"

    const-string/jumbo v0, "l/sucifaad"

    const/4 v3, 0x3

    const-string/jumbo v0, "luco/fuiaa"

    const-string v0, "audio/flac"

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isInMediaCodecWhiteList(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 p0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return p0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isAMediaCodecBlackListModel()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez v1, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isBlackListType(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_4

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x1

    return p0

    :cond_4
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->isLibLoaded()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_5

    :try_start_0
    const/4 v3, 0x0

    invoke-static/range {p0 .. p6}, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->_isACodecCapabilitySupport(IIIIIII)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    return p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 p1, 0x4

    shr-int/2addr v3, p1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v3, 0x5

    const-string/jumbo p1, "pFouo dplatcyeto spi_l iaAbeaCCliialdmt.pr"

    const-string p1, "doym.C_ab oclrdiieipilC eaotplFu atAlpstSa"

    const/4 v3, 0x6

    const-string p1, "C tbpoSrq.yiptidiFoclidllCla  s_Aotaepaaeu"

    const-string p1, "Failed to call _isACodecCapabilitySupport."

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    throw p0

    :cond_5
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo p1, "lasa  ie tFaviyti.dealboo nodr"

    const-string/jumbo p1, "v .boiieoayroataFetlln  iaddr "

    const/4 v3, 0x1

    const-string p1, "d emib r .aael aitvoFrallodtiy"

    const-string p1, "Failed to load native library."

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    throw p0

    :pswitch_data_0
    .packed-switch 0x138a
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static isDDPlusSupported()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isMediaCodecDDPlusSupported()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public static isDolbyDSSupported()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isMediaCodecDolbyDSSupported()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public static isHDRsupport(III)Z
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {p0, p1, p2}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isHDRsupport(III)Z

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x1

    return p0
.end method

.method private static isLibLoaded()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-boolean v0, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->mIsLibLoaded:Z

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public static isVCodecCapabilitySupport(IIIIIII)Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/16 v0, 0x66

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-ne v0, p0, :cond_7

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/16 v0, 0x1a

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eq p1, v0, :cond_4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v0, 0x8a

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eq p1, v0, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/16 v0, 0xa6

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eq p1, v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/16 v0, 0xac

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eq p1, v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/16 v0, 0x405

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eq p1, v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v0, "1v0/oivbeo"

    const-string v0, "/aio1bv0ve"

    const/4 v3, 0x5

    const-string/jumbo v0, "o1id0bevva"

    const-string/jumbo v0, "video/av01"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string v0, "edoh/uuvei"

    const-string v0, "e/edhvuoiv"

    const/4 v3, 0x5

    const-string v0, "dv/cveepho"

    const-string/jumbo v0, "video/hevc"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_0

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string/jumbo v0, "pd.nv/onqev.di9v2ox"

    const-string/jumbo v0, "xevo.d.pnvod/9npvi2"

    const/4 v3, 0x1

    const-string/jumbo v0, "video/x-vnd.on2.vp9"

    const/4 v3, 0x5

    goto :goto_0

    :cond_3
    const/4 v2, 0x5

    move v3, v2

    const-string/jumbo v0, "ids./nqovv28.pnve-x"

    const-string/jumbo v0, "np.x-.v8qod/vi2nevd"

    const-string/jumbo v0, "n-im.edpnoovd8/vx.v"

    const-string/jumbo v0, "video/x-vnd.on2.vp8"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :cond_4
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string v0, "dvovocai/"

    const-string/jumbo v0, "video/avc"

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isInMediaCodecWhiteList(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v1, :cond_5

    const/4 v2, 0x4

    move v3, v2

    const/4 p0, 0x1

    shl-int/2addr v3, p0

    const/4 v2, 0x6

    and-int/2addr v3, v2

    return p0

    :cond_5
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isVMediaCodecBlackListModel()Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez v1, :cond_6

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isBlackListType(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_7

    :cond_6
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    return p0

    :cond_7
    const/4 v2, 0x7

    move v3, v2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->isLibLoaded()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v0, :cond_8

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static/range {p0 .. p6}, Lcom/tencent/thumbplayer/core/common/TPPlayerDecoderCapability;->_isVCodecCapabilitySupport(IIIIIII)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    return p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 p1, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string p1, " sieCbtplleSalsboay cpVcl_dtioadiitC. uaFo"

    const-string p1, "S.sCplVuteastbliodpFoitapalda yCei_l cc io"

    const/4 v3, 0x7

    const-string p1, " cpCaFuilVripodsatSiode lc.aop_yutlC bietl"

    const-string p1, "Failed to call _isVCodecCapabilitySupport."

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    throw p0

    :cond_8
    const/4 v3, 0x2

    const/4 v2, 0x0

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string/jumbo p1, "ib mllnlo.Fa  dtyaevid orearai"

    const/4 v3, 0x0

    const-string p1, "ee.dl  pi atrlb aFtioanryidvlo"

    const-string p1, "Failed to load native library."

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    throw p0
.end method

.method public static setMediaCodecPreferredSoftwareComponent(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->setMediaCodecPreferredSoftwareComponent(Z)V

    const/4 v0, 0x3

    move v1, v0

    return-void
.end method
