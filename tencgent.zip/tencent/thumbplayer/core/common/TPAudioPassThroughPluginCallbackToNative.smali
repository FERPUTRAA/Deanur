.class public Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginCallbackToNative;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$AudioPassThroughPluginListener;


# static fields
.field private static final TAG:Ljava/lang/String; = "TPAudioPassThroughPluginCallback"


# instance fields
.field private mNativeContext:J


# direct methods
.method private constructor <init>(J)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-wide p1, p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginCallbackToNative;->mNativeContext:J

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method private native _onAudioPassThroughStateChanged(Z)V
.end method

.method private getNativeContext()J
    .locals 4
    .annotation build Lcom/tencent/thumbplayer/core/common/TPMethodCalledByNative;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "m s@c~@~ fyovi@@@/@~@~b K@ o~b@~~l.dM ~S @~/@ ~a~~ ti@@4~@o~ @ro~ @@u~n  ~ l@~s t@ ~-@ ~~b~ 1oio"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginCallbackToNative;->mNativeContext:J

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-wide v0
.end method

.method private registerCallback()V
    .locals 2
    .annotation build Lcom/tencent/thumbplayer/core/common/TPMethodCalledByNative;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->addListener(Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$AudioPassThroughPluginListener;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method private unregisterCallback()V
    .locals 2
    .annotation build Lcom/tencent/thumbplayer/core/common/TPMethodCalledByNative;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->removeListener(Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$AudioPassThroughPluginListener;)V

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onAudioPassThroughPlugin(Z)V
    .locals 5

    const/4 v4, 0x1

    const-string/jumbo v0, "uPgmPsAlin: ouuoshorinlgnhgdiuabT"

    const-string v0, "PosrAhu:nlu TigibuPugdnniolgsaPoh"

    const/4 v4, 0x6

    const-string v0, "dPosoiATuuu osgnnoairbgPhluhgPl:i"

    const-string/jumbo v0, "onAudioPassThroughPlugin bPlugin:"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v1, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const-string/jumbo v2, "iAlPrbohskPnaiaTTlubduaoCcuglsgh"

    const-string/jumbo v2, "gbdmlhPuackTasahgsiuuTonrAoPClli"

    const/4 v4, 0x0

    const-string v2, "AhdsbTuTgoiruPoscPilulgCnaPahkla"

    const-string v2, "TPAudioPassThroughPluginCallback"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v1, v2, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginCallbackToNative;->_onAudioPassThroughStateChanged(Z)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void
.end method
