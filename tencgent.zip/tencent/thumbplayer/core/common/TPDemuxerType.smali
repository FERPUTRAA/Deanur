.class public Lcom/tencent/thumbplayer/core/common/TPDemuxerType;
.super Ljava/lang/Object;


# static fields
.field public static final TP_DEMUXER_FFMPEG:I = 0x0

.field public static final TP_DEMUXER_STANDALONE:I = 0x1

.field public static final TP_DEMUXER_UNKNOWN:I = -0x1


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method
