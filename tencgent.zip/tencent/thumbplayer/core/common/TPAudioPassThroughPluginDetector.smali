.class public Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$HdmiAudioPlugBroadcastReceiver;,
        Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$AudioPassThroughPluginListener;
    }
.end annotation


# static fields
.field private static final DEFAULT_MAX_CHANNEL_COUNT:I = 0x8

.field private static final TAG:Ljava/lang/String; = "TPAudioPassThroughPluginDetector"

.field private static hasRegisterReceiver:Z

.field private static isInitted:Z

.field private static listeners:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$AudioPassThroughPluginListener;",
            ">;"
        }
    .end annotation
.end field

.field private static mAudioPassThroughCapabilities:Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

.field private static mContextRef:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/content/Context;",
            ">;"
        }
    .end annotation
.end field

.field private static mHandler:Landroid/os/Handler;

.field private static mIsAudioPassThroughPlugin:Z

.field private static mReceiver:Landroid/content/BroadcastReceiver;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    new-instance v0, Ljava/util/LinkedList;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->listeners:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    sput-boolean v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mIsAudioPassThroughPlugin:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mAudioPassThroughCapabilities:Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic access$100(Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s @~~M f~@Sf@~~~r@  @~b@b@@@~@K~1t~~d ~~ @@c@ vi~~om ~~oal~bslt~o .o @ @@@/@yo~4 u nii ~o@ - /"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->onUpdateAudioCapabilities(Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic access$200(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->notifyAudioPassThroughStateChange(Z)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public static addListener(Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$AudioPassThroughPluginListener;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->listeners:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-interface {v1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-boolean p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->hasRegisterReceiver:Z

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->registerReceiver()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 p0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    sput-boolean p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->hasRegisterReceiver:Z

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v3, 0x0

    throw p0
.end method

.method public static deinit()V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const/4 v5, 0x2

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    sget-boolean v1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->isInitted:Z

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mContextRef:Ljava/lang/ref/WeakReference;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez v1, :cond_0

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->clear()V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x7

    move v5, v4

    sput-boolean v1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->isInitted:Z

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string/jumbo v1, "urTmntcaoPPesiiugdgesoTshoPlrtDA"

    const-string v1, "PPsecraTiAueTduDshsgPgnootutoilr"

    const/4 v5, 0x6

    const-string/jumbo v1, "gPnTotriDudurlThuesePagAotohcioP"

    const-string v1, "TPAudioPassThroughPluginDetector"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v2, "stPdobicrsoeue!T ueTn PdilagtutcioeDnmrcisPAdghu"

    const-string v2, "Drgms ueleuoaoiiTenPPPcd!hsioctd tdenieugrAsuTtc"

    const/4 v5, 0x1

    const-string v2, "TPcgiuudoerhPeecoulPt siiu!anTeeo diDutschAgrtds"

    const-string v2, "TPAudioPassThroughPluginDetector deinit succeed!"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v3, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v3, v1, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    monitor-exit v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-void

    :cond_1
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    monitor-exit v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    return-void

    :catchall_0
    move-exception v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    throw v1
.end method

.method private static getLooper()Landroid/os/Looper;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    return-object v0
.end method

.method public static init(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const/4 v5, 0x6

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string/jumbo v1, "rslunDgpioatAPhthroigsceuuTdTPoP"

    const-string v1, "dsesoilauTuPthiDoPAoTortcnguPhgr"

    const-string/jumbo v1, "olnggstPqoATdetDiuhsraPhcoriuTeP"

    const-string v1, "TPAudioPassThroughPluginDetector"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v2, "PssteTib!orrtaeu geleiroidtusDgihPh cnTnAuoP"

    const-string/jumbo v2, "rhoPtbiAo eiTtnan!egsPriseeu iTnuchgDPotrdlu"

    const-string v2, "dTemuslP noachoiu!ttrgPeetAn rDuiiosgrtnPeTh"

    const-string v2, "TPAudioPassThroughPluginDetector init enter!"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    move v5, v4

    invoke-static {v3, v1, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    sget-boolean v1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->isInitted:Z

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    monitor-exit v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance v1, Ljava/lang/ref/WeakReference;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {v1, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    sput-object v1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mContextRef:Ljava/lang/ref/WeakReference;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 p0, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    sput-boolean p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->isInitted:Z

    const/4 v4, 0x7

    shl-int/2addr v5, v4

    new-instance v1, Landroid/os/Handler;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->getLooper()Landroid/os/Looper;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    sput-object v1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mHandler:Landroid/os/Handler;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->registerReceiver()V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    sput-boolean p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->hasRegisterReceiver:Z

    const/4 v4, 0x4

    and-int/2addr v5, v4

    const-string/jumbo p0, "tuoDohuPsrTasugTchePgPlrtnuAidio"

    const-string p0, "PoTrPtusiDcraThdelhtogiPouusAung"

    const/4 v5, 0x5

    const-string/jumbo p0, "rnDoibThtTseouiudclrPsgAPoeauhPg"

    const-string p0, "TPAudioPassThroughPluginDetector"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo v1, "tuipAougaiehenTu !cPuisuldtsoo iTtnDdsgePPeccr"

    const-string/jumbo v1, "t rcdaDptnTctPuiPouusedlucisegg!ToAo neeiPhhsi"

    const/4 v5, 0x7

    const-string/jumbo v1, "usTutnupP tnPhiouegoiiohdtdD!TArgsacslcriec ee"

    const-string v1, "TPAudioPassThroughPluginDetector init succeed!"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v3, p0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v5, 0x5

    return-void

    :catchall_0
    move-exception p0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    throw p0
.end method

.method public static isAudioPassThroughPlugin()Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const/4 v3, 0x3

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x4

    sget-boolean v1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mIsAudioPassThroughPlugin:Z

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    return v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    throw v1
.end method

.method public static isAudioPassThroughSupport(II)Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mAudioPassThroughCapabilities:Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->supportsEncoding(I)Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget-object p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mAudioPassThroughCapabilities:Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->getMaxChannelCount()I

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-gt p1, p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 p0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    return p0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    return v1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string/jumbo p0, "stqadgPeqouhusorPnieAirTctPTuDhg"

    const-string p0, "PeiltghTqPDPranrectdgTAshiuouuso"

    const/4 v3, 0x6

    const-string/jumbo p0, "ldsunhDrgPsoeuotPsioiPTrhectTuaA"

    const-string p0, "TPAudioPassThroughPluginDetector"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string p1, " ismirPtyeioil hTaoshoCiusdou hppdgmoet!tntubnsdstSaasroPfgpeiu Ta,iiaru hAilis "

    const-string/jumbo p1, "isAudioPassThroughSupport failed, mAudioPassThroughCapabilities is not init yet!"

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v0, 0x4

    const/4 v2, 0x0

    move v3, v2

    invoke-static {v0, p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    return v1
.end method

.method private static notifyAudioPassThroughStateChange(Z)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    sget-boolean v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mIsAudioPassThroughPlugin:Z

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-ne v0, p0, :cond_0

    const/4 v4, 0x0

    const/4 v0, 0x3

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v0, 0x1

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-void

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    sput-boolean p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mIsAudioPassThroughPlugin:Z

    const/4 v4, 0x5

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const/4 v4, 0x7

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->listeners:Ljava/util/List;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v2, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    check-cast v2, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$AudioPassThroughPluginListener;

    const/4 v4, 0x0

    invoke-interface {v2, p0}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$AudioPassThroughPluginListener;->onAudioPassThroughPlugin(Z)V

    const/4 v3, 0x4

    move v4, v3

    goto :goto_1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void

    :catchall_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    throw p0
.end method

.method private static onUpdateAudioCapabilities(Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mAudioPassThroughCapabilities:Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    sput-object p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mAudioPassThroughCapabilities:Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    shl-int/2addr v3, v2

    const-string v0, "abAuoiaaopsd itspteiadl:liitoCiaebsUndioipCu"

    const-string v0, "AtsoolsduinpediCClpaUboiaaitb:iieuda peaitsi"

    const/4 v3, 0x7

    const-string v0, "CdpCUb udaibepsatateiua:isailApiiilonoodeibt"

    const-string/jumbo v0, "onUpdateAudioCapabilities AudioCapabilities:"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mAudioPassThroughCapabilities:Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x2

    const/4 v3, 0x3

    const-string v1, "PrTPuougicuentsmtrghhePldTusoaoA"

    const-string/jumbo v1, "houmsnPgcriPToutsdlAihePgteaTour"

    const/4 v3, 0x2

    const-string/jumbo v1, "osdtrncphhPuTratoiseeiluTgDoPAPu"

    const-string v1, "TPAudioPassThroughPluginDetector"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v0, v1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method private static registerReceiver()V
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-string/jumbo v0, "rvecrsRrqetere geeeton"

    const-string/jumbo v0, "rergocsn eetreteeerRiv"

    const/4 v8, 0x2

    const-string/jumbo v0, "registerReceiver enter"

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/4 v1, 0x2

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string/jumbo v2, "rhntAbPuidogDeuhTgiTocelussrPtaP"

    const/4 v8, 0x3

    const-string/jumbo v2, "ttsrTTechsDsPioeuaroPudihAlunoPg"

    const-string v2, "TPAudioPassThroughPluginDetector"

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {v1, v2, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v7, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    const/16 v3, 0x18

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-ge v0, v3, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    return-void

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x2

    sget-boolean v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->isInitted:Z

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/4 v3, 0x4

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-eqz v0, :cond_5

    const/4 v7, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mContextRef:Ljava/lang/ref/WeakReference;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    if-nez v0, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    goto/16 :goto_0

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mReceiver:Landroid/content/BroadcastReceiver;

    const/4 v7, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v4, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-nez v0, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$HdmiAudioPlugBroadcastReceiver;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-direct {v0, v4}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$HdmiAudioPlugBroadcastReceiver;-><init>(Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$1;)V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mReceiver:Landroid/content/BroadcastReceiver;

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mContextRef:Ljava/lang/ref/WeakReference;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    check-cast v0, Landroid/content/Context;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-nez v0, :cond_3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-string v0, ",rymelvextlsii,ulveelefsacmi  dr!id snoueinciettgirba   eaR"

    const-string v0, "eren lumlllticdRcaa ieoegedbts,evi!ii iven  sentr, syraufix"

    const/4 v8, 0x6

    const-string/jumbo v0, "xs ,o lneenullioaeaie,if tRtietav!rrgcbyle dsimenseiirv   d"

    const-string/jumbo v0, "registerReceiver failed, context is null, maybe is invalid!"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {v3, v2, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    return-void

    :cond_3
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mReceiver:Landroid/content/BroadcastReceiver;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-eqz v3, :cond_4

    const/4 v7, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    new-instance v3, Landroid/content/IntentFilter;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-direct {v3}, Landroid/content/IntentFilter;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string v5, "PoLnnbUDOmtiIoaM..IUHGi.ipdDadAa_erd"

    const-string v5, ".IderUGptMo_Ddana_imi.PAOIDaHLdoUi.n"

    const/4 v8, 0x7

    const-string v5, "aPoanruIUnIMAcidOtiUHaG_D_.do.diLeD."

    const-string v5, "android.media.action.HDMI_AUDIO_PLUG"

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v3, v5}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    sget-object v5, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mReceiver:Landroid/content/BroadcastReceiver;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    sget-object v6, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mHandler:Landroid/os/Handler;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v0, v5, v3, v4, v6}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;)Landroid/content/Intent;

    move-result-object v4

    :cond_4
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {v0, v4}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;->getCapabilities(Landroid/content/Context;Landroid/content/Intent;)Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mAudioPassThroughCapabilities:Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughCapabilities;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string v0, "aqceglipeeResvee ivrre"

    const-string/jumbo v0, "srreecveqeivil eagRree"

    const/4 v8, 0x2

    const-string/jumbo v0, "rvcsreteqlereiRei vgea"

    const-string/jumbo v0, "registerReceiver leave"

    const/4 v7, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {v1, v2, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    return-void

    :cond_5
    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string/jumbo v0, "nesPAi!eetPgrooi ,oPosiirtuthn ylhtddaglrTui  eriguatRieescDsTscrt esveif "

    const-string v0, "!esytg,n rcRetseohluosiPoaint PdsrartuTu esiPeiiTegAgiDdlrth ecovi tfne ir"

    const/4 v8, 0x1

    const-string/jumbo v0, "shomeu AisihgPieier coyuT ocr  inDft!oertP,ereeisPsatltdlnaTRdtingeivregu "

    const-string/jumbo v0, "registerReceiver failed, TPAudioPassThroughPluginDetector is not init yet!"

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {v3, v2, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    return-void
.end method

.method public static removeListener(Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector$AudioPassThroughPluginListener;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const/4 v3, 0x2

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->listeners:Ljava/util/List;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {v1, p0}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    sget-object p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->listeners:Ljava/util/List;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    sget-boolean p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->hasRegisterReceiver:Z

    const/4 v3, 0x6

    const/4 v2, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->unregisterReceiver()V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    sput-boolean p0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->hasRegisterReceiver:Z

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    throw p0
.end method

.method private static unregisterReceiver()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    sget-boolean v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->isInitted:Z

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v1, "nuPtocPouDTirggoeThrissdAuoaleht"

    const-string v1, "TPAudioPassThroughPluginDetector"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v2, 0x4

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mContextRef:Ljava/lang/ref/WeakReference;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    check-cast v0, Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string v0, "erlinbifaci, i,n usrdtmc vsblae x mde nrtll evyieaieRio!gee"

    const-string v0, "ceimu olevira!fnvs elsildc, ineyre latart imeii,gd  bxeesnR"

    const/4 v4, 0x2

    const-string/jumbo v0, "iutd sunitenneraeic cte Rseleiieyivosd,il,rfae!rm xgvblla  "

    const-string/jumbo v0, "registerReceiver failed, context is null, maybe is invalid!"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {v2, v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->mReceiver:Landroid/content/BroadcastReceiver;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    const/4 v3, 0x5

    and-int/2addr v4, v3

    return-void

    :cond_2
    :goto_0
    const/4 v4, 0x0

    const-string/jumbo v0, "uaeitetpiiPocrrriilPuuisoeseef sd!tRThni  orc,teTvleonnggtheyAa   rDoedsti"

    const-string/jumbo v0, "oy roA ot,deaesisotgt nggheicPaen trD ru cnferievuruii!iTthieRTteosPlsdeil"

    const/4 v4, 0x2

    const-string v0, "TtoieuDiqsoRdPgPuntin tairyiloerfctgede s ,eeh g vrloaTuA!rtr einecesiPtsi"

    const-string/jumbo v0, "registerReceiver failed, TPAudioPassThroughPluginDetector is not init yet!"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v2, v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void
.end method
