.class final enum Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/core/common/TPCodecUtils;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4018
    name = "DefinitionName"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;

.field public static final enum DEFINITION_720P:Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const-string v1, "0DsOsNN7EI_ITF2"

    const-string v1, "OEsF7DTIIP02N_N"

    const/4 v4, 0x5

    const-string v1, "EFNmI20DIT7PNO_"

    const-string v1, "DEFINITION_720P"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {v0, v1, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;->DEFINITION_720P:Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x0

    shr-int/2addr v4, v3

    new-array v1, v1, [Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    aput-object v0, v1, v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    sput-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;->$VALUES:[Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o~moo@~~n @~4i~ of1 ~@~~ fol~y@~@ tos/@@@@@ @t@b@~ ~v @~~~i.r@b  @a@Ku@M~l@~/ ~~  @-oSi  cdb ~ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;

    const/4 v2, 0x7

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    check-cast p0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p0
.end method

.method public static values()[Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;->$VALUES:[Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0}, [Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast v0, [Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method
