.class public Lcom/tencent/thumbplayer/core/common/TPNativeThreadPriority;
.super Ljava/lang/Object;


# static fields
.field public static final THREAD_PRIORITY_AUDIO:I = 0x23

.field public static final THREAD_PRIORITY_BACKGROUND:I = 0x9

.field public static final THREAD_PRIORITY_DEFAULT:I = -0x1

.field public static final THREAD_PRIORITY_DISPLAY:I = 0x17

.field public static final THREAD_PRIORITY_FOREGROUND:I = 0x15

.field public static final THREAD_PRIORITY_LOWEST:I = 0x0

.field public static final THREAD_PRIORITY_URGENT_AUDIO:I = 0x26

.field public static final THREAD_PRIORITY_URGENT_DISPLAY:I = 0x1b

.field public static final THREAD_PRIORITY_VIDEO:I = 0x1d


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method
