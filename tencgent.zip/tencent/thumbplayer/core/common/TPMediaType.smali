.class public Lcom/tencent/thumbplayer/core/common/TPMediaType;
.super Ljava/lang/Object;


# static fields
.field public static final TP_MEDIA_TYPE_ATTACHMENT:I = 0x4

.field public static final TP_MEDIA_TYPE_AUDIO:I = 0x1

.field public static final TP_MEDIA_TYPE_DATA:I = 0x2

.field public static final TP_MEDIA_TYPE_SUBTITLE:I = 0x3

.field public static final TP_MEDIA_TYPE_UNKNOWN:I = -0x1

.field public static final TP_MEDIA_TYPE_VIDEO:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method
