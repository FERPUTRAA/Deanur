.class public Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    api = 0x11
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector$ScreenRefreshRateChangedListener;
    }
.end annotation


# static fields
.field public static final DISPLAY_CHANGE:I = 0x2711

.field private static TAG:Ljava/lang/String; = "TPScreenRefreshRateDetector"

.field private static isInitted:Z

.field private static listeners:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector$ScreenRefreshRateChangedListener;",
            ">;"
        }
    .end annotation
.end field

.field private static mContext:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/content/Context;",
            ">;"
        }
    .end annotation
.end field

.field private static mCurScreenRefreshRate:F

.field private static mDisplayListener:Landroid/hardware/display/DisplayManager$DisplayListener;

.field private static mDisplayManager:Landroid/hardware/display/DisplayManager;

.field private static mHandler:Landroid/os/Handler;

.field private static mWindowManager:Landroid/view/WindowManager;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance v0, Ljava/util/LinkedList;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->listeners:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/high16 v0, 0x42700000    # 60.0f

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    sput v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mCurScreenRefreshRate:F

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mDisplayManager:Landroid/hardware/display/DisplayManager;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector$2;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector$2;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mDisplayListener:Landroid/hardware/display/DisplayManager$DisplayListener;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic access$000()Landroid/hardware/display/DisplayManager;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s   m~i. bt-l@@f@M~t@ o@~y~ulb@o4 ~oo@@@ 1~/~   ~~@~oi@ bs@@d~r~@v~ @a~~n S@@@o~K@ifc~/ ~~~  @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mDisplayManager:Landroid/hardware/display/DisplayManager;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic access$100()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->TAG:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method static synthetic access$200(F)V
    .locals 2

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->notifyScreenRefreshRateChange(F)V

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic access$300()Landroid/os/Handler;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mHandler:Landroid/os/Handler;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public static addListener(Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector$ScreenRefreshRateChangedListener;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const/4 v3, 0x2

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->listeners:Ljava/util/List;

    const/4 v3, 0x1

    invoke-interface {v1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    throw p0
.end method

.method public static deinit()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const/4 v5, 0x6

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    sget-boolean v1, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->isInitted:Z

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mContext:Ljava/lang/ref/WeakReference;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->clear()V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    sput-boolean v1, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->isInitted:Z

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->TAG:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string/jumbo v2, "etsscddRcctTesna!fturrDreSeeeeteieoRi echn "

    const/4 v5, 0x7

    const-string v2, "TPScreenRefreshRateDetector deinit succeed!"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v3, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v3, v1, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    monitor-exit v0

    const/4 v5, 0x4

    return-void

    :cond_1
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    monitor-exit v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-void

    :catchall_0
    move-exception v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    throw v1
.end method

.method private static getLooper()Landroid/os/Looper;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    return-object v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public static getScreenRefreshRate()F
    .locals 12

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mContext:Ljava/lang/ref/WeakReference;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x2

    if-nez v0, :cond_0

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->TAG:Ljava/lang/String;

    const/4 v11, 0x5

    const-string/jumbo v1, "trumlnCsom  lext,furte etuds la .minnt"

    const-string v1, "e  m uxnu e,t mnteolstsritaCrtnllufde."

    const/4 v11, 0x2

    const-string/jumbo v1, "t,liout ue selnrdelxeu msCCrnn ta.otf "

    const-string v1, "Current mContext is null, set default."

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x5

    const/4 v2, 0x4

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-static {v2, v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x3

    sget v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mCurScreenRefreshRate:F

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    return v0

    :cond_0
    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x4

    check-cast v0, Landroid/content/Context;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x6

    if-eqz v0, :cond_4

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mWindowManager:Landroid/view/WindowManager;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    if-nez v1, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x1

    const-string/jumbo v1, "oiwwon"

    const/4 v11, 0x7

    const-string/jumbo v1, "iwdwob"

    const-string/jumbo v1, "window"

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x5

    check-cast v1, Landroid/view/WindowManager;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    sput-object v1, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mWindowManager:Landroid/view/WindowManager;

    :cond_1
    const/4 v10, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mDisplayManager:Landroid/hardware/display/DisplayManager;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    if-nez v1, :cond_2

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    const-string/jumbo v1, "slaibyu"

    const-string/jumbo v1, "iysadbl"

    const/4 v11, 0x4

    const-string/jumbo v1, "pysadlp"

    const-string v1, "display"

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x4

    check-cast v0, Landroid/hardware/display/DisplayManager;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mDisplayManager:Landroid/hardware/display/DisplayManager;

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mDisplayListener:Landroid/hardware/display/DisplayManager$DisplayListener;

    const/4 v11, 0x1

    const/4 v10, 0x5

    sget-object v2, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mHandler:Landroid/os/Handler;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/hardware/display/DisplayManager;->registerDisplayListener(Landroid/hardware/display/DisplayManager$DisplayListener;Landroid/os/Handler;)V

    :cond_2
    const/4 v11, 0x1

    const/4 v10, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mWindowManager:Landroid/view/WindowManager;

    const/4 v11, 0x3

    const/4 v10, 0x5

    if-eqz v0, :cond_4

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-interface {v0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v0}, Landroid/view/Display;->getSupportedModes()[Landroid/view/Display$Mode;

    move-result-object v1

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {v0}, Landroid/view/Display;->getMode()Landroid/view/Display$Mode;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    sget-object v2, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->TAG:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v11, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    const-string/jumbo v4, "tdg: ihdquweeM"

    const-string v4, "dw: gtuedMehoi"

    const-string v4, "eos:hewtdgMtd "

    const-string/jumbo v4, "getMode width:"

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v0}, Landroid/view/Display$Mode;->getPhysicalWidth()I

    move-result v4

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x7

    const-string v4, " itme:gp"

    const-string v4, ":eht igp"

    const/4 v11, 0x2

    const-string/jumbo v4, "ih goeth"

    const-string v4, " height:"

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v0}, Landroid/view/Display$Mode;->getPhysicalHeight()I

    move-result v5

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v11, 0x4

    const-string/jumbo v5, "freR bert:heq"

    const-string/jumbo v5, "retR esrq:efh"

    const/4 v11, 0x0

    const-string v5, "a:s eeuehrtRr"

    const-string v5, " refreshRate:"

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {v0}, Landroid/view/Display$Mode;->getRefreshRate()F

    move-result v6

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x2

    const-string v6, "ddsI:eMp"

    const-string v6, "IoseddM:"

    const/4 v11, 0x3

    const-string/jumbo v6, "qeod dI:"

    const-string v6, " ModeId:"

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v0}, Landroid/view/Display$Mode;->getModeId()I

    move-result v7

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x4

    const/4 v7, 0x2

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-static {v7, v2, v3}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x3

    sget-object v2, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->TAG:Ljava/lang/String;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    const-string/jumbo v8, "opsetpntSmuet deeg:lsrdMo"

    const-string/jumbo v8, "euemSdepnolgperM:d ttsotg"

    const/4 v11, 0x2

    const-string v8, "enumepdtlhopMogrsdSe tgte"

    const-string/jumbo v8, "getSupportedModes length:"

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-direct {v3, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x0

    array-length v8, v1

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-static {v7, v2, v3}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v10, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    array-length v3, v1

    const/4 v11, 0x1

    if-ge v2, v3, :cond_3

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x4

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->TAG:Ljava/lang/String;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x7

    const-string/jumbo v9, "tSesooutrgpMpw otideheod"

    const-string/jumbo v9, "iswooeogethttSr Mdpdepdu"

    const/4 v11, 0x5

    const-string/jumbo v9, "ohStebrtuodwpdtMid :eepg"

    const-string/jumbo v9, "getSupportedModes width:"

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x7

    aget-object v9, v1, v2

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {v9}, Landroid/view/Display$Mode;->getPhysicalWidth()I

    move-result v9

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x0

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x0

    aget-object v9, v1, v2

    const/4 v11, 0x6

    const/4 v10, 0x7

    invoke-virtual {v9}, Landroid/view/Display$Mode;->getPhysicalHeight()I

    move-result v9

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    aget-object v9, v1, v2

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {v9}, Landroid/view/Display$Mode;->getRefreshRate()F

    move-result v9

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    aget-object v9, v1, v2

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {v9}, Landroid/view/Display$Mode;->getModeId()I

    move-result v9

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-static {v7, v3, v8}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x4

    goto/16 :goto_0

    :cond_3
    const/4 v11, 0x5

    const/4 v10, 0x5

    invoke-virtual {v0}, Landroid/view/Display$Mode;->getRefreshRate()F

    move-result v0

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    sput v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mCurScreenRefreshRate:F

    :cond_4
    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    sget v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mCurScreenRefreshRate:F

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x3

    return v0
.end method

.method public static init(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const/4 v5, 0x0

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->TAG:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string v2, "ci!rerueeRnbcsSDPTfatnirr t hteteeeoeet"

    const-string/jumbo v2, "onhrcbrt  nceeieetePtDttTenfRs!errSeeia"

    const-string v2, "TPScreenRefreshRateDetector init enter!"

    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v3, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v3, v1, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    sget-boolean v1, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->isInitted:Z

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    monitor-exit v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    return-void

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    new-instance v1, Ljava/lang/ref/WeakReference;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {v1, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    sput-object v1, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mContext:Ljava/lang/ref/WeakReference;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 p0, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    sput-boolean p0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->isInitted:Z

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->initHandleMsg()V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object p0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->TAG:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v1, "chrttecpPRueru iRcissnaoercte eeeeenTD!tf"

    const-string/jumbo v1, "teTsafuetce Pennh!rtoeeiretcuRRreecc sDSi"

    const/4 v5, 0x2

    const-string/jumbo v1, "t ecsenRqrTae eeRtretiiuDchnefeSetscco!dr"

    const-string v1, "TPScreenRefreshRateDetector init succeed!"

    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-static {v3, p0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    monitor-exit v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-void

    :catchall_0
    move-exception p0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    throw p0
.end method

.method public static initHandleMsg()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector$1;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->getLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector$1;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mHandler:Landroid/os/Handler;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method private static notifyScreenRefreshRateChange(F)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mCurScreenRefreshRate:F

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    sub-float v0, p0, v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    cmpl-float v0, v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-ltz v0, :cond_0

    const/4 v3, 0x7

    shr-int/2addr v4, v3

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->TAG:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const-string v2, "SishhanR eesmf oRprgoatehyCfrnCaFecg eeetr"

    const-string/jumbo v2, "etiFSefpmCRhefysea ortCacr eeh anngRrghnoe"

    const/4 v4, 0x5

    const-string v2, "Fggmahse eheonSn moererfRnatefeCtrChi nRca"

    const-string/jumbo v2, "notifyScreenRefreshRateChange Change From "

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget v2, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mCurScreenRefreshRate:F

    const/4 v4, 0x2

    const/4 v3, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    const-string/jumbo v2, "ot  "

    const-string v2, "  to"

    const/4 v4, 0x5

    const-string/jumbo v2, "t  o"

    const-string v2, " to "

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v2, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {v2, v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x1

    move v4, v3

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-nez v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x7

    sput p0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->mCurScreenRefreshRate:F

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const/4 v4, 0x6

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    monitor-enter v0

    :try_start_0
    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->listeners:Ljava/util/List;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz v2, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    check-cast v2, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector$ScreenRefreshRateChangedListener;

    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-interface {v2, p0}, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector$ScreenRefreshRateChangedListener;->onScreenRefreshRateChanged(F)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x0

    return-void

    :catchall_0
    move-exception p0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    throw p0
.end method

.method public static removeListener(Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector$ScreenRefreshRateChangedListener;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPScreenRefreshRateDetector;->listeners:Ljava/util/List;

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-interface {v1, p0}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    throw p0
.end method
