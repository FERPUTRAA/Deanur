.class public Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/core/common/TPCodecCapability;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "TPCodecMaxCapability"
.end annotation


# instance fields
.field public maxBitRate:I

.field public maxChannels:I

.field public maxFramerateFormaxLumaSamples:I

.field public maxLevel:I

.field public maxLumaSamples:I

.field public maxProfile:I

.field public maxSampleRate:I


# direct methods
.method constructor <init>(III)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v0, 0x2

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLumaSamples:I

    iput p2, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxProfile:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput p3, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLevel:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/16 p1, 0x1e

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxFramerateFormaxLumaSamples:I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 p1, -0x1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxBitRate:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxSampleRate:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxChannels:I

    const/4 v0, 0x6

    const/4 v0, 0x5

    return-void
.end method

.method constructor <init>(IIII)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLumaSamples:I

    const/4 v0, 0x5

    move v1, v0

    iput p2, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxProfile:I

    const/4 v0, 0x5

    or-int/2addr v1, v0

    iput p3, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLevel:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p4, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxFramerateFormaxLumaSamples:I

    const/4 v0, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    const/4 p1, -0x1

    const/4 v0, 0x3

    move v1, v0

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxBitRate:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxSampleRate:I

    const/4 v1, 0x2

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxChannels:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method constructor <init>(IIIII)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxProfile:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput p2, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLevel:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p4, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxBitRate:I

    const/4 v0, 0x5

    move v1, v0

    iput p3, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxSampleRate:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p5, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxChannels:I

    const/4 v1, 0x7

    const/4 p1, -0x1

    const/4 v1, 0x0

    move v0, p1

    move v0, p1

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLumaSamples:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxFramerateFormaxLumaSamples:I

    const/4 v1, 0x0

    return-void
.end method
