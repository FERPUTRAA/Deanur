.class public Lcom/tencent/thumbplayer/core/common/TPPixelFormat;
.super Ljava/lang/Object;


# static fields
.field public static final TP_PIX_FMT_MEDIACODEC:I = 0xa7

.field public static final TP_PIX_FMT_NONE:I = -0x1

.field public static final TP_PIX_FMT_RGB565:I = 0x25

.field public static final TP_PIX_FMT_RGBA:I = 0x1a

.field public static final TP_PIX_FMT_YUV420P:I = 0x0

.field public static final TP_PIX_FMT_YUVJ420P:I = 0xc


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method
