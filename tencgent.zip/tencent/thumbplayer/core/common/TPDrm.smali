.class public final Lcom/tencent/thumbplayer/core/common/TPDrm;
.super Ljava/lang/Object;


# static fields
.field private static final TAG:Ljava/lang/String; = "TPDrm"

.field private static mIsLibLoaded:Z


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->loadLibIfNeeded(Landroid/content/Context;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    sput-boolean v0, Lcom/tencent/thumbplayer/core/common/TPDrm;->mIsLibLoaded:Z
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x6

    move v3, v2

    return-void

    :catch_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x4

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    sput-boolean v0, Lcom/tencent/thumbplayer/core/common/TPDrm;->mIsLibLoaded:Z

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x5

    and-int/2addr v1, v0

    return-void
.end method

.method public static getDRMCapabilities()[I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s~t@@~b@@d ~-~~n@ @ i b/~/~i~~o@@l vyr ~4t~1m~@@@ o@ Kf~~~u @  ~ @o.SMb@@s@i@o @o @cfal~ o~~ ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPDrm;->isLibLoaded()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPDrm;->native_getDRMCapabilities()[I

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-array v0, v0, [I

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x4

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v3, 0x3

    const-string v1, "aodmsecu t ivleianlFl .tc f"

    const-string v1, "e scua enoaFl inv.td lifctl"

    const/4 v3, 0x5

    const-string/jumbo v1, "laFaotadl  ctnovfc i en.lui"

    const-string v1, "Failed to call native func."

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    throw v0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo v1, "ltaiebbdooFiavnymarr elt adl  "

    const-string/jumbo v1, "vr miyldtiooaaae tFn iablde rl"

    const/4 v3, 0x6

    const-string/jumbo v1, "rtvy iuad.o irtFlaldnaeileab  "

    const-string v1, "Failed to load native library."

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-direct {v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    throw v0
.end method

.method private static isLibLoaded()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget-boolean v0, Lcom/tencent/thumbplayer/core/common/TPDrm;->mIsLibLoaded:Z

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method static native native_getDRMCapabilities()[I
.end method
