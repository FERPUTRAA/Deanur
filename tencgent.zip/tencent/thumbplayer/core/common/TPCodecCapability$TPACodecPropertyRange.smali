.class public Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/core/common/TPCodecCapability;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "TPACodecPropertyRange"
.end annotation


# instance fields
.field public level:I

.field public lowerboundBitRate:I

.field public lowerboundChannels:I

.field public lowerboundSampleRate:I

.field public profile:I

.field public upperboundBitRate:I

.field public upperboundChannels:I

.field public upperboundSampleRate:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public set(IIIIIIII)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;->upperboundSampleRate:I

    const/4 v0, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p2, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;->upperboundChannels:I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p3, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;->upperboundBitRate:I

    const/4 v0, 0x7

    and-int/2addr v1, v0

    iput p4, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;->lowerboundSampleRate:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p5, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;->lowerboundChannels:I

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p6, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;->lowerboundBitRate:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p7, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;->profile:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p8, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPACodecPropertyRange;->level:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method
