.class public Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$TPNativeAudioAttributeStreamType;,
        Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$TPNativeAudioAttributeFlag;,
        Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$TPNativeAudioAttributeUsage;,
        Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$TPNativeAudioAttributeContentType;,
        Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$Builder;
    }
.end annotation


# static fields
.field public static final TP_NATIVE_CONTENT_MOVIE:I = 0x3

.field public static final TP_NATIVE_CONTENT_MUSIC:I = 0x2

.field public static final TP_NATIVE_CONTENT_SONIFICATION:I = 0x4

.field public static final TP_NATIVE_CONTENT_SPEECH:I = 0x1

.field public static final TP_NATIVE_CONTENT_UNKNOWN:I = 0x0

.field public static final TP_NATIVE_FLAG_AUDIBILITY_ENFORCED:I = 0x1

.field public static final TP_NATIVE_FLAG_HW_AV_SYNC:I = 0x10

.field public static final TP_NATIVE_FLAG_LOW_LATENCY:I = 0x100

.field private static final TP_NATIVE_FLAG_PUBLIC:I = 0x111

.field public static final TP_NATIVE_FLAG_UNKNOWN:I = 0x0

.field public static final TP_NATIVE_STREAM_ALARM:I = 0x4

.field public static final TP_NATIVE_STREAM_DTMF:I = 0x8

.field public static final TP_NATIVE_STREAM_MUSIC:I = 0x3

.field public static final TP_NATIVE_STREAM_NOTIFICATION:I = 0x5

.field public static final TP_NATIVE_STREAM_RING:I = 0x2

.field public static final TP_NATIVE_STREAM_SYSTEM:I = 0x1

.field public static final TP_NATIVE_STREAM_UNKNOWN:I = -0x1

.field public static final TP_NATIVE_STREAM_VOICE_CALL:I = 0x0

.field public static final TP_NATIVE_USAGE_ALARM:I = 0x4

.field public static final TP_NATIVE_USAGE_ASSISTANCE_ACCESSIBILITY:I = 0xb

.field public static final TP_NATIVE_USAGE_ASSISTANCE_NAVIGATION_GUIDANCE:I = 0xc

.field public static final TP_NATIVE_USAGE_ASSISTANCE_SONIFICATION:I = 0xd

.field public static final TP_NATIVE_USAGE_ASSISTANT:I = 0x10

.field public static final TP_NATIVE_USAGE_GAME:I = 0xe

.field public static final TP_NATIVE_USAGE_MEDIA:I = 0x1

.field public static final TP_NATIVE_USAGE_NOTIFICATION:I = 0x5

.field public static final TP_NATIVE_USAGE_NOTIFICATION_COMMUNICATION_DELAYED:I = 0x9

.field public static final TP_NATIVE_USAGE_NOTIFICATION_COMMUNICATION_INSTANT:I = 0x8

.field public static final TP_NATIVE_USAGE_NOTIFICATION_COMMUNICATION_REQUEST:I = 0x7

.field public static final TP_NATIVE_USAGE_NOTIFICATION_EVENT:I = 0xa

.field public static final TP_NATIVE_USAGE_NOTIFICATION_RINGTONE:I = 0x6

.field public static final TP_NATIVE_USAGE_UNKNOWN:I = 0x0

.field public static final TP_NATIVE_USAGE_VOICE_COMMUNICATION:I = 0x2

.field public static final TP_NATIVE_USAGE_VOICE_COMMUNICATION_SIGNALLING:I = 0x3

.field private static final mMapContentTypeToString:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final mMapUsageToString:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private mContentType:I

.field private mFlags:I

.field private mUsage:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    new-instance v0, Ljava/util/HashMap;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mMapContentTypeToString:Ljava/util/HashMap;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    const/4 v1, 0x0

    const/4 v8, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string v2, "NVs_N_NWNTONETCOTAKINs_UE"

    const-string v2, "NVsNEONEOI_WNTATT_UCT_NKN"

    const/4 v8, 0x7

    const-string v2, "K_TmNONVOETIAN_NWTTNCUP_N"

    const-string v2, "TP_NATIVE_CONTENT_UNKNOWN"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v2, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string v3, "N_ANomTNHPCVE_ECEETSTOI_"

    const-string v3, "EVImSTENCNTO_EPAHETT_NC_"

    const/4 v8, 0x3

    const-string v3, "P_T_EbTVSINTCHNEACEOEPNT"

    const-string v3, "TP_NATIVE_CONTENT_SPEECH"

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/4 v3, 0x2

    const/4 v8, 0x7

    const/4 v7, 0x5

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string v4, "EPEoNTuCNTCVIST_U__OMAN"

    const-string v4, "_PNMoTCOTCANUNIVT__ETES"

    const/4 v8, 0x7

    const-string v4, "VCENEIApNITMTN_TCOS_T_U"

    const-string v4, "TP_NATIVE_CONTENT_MUSIC"

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v0, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    const/4 v4, 0x3

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    const-string v5, "TTTPVbINIETVOO_NMCN_EA_"

    const/4 v8, 0x1

    const-string v5, "TENN_VO_qITETNPEOAIMVCT"

    const-string v5, "TP_NATIVE_CONTENT_MOVIE"

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v0, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/4 v5, 0x4

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string v6, "VIsTTPO_uE_CTSINNTFIOCN_ANITAE"

    const-string v6, "PCEC_EuONNTTIITAVONTOFSI_I_ANT"

    const/4 v8, 0x5

    const-string v6, "NOPmIAIIT_AVI_SNFETO_TTETNNCON"

    const-string v6, "TP_NATIVE_CONTENT_SONIFICATION"

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v0, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    new-instance v0, Ljava/util/HashMap;

    const/4 v8, 0x1

    const/4 v7, 0x7

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mMapUsageToString:Ljava/util/HashMap;

    const-string v6, "WANG_TEpU_SNVK_NPNUAOIT"

    const/4 v8, 0x7

    const-string v6, "NAVSoENK_ITG_ATPN_UOUEN"

    const-string v6, "TP_NATIVE_USAGE_UNKNOWN"

    const/4 v8, 0x7

    invoke-virtual {v0, v1, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    const-string v1, "UN_TEbAT__APqEVIDSAEM"

    const-string v1, "VUM_PGNEqEA_EDTIA_TSA"

    const/4 v8, 0x0

    const-string v1, "ATSNPUuAIMEGDAE_I_TE_"

    const-string v1, "TP_NATIVE_USAGE_MEDIA"

    const/4 v8, 0x1

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x5

    const-string v1, "__MAACOpNCNGEUIC_TIOVVENIIOTUTMs_EP"

    const-string v1, "IVsEIEAMC_IEMTTISNUNGVNA_UOCOTC_O_P"

    const/4 v8, 0x0

    const-string v1, "T_IINCCVqAVIOIGUPEAOOMES_NUE_TT_MAN"

    const-string v1, "TP_NATIVE_USAGE_VOICE_COMMUNICATION"

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v0, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    const-string v1, "EAsEENImCT_NNUGVITCCLGGTNALSU_OMN_I_SOMPIAI_OI"

    const-string v1, "IIIm_INNANVCGOACMAM_LTENNGUIS_ESCT_OVUEPTIOLG_"

    const-string v1, "INUmNILAVO__CNT__NAIOCLVNETTIM_IGSMGIEAEAUSCGP"

    const-string v1, "TP_NATIVE_USAGE_VOICE_COMMUNICATION_SIGNALLING"

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v0, v4, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string v1, "MA_ooPNAESAA_REVLT_GU"

    const-string v1, "AAE_oAULN_MAPRSTVE_GT"

    const-string v1, "V_MPTbAI_EGL_UAATARSE"

    const-string v1, "TP_NATIVE_USAGE_ALARM"

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v0, v5, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    const/4 v1, 0x5

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-string v2, "AIbPUVuOAFNOTTTNETA___CGEIIS"

    const-string v2, "ITAIAbTUPTNASTC__ENO_IOVFGIE"

    const/4 v8, 0x1

    const-string v2, "ATCUGOPpEINFSAV_IIIE_TTNTOAN"

    const-string v2, "TP_NATIVE_USAGE_NOTIFICATION"

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/4 v1, 0x6

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    const-string v2, "TVNIETTIqNTE_NOPENFUARCNOAITGG_OIA_IS"

    const-string v2, "TP_NATIVE_USAGE_NOTIFICATION_RINGTONE"

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    const/4 v1, 0x7

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    const-string v2, "OEsICNQUNENRVCTANSIATOO_FMUT_ETSUI_uICAE_GMTPONT_I"

    const-string v2, "ITEUN_uUITQNFPCONE_TCEIIAAG_MCOOAEVNISONTITT_SRU_M"

    const/4 v8, 0x2

    const-string v2, "_UTmTIINSQEFVRTTAOECEIMUITP_UNN_OAITCGONCE__ONISMA"

    const-string v2, "TP_NATIVE_USAGE_NOTIFICATION_COMMUNICATION_REQUEST"

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/16 v1, 0x8

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string v2, "OOOEo_ATN_EATA_NUTTIFAINNIUMOSTIMTpINNCPCNICAV_IGT"

    const-string v2, "TATOEMNpCTIFI_AC_ANIGOASECOIUTTMNIATONIN_N_ITNUP_V"

    const/4 v8, 0x2

    const-string v2, "ETTTTbA__NTISACITONAIIMUANPNIVFMNOCC_N_A_GIINOOSUE"

    const-string v2, "TP_NATIVE_USAGE_NOTIFICATION_COMMUNICATION_INSTANT"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x3

    move v8, v7

    const/16 v1, 0x9

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string v2, "AGTTANu_PqDEIIACYDNEUT_EMCCF_USNN_OTONEIT_IAMIVOLI"

    const-string v2, "SOIAFONDqAGD_LTU_NO_TITCNUNNY_IEMCTAOEC_APMEIIEVTI"

    const/4 v8, 0x1

    const-string v2, "TTUEENEpINF_IAI_T_A_TOLUODINIYCGAP_AEOSNMMIOTVCNAD"

    const-string v2, "TP_NATIVE_USAGE_NOTIFICATION_COMMUNICATION_DELAYED"

    const/4 v7, 0x4

    move v8, v7

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/16 v1, 0xa

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string v2, "NTTG__AEqEFsAVOTIS_EININVPU_TEINTA"

    const-string v2, "TCsINFAI_NATOSEEEGI_UVTPV_NNET_ATI"

    const-string v2, "TAsEIT_IGOEF_NIUPESVCAOTNETNI_NAVT"

    const-string v2, "TP_NATIVE_USAGE_NOTIFICATION_EVENT"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/16 v1, 0xb

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string v2, "CTAm_TLTSAVBSAITCNP_ISSCYmE_IE_EEANGAISU"

    const-string v2, "SVAmETETISN_YAIUIATGLCTCAISSPS_NCA_SEB_E"

    const/4 v8, 0x5

    const-string v2, "SIASo_I_YUTIETPSCSGAASTNEIAB_LVSEE_ACICN"

    const-string v2, "TP_NATIVE_USAGE_ASSISTANCE_ACCESSIBILITY"

    const/4 v8, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x1

    const/16 v1, 0xc

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    const-string v2, "NNAIEbASAANoSIGC_SIEC_UOIAVGTEPTIGN_A_DTNUETV_"

    const-string v2, "VAAUoT_SN_PES_NTE_UIVGCINGIDSGAEINAIAEAAO_TCTN"

    const/4 v8, 0x1

    const-string v2, "_CCI_IuNEAA_ANGNTSEGDTATESUVU_VS_EITONIPANSGAA"

    const-string v2, "TP_NATIVE_USAGE_ASSISTANCE_NAVIGATION_GUIDANCE"

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/16 v1, 0xd

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string v2, "ANPINEOpIUAFISVTOCTSAT__NTbGCA_NIASS_SE"

    const-string v2, "NV_OTbGAAN_ONTSPIASSTSUF_ESINIAEIC_CETA"

    const/4 v8, 0x3

    const-string v2, "TP_NATIVE_USAGE_ASSISTANCE_SONIFICATION"

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    const/16 v1, 0xe

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    const-string v2, "Iu_GUETAq_ENASVM_AGE"

    const-string v2, "MEIGU_uA__EANTVEPASG"

    const/4 v8, 0x0

    const-string v2, "APsTENSAGMA__VEGTU_E"

    const-string v2, "TP_NATIVE_USAGE_GAME"

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/16 v1, 0x10

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string v2, "TNImAGATP_EATEAVUSpS_INTS"

    const-string v2, "TSTA_TPpAESING_NEU_VSTIAA"

    const/4 v8, 0x3

    const-string v2, "I_ANoSAGES_TAUS_ATSNTVPET"

    const-string v2, "TP_NATIVE_USAGE_ASSISTANT"

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mUsage:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mContentType:I

    const/4 v1, 0x6

    move v2, v1

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mFlags:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$1;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic access$102(Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;I)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@oi~ b@f~bn.~ @~@i a/4cr@~@ovti@@@K/~ @@m-@~~  o~@oo~~su~S@y d o~ @  ~~~@  ~l~f @ @~t@bM~ @l ~~1"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mContentType:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    return p1
.end method

.method static synthetic access$202(Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;I)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mUsage:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return p1
.end method

.method static synthetic access$302(Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mFlags:I

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p1
.end method

.method static synthetic access$400()Ljava/util/HashMap;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mMapUsageToString:Ljava/util/HashMap;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic access$500()Ljava/util/HashMap;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mMapContentTypeToString:Ljava/util/HashMap;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public static contentTypeToString(I)Ljava/lang/String;
    .locals 4
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$TPNativeAudioAttributeContentType;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mMapContentTypeToString:Ljava/util/HashMap;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    check-cast p0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object p0

    :cond_0
    const/4 v3, 0x1

    const-string/jumbo v0, "ttnnequnneou ytc kpn"

    const-string/jumbo v0, "etcnontnqun ywkt pne"

    const/4 v3, 0x4

    const-string v0, " nponykpnwetnnttuoce"

    const-string/jumbo v0, "unknown content type"

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object p0
.end method

.method public static usageToString(I)Ljava/lang/String;
    .locals 4
    .param p0    # I
        .annotation runtime Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$TPNativeAudioAttributeUsage;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mMapUsageToString:Ljava/util/HashMap;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    check-cast p0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string/jumbo v0, "nes nguwn uaok"

    const/4 v3, 0x0

    const-string v0, " ewna gkqunuos"

    const-string/jumbo v0, "unknown usage "

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p0
.end method


# virtual methods
.method public getContentType()I
    .locals 3
    .annotation runtime Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$TPNativeAudioAttributeContentType;
    .end annotation

    const/4 v1, 0x0

    const/4 v1, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mContentType:I

    const/4 v2, 0x4

    return v0
.end method

.method public getFlags()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mFlags:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    and-int/lit16 v0, v0, 0x111

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method public getUsage()I
    .locals 3
    .annotation runtime Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes$TPNativeAudioAttributeUsage;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mUsage:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "btstd=eigmtsAus ueiau:o"

    const-string/jumbo v1, "uebmid=aAgeAuossit:tt u"

    const/4 v3, 0x3

    const-string v1, "Asumstrtbu=aote:dAeigui"

    const-string v1, "AudioAttributes: usage="

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mUsage:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v1}, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->usageToString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v1, "no=coe nt"

    const-string v1, "c nooe=nt"

    const/4 v3, 0x0

    const-string/jumbo v1, "n= etbntc"

    const-string v1, " content="

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mContentType:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v1}, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->contentTypeToString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const-string v1, "alx0=fu s"

    const-string v1, "0fla=bsx "

    const/4 v3, 0x5

    const-string/jumbo v1, "fx0agl=p "

    const-string v1, " flags=0x"

    const/4 v2, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, p0, Lcom/tencent/thumbplayer/core/common/TPNativeAudioAttributes;->mFlags:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0
.end method
