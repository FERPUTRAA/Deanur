.class public Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/thumbplayer/core/common/TPCodecCapability;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "TPHdrSupportVersionRange"
.end annotation


# instance fields
.field public lowerboundAndroidAPILevel:I

.field public lowerboundPatchVersion:I

.field public lowerboundSystemVersion:I

.field public upperboundAndroidAPILevel:I

.field public upperboundPatchVersion:I

.field public upperboundSystemVersion:I


# direct methods
.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    shl-int/2addr v1, v0

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->upperboundAndroidAPILevel:I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p2, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->lowerboundAndroidAPILevel:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(IIII)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->upperboundSystemVersion:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput p2, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->lowerboundSystemVersion:I

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput p3, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->upperboundPatchVersion:I

    const/4 v1, 0x5

    iput p4, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->lowerboundPatchVersion:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method
