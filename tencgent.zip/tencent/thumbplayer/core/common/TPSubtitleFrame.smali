.class public Lcom/tencent/thumbplayer/core/common/TPSubtitleFrame;
.super Ljava/lang/Object;


# instance fields
.field public data:[[B

.field public format:I

.field public height:I

.field public linesize:[I

.field public ptsUs:J

.field public rotation:I

.field public sampleAspectRatioDen:I

.field public sampleAspectRatioNum:I

.field public width:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method
