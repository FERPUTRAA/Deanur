.class public Lcom/tencent/thumbplayer/core/common/TPCodecUtils;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel;,
        Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;
    }
.end annotation


# static fields
.field public static final CAP_AUDIO_AAC:I = 0x8

.field public static final CAP_AUDIO_DD:I = 0x10

.field public static final CAP_AUDIO_DDP:I = 0x20

.field public static final CAP_AUDIO_DTS:I = 0x80

.field public static final CAP_AUDIO_FLAC:I = 0x40

.field public static final CAP_VIDEO_AVC:I = 0x1

.field public static final CAP_VIDEO_HEVC:I = 0x2

.field public static final CAP_VIDEO_VP8:I = 0x100

.field public static final CAP_VIDEO_VP9:I = 0x4

.field public static final PLAYER_LEVEL_0:I = 0x0

.field public static final PLAYER_LEVEL_1:I = 0x1

.field public static final PLAYER_LEVEL_11:I = 0xb

.field public static final PLAYER_LEVEL_16:I = 0x10

.field public static final PLAYER_LEVEL_21:I = 0x15

.field public static final PLAYER_LEVEL_26:I = 0x1a

.field public static final PLAYER_LEVEL_28:I = 0x1c

.field public static final PLAYER_LEVEL_33:I = 0x21

.field public static final PLAYER_LEVEL_6:I = 0x6

.field public static final PLAYER_LEVEL_UNKNOWN:I = -0x1

.field private static final TAG:Ljava/lang/String; = "TPCodecUtils"

.field private static final VVC_SHD_HISI_CPU_NAME:Ljava/lang/String; = "Kirin9000E"

.field private static final VVC_SHD_MTK_CPU_NAME:Ljava/lang/String; = "MT6893"

.field private static final VVC_SHD_QUALCOMMN_CPU_NAME:Ljava/lang/String; = "SM8250"

.field private static final VVC_SHD_SAMSUNG_CPU_NAME:Ljava/lang/String; = "Exynos2100"

.field private static mAACMaxSupportedBitrate:I = 0x7c830

.field private static mAACMaxSupportedChannels:I = 0x8

.field private static mAACMaxSupportedSamplerate:I = 0x17700

.field private static mAMediaCodecBlackListInstance:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static mAMediaCodecBlackListModel:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field protected static mAMediaCodecCapList:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static mAV1SWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability; = null

.field private static mAVCSWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability; = null

.field private static mAVS3WMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability; = null

.field private static mAudioMaxCapCodecInstance:Ljava/util/HashMap; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static mAvs3DeviceLevel:I = -0x1

.field private static mCodecCapBlackList:Ljava/util/HashMap; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static mCodecCapWhiteList:Ljava/util/HashMap; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static mContext:Landroid/content/Context; = null

.field private static mDDPMaxSupportedBitrate:I = 0x5dc000

.field private static mDDPMaxSupportedChannels:I = 0x8

.field private static mDDPMaxSupportedSamplerate:I = 0xbb80

.field private static mDefinitionNameToDecodeLevelTable:Ljava/util/HashMap; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static mDrmL1BlackList:Ljava/util/HashMap; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field private static mFLACMaxSupportedBitrate:I = 0x1406f40

.field private static mFLACMaxSupportedChannels:I = 0x8

.field private static mFLACMaxSupportedSamplerate:I = 0x2ee00

.field private static mFhdAvs3HisiIndex:I = 0x0

.field private static mFhdAvs3QualcommIndex:I = 0x0

.field private static mHDRTypeToHDRHardwareCodecWhiteListMap:Ljava/util/HashMap; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Ljava/util/ArrayList<",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;",
            ">;>;"
        }
    .end annotation
.end field

.field private static mHDRTypeToHDRSoftwareCodecWhiteListMap:Ljava/util/HashMap; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Ljava/util/ArrayList<",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;",
            ">;>;"
        }
    .end annotation
.end field

.field private static mHDRVividSupportVersionMap:Ljava/util/HashMap; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;",
            ">;"
        }
    .end annotation
.end field

.field private static mHEVCSWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability; = null

.field private static mHdHevcHisiIndex:I = 0x0

.field private static mHdHevcMtkIndex:I = 0x0

.field private static mHdHevcQualcommIndex:I = 0x0

.field private static mHdHevcSamsungIndex:I = 0x0

.field private static mHdrBlackMap:Ljava/util/HashMap; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;",
            ">;>;"
        }
    .end annotation
.end field

.field private static mHdrWhiteMap:Ljava/util/HashMap; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;",
            ">;>;"
        }
    .end annotation
.end field

.field private static mHevcDeviceLevel:I = -0x1

.field private static mIsFFmpegCapGot:Z = false

.field private static mIsInitDone:Z = false

.field private static mLocalCache:Lcom/tencent/thumbplayer/core/thirdparties/LocalCache; = null

.field private static mMaxACodecHwCapabilityMap:Ljava/util/HashMap; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;",
            ">;"
        }
    .end annotation
.end field

.field private static mMaxACodecSwCapabilityMap:Ljava/util/HashMap; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;",
            ">;"
        }
    .end annotation
.end field

.field private static mMaxVCodecHwCapabilityMap:Ljava/util/HashMap; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;",
            ">;"
        }
    .end annotation
.end field

.field private static mMaxVCodecSwCapabilityMap:Ljava/util/HashMap; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;",
            ">;"
        }
    .end annotation
.end field

.field private static mPreferredSoftwareComponent:Z = false

.field private static mShdAvs3QualcommIndex:I = 0x0

.field private static mShdHevcHisiIndex:I = 0x0

.field private static mShdHevcMtkIndex:I = 0x0

.field private static mShdHevcQualcommIndex:I = 0x0

.field private static mShdHevcSamsungIndex:I = 0x0

.field private static mSupportedMediaCodec:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static mVMediaCodecBlackListModel:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field protected static mVMediaCodecCapList:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static mVP8SWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability; = null

.field private static mVP9SWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability; = null

.field private static mVVCSWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability; = null

.field private static mVideoCodecIdToSwCapabilityModel:Landroid/util/SparseArray; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel;",
            ">;"
        }
    .end annotation
.end field

.field private static mVvcDeviceLevel:I = -0x1

.field private static mWideVineBlackListModel:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 12

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x4

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecCapList:Ljava/util/ArrayList;

    const/4 v11, 0x3

    const/4 v10, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x7

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAMediaCodecCapList:Ljava/util/ArrayList;

    const/4 v11, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x4

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v11, 0x6

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x6

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAMediaCodecBlackListModel:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x5

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAMediaCodecBlackListInstance:Ljava/util/ArrayList;

    const/4 v10, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x4

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mSupportedMediaCodec:Ljava/util/ArrayList;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x6

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdrWhiteMap:Ljava/util/HashMap;

    const/4 v10, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    new-instance v0, Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x5

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdrBlackMap:Ljava/util/HashMap;

    const/4 v11, 0x2

    const/4 v10, 0x7

    new-instance v0, Ljava/util/HashMap;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x1

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x3

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRTypeToHDRSoftwareCodecWhiteListMap:Ljava/util/HashMap;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRTypeToHDRHardwareCodecWhiteListMap:Ljava/util/HashMap;

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x1

    new-instance v0, Ljava/util/HashMap;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x3

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAudioMaxCapCodecInstance:Ljava/util/HashMap;

    const/4 v11, 0x5

    const/4 v10, 0x2

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v11, 0x0

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mWideVineBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    new-instance v0, Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x7

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDrmL1BlackList:Ljava/util/HashMap;

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x4

    const/4 v0, 0x0

    const/4 v11, 0x4

    sput-boolean v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mIsInitDone:Z

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x6

    sput-boolean v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mPreferredSoftwareComponent:Z

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x2

    const/16 v1, 0x20

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x0

    sput v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mShdHevcQualcommIndex:I

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    const/16 v1, 0x14

    const/4 v11, 0x5

    const/4 v10, 0x6

    sput v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdHevcQualcommIndex:I

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    const/16 v1, 0xc

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x3

    sput v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mShdHevcMtkIndex:I

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x4

    const/16 v1, 0x8

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x7

    sput v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdHevcMtkIndex:I

    const/4 v10, 0x4

    shl-int/2addr v11, v10

    sput v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mShdHevcHisiIndex:I

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x7

    const/4 v2, 0x3

    const/4 v10, 0x0

    move v11, v10

    sput v2, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdHevcHisiIndex:I

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    sput v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mShdHevcSamsungIndex:I

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    const/4 v1, 0x5

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    sput v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdHevcSamsungIndex:I

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/16 v3, 0x3a

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x4

    sput v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mFhdAvs3QualcommIndex:I

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    const/16 v3, 0x37

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x6

    sput v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mShdAvs3QualcommIndex:I

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x4

    const/16 v3, 0xe

    const/4 v10, 0x4

    move v11, v10

    sput v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mFhdAvs3HisiIndex:I

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    new-instance v3, Landroid/util/SparseArray;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-direct {v3}, Landroid/util/SparseArray;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x6

    sput-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVideoCodecIdToSwCapabilityModel:Landroid/util/SparseArray;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x3

    new-instance v3, Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x6

    sput-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDefinitionNameToDecodeLevelTable:Ljava/util/HashMap;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    new-instance v3, Ljava/util/HashMap;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x4

    sput-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mCodecCapWhiteList:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x7

    const/16 v4, 0xb

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    const-string v5, "1ss5JN"

    const-string v5, "11s5NJ"

    const/4 v11, 0x4

    const-string v5, "5NJm1X"

    const-string v5, "NX511J"

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {v3, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mCodecCapWhiteList:Ljava/util/HashMap;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x6

    const-string v6, "Vi0Mo31790m"

    const-string v6, "370m09VMiH1"

    const/4 v11, 0x7

    const-string v6, "83V1Hb709Mi"

    const-string v6, "Hi3798MV100"

    const/4 v10, 0x7

    move v11, v10

    invoke-virtual {v3, v6, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x7

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mCodecCapWhiteList:Ljava/util/HashMap;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    const-string v6, "7u/c75u068u68o/9duu/6u97auf975f/856/"

    const-string/jumbo v6, "ua7uo86/85uu5u/678f///36779u9f5d60c9"

    const/4 v11, 0x3

    const-string v6, "/6u5/7cp9u68583u6a7798u/9750u6fd/f//"

    const-string/jumbo v6, "\u957f\u8679\u667a\u80fd\u7535\u89c6"

    const/4 v10, 0x0

    move v11, v10

    invoke-virtual {v3, v6, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mCodecCapWhiteList:Ljava/util/HashMap;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    const-string/jumbo v7, "ob10d ToqiV c9nTrAn  "

    const-string v7, "0nd ob9nV 1oTiTdc r A"

    const/4 v11, 0x5

    const-string/jumbo v7, "l sA 0io1nc VnT d9dro"

    const-string v7, "Android TV on Tcl 901"

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {v3, v7, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mCodecCapWhiteList:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x1

    const-string v7, "880mtx"

    const-string/jumbo v7, "ut8x08"

    const/4 v11, 0x4

    const-string v7, "0bt8ox"

    const-string/jumbo v7, "xt880b"

    const/4 v11, 0x5

    const/4 v10, 0x7

    invoke-virtual {v3, v7, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x3

    const-string v3, "ClepcbotTiUd"

    const-string v3, "PltCeTUpdoci"

    const/4 v11, 0x3

    const-string/jumbo v3, "iUTdctuPlose"

    const-string v3, "TPCodecUtils"

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    const-string/jumbo v4, "iltneiqpis  hiw"

    const-string/jumbo v4, "ilhiiistqwnte  "

    const/4 v11, 0x5

    const-string/jumbo v4, "iilth  tqsiewit"

    const-string/jumbo v4, "white list init"

    const/4 v10, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x1

    const/4 v7, 0x2

    const/4 v11, 0x4

    invoke-static {v7, v3, v4}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mSupportedMediaCodec:Ljava/util/ArrayList;

    const/4 v11, 0x2

    const-string/jumbo v4, "vdsocs/va"

    const-string/jumbo v4, "ocsdeva/v"

    const/4 v11, 0x4

    const-string v4, "decmivvo/"

    const-string/jumbo v4, "video/avc"

    const/4 v11, 0x4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x2

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mSupportedMediaCodec:Ljava/util/ArrayList;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x2

    const-string/jumbo v4, "hvdeocvieo"

    const-string/jumbo v4, "odemicvhev"

    const/4 v11, 0x7

    const-string/jumbo v4, "ovhdvbec/i"

    const-string/jumbo v4, "video/hevc"

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x3

    move v11, v10

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mSupportedMediaCodec:Ljava/util/ArrayList;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    const-string/jumbo v4, "nvp.ov-8xodoveind/."

    const/4 v11, 0x7

    const-string v4, "8ex2dou.dpv-/i.onnv"

    const-string/jumbo v4, "video/x-vnd.on2.vp8"

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mSupportedMediaCodec:Ljava/util/ArrayList;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x5

    const-string v4, "/vb.de.ppdoonx-2vni"

    const-string v4, "-novob.iv2.penv/ddx"

    const/4 v11, 0x3

    const-string/jumbo v4, "v9pivn-dqn./ooxed2."

    const-string/jumbo v4, "video/x-vnd.on2.vp9"

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mSupportedMediaCodec:Ljava/util/ArrayList;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x4

    const-string/jumbo v4, "oievd/u0av"

    const/4 v11, 0x0

    const-string v4, "e/sviv1od0"

    const-string/jumbo v4, "video/av01"

    const/4 v11, 0x1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x6

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mSupportedMediaCodec:Ljava/util/ArrayList;

    const/4 v11, 0x3

    const-string v4, "dammu-mtpioap/4"

    const-string v4, "apimlmopt/da-4u"

    const/4 v11, 0x0

    const-string/jumbo v4, "utolo/aaad-mmi4"

    const-string v4, "audio/mp4a-latm"

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mSupportedMediaCodec:Ljava/util/ArrayList;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    const-string v4, "coid/bqa3"

    const-string v4, "co3/aaidq"

    const/4 v11, 0x5

    const-string v4, "aaid/3uou"

    const-string v4, "audio/ac3"

    const/4 v11, 0x0

    const/4 v10, 0x7

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mSupportedMediaCodec:Ljava/util/ArrayList;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x4

    const-string v4, "/ai3cdepus"

    const-string/jumbo v4, "uesdi/aa3c"

    const/4 v11, 0x6

    const-string v4, "/ocedua3qa"

    const-string v4, "audio/eac3"

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x4

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mSupportedMediaCodec:Ljava/util/ArrayList;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    const-string v4, "cisaeu/3coaomj"

    const-string/jumbo v4, "oijm3/aeocc-au"

    const/4 v11, 0x4

    const-string v4, "3-amacu/oijecd"

    const-string v4, "audio/eac3-joc"

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x6

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mSupportedMediaCodec:Ljava/util/ArrayList;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x2

    const-string/jumbo v4, "oilaoaduf/"

    const-string/jumbo v4, "fcauod/lai"

    const/4 v11, 0x4

    const-string v4, "aui/dblacf"

    const-string v4, "audio/flac"

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mSupportedMediaCodec:Ljava/util/ArrayList;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x6

    const-string/jumbo v4, "otduvsuidd./a"

    const-string v4, "audio/vnd.dts"

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAMediaCodecBlackListInstance:Ljava/util/ArrayList;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    const-string/jumbo v4, "uXMaidepqri.ftOc..a.ocbdel"

    const-string v4, "Xu..abcedoadqeftiOi.M.rloc"

    const/4 v11, 0x3

    const-string v4, "edila.t.qqOo.MXof.cirducad"

    const-string v4, "OMX.qti.audio.decoder.flac"

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x2

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    const-string v4, "78suJM00"

    const-string v4, "70J0M8uS"

    const/4 v11, 0x1

    const-string v4, "0M0mS-J7"

    const-string v4, "SM-J7008"

    const/4 v11, 0x6

    const/4 v10, 0x7

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x2

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x7

    const-string v4, "M0p-o805"

    const-string v4, "M0S058-p"

    const/4 v11, 0x0

    const-string v4, "8J0M5bS-"

    const-string v4, "SM-J5008"

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x4

    const-string v4, "60q iCuL"

    const-string/jumbo v4, "qCi T60L"

    const/4 v11, 0x3

    const-string v4, " 8CiL6Tp"

    const-string v4, "TCL i806"

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x0

    const-string/jumbo v4, "io 1Yvs1qi "

    const-string/jumbo v4, "ivsYo T1i1 "

    const/4 v11, 0x6

    const-string v4, "1 sivi TYo1"

    const-string/jumbo v4, "vivo Y11i T"

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x3

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x2

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    const-string v4, "1 mmS"

    const-string v4, "M Sm1"

    const/4 v11, 0x6

    const-string v4, "M ISo"

    const-string v4, "MI 1S"

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x6

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x6

    const-string/jumbo v4, "o2S9PbA"

    const-string v4, "A9P2oS8"

    const/4 v11, 0x4

    const-string v4, "8SA92Pu"

    const-string v4, "SP9832A"

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    const-string/jumbo v4, "pb0AP89"

    const-string v4, "3P0A8b9"

    const/4 v11, 0x1

    const-string v4, "3q80P9A"

    const-string v4, "SP9830A"

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x7

    const/4 v10, 0x7

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    const-string v4, "OTsO 71Gu"

    const-string v4, "TVO1GOu 7"

    const/4 v11, 0x6

    const-string v4, "TG mO71VT"

    const-string v4, "VOTO GT17"

    const/4 v11, 0x7

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x4

    const/4 v10, 0x2

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x7

    const-string/jumbo v4, "p-0Lo1VA"

    const-string v4, "A1VLE0-p"

    const/4 v11, 0x2

    const-string v4, "EVA-AL10"

    const/4 v11, 0x5

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x1

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x1

    const v5, 0x98967f

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x3

    const v6, 0x10c985

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x3

    const/16 v8, 0x63

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-direct {v4, v5, v6, v8, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x4

    const-string/jumbo v9, "qT0AAb-0"

    const-string/jumbo v9, "q0AT0-AS"

    const/4 v11, 0x7

    const-string v9, "A0T0-SuA"

    const-string v9, "TAS-AL00"

    const/4 v11, 0x0

    const/4 v10, 0x4

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x6

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x6

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x6

    invoke-direct {v4, v5, v6, v8, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    const-string v9, "TAT0-Ssp"

    const-string v9, "T0sS0T-A"

    const/4 v11, 0x4

    const-string/jumbo v9, "qTSL0A0-"

    const-string v9, "TAS-TL00"

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x5

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-direct {v4, v5, v6, v8, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    const-string v9, "-SsNAA0m"

    const-string v9, "S0Nm0-AA"

    const/4 v11, 0x5

    const-string v9, "A0AmN-0T"

    const-string v9, "TAS-AN00"

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x0

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v10, 0x7

    const/4 v10, 0x4

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-direct {v4, v5, v6, v8, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x1

    const/4 v10, 0x5

    const-string v9, "NIAoo0-0"

    const-string v9, "AIO-o00N"

    const/4 v11, 0x3

    const-string v9, "AO-0LbN0"

    const-string v9, "LIO-AN00"

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v10, 0x7

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x1

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-direct {v4, v5, v6, v8, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x7

    const-string v9, "LOI00NuAb"

    const-string v9, "0OP0LbAIN"

    const/4 v11, 0x2

    const-string v9, "A-L0NPIp0"

    const-string v9, "LIO-AN00P"

    const/4 v11, 0x3

    const/4 v10, 0x0

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x2

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-direct {v4, v5, v6, v8, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x3

    const-string v9, "L-Au0OI0q"

    const-string v9, "O-L00IumA"

    const/4 v11, 0x6

    const-string/jumbo v9, "mAs0LI-0N"

    const-string v9, "LIO-AN00m"

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x5

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-direct {v4, v5, v6, v8, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    const-string v9, "0-LmIpOL"

    const-string v9, "0-LLOI0p"

    const/4 v11, 0x0

    const-string v9, "-TO0o0LL"

    const-string v9, "LIO-TL00"

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x0

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x0

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-direct {v4, v5, v6, v8, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    const-string v9, "LA-O0bLI"

    const-string v9, "LIO-AL00"

    const/4 v10, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-direct {v4, v5, v6, v8, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x7

    const-string v9, "NN0AA0u-"

    const-string/jumbo v9, "q0A0-NAN"

    const/4 v11, 0x7

    const-string v9, "-NNAA0Ap"

    const-string v9, "ANA-AN00"

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x1

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x5

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-direct {v4, v5, v6, v8, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x2

    const-string/jumbo v9, "qANNT0-A"

    const-string v9, "NAsNA0-T"

    const/4 v11, 0x7

    const-string v9, "ANs-NTA0"

    const-string v9, "ANA-TN00"

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x1

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x1

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-direct {v4, v5, v6, v8, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x7

    const-string v9, "EmSm0LN-"

    const-string v9, "00-mENLS"

    const/4 v11, 0x7

    const-string v9, "0S0Eo-LA"

    const-string v9, "ELS-AN00"

    const/4 v11, 0x1

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x4

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x2

    invoke-direct {v4, v5, v6, v8, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x6

    const-string v6, "T0oS-b0L"

    const-string v6, "LT-0o0SE"

    const/4 v11, 0x1

    const-string v6, "S-0LN0uT"

    const-string v6, "ELS-TN00"

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v3, v6, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x5

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x5

    const v6, 0x10c986

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-direct {v4, v5, v6, v8, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x7

    const/4 v10, 0x4

    const-string v6, "1LN-SEAp"

    const-string v6, "ES1-LbNA"

    const/4 v11, 0x1

    const-string/jumbo v6, "qANES0L1"

    const-string v6, "ELS-AN10"

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {v3, v6, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x3

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x2

    const v6, 0x10c976

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-direct {v4, v5, v6, v8, v1}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x4

    const-string v9, "M-suL9RX"

    const-string v9, "XR09-MuL"

    const/4 v11, 0x0

    const-string v9, "A-XmRM0L"

    const-string v9, "MRX-AL09"

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x4

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-direct {v4, v5, v6, v8, v1}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x0

    const-string v9, "9A1R-MXp"

    const/4 v11, 0x5

    const-string v9, "-19MoRLX"

    const-string v9, "MRX-AL19"

    const/4 v11, 0x7

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x6

    shr-int/2addr v11, v10

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v10, 0x4

    const/4 v11, 0x1

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-direct {v4, v5, v6, v8, v1}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    const-string/jumbo v9, "q9XW-bR"

    const-string v9, "Rq9W-X0"

    const/4 v11, 0x3

    const-string v9, "MR-9X0u"

    const-string v9, "MRX-W09"

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x6

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x4

    invoke-direct {v4, v5, v6, v8, v1}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    const-string/jumbo v9, "pW1MR9X"

    const-string v9, "MRX-W19"

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x2

    invoke-direct {v4, v5, v6, v8, v1}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x2

    const-string/jumbo v9, "qAsMXN9R"

    const-string v9, "MRsNA-X9"

    const-string v9, "A9s-RN1X"

    const-string v9, "MRX-AN19"

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x5

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x4

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-direct {v4, v5, v6, v8, v1}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x0

    const-string v9, "MXWm2-m"

    const-string v9, "M92mW-X"

    const/4 v11, 0x0

    const-string v9, "MRX-W29"

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x2

    sget-object v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x4

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-direct {v4, v5, v6, v8, v1}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x2

    const-string v1, "-3RWoMX"

    const-string v1, "MRX-W39"

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v3, v1, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x4

    and-int/2addr v11, v10

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x1

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x0

    const-string/jumbo v4, "o-C0EbNA"

    const-string v4, "O0NAo-EC"

    const/4 v11, 0x6

    const-string v4, "ECN-AOu0"

    const-string v4, "OCE-AN00"

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x6

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x6

    const/4 v10, 0x1

    const-string v4, "0AOCb-1p"

    const-string v4, "CO-0AbN1"

    const-string/jumbo v4, "qNOC-0EA"

    const-string v4, "OCE-AN10"

    const/4 v11, 0x4

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x3

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x0

    const-string v4, "L0s5ECuO"

    const-string v4, "-ECLO0u5"

    const/4 v11, 0x7

    const-string v4, "OCE-AL50"

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v10, 0x6

    or-int/2addr v11, v10

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x4

    const-string/jumbo v4, "pO0mAN5C"

    const-string v4, "5NC-OA0p"

    const-string v4, "50N-oOEC"

    const-string v4, "OCE-AN50"

    const/4 v11, 0x0

    const/4 v10, 0x2

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x5

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x0

    const/4 v10, 0x2

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    const-string v4, "9X-HObq"

    const-string v4, "9qXON-H"

    const/4 v11, 0x4

    const-string v4, "NH9X-Ou"

    const-string v4, "NOH-NX9"

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v10, 0x1

    move v11, v10

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x2

    const-string v4, "0ONsH-Ap"

    const-string v4, "OAsHN-N0"

    const/4 v11, 0x2

    const-string/jumbo v4, "qH-NO0NA"

    const-string v4, "NOH-AN00"

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x7

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    const-string v4, "NHsA1-mN"

    const-string v4, "-N1mAHNO"

    const/4 v11, 0x2

    const-string v4, "-10mONHA"

    const-string v4, "NOH-AN01"

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x1

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v10, 0x5

    or-int/2addr v11, v10

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const-string/jumbo v4, "oALHo0O0"

    const-string v4, "NHALo0O0"

    const/4 v11, 0x7

    const-string v4, "HOLA0bN0"

    const-string v4, "NOH-AL00"

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x7

    const-string v4, "ANb0-OuN"

    const-string v4, "NA0ONb-0"

    const/4 v11, 0x4

    const-string v4, "PO0-N0Np"

    const-string v4, "NOP-AN00"

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x3

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-string/jumbo v4, "q0D-JNA0"

    const-string v4, "JAD-AN00"

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x4

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x7

    const-string v4, "JAs-uN0D"

    const-string v4, "D0N-JAu1"

    const/4 v11, 0x4

    const-string v4, "ADJm0NA-"

    const-string v4, "JAD-AN10"

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x6

    move v11, v10

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v10, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x4

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x1

    const/4 v10, 0x0

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x7

    const-string/jumbo v4, "p-5Ao0LA"

    const-string v4, "L-AJA05p"

    const/4 v11, 0x0

    const-string v4, "AAJ0Lb5D"

    const-string v4, "JAD-AL50"

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x4

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    const-string/jumbo v4, "qAJA-DL6"

    const/4 v11, 0x3

    const-string v4, "-A6ADJuL"

    const-string v4, "JAD-AL60"

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x5

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x6

    const-string/jumbo v4, "p-ADNJ2"

    const-string v4, "J-sDA2N"

    const-string v4, "DqJ9-A2"

    const-string v4, "JAD-N29"

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x7

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x5

    const-string v4, "-Ns9Jm0"

    const-string v4, "90Dm-JN"

    const/4 v11, 0x2

    const-string v4, "D-Am9J0"

    const-string v4, "JAD-N09"

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x2

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x7

    const v4, 0x30dfb

    const/4 v10, 0x6

    move v11, v10

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x4

    const-string v6, "E-5GoHo5"

    const-string v6, "50HGo-E5"

    const/4 v11, 0x0

    const-string v6, "55-E0bEH"

    const-string v6, "HEGE-550"

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x3

    const/4 v10, 0x7

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v10, 0x4

    move v11, v10

    const-string v6, "-5HbG5u0E"

    const-string v6, "5-EGHbE05"

    const-string v6, "HEGE-550B"

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x4

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    const-string v6, "-CGE5H5p0"

    const-string v6, "HEGE-550C"

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x2

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x3

    const-string v6, "E550XGEuq"

    const-string v6, "XE0GE-u55"

    const-string v6, "HEGE-550X"

    const/4 v10, 0x3

    shr-int/2addr v11, v10

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x4

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x0

    const-string v6, "AXspE-EH50"

    const-string v6, "XGEHEA-p50"

    const-string v6, "0HAmEE5X5G"

    const-string v6, "HEGE-550AX"

    const/4 v11, 0x1

    const/4 v10, 0x1

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x6

    const-string v6, "HE-qo06E"

    const-string/jumbo v6, "q6-EEHG0"

    const-string v6, "E65EGbH0"

    const-string v6, "HEGE-560"

    const/4 v11, 0x7

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x6

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x0

    const-string v6, "05EE6BuH-"

    const-string v6, "HEGE-560B"

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x6

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    const-string v4, "E5-GHEsp"

    const-string v4, "HGsEE75-"

    const/4 v11, 0x0

    const-string/jumbo v4, "q-EE05GH"

    const-string v4, "HEGE-570"

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x1

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v10, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x3

    const v4, 0x30dec

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    const-string v4, "-7sPLT0m"

    const-string v4, "60Lm7P-T"

    const/4 v11, 0x3

    const-string v4, "PL-mAT76"

    const-string v4, "PLAT-760"

    const/4 v10, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x1

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x5

    const v4, 0x30df9

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x7

    const-string v6, "3-5To0NK"

    const/4 v11, 0x6

    const-string v6, "0-3AoTKN"

    const-string v6, "KANT-350"

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v10, 0x4

    move v11, v10

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x4

    const/4 v10, 0x3

    const-string v6, "NTK35bBA0"

    const/4 v11, 0x7

    const-string v6, "BNKA5b0T-"

    const-string v6, "KANT-350B"

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x3

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x1

    const-string v6, "TNK5C3uuA"

    const-string v6, "3ATN5-uKC"

    const/4 v11, 0x7

    const-string v6, "5CA30NKpT"

    const-string v6, "KANT-350C"

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-string v6, "3pT05-AKq"

    const-string v6, "03KA5STp-"

    const-string v6, "5Ss0NA3K-"

    const-string v6, "KANT-350S"

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x7

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x1

    const-string v6, "Tq-m30AK"

    const-string/jumbo v6, "qA6KT-30"

    const/4 v11, 0x4

    const-string v6, "K6ANoT-0"

    const-string v6, "KANT-360"

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x1

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v10, 0x4

    const/4 v11, 0x7

    const-string v6, "N03-6bSsT"

    const-string v6, "3KsT0S-6N"

    const/4 v11, 0x3

    const-string v6, "3SKA-NuT6"

    const-string v6, "KANT-360S"

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x0

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x4

    const-string v6, "T3-7KmAp"

    const-string v6, "7K-m30AT"

    const/4 v11, 0x5

    const-string/jumbo v6, "q-TAK037"

    const-string v6, "KANT-370"

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x7

    const-string v4, "N-s0AoKS7"

    const-string v4, "SK0-o7N3A"

    const/4 v11, 0x4

    const-string v4, "0TSmK3-AN"

    const-string v4, "KANT-370S"

    const/4 v11, 0x3

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v10, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x0

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x7

    const v4, 0x30df7

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x1

    const-string v6, "53-KoAT9"

    const-string v6, "KANT-359"

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x0

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v10, 0x6

    move v11, v10

    const-string v4, "6TAN9bKb"

    const-string v4, "K9T63bAN"

    const-string v4, "N9TA6-uK"

    const-string v4, "KANT-369"

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v11, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x3

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x0

    const-string v4, "Tu5H0-5p"

    const-string v4, "TH5A05u-"

    const/4 v11, 0x2

    const-string v4, "THAL-550"

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v10, 0x5

    and-int/2addr v11, v10

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x7

    const/4 v10, 0x5

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x4

    const-string/jumbo v4, "qpL65-TA"

    const-string v4, "L56T0-Ap"

    const/4 v11, 0x7

    const-string v4, "0LsT6HA5"

    const-string v4, "THAL-560"

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x2

    const-string v4, "-THmA75q"

    const-string/jumbo v4, "qLH75T-A"

    const/4 v11, 0x5

    const-string v4, "AHT-oL05"

    const-string v4, "THAL-570"

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x4

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v10, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    const-string v4, "AH5Lsb-8"

    const-string v4, "80sH-A5L"

    const/4 v11, 0x4

    const-string v4, "T-LA5Hu0"

    const-string v4, "THAL-580"

    const/4 v10, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v10, 0x1

    and-int/2addr v11, v10

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-string v4, "RF-0GEmp"

    const-string v4, "0FEmG7R-"

    const/4 v11, 0x5

    const-string/jumbo v4, "q7-07EGR"

    const-string v4, "FREG-770"

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x1

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x0

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x7

    const-string v4, "-0sD2E2C"

    const-string v4, "CE2Do20-"

    const-string v4, "SC-mDE02"

    const-string v4, "DESC-220"

    const/4 v11, 0x2

    const/4 v10, 0x6

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x7

    or-int/2addr v11, v10

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x0

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const v4, 0x9ba5ed

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x2

    const/4 v10, 0x1

    const-string v6, "0C5DoY2bE-"

    const-string v6, "-YE20b5DSC"

    const/4 v11, 0x5

    const-string v6, "20CE-bSY5S"

    const-string v6, "DESC-250SY"

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x2

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v10, 0x0

    move v11, v10

    const-string v6, "S5DSu2u-E"

    const-string v6, "2SS-5Du0E"

    const/4 v11, 0x6

    const-string v6, "S05DSE2p-"

    const-string v6, "DESC-250S"

    const/4 v11, 0x4

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x3

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x0

    const-string v6, "DC-ZSE2pq5"

    const-string v6, "25-S0DZpEC"

    const/4 v11, 0x6

    const-string v6, "E0sZ5-D2CS"

    const-string v6, "DESC-250SZ"

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x5

    const/4 v10, 0x7

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x4

    const-string v6, "SC2mDq-0"

    const-string/jumbo v6, "q0DS5C2-"

    const/4 v11, 0x4

    const-string v6, "2CEDoS0-"

    const-string v6, "DESC-250"

    const/4 v11, 0x5

    const/4 v10, 0x7

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x4

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    const-string v6, "-S0CEbsDSY"

    const-string v6, "-2sSEC0SDY"

    const/4 v11, 0x5

    const-string v6, "DESC-260SY"

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x3

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x6

    const-string v6, "CDSE2mu60"

    const-string v6, "SE0mDCS62"

    const/4 v11, 0x3

    const-string v6, "2E0SCD-pS"

    const-string v6, "DESC-260S"

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x5

    const-string v6, "-S2oED6CqS"

    const-string v6, "0S-Do26SCE"

    const/4 v11, 0x1

    const-string v6, "20s6-CZDSE"

    const-string v6, "DESC-260SZ"

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {v1, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x1

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    const-string v4, "DS6mC2b-"

    const-string v4, "D6S-Cb02"

    const/4 v11, 0x2

    const-string v4, "6S0-o2ED"

    const-string v4, "DESC-260"

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x7

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    const v4, 0x9ba5e3

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-direct {v3, v5, v4, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x1

    const-string v4, "2S-C0b7u"

    const-string v4, "02CS-Du7"

    const/4 v11, 0x2

    const-string v4, "D0EC7Su2"

    const-string v4, "DESC-270"

    const/4 v10, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v10, 0x4

    or-int/2addr v11, v10

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v10, 0x4

    or-int/2addr v11, v10

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x2

    const-string v4, "9-R0K7SpA"

    const-string v4, "SOKR-790A"

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v11, 0x5

    const/4 v10, 0x3

    invoke-direct {v3, v5, v0, v8, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;-><init>(IIII)V

    const/4 v10, 0x0

    shr-int/2addr v11, v10

    const-string v4, "V05Op-STq"

    const-string v4, "-0TOV35pS"

    const/4 v11, 0x4

    const-string v4, "TLsVSO3-0"

    const-string v4, "VOLT-350S"

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mWideVineBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const-string/jumbo v3, "q-VmL0RL"

    const-string/jumbo v3, "qRL-VLA0"

    const/4 v11, 0x5

    const-string v3, "0RL-oAV9"

    const-string v3, "RVL-AL09"

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mWideVineBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x6

    const-string v3, "LT92-bL"

    const-string v3, "2LsL9-T"

    const/4 v11, 0x3

    const-string v3, "TLC-92u"

    const-string v3, "CLT-L29"

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mWideVineBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x0

    const-string v3, "_UZASAmpS0"

    const-string v3, "0AAmD_ZSSU"

    const/4 v11, 0x6

    const-string v3, "0US0ZAS_qA"

    const-string v3, "ASUS_Z00AD"

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mWideVineBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDrmL1BlackList:Ljava/util/HashMap;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x3

    sget-object v4, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mWideVineBlackListModel:Ljava/util/ArrayList;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVideoCodecIdToSwCapabilityModel:Landroid/util/SparseArray;

    const/4 v10, 0x4

    move v11, v10

    new-instance v3, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;

    const/4 v11, 0x5

    const/4 v10, 0x1

    invoke-direct {v3}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;-><init>()V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x7

    sget-object v4, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;->DEFINITION_720P:Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;

    const/4 v11, 0x0

    const-string v5, "05sM2S"

    const-string v5, "SM8250"

    const/4 v11, 0x6

    const/4 v10, 0x6

    invoke-virtual {v3, v0, v4, v5}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;->addVideoDecCap(ILcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;Ljava/lang/String;)Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;

    move-result-object v3

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x7

    const/4 v5, 0x1

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x7

    const-string v6, "83MmTo"

    const-string v6, "T8M9o3"

    const/4 v11, 0x0

    const-string v6, "3689oM"

    const-string v6, "MT6893"

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {v3, v5, v4, v6}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;->addVideoDecCap(ILcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;Ljava/lang/String;)Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;

    move-result-object v3

    const/4 v11, 0x5

    const/4 v10, 0x3

    const-string v5, "000b9biErK"

    const-string v5, "900E0binrK"

    const/4 v11, 0x2

    const-string v5, "00inKrui0E"

    const-string v5, "Kirin9000E"

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v3, v7, v4, v5}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;->addVideoDecCap(ILcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;Ljava/lang/String;)Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;

    move-result-object v3

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    const-string v5, "0yxs1n0puo"

    const-string/jumbo v5, "ys20nxuo10"

    const/4 v11, 0x3

    const-string v5, "E21sn0x0qy"

    const-string v5, "Exynos2100"

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {v3, v2, v4, v5}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;->addVideoDecCap(ILcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;Ljava/lang/String;)Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;

    move-result-object v2

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {v2}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel$Builder;->build()Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel;

    move-result-object v2

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    const/16 v3, 0xc1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {v1, v3, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDefinitionNameToDecodeLevelTable:Ljava/util/HashMap;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    const/16 v2, 0x15

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v1, v4, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    sput-boolean v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mIsFFmpegCapGot:Z

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x2

    new-instance v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/16 v2, 0x1e

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-direct {v1, v0, v0, v0, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;-><init>(IIII)V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    sput-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAVCSWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x1

    new-instance v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-direct {v1, v0, v0, v0, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;-><init>(IIII)V

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x6

    sput-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHEVCSWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x3

    new-instance v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v11, 0x6

    const/4 v10, 0x1

    invoke-direct {v1, v0, v0, v0, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;-><init>(IIII)V

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x7

    sput-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVP9SWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x7

    new-instance v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v11, 0x2

    const/4 v10, 0x2

    invoke-direct {v1, v0, v0, v0, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;-><init>(IIII)V

    const/4 v11, 0x3

    const/4 v10, 0x4

    sput-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAVS3WMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x7

    new-instance v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v11, 0x5

    invoke-direct {v1, v0, v0, v0, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;-><init>(IIII)V

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    sput-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAV1SWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    new-instance v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v10, 0x7

    and-int/2addr v11, v10

    invoke-direct {v1, v0, v0, v0, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;-><init>(IIII)V

    const/4 v11, 0x0

    const/4 v10, 0x5

    sput-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVP8SWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v11, 0x7

    new-instance v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-direct {v1, v0, v0, v0, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;-><init>(IIII)V

    const/4 v11, 0x5

    const/4 v10, 0x7

    sput-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVVCSWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    new-instance v0, Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x7

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecHwCapabilityMap:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    new-instance v0, Ljava/util/HashMap;

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x5

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecSwCapabilityMap:Ljava/util/HashMap;

    const/4 v11, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x4

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecHwCapabilityMap:Ljava/util/HashMap;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x0

    sput-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecSwCapabilityMap:Ljava/util/HashMap;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic access$102(Z)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s y@ s~@ /to@ooaf@ ~i-@~o@~~. @ ~ 1@~4o~~~v@@~ r@~bn @l@if~ b~@ ou~@/ti ~~@~~~ @d@b KM@ l cm S"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    sput-boolean p0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mIsInitDone:Z

    const/4 v1, 0x3

    return p0
.end method

.method public static addDRMLevel1Blacklist(I)Z
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDrmL1BlackList:Ljava/util/HashMap;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDrmL1BlackList:Ljava/util/HashMap;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    check-cast v0, Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-nez v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDrmL1BlackList:Ljava/util/HashMap;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDrmL1BlackList:Ljava/util/HashMap;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1, p0, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 p0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    return p0
.end method

.method public static addHDRBlackList(ILjava/lang/String;Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;)Z
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-nez p2, :cond_0

    const/4 v4, 0x0

    const/4 p0, 0x1

    const/4 v4, 0x2

    const/4 p0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    return p0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdrBlackMap:Ljava/util/HashMap;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdrBlackMap:Ljava/util/HashMap;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    check-cast v0, Ljava/util/HashMap;

    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdrBlackMap:Ljava/util/HashMap;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-nez v1, :cond_1

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto :goto_0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    sget-object p1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdrBlackMap:Ljava/util/HashMap;

    const/4 v4, 0x1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1, p0, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 p0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    return p0
.end method

.method private static addHDRVersionRangeToWhiteList(ILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;Ljava/util/HashMap;)V
    .locals 5
    .param p1    # Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/HashMap;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;",
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Ljava/util/ArrayList<",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;",
            ">;>;)V"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    invoke-virtual {p2, v0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p2, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    check-cast v0, Ljava/util/ArrayList;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v1, 0x0

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-ge v1, v2, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    check-cast v2, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p1, v2}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isTheSameVersionRange(Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;)Z

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_1

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p2, p0, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void
.end method

.method public static addHDRVideoDecoderTypeWhiteList(IILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;)Z
    .locals 3
    .param p2    # Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/16 v0, 0x65

    const/4 v2, 0x1

    if-eq p1, v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/16 v0, 0x66

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eq p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const-string/jumbo p0, "scPmUpeloCdT"

    const-string/jumbo p0, "ldiPUcCpTose"

    const/4 v2, 0x4

    const-string p0, "TildoctUosPe"

    const-string p0, "TPCodecUtils"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string/jumbo p1, "isunhb opiHttedce yepit.Ltdo cDdreeDdVpRderrsWe,doTqo"

    const-string p1, "WRyttnd qDohdeV.po,e eetedsDpdHcsiopo LdirucrieroTted"

    const/4 v2, 0x7

    const-string p1, "D  HRcuoWyd.VudirDooadee ceertripLohdpedpsetesTnotid,"

    const-string p1, "addHDRVideoDecoderTypeWhiteList, decoder not support."

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p2, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p2, p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_1

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object p1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRTypeToHDRHardwareCodecWhiteListMap:Ljava/util/HashMap;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    goto :goto_0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    sget-object p1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRTypeToHDRSoftwareCodecWhiteListMap:Ljava/util/HashMap;

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p0, p2, p1}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->addHDRVersionRangeToWhiteList(ILcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;Ljava/util/HashMap;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 p0, 0x1

    :goto_1
    const/4 v1, 0x1

    const/4 v2, 0x2

    return p0
.end method

.method public static addHDRWhiteList(ILjava/lang/String;Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;)Z
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez p2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 p0, 0x3

    const/4 p0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    return p0

    :cond_0
    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdrWhiteMap:Ljava/util/HashMap;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdrWhiteMap:Ljava/util/HashMap;

    const/4 v4, 0x7

    const/4 v3, 0x5

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast v0, Ljava/util/HashMap;

    const/4 v4, 0x6

    const/4 v3, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdrWhiteMap:Ljava/util/HashMap;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x4

    move v4, v3

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :cond_2
    const/4 v4, 0x7

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object p1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdrWhiteMap:Ljava/util/HashMap;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1, p0, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    move v4, v3

    const/4 p0, 0x1

    move v4, p0

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    return p0
.end method

.method public static checkHDRVividSupportByVersion(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 13

    const-string v0, "."

    const-string v0, "."

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    filled-new-array {v1, v2, v2, v3}, [I

    move-result-object v4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    const-string v6, "UiceTlopPCss"

    const-string v6, "descoTPsCilU"

    const-string v6, "TPCodecUtils"

    const/4 v7, -0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    if-nez v5, :cond_9

    const-string v5, "/./"

    const-string v5, ".//"

    const-string v5, "//."

    const-string v5, "\\."

    invoke-virtual {p1, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    array-length v10, v5

    if-ne v10, v8, :cond_9

    aget-object v10, v5, v9

    const-string v11, " "

    const-string v11, " "

    invoke-virtual {v10, v11}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v10

    array-length v11, v10

    if-ne v11, v1, :cond_0

    aget-object v10, v10, v2

    if-eqz v10, :cond_0

    aput-object v10, v5, v9

    :cond_0
    aget-object v10, v5, v3

    const-string v11, "(//"

    const-string v11, "\\("

    invoke-virtual {v10, v11}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v10

    array-length v11, v10

    if-ne v11, v1, :cond_1

    aget-object v10, v10, v9

    if-eqz v10, :cond_1

    aput-object v10, v5, v3

    :cond_1
    move v10, v9

    move v10, v9

    :goto_0
    if-ge v10, v8, :cond_4

    aget-object v11, v5, v10

    if-eqz v11, :cond_3

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v11

    aget v12, v4, v10

    if-eq v11, v12, :cond_2

    goto :goto_1

    :cond_2
    add-int/lit8 v10, v10, 0x1

    goto :goto_0

    :cond_3
    :goto_1
    move v4, v9

    move v4, v9

    move v4, v9

    move v4, v9

    goto :goto_2

    :cond_4
    move v4, v2

    move v4, v2

    move v4, v2

    move v4, v2

    :goto_2
    if-eqz v4, :cond_9

    :try_start_0
    invoke-virtual {p1, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v4

    if-ne v4, v7, :cond_5

    move v5, v9

    move v5, v9

    move v5, v9

    move v5, v9

    goto :goto_3

    :cond_5
    add-int/lit8 v5, v4, -0x2

    invoke-static {p1, v5, v4}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getValueFromSubstring(Ljava/lang/String;II)I

    move-result v5
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_3

    :goto_3
    add-int/2addr v4, v2

    :try_start_1
    invoke-virtual {p1, v0, v4}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v4

    if-ne v4, v7, :cond_6

    move v10, v9

    move v10, v9

    move v10, v9

    move v10, v9

    goto :goto_4

    :cond_6
    add-int/lit8 v10, v4, -0x1

    invoke-static {p1, v10, v4}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getValueFromSubstring(Ljava/lang/String;II)I

    move-result v10
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_2

    :goto_4
    add-int/2addr v4, v2

    :try_start_2
    invoke-virtual {p1, v0, v4}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v0

    if-ne v0, v7, :cond_7

    move v4, v9

    move v4, v9

    goto :goto_5

    :cond_7
    add-int/lit8 v4, v0, -0x1

    invoke-static {p1, v4, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getValueFromSubstring(Ljava/lang/String;II)I

    move-result v4
    :try_end_2
    .catch Ljava/lang/NumberFormatException; {:try_start_2 .. :try_end_2} :catch_1

    :goto_5
    if-ne v0, v7, :cond_8

    goto :goto_7

    :cond_8
    add-int/lit8 v11, v0, 0x1

    add-int/2addr v0, v8

    :try_start_3
    invoke-static {p1, v11, v0}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getValueFromSubstring(Ljava/lang/String;II)I

    move-result p1
    :try_end_3
    .catch Ljava/lang/NumberFormatException; {:try_start_3 .. :try_end_3} :catch_0

    goto :goto_8

    :catch_0
    move-exception p1

    goto :goto_6

    :catch_1
    move-exception p1

    move v4, v9

    move v4, v9

    move v4, v9

    move v4, v9

    goto :goto_6

    :catch_2
    move-exception p1

    move v4, v9

    move v4, v9

    move v4, v9

    move v4, v9

    move v10, v4

    move v10, v4

    move v10, v4

    goto :goto_6

    :catch_3
    move-exception p1

    move v4, v9

    move v4, v9

    move v5, v4

    move v5, v4

    move v5, v4

    move v10, v5

    move v10, v5

    move v10, v5

    move v10, v5

    :goto_6
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v11, "dopvesVoqeveetcmauice:i)hrriBl (dauVnriVplSkfDnoHys"

    const-string/jumbo v11, "v:rmoheisucVVHoSciekVuiyrpDrRBe(f)iddllseaevtnnpa o"

    const-string/jumbo v11, "i stBnu)lurslDiV:vriedoefsVSyo(okavRppceVHridainehe"

    const-string v11, "checkHDRVividSupportByVersion failed(versionValue):"

    invoke-direct {v0, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v8, v6, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    :goto_7
    move p1, v9

    move p1, v9

    move p1, v9

    :goto_8
    const v0, 0x186a0

    mul-int/2addr v5, v0

    mul-int/lit16 v10, v10, 0x2710

    add-int/2addr v5, v10

    mul-int/lit16 v4, v4, 0x3e8

    add-int/2addr v5, v4

    add-int/2addr v5, p1

    goto :goto_9

    :cond_9
    move v5, v9

    move v5, v9

    move v5, v9

    move v5, v9

    :goto_9
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_b

    const-string/jumbo p1, "tocmh"

    const-string p1, "ahcto"

    const-string p1, "actpo"

    const-string/jumbo p1, "patch"

    invoke-virtual {p2, p1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    array-length v4, v0

    if-ne v4, v1, :cond_b

    aget-object v0, v0, v2

    if-eqz v0, :cond_b

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-ne v0, v3, :cond_b

    :try_start_4
    invoke-virtual {p2, p1}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result p1

    if-ne p1, v7, :cond_a

    goto :goto_a

    :cond_a
    add-int/lit8 v0, p1, 0x5

    add-int/lit8 p1, p1, 0x7

    invoke-static {p2, v0, p1}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getValueFromSubstring(Ljava/lang/String;II)I

    move-result p1
    :try_end_4
    .catch Ljava/lang/NumberFormatException; {:try_start_4 .. :try_end_4} :catch_4

    goto :goto_b

    :catch_4
    move-exception p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v3, "vcreDbSt):yet(VnoBipHdVkouiuRahrpeibcaaechdfVlsip"

    const-string/jumbo v3, "rtu:(bSDiidtBhcpdhVHfelayoeVpVaiR)vsrepuccnleikoa"

    const-string v3, "e(u)uius:ededR lpilofahtycaVaciBehpHpSiktrDcoVnvr"

    const-string v3, "checkHDRVividSupportByVersion failed(patchValue):"

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v8, v6, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    :cond_b
    :goto_a
    move p1, v9

    move p1, v9

    move p1, v9

    move p1, v9

    :goto_b
    invoke-static {p0, v5, p1}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isInHDRVividWhiteList(Ljava/lang/String;II)Z

    move-result v0

    const-string/jumbo v3, "p: ahtc"

    const-string/jumbo v3, "tc: hau"

    const-string v3, " qpta:h"

    const-string v3, " patch:"

    const-string/jumbo v4, "iespr s:v"

    const-string v4, "e ivor:ps"

    const-string v4, " version:"

    if-eqz v0, :cond_c

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "DnVHdsoiqpH or:toiwke livnRerdhitSdipvuVyit ,BsimDlchVi eRe"

    const-string/jumbo v0, "oremulkDSptsRVi Dih dHvv ,liih mnHeptd:weicoRsVdneiVrBiocty"

    const-string v0, "checkHDRVividSupportByVersion in HDRVivid whitelist, model:"

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, v6, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    return v2

    :cond_c
    invoke-static {p0, v5, p1}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isInHDRVividBlackList(Ljava/lang/String;II)Z

    move-result v0

    if-eqz v0, :cond_d

    new-instance p1, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "iekroDcciislloDHd  vhsnivtumcbdpdtiS ia rseloVyi,VBRnVpo:Rk"

    const-string/jumbo v0, "hcsoid  Vs:DosncrtimeV Rlekop,lRcVap kHilydvriidnitSiubvDBe"

    const-string/jumbo v0, "nctsRbiH r isiS dcoDkVeovrpR,aDlbmVeliHdicei opkiyVluthndvB"

    const-string v0, "checkHDRVividSupportByVersion in HDRVivid blacklist, model:"

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, v6, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    return v9

    :cond_d
    sget-object p2, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    invoke-virtual {p2, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_f

    sget-object p2, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRVividSupportVersionMap:Ljava/util/HashMap;

    invoke-virtual {p2, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    iget p2, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->upperboundSystemVersion:I

    if-gt v5, p2, :cond_f

    iget p2, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->lowerboundSystemVersion:I

    if-le v5, p2, :cond_e

    return v2

    :cond_e
    if-ne v5, p2, :cond_f

    iget p2, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->upperboundPatchVersion:I

    if-gt p1, p2, :cond_f

    iget p0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->lowerboundPatchVersion:I

    if-lt p1, p0, :cond_f

    return v2

    :cond_f
    return v9
.end method

.method private static convertDefinitionNameToDecodeLevel(Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;)I
    .locals 3
    .param p0    # Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDefinitionNameToDecodeLevelTable:Ljava/util/HashMap;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    check-cast p0, Ljava/lang/Integer;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x3

    return p0

    :cond_0
    const/4 v2, 0x7

    const/4 p0, -0x1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return p0
.end method

.method public static convertDolbyVisionToOmxLevel(I)I
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 v0, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    shl-int/2addr v0, p0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const-string/jumbo v1, "scPmdtTeCUil"

    const/4 v6, 0x2

    const-string/jumbo v1, "sedCoTucltiU"

    const-string v1, "TPCodecUtils"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v2, 0x2

    const/4 v5, 0x4

    move v6, v5

    if-lez v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/16 v3, 0x100

    const/4 v6, 0x0

    if-gt v0, v3, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const-string/jumbo v4, "mob:orepiyLo lvoeosiielVbnnnetxOTiyVocsLDvdevo"

    const-string v4, "OroToenlvoVoxylLncosdiVoiilv:DbvemetoLynbse ie"

    const/4 v6, 0x6

    const-string/jumbo v4, "nio rvoLqetsbmciyooOvVxloeTlod:eslLnnVbieiyDvl"

    const-string v4, "convertDolbyVisionToOmxLevel dolbyVisionLevel:"

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string p0, "besLvo :xe"

    const-string p0, ":xoeebLvm "

    const/4 v6, 0x6

    const-string p0, " :mmexLovl"

    const-string p0, " omxLevel:"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v2, v1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    return v0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string/jumbo v0, "tnpnVTusplvrmcuoeU OeieDtsvoxLnlleyobdiloovree"

    const/4 v6, 0x1

    const-string v0, "convertDolbyVisionToOmxLevel Unsupported level"

    const/4 v6, 0x2

    const/4 v5, 0x2

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v2, v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    return p0
.end method

.method public static convertDolbyVisionToOmxProfile(I)I
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v0, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    shl-int/2addr v0, p0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string v1, "cdTUoieCPtsp"

    const-string v1, "TCesUdPpcito"

    const/4 v6, 0x3

    const-string/jumbo v1, "ilsPTbCtcoUd"

    const-string v1, "TPCodecUtils"

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v2, 0x2

    const/4 v5, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-lez p0, :cond_0

    const/4 v6, 0x0

    const/16 v3, 0x200

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-gt p0, v3, :cond_0

    const/4 v6, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string/jumbo v4, "rfeooTuboqllPVon ooVibOeminoc:slofeyirDyiridlisPvx"

    const-string v4, "Vy:ovPleqnonioifmliois cfVoreTdnbboiDoPlOyrsorielx"

    const/4 v6, 0x2

    const-string/jumbo v4, "oiblcinpeilsdooioroDlTeli ni:VPonbPtyxovfseOyormVr"

    const-string v4, "convertDolbyVisionToOmxProfile dolbyVisionProfile:"

    const/4 v5, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string p0, " sxifoemqrlP"

    const-string p0, "Pfsl xmoi:er"

    const/4 v6, 0x3

    const-string p0, "e:simrlfxoP "

    const-string p0, " omxProfile:"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v2, v1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    return v0

    :cond_0
    const/4 v5, 0x2

    move v6, v5

    const-string v0, "UdpmxroenfsvDmPcisierlrrot eVouofn nyTopollOimpeit"

    const-string/jumbo v0, "lTomDmePriiidxnvrresooofyt pnnUtcpeopVir soelOoufl"

    const/4 v6, 0x3

    const-string/jumbo v0, "olerofiPfVyerotspOinoc oUporllTbnipotes xrdomDiunv"

    const-string v0, "convertDolbyVisionToOmxProfile Unsupported profile"

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v0, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v2, v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    return p0
.end method

.method public static declared-synchronized getACodecSWMaxCapabilityMap()Ljava/util/HashMap;
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;",
            ">;"
        }
    .end annotation

    const-class v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    monitor-enter v1

    :try_start_0
    const-string/jumbo v0, "otUoibsPTCed"

    const-string v0, "TUeiotdosClP"

    const-string v0, "cTtPdluCsUeo"

    const-string v0, "TPCodecUtils"

    const-string v2, " ibCaMipiyegccotpCuAanxflb MepStWnd"

    const-string/jumbo v2, "iMianbpCleSgCadWcniypoc beMatufA tx"

    const-string v2, "bAMfgancqdaSlxiCpiC  patcuMWaneoyet"

    const-string/jumbo v2, "getACodecSWMaxCapabilityMap func in"

    const/4 v3, 0x2

    invoke-static {v3, v0, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecSwCapabilityMap:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecSwCapabilityMap:Ljava/util/HashMap;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return-object v0

    :cond_0
    :try_start_1
    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v5, 0x0

    const/4 v6, 0x0

    sget v7, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAACMaxSupportedSamplerate:I

    sget v8, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAACMaxSupportedBitrate:I

    sget v9, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAACMaxSupportedChannels:I

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    invoke-direct/range {v4 .. v9}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;-><init>(IIIII)V

    new-instance v2, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v11, 0x0

    const/4 v12, 0x0

    sget v13, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mFLACMaxSupportedSamplerate:I

    sget v14, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mFLACMaxSupportedBitrate:I

    sget v15, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mFLACMaxSupportedChannels:I

    move-object v10, v2

    move-object v10, v2

    move-object v10, v2

    move-object v10, v2

    invoke-direct/range {v10 .. v15}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;-><init>(IIIII)V

    new-instance v10, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v5, 0x0

    const/4 v6, 0x0

    sget v7, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDDPMaxSupportedSamplerate:I

    sget v8, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDDPMaxSupportedBitrate:I

    sget v9, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDDPMaxSupportedChannels:I

    move-object v4, v10

    move-object v4, v10

    move-object v4, v10

    move-object v4, v10

    invoke-direct/range {v4 .. v9}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;-><init>(IIIII)V

    new-instance v4, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v12, 0x0

    const/4 v13, 0x0

    sget v14, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDDPMaxSupportedSamplerate:I

    sget v15, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDDPMaxSupportedBitrate:I

    sget v16, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDDPMaxSupportedChannels:I

    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    invoke-direct/range {v11 .. v16}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;-><init>(IIIII)V

    sget-object v5, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecSwCapabilityMap:Ljava/util/HashMap;

    const/16 v6, 0x138a

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v5, v6, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecSwCapabilityMap:Ljava/util/HashMap;

    const/16 v5, 0x1394

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v0, v5, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecSwCapabilityMap:Ljava/util/HashMap;

    const/16 v2, 0x138b

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecSwCapabilityMap:Ljava/util/HashMap;

    const/16 v2, 0x13b0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v0, "oWsasSatlMuaAMepaCisdtcsuxC .cyceiep"

    const-string v0, "aaAs CuoliuceMpscxStMCysdce.tpeaabWi"

    const-string v0, "CMMmedWbuciSaClAaxpgteo ipsets.cscya"

    const-string/jumbo v0, "getACodecSWMaxCapabilityMap success."

    invoke-static {v3, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecSwCapabilityMap:Ljava/util/HashMap;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit v1

    return-object v0

    :catch_0
    :try_start_2
    const-string v0, "ciUsooCtpedP"

    const-string v0, "PdcUilspoetC"

    const-string v0, "UetcibToPdsl"

    const-string v0, "TPCodecUtils"

    const-string/jumbo v2, "npgeSpuaMedaApqyctotMexaixiaWCtb lCic"

    const-string v2, "AiaCSaeaqgadxinecilobpexctyMMptet WCp"

    const-string/jumbo v2, "pocaMgCpieSe xaixcotMeppWbitatynCalde"

    const-string/jumbo v2, "getACodecSWMaxCapabilityMap exception"

    const/4 v3, 0x4

    invoke-static {v3, v0, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit v1

    const/4 v0, 0x0

    return-object v0

    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public static declared-synchronized getAMediaCodecMaxCapabilityMap()Ljava/util/HashMap;
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;",
            ">;"
        }
    .end annotation

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    monitor-enter v0

    :try_start_0
    const-string/jumbo v1, "lisoUPcsTteC"

    const-string v1, "dsePcotUqClT"

    const-string v1, "TPCodecUtils"

    const-string/jumbo v2, "ntsMndmxgocMaldtiCeiCe aAfu Mpiebyaicp"

    const-string/jumbo v2, "gMCmiintduiA ofadpaex nyeCbtcilMcpeaMa"

    const-string/jumbo v2, "iiamebfC MptluaegdiAaCdMapcayxMe tcnio"

    const-string/jumbo v2, "getAMediaCodecMaxCapabilityMap func in"

    const/4 v3, 0x2

    invoke-static {v3, v1, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecHwCapabilityMap:Ljava/util/HashMap;

    invoke-virtual {v1}, Ljava/util/HashMap;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    const-string/jumbo v1, "oTPtolsioCec"

    const-string v1, "csoCoPTeitUl"

    const-string v1, "dolscbtUPieC"

    const-string v1, "TPCodecUtils"

    const-string v2, "ep mdauitanmorao xm  euuy drecrtb mroa"

    const-string v2, "  ac b d yoemduip nrrermxmaoomattaeurp"

    const-string v2, " uttcaepa umydm r o medpi mrosnxaoraer"

    const-string/jumbo v2, "return memory stored audio max cap map"

    invoke-static {v3, v1, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecHwCapabilityMap:Ljava/util/HashMap;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-object v1

    :cond_0
    :try_start_1
    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mLocalCache:Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;

    invoke-static {v1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->getTPMediaDecoderInfos(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    move-result-object v1

    array-length v2, v1

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v2, :cond_4

    aget-object v5, v1, v4

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderMimeType()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isAudio()Z

    move-result v7

    if-eqz v7, :cond_3

    invoke-static {v6}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isSupportedMediaCodec(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_3

    invoke-static {v6}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isInMediaCodecBlackList(Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :cond_3

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderName()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isAMediaCodecBlackListInstance(Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :cond_3

    const-string/jumbo v7, "uoPtCUldqcei"

    const-string v7, "cPoUdeuClTti"

    const-string/jumbo v7, "iosCscUTdePt"

    const-string v7, "TPCodecUtils"

    new-instance v8, Ljava/lang/StringBuilder;

    const-string v9, "emduAiypTMeo  pi"

    const-string/jumbo v9, "yp m:oeuiAmiMd T"

    const-string v9, "Audio MimeType: "

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, "eNaooc  edc:"

    const-string v9, " codecName: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v3, v7, v8}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxProfileLevel()Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

    move-result-object v7

    new-instance v14, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    iget v9, v7, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->profile:I

    iget v10, v7, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->level:I

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxAudioSampleRate()I

    move-result v11

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxAudioBitRate()I

    move-result v12

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxAudioChannels()I

    move-result v13

    move-object v8, v14

    move-object v8, v14

    move-object v8, v14

    move-object v8, v14

    invoke-direct/range {v8 .. v13}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;-><init>(IIIII)V

    sget-object v7, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecHwCapabilityMap:Ljava/util/HashMap;

    invoke-static {v6}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getSupportedCodecId(Ljava/lang/String;)I

    move-result v8

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_2

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxAudioSampleRate()I

    move-result v7

    sget-object v8, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecHwCapabilityMap:Ljava/util/HashMap;

    invoke-static {v6}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getSupportedCodecId(Ljava/lang/String;)I

    move-result v9

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    iget v8, v8, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxSampleRate:I

    if-gt v7, v8, :cond_1

    const-string/jumbo v7, "juiocbqaoea/-d"

    const-string v7, "-jaodiu3q/acoe"

    const-string v7, "/a3jeouoc-idcu"

    const-string v7, "audio/eac3-joc"

    invoke-static {v6, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_3

    :cond_1
    const-string v7, "eUcdsiTptCos"

    const-string v7, "cTsedisCtPUo"

    const-string/jumbo v7, "ltCPsTedqoci"

    const-string v7, "TPCodecUtils"

    new-instance v8, Ljava/lang/StringBuilder;

    const-string v9, "a:smocead uNi edo"

    const-string v9, "cedmadNuie: m aoo"

    const-string/jumbo v9, "oc mameadiue dNoc"

    const-string v9, "audio codecName: "

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, ":a loaxpromeSmat"

    const-string/jumbo v9, "mtaxolS rp: amae"

    const-string/jumbo v9, "l:earbmtpSme xa "

    const-string v9, " maxSamplerate: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxAudioSampleRate()I

    move-result v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, "alhx sumna :nC"

    const-string/jumbo v9, "nhna baCx :sml"

    const-string v9, "  aaenCphsxm:n"

    const-string v9, " maxChannels: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxAudioChannels()I

    move-result v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v3, v7, v8}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    invoke-static {v6}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getSupportedCodecId(Ljava/lang/String;)I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    sget-object v8, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecHwCapabilityMap:Ljava/util/HashMap;

    invoke-static {v7, v14, v8}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->replace(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/HashMap;)V

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderName()Ljava/lang/String;

    move-result-object v5

    sget-object v7, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAudioMaxCapCodecInstance:Ljava/util/HashMap;

    invoke-static {v6, v5, v7}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->replace(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/HashMap;)V

    goto :goto_1

    :cond_2
    const-string v7, "dcPleTtuqsoC"

    const-string/jumbo v7, "sCUoTPudetlc"

    const-string/jumbo v7, "sesildTUcoCP"

    const-string v7, "TPCodecUtils"

    new-instance v8, Ljava/lang/StringBuilder;

    const-string/jumbo v9, "muamece:ooNca i p"

    const-string/jumbo v9, "uoide:Np mcc oaae"

    const-string/jumbo v9, "odc:ouomaa  cedNe"

    const-string v9, "audio codecName: "

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v9, "mtaSxb meerapa: "

    const-string v9, " maxSamplerate: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxAudioSampleRate()I

    move-result v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, "Csn enux lamq:"

    const-string v9, "Cxsh e aqmnnl:"

    const-string v9, " :mx eaphasnnC"

    const-string v9, " maxChannels: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxAudioChannels()I

    move-result v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v3, v7, v8}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    invoke-static {v6}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getSupportedCodecId(Ljava/lang/String;)I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    sget-object v8, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecHwCapabilityMap:Ljava/util/HashMap;

    invoke-static {v7, v14, v8}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->replace(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/HashMap;)V

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderName()Ljava/lang/String;

    move-result-object v5

    sget-object v7, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAudioMaxCapCodecInstance:Ljava/util/HashMap;

    invoke-static {v6, v5, v7}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->replace(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/HashMap;)V

    sget-object v5, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAMediaCodecCapList:Ljava/util/ArrayList;

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_3
    :goto_1
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_0

    :catch_0
    move-exception v1

    :try_start_2
    const-string v2, "dPcsUCelqsTt"

    const-string v2, "cdsTsePCUtol"

    const-string v2, "PesisCtdoclU"

    const-string v2, "TPCodecUtils"

    new-instance v3, Ljava/lang/StringBuilder;

    const-string/jumbo v4, "ladmemiCei:dyfatclbaaopepeCgdixa AMaiM"

    const-string/jumbo v4, "y:impapegildtdAdcaaCea alebaoMiMeMfCxi"

    const-string v4, "d:atofteClba gdiMiixayaAMelMeoipCaceap"

    const-string/jumbo v4, "getAMediaCodecMaxCapabilityMap failed:"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    invoke-static {v3, v2, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    :cond_4
    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxACodecHwCapabilityMap:Ljava/util/HashMap;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit v0

    return-object v1

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method public static getAV1SWDecodeLevel()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getDecodeLevelByCoresAndFreq()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public static getAudioMediaCodecPassThroughCap(III)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/16 v0, 0x138c

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eq p0, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 p0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    return p0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/16 p0, 0x14

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-ne p1, p0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 p0, 0x7

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    goto :goto_1

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/16 p0, 0x32

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eq p1, p0, :cond_3

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/16 p0, 0x3c

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-ne p1, p0, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    goto :goto_0

    :cond_2
    const/4 v2, 0x2

    const/4 p0, 0x1

    const/4 v2, 0x1

    move v1, p0

    move v1, p0

    const/4 v2, 0x2

    goto :goto_1

    :cond_3
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/16 p0, 0x8

    :goto_1
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p0, p2}, Lcom/tencent/thumbplayer/core/common/TPAudioPassThroughPluginDetector;->isAudioPassThroughSupport(II)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    return p0
.end method

.method public static getAvs3SWDecodeLevel()I
    .locals 8

    const/4 v7, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuHarewareName()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuHWProducter(Ljava/lang/String;)I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuHWProductIndex(Ljava/lang/String;)I

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const-string/jumbo v4, "rmeWeb o=,udevdoSgWtoCl[PLD]eHreccs uevA3t"

    const-string v4, "eoeWocurDe Hmu]=[LgWdvc3dPl etAsvro,SpeetC"

    const/4 v7, 0x5

    const-string/jumbo v4, "sPrcuguL ,ue[e=te vWdecSotWeHldo eDr3Cmvp]"

    const-string v4, "[getAvs3SWDecodeLevel], mCpuHWProducter = "

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const-string v4, " p,retCpueFb)a (x gq"

    const-string v4, "eaxu(begrC ,qMtp F) "

    const/4 v7, 0x2

    const-string/jumbo v4, "qtC (ug=qM e,arp Fe)"

    const-string v4, ", getMaxCpuFreq() = "

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getMaxCpuFreq()J

    move-result-wide v4

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string/jumbo v4, "ses, o =Crn m"

    const-string v4, ", numCores = "

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getNumCores()I

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string/jumbo v4, "uPCmt m=o,ruuHxpcWd"

    const-string v4, " dxtmou=HruP,CucWpd"

    const/4 v7, 0x3

    const-string v4, ",W= odpoIdurxHutcmC"

    const-string v4, ", mCpuHWProductIdx="

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x4

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const-string/jumbo v4, "h=rareap,wd"

    const/4 v7, 0x0

    const-string v4, "aha,=b edrr"

    const-string v4, ", hardware="

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/4 v3, 0x2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v4, "UesoTPuqCdtc"

    const-string v4, "deUTotlsqcCP"

    const/4 v7, 0x4

    const-string/jumbo v4, "olcPtispTedC"

    const-string v4, "TPCodecUtils"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v3, v4, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    sget v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAvs3DeviceLevel:I

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v4, -0x1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-eq v4, v0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    return v0

    :cond_0
    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v0, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    sput v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAvs3DeviceLevel:I

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-eq v4, v1, :cond_4

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/16 v0, 0x1a

    const/4 v7, 0x6

    const/4 v6, 0x5

    if-eqz v1, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    const/4 v4, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eq v1, v4, :cond_4

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eq v1, v3, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v0, 0x3

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eq v1, v0, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto :goto_2

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    sget v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mFhdAvs3HisiIndex:I

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-lt v2, v1, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    goto :goto_0

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    sget v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mFhdAvs3QualcommIndex:I

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-lt v2, v1, :cond_3

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    goto :goto_1

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    sget v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mShdAvs3QualcommIndex:I

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-lt v2, v0, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/16 v0, 0x15

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    goto :goto_1

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getDecodeLevelByCoresAndFreq()I

    move-result v0

    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    sput v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAvs3DeviceLevel:I

    :goto_2
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    sget v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAvs3DeviceLevel:I

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    return v0
.end method

.method private static getDecodeLevelByCoresAndFreq()I
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getNumCores()I

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/16 v1, 0x8

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    const/16 v2, 0x15

    const/16 v3, 0x10

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-lt v0, v1, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getMaxCpuFreq()J

    move-result-wide v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    div-long/2addr v0, v4

    const/4 v7, 0x3

    move v8, v7

    const-wide/16 v4, 0x4b0

    const-wide/16 v4, 0x4b0

    const/4 v8, 0x5

    const-wide/16 v4, 0x4b0

    const-wide/16 v4, 0x4b0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    cmp-long v0, v0, v4

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-ltz v0, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    goto :goto_0

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    move v2, v3

    move v2, v3

    const/4 v8, 0x7

    move v2, v3

    move v2, v3

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    goto :goto_0

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getNumCores()I

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/4 v1, 0x6

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-lt v0, v1, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getMaxCpuFreq()J

    move-result-wide v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    div-long/2addr v0, v4

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-wide/16 v4, 0x578

    const-wide/16 v4, 0x578

    const/4 v8, 0x0

    const-wide/16 v4, 0x578

    const-wide/16 v4, 0x578

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    cmp-long v0, v0, v4

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-ltz v0, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    goto :goto_0

    :cond_2
    const/4 v8, 0x5

    const/4 v7, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getNumCores()I

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/4 v6, 0x4

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-lt v0, v6, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getMaxCpuFreq()J

    move-result-wide v0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    div-long/2addr v0, v4

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-wide/16 v4, 0x640

    const-wide/16 v4, 0x640

    const/4 v8, 0x5

    const-wide/16 v4, 0x640

    const-wide/16 v4, 0x640

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    cmp-long v0, v0, v4

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    if-ltz v0, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    goto :goto_0

    :cond_3
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    move v2, v1

    move v2, v1

    const/4 v8, 0x3

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    return v2
.end method

.method public static declared-synchronized getDecoderMaxCapabilityMapAsync()V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const/4 v5, 0x1

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    sget-boolean v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mIsInitDone:Z

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v2, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string v1, "PtlUdCTcqieo"

    const-string v1, "TPCodecUtils"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string/jumbo v3, "ypsrie dry erceldtoita,rtsan!aidreni i aebtlccdy"

    const-string/jumbo v3, "rrsi!nctiatlrtteieocd aidayul dbard,epieycnr  ey"

    const/4 v5, 0x4

    const-string v3, "de,marodllinccniytcpa etir!i arteet bdrduilyray "

    const-string v3, "decoder capability already init,return directly!"

    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v2, v1, v3}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    monitor-exit v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-void

    :cond_0
    :try_start_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string v1, "TPlmCicteoUd"

    const-string/jumbo v1, "ioCToPedltUc"

    const-string v1, "TPCodecUtils"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string/jumbo v3, "ilcenb qeactoatecon dehynraait  db wcrre! thoeaidtt ,irpyiius"

    const-string/jumbo v3, "laeho tettertddeqity!ncydicatrih, rr  iiaa aase  pcioecuonnwb"

    const/4 v5, 0x2

    const-string/jumbo v3, "rthernu  i iar !daqbhuitic,naieawlsadoetictdcypc tarcyn eee t"

    const-string v3, "decoder capability not init,acquire async with create thread!"

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    invoke-static {v2, v1, v3}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    new-instance v1, Ljava/lang/Thread;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance v2, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$1;

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {v2}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$1;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-direct {v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string v2, "_cdeTetpcih_rboadPnt"

    const-string v2, "_at_ebcorPhiTectd_dn"

    const/4 v5, 0x7

    const-string/jumbo v2, "tecnddriq_T_ioathc_e"

    const-string v2, "TP_codec_init_thread"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    monitor-exit v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-void

    :catchall_0
    move-exception v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    monitor-exit v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    throw v1
.end method

.method public static getDecoderName(Ljava/lang/String;Z)Ljava/lang/String;
    .locals 11

    const/4 v10, 0x6

    const/4 v9, 0x3

    const-string/jumbo v0, "iudua"

    const/4 v10, 0x4

    const-string/jumbo v0, "ousia"

    const-string v0, "audio"

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-eqz v0, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    const-string p1, "ep3maa/diu"

    const-string/jumbo p1, "odu/3aapei"

    const/4 v10, 0x3

    const-string/jumbo p1, "uaceo3/dao"

    const-string p1, "audio/eac3"

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-static {p0, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-eqz p1, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    sget-object p1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAudioMaxCapCodecInstance:Ljava/util/HashMap;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x5

    const-string v0, "acad3bejqi-ou/"

    const-string/jumbo v0, "i3ca-d/oqujace"

    const-string v0, "a/icd3uuoo-ecj"

    const-string v0, "audio/eac3-joc"

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {p1, v0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eqz p1, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    sget-object p0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAudioMaxCapCodecInstance:Ljava/util/HashMap;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {p0, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    check-cast p0, Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v10, 0x1

    return-object p0

    :cond_0
    const/4 v9, 0x0

    move v10, v9

    sget-object p1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAudioMaxCapCodecInstance:Ljava/util/HashMap;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {p1, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x5

    if-eqz p1, :cond_8

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    sget-object p1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAudioMaxCapCodecInstance:Ljava/util/HashMap;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {p1, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    check-cast p0, Ljava/lang/String;

    const/4 v10, 0x5

    return-object p0

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mLocalCache:Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;

    const/4 v9, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-static {v1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->getTPMediaDecoderInfos(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    array-length v2, v1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x4

    const/4 v3, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    move v4, v3

    move v4, v3

    const/4 v10, 0x7

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    if-ge v4, v2, :cond_3

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    aget-object v5, v1, v4

    const/4 v9, 0x6

    or-int/2addr v10, v9

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderMimeType()Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-static {p0, v6}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eqz v6, :cond_2

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isSecureDecoder()Z

    move-result v6

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    if-ne v6, p1, :cond_2

    const/4 v10, 0x2

    const/4 v9, 0x5

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x5

    const-string/jumbo v7, "t:moaedpereNDce"

    const-string/jumbo v7, "getDecoderName:"

    const/4 v10, 0x1

    const/4 v9, 0x4

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x7

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderName()Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x6

    const/4 v9, 0x0

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v7, 0x2

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    const-string/jumbo v8, "iescsTlCqUtd"

    const-string/jumbo v8, "sdscCetoiUlT"

    const/4 v10, 0x2

    const-string v8, "TPCodecUtils"

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {v7, v8, v6}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x5

    add-int/lit8 v4, v4, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    goto :goto_0

    :cond_3
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_4
    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eqz p1, :cond_7

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    check-cast p1, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isVideo()Z

    move-result v1

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-eqz v1, :cond_5

    const/4 v10, 0x3

    const/4 v9, 0x6

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isVideoSofwareDecoder()Z

    move-result v1

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    sget-boolean v2, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mPreferredSoftwareComponent:Z

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eq v1, v2, :cond_6

    :cond_5
    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isAudio()Z

    move-result v1

    const/4 v9, 0x7

    shl-int/2addr v10, v9

    if-eqz v1, :cond_4

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isAudioSofwareDecoder()Z

    move-result v1

    const/4 v9, 0x0

    xor-int/2addr v10, v9

    sget-boolean v2, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mPreferredSoftwareComponent:Z

    const/4 v9, 0x6

    shl-int/2addr v10, v9

    if-ne v1, v2, :cond_4

    :cond_6
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderName()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    return-object p0

    :cond_7
    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p0

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-nez p0, :cond_8

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x1

    check-cast p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderName()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    return-object p0

    :cond_8
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/4 p0, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    return-object p0
.end method

.method public static getDisplayVersion()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public static getDolbyVisionDecoderName(Ljava/lang/String;IIZ)Ljava/lang/String;
    .locals 12

    const-string/jumbo p2, "odsiiyeoonml/bvvis"

    const-string/jumbo p2, "syvmidvoon/iedlbio"

    const-string/jumbo p2, "sdlmbiyo/-nvoedvii"

    const-string/jumbo p2, "video/dolby-vision"

    invoke-static {p2, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v0, 0x0

    if-nez p2, :cond_0

    return-object v0

    :cond_0
    invoke-static {p1}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->convertDolbyVisionToOmxProfile(I)I

    move-result p2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mLocalCache:Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;

    invoke-static {v1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->getTPMediaDecoderInfos(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x0

    move v4, v3

    move v4, v3

    move v4, v3

    move v4, v3

    :goto_0
    if-ge v4, v2, :cond_3

    aget-object v5, v1, v4

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getProfileLevels()[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

    move-result-object v6

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderMimeType()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_2

    array-length v7, v6

    move v8, v3

    move v8, v3

    move v8, v3

    move v8, v3

    :goto_1
    if-ge v8, v7, :cond_2

    aget-object v9, v6, v8

    iget v10, v9, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->profile:I

    if-ne v10, p2, :cond_1

    new-instance v10, Ljava/lang/StringBuilder;

    const-string/jumbo v11, "tnyooicV ao:mooesgf oilprebeDNdDlre"

    const-string/jumbo v11, "mntbofrop:o ideD oNcoDrgselieeyliVa"

    const-string v11, "d i abiNoceeemgsfiDoenbpryDrl:eolVt"

    const-string/jumbo v11, "getDolbyVisionDecoderName  profile:"

    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v9, v9, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->profile:I

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, "d vblPu:ore"

    const-string v9, " :rilboePvd"

    const-string v9, "elor vip:dP"

    const-string v9, " dvProfile:"

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, "beuSu:ceq"

    const-string/jumbo v9, "rbSceuu:e"

    const-string v9, "e scre:Su"

    const-string v9, " bSecure:"

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, p3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v9, "enam: "

    const-string v9, " name:"

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const/4 v10, 0x2

    const-string/jumbo v11, "sePooCtUTidc"

    const-string v11, "TPCodecUtils"

    invoke-static {v10, v11, v9}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isSecureDecoder()Z

    move-result v9

    if-ne v9, p3, :cond_1

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderName()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    add-int/lit8 v8, v8, 0x1

    goto :goto_1

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_3
    return-object v0
.end method

.method public static getHevcSWDecodeLevel()I
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuHarewareName()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuHWProducter(Ljava/lang/String;)I

    move-result v1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuHWProductIndex(Ljava/lang/String;)I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string v4, "DegetboerWl=r]Lec,poSpe  HWmC[dcceue Hvtvd"

    const-string v4, "=Werm]eppL rDtveSceHoegct ,uPdWolvdHee [cC"

    const/4 v7, 0x1

    const-string v4, "=dH m[uue epeueHClreoDLc erovct]dWtPvSeg,W"

    const-string v4, "[getHevcSWDecodeLevel], mCpuHWProducter = "

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    const-string/jumbo v4, "tg ex(=pqqFa) Cr,ep "

    const-string/jumbo v4, "uqF=gr (qp,)eea x Ct"

    const/4 v7, 0x5

    const-string v4, "=,a CtMqq(u) r eFpeg"

    const-string v4, ", getMaxCpuFreq() = "

    const/4 v6, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getMaxCpuFreq()J

    move-result-wide v4

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    const-string v4, "C s rs,neou ="

    const-string v4, " =s Cnr,eu om"

    const/4 v7, 0x7

    const-string v4, ", numCores = "

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getNumCores()I

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string/jumbo v4, "pmtmoI,xrWCPuH= udm"

    const-string/jumbo v4, "u,pmWIomPcHtud rCx="

    const/4 v7, 0x6

    const-string v4, "=c,PoWop IrCHtxdmud"

    const-string v4, ", mCpuHWProductIdx="

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-string/jumbo v4, "rdroabe,a=w"

    const-string v4, "=he,oradarw"

    const-string v4, ",aawr=ue dr"

    const-string v4, ", hardware="

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 v3, 0x2

    const/4 v6, 0x0

    move v7, v6

    const-string v4, "PelcTbsoiCUd"

    const/4 v7, 0x2

    const-string/jumbo v4, "idoscePpCUTt"

    const-string v4, "TPCodecUtils"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {v3, v4, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    sget v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHevcDeviceLevel:I

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/4 v4, -0x1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eq v4, v0, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    return v0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    sput v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHevcDeviceLevel:I

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-eq v4, v1, :cond_9

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/16 v0, 0x10

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/16 v4, 0x15

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz v1, :cond_7

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 v5, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eq v1, v5, :cond_5

    const/4 v6, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-eq v1, v3, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/4 v3, 0x3

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eq v1, v3, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto :goto_3

    :cond_1
    const/4 v6, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    sget v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mShdHevcSamsungIndex:I

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-lt v2, v1, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x0

    goto :goto_0

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    sget v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdHevcSamsungIndex:I

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-lt v2, v1, :cond_9

    const/4 v6, 0x5

    const/4 v6, 0x4

    goto :goto_1

    :cond_3
    const/4 v7, 0x6

    sget v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mShdHevcHisiIndex:I

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-lt v2, v1, :cond_4

    const/4 v7, 0x4

    goto :goto_0

    :cond_4
    const/4 v6, 0x2

    const/4 v6, 0x4

    sget v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdHevcHisiIndex:I

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-lt v2, v1, :cond_9

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    goto :goto_1

    :cond_5
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    sget v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mShdHevcMtkIndex:I

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-lt v2, v1, :cond_6

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    goto :goto_0

    :cond_6
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    sget v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdHevcMtkIndex:I

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-lt v2, v1, :cond_9

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    goto :goto_1

    :cond_7
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    sget v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mShdHevcQualcommIndex:I

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-lt v2, v1, :cond_8

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    sput v4, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHevcDeviceLevel:I

    const/4 v6, 0x6

    goto :goto_3

    :cond_8
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    sget v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdHevcQualcommIndex:I

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-lt v2, v1, :cond_9

    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto :goto_2

    :cond_9
    const/4 v7, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getDecodeLevelByCoresAndFreq()I

    move-result v0

    :goto_2
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    sput v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHevcDeviceLevel:I

    :goto_3
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    sget v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHevcDeviceLevel:I

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    return v0
.end method

.method public static getMaxLumaSample(Ljava/lang/String;I)I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const-string/jumbo v0, "oia/uvvdq"

    const-string v0, "dvieoauv/"

    const/4 v2, 0x6

    const-string/jumbo v0, "vcsaieodv"

    const-string/jumbo v0, "video/avc"

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/tencent/thumbplayer/core/common/TPMediaCodecProfileLevel;->getAVCMaxLumaSample(I)I

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return p0

    :cond_0
    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string v0, "epomecvi/h"

    const-string/jumbo v0, "oehve/vpic"

    const/4 v2, 0x5

    const-string/jumbo v0, "ioveochvd/"

    const-string/jumbo v0, "video/hevc"

    const/4 v2, 0x6

    const/4 v1, 0x7

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/tencent/thumbplayer/core/common/TPMediaCodecProfileLevel;->getHEVCMaxLumaSample(I)I

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return p0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string v0, "dvv.ibdnxeponv/8qo2"

    const-string v0, "2vxv8dooqien/.dv.pn"

    const/4 v2, 0x0

    const-string/jumbo v0, "video/x-vnd.on2.vp8"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/core/common/TPMediaCodecProfileLevel;->getVP8MaxLumaSample(I)I

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return p0

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string v0, "e.s2o-vodivnp/.9xnv"

    const/4 v2, 0x2

    const-string v0, "/-.9dvuinnvdpo2ovex"

    const-string/jumbo v0, "video/x-vnd.on2.vp9"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_3

    const/4 v2, 0x4

    const/4 v1, 0x0

    invoke-static {p1}, Lcom/tencent/thumbplayer/core/common/TPMediaCodecProfileLevel;->getVP9MaxLumaSample(I)I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    return p0

    :cond_3
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string v0, "e/1avmipod"

    const-string v0, "avdmie1v/o"

    const/4 v2, 0x0

    const-string v0, "1ve0iad/qv"

    const-string/jumbo v0, "video/av01"

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p0, :cond_4

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/core/common/TPMediaCodecProfileLevel;->getAV1MaxLumaSample(I)I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return p0

    :cond_4
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 p0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return p0
.end method

.method public static declared-synchronized getMaxSupportedFrameRatesFor(IIII)I
    .locals 15

    move v0, p0

    move v0, p0

    move v0, p0

    move v0, p0

    move/from16 v6, p2

    move/from16 v6, p2

    move/from16 v6, p2

    move/from16 v6, p2

    move/from16 v7, p3

    move/from16 v7, p3

    move/from16 v7, p3

    move/from16 v7, p3

    const-class v8, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v8, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v8, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v8, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    monitor-enter v8

    const/16 v1, 0x65

    const/16 v2, 0x1e

    if-eq v0, v1, :cond_5

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    goto/16 :goto_2

    :cond_0
    :try_start_0
    invoke-static/range {p1 .. p1}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getSupportedHWMimeType(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v1, :cond_1

    monitor-exit v8

    return v2

    :cond_1
    :try_start_1
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mLocalCache:Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;

    invoke-static {v1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->getTPMediaDecoderInfos(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    move-result-object v1

    array-length v2, v1

    const/4 v10, 0x0

    move v3, v10

    move v3, v10

    move v3, v10

    move v3, v10

    :goto_0
    if-ge v3, v2, :cond_4

    aget-object v4, v1, v3

    invoke-virtual {v4}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderMimeType()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3

    invoke-virtual {v4}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderMaxWidth()I

    move-result v11

    invoke-virtual {v4}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderMaxHeight()I

    move-result v1

    invoke-virtual {v4}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderLumaWidth()I

    move-result v2

    invoke-virtual {v4}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderLumaHeight()I

    move-result v12

    invoke-virtual {v4}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderMaxFrameRateForMaxLuma()I

    move-result v13

    invoke-virtual {v4}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderMaxFrameRate()I

    move-result v14

    move v0, v11

    move v0, v11

    move v0, v11

    move v3, v12

    move/from16 v4, p2

    move/from16 v4, p2

    move/from16 v4, p2

    move/from16 v5, p3

    move/from16 v5, p3

    move/from16 v5, p3

    move/from16 v5, p3

    invoke-static/range {v0 .. v5}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isLimitMaxWidthOrMaxHeight(IIIIII)Z

    move-result v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    if-eqz v0, :cond_2

    monitor-exit v8

    return v10

    :cond_2
    mul-int v0, v11, v12

    int-to-long v0, v0

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    mul-long/2addr v0, v2

    mul-int v4, v6, v7

    int-to-long v4, v4

    mul-long/2addr v4, v2

    :try_start_3
    invoke-static {v4, v5, v2, v3}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v2

    div-long/2addr v0, v2

    long-to-int v0, v0

    mul-int/2addr v0, v13

    const/4 v1, 0x1

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-static {v14, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    const-string v0, "UoseTCicsPol"

    const-string/jumbo v0, "tClUocioTesP"

    const-string v0, "eTCmPsilcUot"

    const-string v0, "TPCodecUtils"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "rwdaoo trtdxeiepog:bspmuSeatm FFteaR"

    const-string/jumbo v2, "wa Faburdsre:gpmetei txdemoRtFoaSptr"

    const-string/jumbo v2, "gha Fb:rStwttdeoe xemtaFasedrpoRimrp"

    const-string/jumbo v2, "getSupportedFrameRatesFor max width:"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v2, "g:uh humaxi "

    const-string/jumbo v2, "i :htmuhxga "

    const-string v2, "a: exhtpghm "

    const-string v2, " max height:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v2, "r:onotrxqr m afmpasaafirt  lxmueo "

    const-string v2, "aoaetxupoa rora:rnr mmfmie  xsf tl"

    const-string v2, "aesa iuaom frnaferromx: trxtm sole"

    const-string v2, " max framerate for max resolution:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " etm:rhqntwrdcu"

    const-string v2, "cwhd:rtrqt un e"

    const-string v2, "e icortw:rhd tn"

    const-string v2, " current width:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v2, "it shbgh"

    const-string/jumbo v2, "h:sgth i"

    const-string v2, " height:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v2, "etexmouarrapra tfps u: "

    const-string v2, " max support framerate:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x2

    invoke-static {v2, v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_1

    :cond_3
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_0

    :catch_0
    move-exception v0

    :try_start_4
    const-string/jumbo v1, "lUieosTptdcC"

    const-string v1, "TPCodecUtils"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, ":FgedRmiqpaeoeSatstferlptFumrearo xM"

    const-string/jumbo v3, "pefmuprrg:MaedtFoaisReeeSottalr mxdF"

    const-string v3, "eesluariaretam:Sdef oMtoxdpgeasRptFr"

    const-string/jumbo v3, "getMaxSupportedFrameRatesFor failed:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    invoke-static {v2, v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    :cond_4
    :goto_1
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    monitor-exit v8

    return v0

    :catchall_0
    move-exception v0

    monitor-exit v8

    throw v0

    :cond_5
    :goto_2
    monitor-exit v8

    return v2
.end method

.method private static getSoftMaxSamples(I)I
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eq p0, v0, :cond_7

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eq p0, v0, :cond_6

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/16 v0, 0xb

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eq p0, v0, :cond_5

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/16 v0, 0x10

    const/4 v1, 0x1

    move v2, v1

    if-eq p0, v0, :cond_4

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/16 v0, 0x15

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eq p0, v0, :cond_3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/16 v0, 0x1a

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eq p0, v0, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/16 v0, 0x1c

    const/4 v2, 0x3

    if-eq p0, v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/16 v0, 0x21

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eq p0, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/high16 p0, 0x870000

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x0

    const p0, 0x7e9000

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    goto :goto_0

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    const p0, 0x1fa400

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :cond_3
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    const p0, 0xe1000

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_4
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    const p0, 0x75300

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_0

    :cond_5
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    const p0, 0x63600

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    goto :goto_0

    :cond_6
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    const p0, 0x4b000

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_7
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    const p0, 0x1fa40

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    return p0
.end method

.method private static getSupportedCodecId(Ljava/lang/String;)I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string/jumbo v0, "ooemc/vad"

    const-string v0, "cdavoi/eo"

    const/4 v2, 0x3

    const-string v0, "eac/odvoi"

    const-string/jumbo v0, "video/avc"

    const/4 v2, 0x7

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/16 p0, 0x1a

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string/jumbo v0, "oci/bbdehv"

    const-string/jumbo v0, "veichbvod/"

    const/4 v2, 0x3

    const-string v0, "cvdheouei/"

    const-string/jumbo v0, "video/hevc"

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/16 p0, 0xac

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return p0

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    const-string v0, "/dv2voun-xoin.dp8e."

    const/4 v2, 0x1

    const-string v0, ".exnvippv2vnd/o8od."

    const-string/jumbo v0, "video/x-vnd.on2.vp8"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/16 p0, 0x8a

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return p0

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string/jumbo v0, "vdvdvx/.qoippne.no2"

    const-string/jumbo v0, "ndoxov2pvnei.v-dp./"

    const/4 v2, 0x4

    const-string v0, "eosdn../pvvod2n-9xv"

    const-string/jumbo v0, "video/x-vnd.on2.vp9"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/16 p0, 0xa6

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p0

    :cond_3
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-string/jumbo v0, "vvemid0a/o"

    const-string v0, "0oiavedvq/"

    const/4 v2, 0x4

    const-string v0, "0/viod1ova"

    const-string/jumbo v0, "video/av01"

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    if-eqz v0, :cond_4

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/16 p0, 0x405

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    return p0

    :cond_4
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string/jumbo v0, "i/umpbmaad4tloa"

    const-string/jumbo v0, "iusoamada/4lmtp"

    const/4 v2, 0x2

    const-string/jumbo v0, "i4mlaau/-mtoadp"

    const-string v0, "audio/mp4a-latm"

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_5

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/16 p0, 0x138a

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return p0

    :cond_5
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string v0, "duic3mapo"

    const-string/jumbo v0, "i3omaduac"

    const/4 v2, 0x2

    const-string/jumbo v0, "uca3/daoq"

    const-string v0, "audio/ac3"

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_6

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/16 p0, 0x138b

    const/4 v2, 0x7

    const/4 v1, 0x1

    return p0

    :cond_6
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    const-string v0, "cos3a/iedo"

    const-string/jumbo v0, "i/a3ooeacd"

    const/4 v2, 0x1

    const-string/jumbo v0, "o/3madiaec"

    const-string v0, "audio/eac3"

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-nez v0, :cond_a

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string v0, "cbojo-e3aoiduc"

    const-string v0, "3uaoibcj-cdaoe"

    const/4 v2, 0x0

    const-string/jumbo v0, "ij/aabo-dcoceu"

    const-string v0, "audio/eac3-joc"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_7

    const/4 v1, 0x7

    shr-int/2addr v2, v1

    goto :goto_0

    :cond_7
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string/jumbo v0, "ouafacui/d"

    const-string/jumbo v0, "fcoaidual/"

    const/4 v2, 0x0

    const-string/jumbo v0, "l/uoadapci"

    const-string v0, "audio/flac"

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_8

    const/16 p0, 0x1394

    const/4 v2, 0x3

    const/4 v1, 0x5

    return p0

    :cond_8
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string/jumbo v0, "uvtin/dsq.opa"

    const-string/jumbo v0, "uiadontpd/.sv"

    const/4 v2, 0x6

    const-string/jumbo v0, "v.s/iodddasnt"

    const-string v0, "audio/vnd.dts"

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz p0, :cond_9

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/16 p0, 0x138c

    const/4 v2, 0x7

    return p0

    :cond_9
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p0, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return p0

    :cond_a
    :goto_0
    const/4 v1, 0x3

    move v2, v1

    const/16 p0, 0x13b0

    const/4 v2, 0x4

    return p0
.end method

.method private static getSupportedHWMimeType(I)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/16 v0, 0x1a

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eq p0, v0, :cond_4

    const/4 v1, 0x6

    or-int/2addr v2, v1

    const/16 v0, 0x8a

    if-eq p0, v0, :cond_3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/16 v0, 0xa6

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eq p0, v0, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/16 v0, 0xac

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eq p0, v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/16 v0, 0x405

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eq p0, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const-string p0, "ai0mdeo1qv"

    const-string/jumbo p0, "vvi0oeadq1"

    const/4 v2, 0x7

    const-string p0, "e1dio0vo/a"

    const-string/jumbo p0, "video/av01"

    const/4 v2, 0x6

    const/4 v1, 0x2

    goto :goto_0

    :cond_1
    const/4 v2, 0x7

    const-string p0, "/chvdbeisv"

    const-string p0, "ehsovi/dvc"

    const/4 v2, 0x1

    const-string p0, "dochv/uive"

    const-string/jumbo p0, "video/hevc"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :cond_2
    const/4 v1, 0x7

    const/4 v1, 0x6

    const-string/jumbo p0, "x.vp.odp-d9vioe2nm/"

    const-string/jumbo p0, "xd.m2/envo-oi9pv.nd"

    const/4 v2, 0x2

    const-string/jumbo p0, "o.-ie9voqv.d2npvd/n"

    const-string/jumbo p0, "video/x-vnd.on2.vp9"

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    goto :goto_0

    :cond_3
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string p0, ".osnpe2vdox-io.vd/v"

    const-string/jumbo p0, "oe.dox-i2pdnov/vvn."

    const/4 v2, 0x4

    const-string p0, "8e-m.n2.pvnx/dvidvo"

    const-string/jumbo p0, "video/x-vnd.on2.vp8"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    goto :goto_0

    :cond_4
    const/4 v2, 0x4

    const-string p0, "/deaobvvi"

    const-string/jumbo p0, "vdiovb/ae"

    const/4 v2, 0x2

    const-string p0, "c/iavbdov"

    const-string/jumbo p0, "video/avc"

    :goto_0
    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public static getSystemPatchVersion()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public static declared-synchronized getVCodecSWMaxCapabilityMap()Ljava/util/HashMap;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;",
            ">;"
        }
    .end annotation

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x0

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const/4 v13, 0x2

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x1

    const-string v1, "cUloituseuCP"

    const-string/jumbo v1, "ilCUTcuetoPs"

    const/4 v13, 0x7

    const-string v1, "TodCticplUPe"

    const-string v1, "TPCodecUtils"

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x4

    const-string v2, "aapdCeipuMpenWtiyclxcM goCfVabitSn "

    const/4 v13, 0x3

    const-string/jumbo v2, "gaMn aCbqeVtiaplpdcyunMWeiSCoita cf"

    const-string/jumbo v2, "getVCodecSWMaxCapabilityMap func in"

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x0

    const/4 v3, 0x2

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x7

    invoke-static {v3, v1, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x3

    sget-boolean v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mIsFFmpegCapGot:Z

    const/4 v12, 0x6

    const/4 v12, 0x0

    if-eqz v1, :cond_0

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecSwCapabilityMap:Ljava/util/HashMap;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v13, 0x6

    monitor-exit v0

    const/4 v13, 0x6

    const/4 v12, 0x2

    return-object v1

    :cond_0
    :try_start_1
    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getHevcSWDecodeLevel()I

    move-result v1

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x6

    invoke-static {v1}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getSoftMaxSamples(I)I

    move-result v2

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getAvs3SWDecodeLevel()I

    move-result v4

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getAV1SWDecodeLevel()I

    move-result v5

    const/4 v12, 0x1

    move v13, v12

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getVvcSWDecodeLevel()I

    move-result v6

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x5

    invoke-static {v4}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getSoftMaxSamples(I)I

    move-result v7

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x7

    invoke-static {v5}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getSoftMaxSamples(I)I

    move-result v8

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x2

    invoke-static {v6}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getSoftMaxSamples(I)I

    move-result v9

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x4

    new-instance v10, Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-string v11, "cCsaovVdieaeDMbehpavlypctlLC,eMScq:dW ioeateg"

    const-string/jumbo v11, "oltevoxdqeeD Mta:ccbhcClaLedM,ySpViaiCveWagep"

    const/4 v13, 0x1

    const-string/jumbo v11, "yD mecCtoMgalSLdaeVecCpioaial:vpMvW,beeedtceh"

    const-string/jumbo v11, "getVCodecSWMaxCapabilityMap, hevcDecodeLevel:"

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x5

    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x0

    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x5

    const-string/jumbo v1, "sa,eov:e Lvocs3eeD"

    const-string v1, "e3sLv,eeeslv Doa:c"

    const/4 v13, 0x4

    const-string v1, " cev:baoe3sevdLlD,"

    const-string v1, ", avs3DecodeLevel:"

    const/4 v13, 0x1

    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x3

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x5

    const/4 v12, 0x1

    const-string v1, ":eeVoAueD1dvLcem,"

    const-string v1, "1lvmAec:LeDeo,Vde"

    const/4 v13, 0x6

    const-string v1, "V dceL:peveDolA,e"

    const-string v1, ", AV1DecodeLevel:"

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x6

    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x6

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x3

    const-string/jumbo v1, "vdlccvLoq,e voeee"

    const-string v1, "c,veolvLeDc oveed"

    const/4 v13, 0x7

    const-string/jumbo v1, "lesdce vcLv:Deev,"

    const-string v1, ", vvcDecodeLevel:"

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x7

    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x3

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    shl-int/2addr v13, v12

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x7

    invoke-static {v3, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAVCSWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x4

    iput v2, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLumaSamples:I

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x0

    const/16 v4, 0x40

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x0

    iput v4, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxProfile:I

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x5

    const/high16 v4, 0x10000

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x1

    iput v4, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLevel:I

    const/4 v13, 0x3

    const/4 v12, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecSwCapabilityMap:Ljava/util/HashMap;

    const/4 v12, 0x2

    move v13, v12

    const/16 v4, 0x1a

    const/4 v13, 0x6

    const/4 v12, 0x1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x7

    sget-object v5, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAVCSWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v1, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHEVCSWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x2

    iput v2, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLumaSamples:I

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x7

    iput v3, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxProfile:I

    const/4 v13, 0x4

    const/4 v12, 0x4

    const/high16 v4, 0x2000000

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x4

    iput v4, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLevel:I

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecSwCapabilityMap:Ljava/util/HashMap;

    const/4 v13, 0x2

    const/16 v4, 0xac

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x3

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x2

    sget-object v5, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHEVCSWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x5

    invoke-virtual {v1, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVP9SWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v12, 0x4

    move v13, v12

    iput v2, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLumaSamples:I

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x1

    const/16 v4, 0x8

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x1

    iput v4, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxProfile:I

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x3

    const/16 v5, 0x2000

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x1

    iput v5, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLevel:I

    const/4 v13, 0x2

    const/4 v12, 0x1

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecSwCapabilityMap:Ljava/util/HashMap;

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x3

    const/16 v5, 0xa6

    const/4 v12, 0x0

    move v13, v12

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x5

    sget-object v6, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVP9SWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-virtual {v1, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVP8SWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x5

    iput v2, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLumaSamples:I

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x7

    const/4 v5, 0x1

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x3

    iput v5, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxProfile:I

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x1

    iput v4, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLevel:I

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecSwCapabilityMap:Ljava/util/HashMap;

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/16 v4, 0x8a

    const/4 v13, 0x1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x5

    sget-object v6, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVP8SWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v13, 0x3

    invoke-virtual {v1, v4, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAVS3WMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x1

    iput v7, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLumaSamples:I

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x7

    const/4 v4, 0x0

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x5

    iput v4, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxProfile:I

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x2

    iput v4, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLevel:I

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecSwCapabilityMap:Ljava/util/HashMap;

    const/4 v13, 0x4

    const/16 v6, 0xc0

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x2

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x0

    sget-object v10, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAVS3WMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x3

    invoke-virtual {v1, v6, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x3

    shl-int/2addr v13, v12

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAV1SWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    iput v8, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLumaSamples:I

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x4

    iput v4, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxProfile:I

    const/4 v13, 0x1

    const/4 v12, 0x7

    iput v4, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLevel:I

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x1

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecSwCapabilityMap:Ljava/util/HashMap;

    const/4 v13, 0x7

    const/16 v6, 0x405

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x0

    sget-object v10, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAV1SWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v13, 0x3

    const/4 v12, 0x4

    invoke-virtual {v1, v6, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVVCSWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x6

    iput v9, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLumaSamples:I

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x7

    iput v4, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxProfile:I

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x7

    iput v4, v1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLevel:I

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecSwCapabilityMap:Ljava/util/HashMap;

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x0

    const/16 v4, 0xc1

    const/4 v13, 0x1

    const/4 v12, 0x4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x4

    sget-object v6, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVVCSWMaxCapability:Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x5

    invoke-virtual {v1, v4, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x7

    and-int/2addr v13, v12

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x4

    const-string v4, "MaSotb:l,CxdsmuicypuaaMpeVacp vxcemSiH meLabcltesCagWsas"

    const-string/jumbo v4, "lmcmVetWeilpaHca pMuCveaaiaScdLuec,boxpxSaCtasy eMmsgmss"

    const-string/jumbo v4, "getVCodecSWMaxCapabilityMap success, maxHevcLumaSamples:"

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x7

    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x3

    const-string/jumbo v2, "smxaopaa3uvemLu,Ss Am"

    const-string v2, " apmmSusvAaex,usmL3al"

    const/4 v13, 0x2

    const-string v2, "AmSmab ,esL:pu3vamlxs"

    const-string v2, ", maxAvs3LumaSamples:"

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    move v13, v12

    const-string v2, "V,xmSpu1pLlm aaAem:u"

    const-string/jumbo v2, "xamAmVmp,Lelu aa:S1p"

    const/4 v13, 0x0

    const-string/jumbo v2, "salmxL,pemAm1pV:uS a"

    const-string v2, ", maxAV1LumaSamples:"

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x3

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x4

    const-string/jumbo v2, "xmSVmcvpqLus emq,aal"

    const-string v2, ":spS,LvaqcVamux lmem"

    const/4 v13, 0x1

    const-string/jumbo v2, "sus:a mpVmcSeavaLlm,"

    const-string v2, ", maxVvcLumaSamples:"

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x7

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x1

    invoke-static {v3, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x1

    sput-boolean v5, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mIsFFmpegCapGot:Z

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecSwCapabilityMap:Ljava/util/HashMap;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v13, 0x0

    const/4 v12, 0x7

    monitor-exit v0

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x4

    return-object v1

    :catch_0
    :try_start_2
    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x6

    const-string/jumbo v1, "ieUmdcoTssCP"

    const-string v1, "UisteTcCdsoP"

    const/4 v13, 0x7

    const-string v1, "TPCodecUtils"

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x4

    const-string v2, "MdVMoCataSioxlCeiWypmgixpno caceabtee"

    const-string/jumbo v2, "tnpmabec iSexeCoiWlgtaMtVixMdapceCayo"

    const/4 v13, 0x4

    const-string v2, "bVtpdbpoax peitcCegaMCeaMonySliWeiact"

    const-string/jumbo v2, "getVCodecSWMaxCapabilityMap exception"

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x2

    const/4 v3, 0x4

    const/4 v13, 0x7

    const/4 v12, 0x1

    invoke-static {v3, v1, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v13, 0x4

    const/4 v12, 0x4

    const/4 v13, 0x1

    monitor-exit v0

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x4

    const/4 v0, 0x0

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x1

    return-object v0

    :catchall_0
    move-exception v1

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x2

    monitor-exit v0

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x6

    throw v1
.end method

.method public static declared-synchronized getVMediaCodecMaxCapabilityMap()Ljava/util/HashMap;
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;",
            ">;"
        }
    .end annotation

    const/4 v14, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x2

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const/4 v14, 0x0

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const/4 v14, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x7

    const-string v1, "CTioocultUPs"

    const-string v1, "TUtcoisPelCo"

    const/4 v14, 0x7

    const-string/jumbo v1, "etcloPspdiTU"

    const-string v1, "TPCodecUtils"

    const/4 v14, 0x3

    const/4 v13, 0x1

    const-string/jumbo v2, "ypbdgbMVaaoalCtieMic aeuixCni ednMcaft"

    const/4 v14, 0x2

    const-string v2, "dxeMieiCqtdiMMgpanbo pce nVfaaCtiauacy"

    const-string/jumbo v2, "getVMediaCodecMaxCapabilityMap func in"

    const/4 v14, 0x7

    const/4 v3, 0x2

    const/4 v14, 0x1

    move v13, v3

    move v13, v3

    const/4 v14, 0x6

    invoke-static {v3, v1, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecHwCapabilityMap:Ljava/util/HashMap;

    const/4 v14, 0x0

    const/4 v13, 0x7

    const/4 v14, 0x4

    invoke-virtual {v1}, Ljava/util/HashMap;->isEmpty()Z

    move-result v1

    const/4 v14, 0x1

    const/4 v13, 0x4

    const/4 v14, 0x0

    if-nez v1, :cond_0

    const/4 v14, 0x4

    const/4 v13, 0x5

    const/4 v14, 0x5

    const-string/jumbo v1, "slsCuUodTteP"

    const-string v1, "PeoTlduUtCsi"

    const/4 v14, 0x0

    const-string/jumbo v1, "itlmoCsedUcT"

    const-string v1, "TPCodecUtils"

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x1

    const-string v2, "epsroaomuemd xdpteta rm  rrvo ay picon"

    const-string/jumbo v2, "ittasr pmpp  eree cadvmroenayroox udm "

    const/4 v14, 0x6

    const-string v2, "dcmaebmotirydeers  ox vrpaaoterpum n m"

    const-string/jumbo v2, "return memory stored video max cap map"

    const/4 v14, 0x7

    const/4 v13, 0x4

    invoke-static {v3, v1, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x7

    xor-int/2addr v14, v13

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecHwCapabilityMap:Ljava/util/HashMap;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x4

    monitor-exit v0

    const/4 v14, 0x7

    const/4 v13, 0x4

    const/4 v14, 0x0

    return-object v1

    :cond_0
    :try_start_1
    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mLocalCache:Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x3

    invoke-static {v1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->getTPMediaDecoderInfos(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    move-result-object v1

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x1

    array-length v2, v1

    const/4 v14, 0x4

    const/4 v13, 0x2

    const/4 v14, 0x0

    const/4 v4, 0x0

    :goto_0
    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x2

    if-ge v4, v2, :cond_3

    const/4 v14, 0x0

    const/4 v13, 0x1

    const/4 v14, 0x1

    aget-object v5, v1, v4

    const/4 v14, 0x1

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderMimeType()Ljava/lang/String;

    move-result-object v6

    const/4 v14, 0x4

    const/4 v13, 0x3

    const/4 v14, 0x6

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isVideo()Z

    move-result v7

    const/4 v13, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x2

    if-eqz v7, :cond_2

    const/4 v14, 0x2

    const/4 v13, 0x2

    const/4 v14, 0x5

    sget-object v7, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecCapList:Ljava/util/ArrayList;

    const/4 v14, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x1

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v14, 0x4

    const/4 v13, 0x2

    const/4 v14, 0x3

    const-string v7, "PeilstuoTCqc"

    const-string/jumbo v7, "lPceoidsqtTC"

    const/4 v14, 0x6

    const-string v7, "ctldCPspiUoe"

    const-string v7, "TPCodecUtils"

    const/4 v14, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x2

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x0

    const-string v9, "Mm eVidyqe eosiT"

    const-string/jumbo v9, "yesiepidVMe T mo"

    const/4 v14, 0x2

    const-string v9, " ps mVoie:ieTedy"

    const-string v9, "Video MimeType: "

    const/4 v14, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x5

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v14, 0x4

    const/4 v13, 0x0

    const/4 v14, 0x3

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x2

    const-string v9, "ee mNcmcodm "

    const-string v9, "d omaecmecN "

    const/4 v14, 0x1

    const-string v9, "e:d oeaccN m"

    const-string v9, " codecName: "

    const/4 v13, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x0

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x0

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderName()Ljava/lang/String;

    move-result-object v9

    const/4 v14, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x2

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x5

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v14, 0x0

    const/4 v13, 0x4

    const/4 v14, 0x1

    invoke-static {v3, v7, v8}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x6

    invoke-static {v6}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isSupportedMediaCodec(Ljava/lang/String;)Z

    move-result v7

    const/4 v14, 0x3

    const/4 v13, 0x1

    if-eqz v7, :cond_2

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x0

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isSecureDecoder()Z

    move-result v7

    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x4

    if-nez v7, :cond_2

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x6

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getMaxProfileLevel()Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

    move-result-object v7

    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x2

    new-instance v8, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v14, 0x6

    const/4 v13, 0x6

    iget v9, v7, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->level:I

    const/4 v14, 0x6

    const/4 v13, 0x4

    const/4 v14, 0x3

    invoke-static {v6, v9}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getMaxLumaSample(Ljava/lang/String;I)I

    move-result v9

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x6

    iget v10, v7, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->profile:I

    const/4 v14, 0x3

    const/4 v13, 0x1

    iget v11, v7, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->level:I

    const/4 v14, 0x4

    const/4 v13, 0x1

    const/4 v14, 0x3

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderMaxFrameRateForMaxLuma()I

    move-result v12

    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x5

    invoke-direct {v8, v9, v10, v11, v12}, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;-><init>(IIII)V

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x0

    const-string v9, "dlseobiocPUC"

    const-string v9, "UtClocioPeds"

    const/4 v14, 0x7

    const-string v9, "PCTUlouiescd"

    const-string v9, "TPCodecUtils"

    const/4 v14, 0x2

    const/4 v13, 0x7

    const/4 v14, 0x4

    new-instance v10, Ljava/lang/StringBuilder;

    const/4 v13, 0x4

    move v14, v13

    const-string/jumbo v11, "oc obNep cdimede:"

    const-string v11, "edodebice acmN: o"

    const/4 v14, 0x5

    const-string/jumbo v11, "vece :edqcNidoaom"

    const-string/jumbo v11, "video codecName: "

    const/4 v14, 0x2

    const/4 v13, 0x2

    const/4 v14, 0x1

    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v14, 0x0

    const/4 v13, 0x6

    const/4 v14, 0x4

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderName()Ljava/lang/String;

    move-result-object v11

    const/4 v14, 0x6

    const/4 v13, 0x6

    const/4 v14, 0x3

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    move v14, v13

    const-string/jumbo v11, "susmlau e:alm"

    const-string/jumbo v11, "le:a sualum m"

    const/4 v14, 0x2

    const-string/jumbo v11, "seumpmlm la: "

    const-string v11, " lumasample: "

    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x7

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x4

    iget v11, v7, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->level:I

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x1

    invoke-static {v6, v11}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getMaxLumaSample(Ljava/lang/String;I)I

    move-result v11

    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x2

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x4

    const-string v11, "ee:aortrp a "

    const-string v11, "ere aftpa:r "

    const/4 v14, 0x3

    const-string v11, "e m ebrr:tfa"

    const-string v11, " framerate: "

    const/4 v14, 0x0

    const/4 v13, 0x6

    const/4 v14, 0x2

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x0

    const/4 v13, 0x1

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderMaxFrameRateForMaxLuma()I

    move-result v5

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x2

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v14, 0x1

    const/4 v13, 0x4

    const/4 v14, 0x2

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v14, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x2

    invoke-static {v3, v9, v5}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v14, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x3

    sget-object v5, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecHwCapabilityMap:Ljava/util/HashMap;

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x3

    invoke-static {v6}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getSupportedCodecId(Ljava/lang/String;)I

    move-result v9

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x7

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x0

    invoke-virtual {v5, v9}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x6

    if-eqz v5, :cond_1

    const/4 v14, 0x1

    const/4 v13, 0x0

    iget v5, v7, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->level:I

    const/4 v14, 0x3

    const/4 v13, 0x6

    const/4 v14, 0x7

    sget-object v7, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecHwCapabilityMap:Ljava/util/HashMap;

    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x1

    invoke-static {v6}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getSupportedCodecId(Ljava/lang/String;)I

    move-result v9

    const/4 v14, 0x0

    const/4 v13, 0x6

    const/4 v14, 0x5

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    const/4 v14, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x3

    invoke-virtual {v7, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x6

    check-cast v7, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;

    const/4 v13, 0x6

    and-int/2addr v14, v13

    iget v7, v7, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPCodecMaxCapability;->maxLevel:I

    const/4 v14, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x3

    if-le v5, v7, :cond_2

    :cond_1
    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x3

    invoke-static {v6}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getSupportedCodecId(Ljava/lang/String;)I

    move-result v5

    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x1

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v14, 0x1

    const/4 v13, 0x4

    const/4 v14, 0x4

    sget-object v6, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecHwCapabilityMap:Ljava/util/HashMap;

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x7

    invoke-static {v5, v8, v6}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->replace(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/HashMap;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_2
    const/4 v14, 0x3

    const/4 v13, 0x6

    add-int/lit8 v4, v4, 0x1

    const/4 v14, 0x6

    const/4 v13, 0x0

    const/4 v14, 0x2

    goto/16 :goto_0

    :catch_0
    move-exception v1

    :try_start_2
    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x1

    const-string/jumbo v2, "oUqPdsuetTCi"

    const-string v2, "UTtdCsloqPei"

    const-string/jumbo v2, "sUoTPitpdClc"

    const-string v2, "TPCodecUtils"

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    const/4 v13, 0x4

    const/4 v14, 0x5

    const-string v4, "capfexCdq iaMdligC:aetoyeieiMaVdtMpaal"

    const-string/jumbo v4, "getVMediaCodecMaxCapabilityMap failed:"

    const/4 v14, 0x1

    const/4 v13, 0x5

    const/4 v14, 0x1

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x3

    invoke-static {v1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    const/4 v14, 0x4

    const/4 v13, 0x1

    const/4 v14, 0x3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    const/4 v13, 0x7

    const/4 v14, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x3

    const/4 v3, 0x4

    const/4 v14, 0x4

    const/4 v13, 0x2

    const/4 v14, 0x2

    invoke-static {v3, v2, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mMaxVCodecHwCapabilityMap:Ljava/util/HashMap;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v14, 0x2

    monitor-exit v0

    const/4 v14, 0x7

    const/4 v13, 0x4

    const/4 v14, 0x1

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x5

    monitor-exit v0

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x4

    throw v1
.end method

.method private static getValueFromSubstring(Ljava/lang/String;II)I
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    if-gez p1, :cond_0

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p1, 0x0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-lt p2, v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p2

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    add-int/lit8 p2, p2, -0x1

    :cond_1
    const/4 v1, 0x2

    const/4 v1, 0x5

    if-le p1, p2, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    move p1, p2

    move p1, p2

    const/4 v2, 0x6

    move p1, p2

    move p1, p2

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p0
.end method

.method private static getVvcSWDecodeLevel()I
    .locals 9

    const/4 v7, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    sget v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVvcDeviceLevel:I

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/4 v1, -0x1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eq v0, v1, :cond_0

    const/4 v8, 0x1

    return v0

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuHarewareName()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuHWProducter(Ljava/lang/String;)I

    move-result v2

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuHWProductIndex(Ljava/lang/String;)I

    move-result v3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string/jumbo v5, "uds cvpm D,P[HeCSlVorsctgedcLuWeeo rve]W"

    const-string/jumbo v5, "ves lo[rDL cd]uCHgSceePvo,eeueptdV WcWrm"

    const/4 v8, 0x4

    const-string v5, "Wuemm=tcPrgSrdvWpCec,]oudc  ee[eVDevL lH"

    const-string v5, "[getVvcSWDecodeLevel], mCpuHWProducer = "

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    move v8, v7

    const-string/jumbo v5, "r (Moqa )C=mpeFetgu "

    const-string/jumbo v5, "p=(me )q C gFeu,raMt"

    const/4 v8, 0x3

    const-string/jumbo v5, "guxMabeFrp)Cqe ,(  t"

    const-string v5, ", getMaxCpuFreq() = "

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getMaxCpuFreq()J

    move-result-wide v5

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v4, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    and-int/2addr v8, v7

    const-string/jumbo v5, "n= , uursoC o"

    const-string v5, "  eCo=on sr,u"

    const-string v5, "=  moCupn,sre"

    const-string v5, ", numCores = "

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getNumCores()I

    move-result v5

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    const-string v5, " xrCWI uquoPtb,pcdHm="

    const-string/jumbo v5, "mP,dpb t=WH I ocuCrxu"

    const/4 v8, 0x0

    const-string/jumbo v5, "uPs mrI  =HdtudpcCW,o"

    const-string v5, ", mCpuHWProductIdx = "

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string/jumbo v5, "u dmaerah = w"

    const-string v5, ",e rwduh a a="

    const/4 v8, 0x6

    const-string v5, "ehr oa ,dwar "

    const-string v5, ", hardware = "

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/4 v4, 0x2

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string v5, "PTsedbciCplt"

    const-string v5, "dlPsoCepcTit"

    const/4 v8, 0x4

    const-string/jumbo v5, "tCidsUuPeloT"

    const-string v5, "TPCodecUtils"

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {v4, v5, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    const/4 v0, 0x3

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    const/4 v4, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-ne v2, v1, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string/jumbo v1, "ructr  cqierinnff sdt  pralonec tp cucderierlerhaompncePm:tarste uu i,nusutHo "

    const/4 v8, 0x2

    const-string v1, ",iofPeuprpanuccpfaun oetmrnHrttwtrucr :ui e paomec ie rlrh ttrldsdnnccus seei "

    const-string v1, "current cpu manufacturer is not listed in the performance list, cpuHwProducer:"

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v0, v5, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x5

    sput v4, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVvcDeviceLevel:I

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    return v4

    :cond_1
    const/4 v7, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-ne v3, v1, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string/jumbo v1, "uPstnceowthe:eddIinlcultxircr dn rHet ppi i  umsn tousecltmor p, d crfeas"

    const/4 v8, 0x1

    const-string v1, "apctcsedqrlsrrrnoctmdlmcnuIot ne x dcpph,o nsii:e tuiutPurtH fe eido  elw"

    const-string v1, "current cpu model is not listed in the performance list, cpuHwProductIdx:"

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    goto :goto_0

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    const/16 v0, 0xc1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {v0, v2, v3}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->selectBestDecodeLevelFromCapabilityTable(III)I

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-eq v0, v1, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    move v4, v0

    move v4, v0

    move v4, v0

    move v4, v0

    :cond_3
    const/4 v8, 0x0

    const/4 v7, 0x4

    sput v4, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVvcDeviceLevel:I

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    return v4
.end method

.method public static declared-synchronized init(Landroid/content/Context;Z)V
    .locals 6

    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const/4 v5, 0x2

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const-string v1, "PelmsTUtiocd"

    const/4 v5, 0x2

    const-string v1, "TtslcUioCPes"

    const-string v1, "TPCodecUtils"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v2, "ecnmchio  eabaaodlcls: "

    const-string v2, "doecoeclaehas l:c a nbi"

    const/4 v5, 0x1

    const-string v2, "c :eo lbesea ahlcocldna"

    const-string/jumbo v2, "is local cache enabled:"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v3, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v3, v1, v2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    sput-object p0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mContext:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz p1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;->get(Landroid/content/Context;)Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    sput-object p0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mLocalCache:Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getDecoderMaxCapabilityMapAsync()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    monitor-exit v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void

    :catchall_0
    move-exception p0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    monitor-exit v0

    const/4 v4, 0x2

    move v5, v4

    throw p0
.end method

.method public static isAMediaCodecBlackListInstance(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAMediaCodecBlackListInstance:Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return p0
.end method

.method public static isAMediaCodecBlackListModel()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAMediaCodecBlackListModel:Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    return v0
.end method

.method public static isBlackListType(Ljava/lang/String;)Z
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v0, "-R b7bO"

    const-string v0, "O R7Pb-"

    const/4 v4, 0x2

    const-string v0, "-O RHPu"

    const-string v0, "PRO 7-H"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string v1, "+RuPP+7pOs"

    const-string/jumbo v1, "sO+P7PuR+u"

    const/4 v4, 0x4

    const-string v1, "RPPuO++7ql"

    const-string v1, "PRO+7+Plus"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v2, "sPs lu7RpO"

    const-string v2, "O ulP7Rps "

    const/4 v4, 0x2

    const-string v2, "POlm 7u sP"

    const-string v2, "PRO 7 Plus"

    const/4 v3, 0x6

    move v4, v3

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {v0, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v0, "echvodieov"

    const-string/jumbo v0, "video/hevc"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz p0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 p0, 0x1

    const/4 v4, 0x2

    return p0

    :cond_0
    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 p0, 0x0

    const/4 v4, 0x6

    return p0
.end method

.method private static declared-synchronized isHDR10Support(I)Z
    .locals 11

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const/4 v10, 0x2

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mLocalCache:Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;

    const/4 v10, 0x4

    invoke-static {v1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->getTPMediaDecoderInfos(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x5

    array-length v2, v1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    const/4 v3, 0x0

    const/4 v10, 0x1

    move v4, v3

    move v4, v3

    const/4 v10, 0x0

    move v4, v3

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-ge v4, v2, :cond_2

    const/4 v9, 0x4

    move v10, v9

    aget-object v5, v1, v4

    const/4 v10, 0x6

    const/4 v9, 0x5

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderMimeType()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-string v7, "dvchebeivq"

    const-string v7, "ceiehvodqv"

    const/4 v10, 0x2

    const-string v7, "ecohevuidv"

    const-string/jumbo v7, "video/hevc"

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-static {v6, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-eqz v6, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getProfileLevels()[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

    move-result-object v5

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    array-length v6, v5

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    move v7, v3

    const/4 v10, 0x3

    move v7, v3

    move v7, v3

    :goto_1
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-ge v7, v6, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x0

    aget-object v8, v5, v7

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget v8, v8, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->profile:I

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-ne v8, p0, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-string/jumbo v1, "iUldTsepPtCc"

    const-string/jumbo v1, "lisTPUetCdsc"

    const/4 v10, 0x3

    const-string v1, "cUtiosldqTPe"

    const-string v1, "TPCodecUtils"

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    const-string/jumbo v2, "sdspor0umh pr "

    const-string/jumbo v2, "r0om u 1srpphd"

    const/4 v10, 0x7

    const-string/jumbo v2, "prtm0so udr ph"

    const-string/jumbo v2, "support hdr10 "

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {v2, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    const/4 v2, 0x2

    const/4 v10, 0x5

    const/4 v9, 0x3

    invoke-static {v2, v1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    monitor-exit v0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    const/4 p0, 0x1

    const/4 v9, 0x5

    move v10, v9

    return p0

    :cond_0
    const/4 v9, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    add-int/lit8 v7, v7, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    goto :goto_1

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    add-int/lit8 v4, v4, 0x1

    const/4 v10, 0x4

    goto/16 :goto_0

    :cond_2
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    monitor-exit v0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    return v3

    :catchall_0
    move-exception p0

    const/4 v9, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    monitor-exit v0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    throw p0
.end method

.method private static declared-synchronized isHDRDVSupport(II)Z
    .locals 12

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x3

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x3

    monitor-enter v0

    const/4 v11, 0x6

    if-nez p0, :cond_0

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x1

    if-nez p1, :cond_0

    :try_start_0
    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    sget-object p0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecCapList:Ljava/util/ArrayList;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    const-string/jumbo p1, "olbvovod-oieysdiio"

    const-string/jumbo p1, "oioiod-oidle/vsybv"

    const/4 v11, 0x7

    const-string p1, "bi/eobdysoinil-vov"

    const-string/jumbo p1, "video/dolby-vision"

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x2

    monitor-exit v0

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    return p0

    :cond_0
    :try_start_1
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mLocalCache:Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;

    const/4 v11, 0x2

    invoke-static {v1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->getTPMediaDecoderInfos(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    move-result-object v1

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    array-length v2, v1

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    const/4 v3, 0x0

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    move v4, v3

    move v4, v3

    const/4 v11, 0x4

    move v4, v3

    :goto_0
    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x0

    if-ge v4, v2, :cond_3

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    aget-object v5, v1, v4

    const/4 v11, 0x7

    const/4 v10, 0x7

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getDecoderMimeType()Ljava/lang/String;

    move-result-object v6

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x4

    const-string/jumbo v7, "yosdd-ubbniloivoi/"

    const-string v7, "ebdldbo/insv-iyioo"

    const/4 v11, 0x2

    const-string/jumbo v7, "oiobsl-pdoiivdy/ne"

    const-string/jumbo v7, "video/dolby-vision"

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-static {v6, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x7

    if-eqz v6, :cond_2

    const/4 v10, 0x4

    xor-int/2addr v11, v10

    invoke-virtual {v5}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->getProfileLevels()[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;

    move-result-object v5

    const/4 v11, 0x7

    const/4 v10, 0x7

    array-length v6, v5

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x2

    move v7, v3

    move v7, v3

    const/4 v11, 0x7

    move v7, v3

    :goto_1
    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x0

    if-ge v7, v6, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x0

    aget-object v8, v5, v7

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    iget v9, v8, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->profile:I

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    if-ne v9, p0, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x0

    iget v8, v8, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo$DecoderProfileLevel;->level:I

    const/4 v11, 0x4

    const/4 v10, 0x7

    if-ne v8, p1, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    const-string/jumbo p0, "loPistudUCec"

    const/4 v11, 0x2

    const-string p0, "cUCTeidsqotP"

    const-string p0, "TPCodecUtils"

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x7

    const-string/jumbo p1, "posoipbrdlityouspsn"

    const-string/jumbo p1, "stdoroop npibiulsyp"

    const/4 v11, 0x3

    const-string/jumbo p1, "v omnriplsuoipodbty"

    const-string/jumbo p1, "support dolbyvision"

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x0

    const/4 v1, 0x2

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-static {v1, p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x3

    monitor-exit v0

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x0

    const/4 p0, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x5

    return p0

    :cond_1
    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x7

    add-int/lit8 v7, v7, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    goto :goto_1

    :cond_2
    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x2

    add-int/lit8 v4, v4, 0x1

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x4

    goto/16 :goto_0

    :cond_3
    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x0

    monitor-exit v0

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x5

    return v3

    :catchall_0
    move-exception p0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    monitor-exit v0

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x5

    throw p0
.end method

.method public static isHDRDecoderTypeSupport(II)Z
    .locals 7
    .annotation build Lcom/tencent/thumbplayer/core/common/TPMethodCalledByNative;
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x4

    move v6, v5

    const-string v1, "PCdeoltqiocT"

    const-string v1, "eldcPiCoqtUT"

    const/4 v6, 0x0

    const-string v1, "CeUiTbPdscto"

    const-string v1, "TPCodecUtils"

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v2, 0x3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/16 v3, 0x66

    const/4 v6, 0x7

    const/4 v5, 0x0

    if-eq p1, v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/16 v4, 0x65

    const/4 v5, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eq p1, v4, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const-string p0, "eSydDtusu T tedeoeit p rnroppTedHeDss ducyTeRrppyc,oo=opd,cepo "

    const-string p0, "ToseesypprSpoRTTpe, cou ,re=spr pcrH tdtyD upeoDnodyeddi eedtoc"

    const/4 v6, 0x4

    const-string/jumbo p0, "isHDRDecodeTypeSupport, not support decoderType, decoderType = "

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v2, v1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    return v0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-ne p1, v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    sget-object p1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRTypeToHDRHardwareCodecWhiteListMap:Ljava/util/HashMap;

    const/4 v6, 0x5

    const/4 v5, 0x2

    goto :goto_1

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    sget-object p1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHDRTypeToHDRSoftwareCodecWhiteListMap:Ljava/util/HashMap;

    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p1, v3}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-nez v3, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string/jumbo p1, "hptTeh,p nodyd i=H S pmspT u, RoewrppeeyDittrgiytrooDcefcensLd T"

    const-string/jumbo p1, "hepmTpiiht pooto=t wrfiLn rDeiyHeSoye rcpc utysd gddp eeDT,RTns,"

    const/4 v6, 0x0

    const-string/jumbo p1, "o yneTdpqi T,wodgnprcieDyRhpfLptre reo= u otDHdstTs hhy ieeptS,i"

    const-string/jumbo p1, "isHDRDecodeTypeSupport, not config hdrType whiteList, hdrType = "

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    goto :goto_0

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p1, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x2

    check-cast p0, Ljava/util/ArrayList;

    const/4 v5, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isInHDRVersionRangeWhiteList(Ljava/util/ArrayList;)Z

    move-result p0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    return p0
.end method

.method public static isHDRsupport(III)Z
    .locals 5
    .annotation build Lcom/tencent/thumbplayer/core/common/TPMethodCalledByNative;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v0, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x3

    if-ne p0, v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isHDRDVSupport(II)Z

    move-result p0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    return p0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-nez p0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/16 p0, 0x1000

    const/4 v3, 0x0

    move v4, v3

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isHDR10Support(I)Z

    move-result p0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    return p0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 p1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-ne p0, p1, :cond_2

    const/4 v3, 0x7

    shr-int/2addr v4, v3

    const/16 p0, 0x2000

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isHDR10Support(I)Z

    move-result p0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    return p0

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 p1, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-ne p0, p1, :cond_3

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getDisplayVersion()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getSystemPatchVersion()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v1, ":Hssi(RiardssliDieHVv) nRitrdopDypvu:os"

    const-string/jumbo v1, "td(soiR:psaHlirDHsoiyV)eudvip iDsr:nRvo"

    const/4 v4, 0x2

    const-string/jumbo v1, "isom:ndippeHpR(Hs ravidssR)DDui:iVytvro"

    const-string/jumbo v1, "isHDRsupport(HDRVivid):display version:"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string v1, "bdsooUteiTPc"

    const-string v1, "coeidbCsTPUt"

    const/4 v4, 0x2

    const-string v1, "dUslCbPcieot"

    const-string v1, "TPCodecUtils"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {v0, v1, p2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v2, "hciVioupu:(dRpar)v :sHDsurpsitHtDoRnv"

    const-string v2, ":DtdonuV:uct(iHir )irsvshDoppRsHapRvi"

    const/4 v4, 0x3

    const-string/jumbo v2, "s:HHoriphitpe(RndsvDVDc u:ppi)toiaRvs"

    const-string/jumbo v2, "isHDRsupport(HDRVivid):patch version:"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v2, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v0, v1, p2}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p2, p0, p1}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->checkHDRVividSupportByVersion(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result p0

    const/4 v4, 0x6

    const/4 v3, 0x2

    return p0

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    return p0
.end method

.method public static isInDRMLevel1Blacklist(I)Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDrmL1BlackList:Ljava/util/HashMap;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    move v3, v2

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mDrmL1BlackList:Ljava/util/HashMap;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    check-cast p0, Ljava/util/ArrayList;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    return p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 p0, 0x0

    move v3, p0

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    return p0
.end method

.method private static isInHDRVersionRangeWhiteList(Ljava/util/ArrayList;)Z
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;",
            ">;)Z"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/4 v0, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-nez p0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x2

    return v0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    move v1, v0

    move v1, v0

    const/4 v6, 0x1

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-ge v1, v2, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x0

    check-cast v2, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget v4, v2, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->upperboundAndroidAPILevel:I

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-gt v3, v4, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget v2, v2, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->lowerboundAndroidAPILevel:I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-lt v3, v2, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string/jumbo p0, "tdPceiopqCUs"

    const-string p0, "cdesCotpiPTU"

    const/4 v6, 0x0

    const-string/jumbo p0, "tesscdUiloCP"

    const-string p0, "TPCodecUtils"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string/jumbo v0, "rotmV!niHRLiiDnteeWsnigqsae"

    const-string/jumbo v0, "tRVr!nigqineRHesDnoWstieLai"

    const/4 v6, 0x4

    const-string/jumbo v0, "sWtioRRhVeDnisrieage!Lontni"

    const-string/jumbo v0, "inHDRVersionRangeWhiteList!"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v1, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v1, p0, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v0, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    goto :goto_1

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_0

    :cond_2
    :goto_1
    return v0
.end method

.method public static isInHDRVividBlackList(Ljava/lang/String;II)Z
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdrBlackMap:Ljava/util/HashMap;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdrBlackMap:Ljava/util/HashMap;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    check-cast v0, Ljava/util/HashMap;

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    check-cast p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->upperboundSystemVersion:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-gt p1, v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->lowerboundSystemVersion:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    if-lt p1, v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->upperboundPatchVersion:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-gt p2, p1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget p0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->lowerboundPatchVersion:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-lt p2, p0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 p0, 0x1

    move v4, p0

    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    return p0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    return v2
.end method

.method public static isInHDRVividWhiteList(Ljava/lang/String;II)Z
    .locals 5

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdrWhiteMap:Ljava/util/HashMap;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v1, 0x4

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mHdrWhiteMap:Ljava/util/HashMap;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    check-cast v0, Ljava/util/HashMap;

    const/4 v3, 0x4

    move v4, v3

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    check-cast p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->upperboundSystemVersion:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-gt p1, v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->lowerboundSystemVersion:I

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-lt p1, v0, :cond_0

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget p1, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->upperboundPatchVersion:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-gt p2, p1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget p0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->lowerboundPatchVersion:I

    const/4 v3, 0x5

    shl-int/2addr v4, v3

    if-lt p2, p0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 p0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    return p0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    return v2
.end method

.method public static isInMediaCodecBlackList(Ljava/lang/String;)Z
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    shr-int/2addr v5, v4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x1

    if-nez v1, :cond_9

    const/4 v5, 0x7

    const/4 v4, 0x3

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mCodecCapBlackList:Ljava/util/HashMap;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v1, :cond_9

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v1, v0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v1, :cond_9

    const/4 v4, 0x4

    const/4 v4, 0x7

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mCodecCapBlackList:Ljava/util/HashMap;

    const/4 v4, 0x5

    xor-int/2addr v5, v4

    invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    check-cast v0, Ljava/lang/Integer;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string/jumbo v1, "iadvebocv"

    const-string/jumbo v1, "evsoivcad"

    const/4 v5, 0x2

    const-string/jumbo v1, "veciaouvd"

    const-string/jumbo v1, "video/avc"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v3, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    and-int/2addr p0, v3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz p0, :cond_9

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    move v2, v3

    move v2, v3

    move v2, v3

    move v2, v3

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    goto/16 :goto_1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string v1, "demcohip/v"

    const-string v1, "/cvmehdovi"

    const/4 v5, 0x6

    const-string v1, "ec/ivhdoqv"

    const-string/jumbo v1, "video/hevc"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    and-int/lit8 p0, p0, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz p0, :cond_9

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string v1, ".inpoon.2xdov-edv/v"

    const-string/jumbo v1, "video/x-vnd.on2.vp8"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    and-int/lit16 p0, p0, 0x100

    const/4 v5, 0x0

    if-eqz p0, :cond_9

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo v1, "nbsexv2o-.d/n.9ovvi"

    const-string v1, "doov9bx2nv.-ndi/v.e"

    const/4 v5, 0x2

    const-string v1, "9dvm-ind..p2nvx/ooe"

    const-string/jumbo v1, "video/x-vnd.on2.vp9"

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    if-eqz v1, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    and-int/lit8 p0, p0, 0x4

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz p0, :cond_9

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto/16 :goto_0

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string v1, "du/ao-oatu4lmam"

    const-string/jumbo v1, "oamamtu/au-dl4p"

    const/4 v5, 0x2

    const-string/jumbo v1, "mdp/-ba4aaouimt"

    const-string v1, "audio/mp4a-latm"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    if-eqz v1, :cond_4

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    and-int/lit8 p0, p0, 0x8

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz p0, :cond_9

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto/16 :goto_0

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string v1, "coiuad3pa"

    const/4 v5, 0x1

    const-string v1, "3/uoaauci"

    const-string v1, "audio/ac3"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v1, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    and-int/lit8 p0, p0, 0x10

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz p0, :cond_9

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto/16 :goto_0

    :cond_5
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string v1, "eciaq/opdu"

    const-string/jumbo v1, "iaodac/equ"

    const/4 v5, 0x0

    const-string v1, "deao3/ucqi"

    const-string v1, "audio/eac3"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz v1, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    and-int/lit8 p0, p0, 0x20

    const/4 v5, 0x3

    const/4 v4, 0x4

    if-eqz p0, :cond_9

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto/16 :goto_0

    :cond_6
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string v1, "casfaul/oi"

    const-string v1, "audio/flac"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v1, :cond_7

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    and-int/lit8 p0, p0, 0x40

    const/4 v4, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz p0, :cond_9

    const/4 v5, 0x7

    goto/16 :goto_0

    :cond_7
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v1, "dvtmndiaso.du"

    const-string/jumbo v1, "sosnutva.ddid"

    const/4 v5, 0x5

    const-string v1, "dddaooiuntsv."

    const-string v1, "audio/vnd.dts"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v1, :cond_8

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    and-int/lit16 p0, p0, 0x80

    if-eqz p0, :cond_9

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto/16 :goto_0

    :cond_8
    const/4 v5, 0x4

    const/4 v4, 0x1

    const-string v1, "/eoiobcm-aa3jc"

    const-string/jumbo v1, "oi/mcae-ado3jc"

    const/4 v5, 0x5

    const-string v1, "c3uooeuajiacd/"

    const-string v1, "audio/eac3-joc"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz p0, :cond_9

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    and-int/lit8 p0, p0, 0x20

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz p0, :cond_9

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto/16 :goto_0

    :cond_9
    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    return v2
.end method

.method public static isInMediaCodecWhiteList(Ljava/lang/String;)Z
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-nez v1, :cond_8

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mCodecCapWhiteList:Ljava/util/HashMap;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz v1, :cond_8

    const/4 v5, 0x4

    invoke-virtual {v1, v0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v1, :cond_8

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mCodecCapWhiteList:Ljava/util/HashMap;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    check-cast v0, Ljava/lang/Integer;

    const/4 v5, 0x7

    const-string v1, "a/vvciopo"

    const-string/jumbo v1, "vacio/dvo"

    const/4 v5, 0x2

    const-string v1, "caoidv/eq"

    const-string/jumbo v1, "video/avc"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v3, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    and-int/2addr p0, v3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz p0, :cond_8

    :goto_0
    const/4 v4, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    move v2, v3

    move v2, v3

    const/4 v5, 0x2

    move v2, v3

    move v2, v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    goto/16 :goto_1

    :cond_0
    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string v1, "edsevhvcio"

    const-string/jumbo v1, "video/hevc"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v1, :cond_1

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x2

    and-int/lit8 p0, p0, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz p0, :cond_8

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    const-string/jumbo v1, "ov2mepdi.v/on-d8bxn"

    const-string/jumbo v1, "p2onvbdx8v-enoi./dv"

    const/4 v5, 0x4

    const-string v1, "./ivo8vndxoepo.n-2d"

    const-string/jumbo v1, "video/x-vnd.on2.vp8"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v1, :cond_2

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x5

    const/4 v4, 0x0

    and-int/lit16 p0, p0, 0x100

    const/4 v4, 0x5

    move v5, v4

    if-eqz p0, :cond_8

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x1

    const-string/jumbo v1, "vovnxbp.-eu2o9.ddn/"

    const-string v1, "d2o9vduv-nop.vn/ex."

    const/4 v5, 0x2

    const-string/jumbo v1, "v-iv2nuon.dxe/do.pv"

    const-string/jumbo v1, "video/x-vnd.on2.vp9"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz v1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    and-int/lit8 p0, p0, 0x4

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz p0, :cond_8

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    goto/16 :goto_0

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-string v1, "audio/mp4a-latm"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v1, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    and-int/lit8 p0, p0, 0x8

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz p0, :cond_8

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto/16 :goto_0

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string/jumbo v1, "op/3adupi"

    const-string v1, "caoid/3pu"

    const/4 v5, 0x4

    const-string v1, "/aoai3udq"

    const-string v1, "audio/ac3"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v1, :cond_5

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x3

    const/4 v4, 0x0

    and-int/lit8 p0, p0, 0x10

    const/4 v5, 0x2

    if-eqz p0, :cond_8

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    goto/16 :goto_0

    :cond_5
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string v1, "ai3uadcoqe"

    const/4 v5, 0x5

    const-string v1, "/isacdoa3e"

    const-string v1, "audio/eac3"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v1, :cond_6

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    and-int/lit8 p0, p0, 0x20

    const/4 v5, 0x4

    const/4 v4, 0x6

    if-eqz p0, :cond_8

    const/4 v5, 0x1

    const/4 v4, 0x5

    goto/16 :goto_0

    :cond_6
    const/4 v5, 0x3

    const-string/jumbo v1, "uoamsd/lci"

    const-string v1, "aus/coilda"

    const-string/jumbo v1, "ial/ocodau"

    const-string v1, "audio/flac"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v1, :cond_7

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    and-int/lit8 p0, p0, 0x40

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz p0, :cond_8

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto/16 :goto_0

    :cond_7
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v1, "imasnbdd.dv/t"

    const-string v1, "dn.mdutiavsd/"

    const/4 v5, 0x4

    const-string/jumbo v1, "odaid.uvtnsdu"

    const-string v1, "audio/vnd.dts"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz p0, :cond_8

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x0

    and-int/lit16 p0, p0, 0x80

    if-eqz p0, :cond_8

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_8
    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    return v2
.end method

.method private static isLimitMaxWidthOrMaxHeight(IIIIII)Z
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v0, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-le p4, p5, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-gt p4, p0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-gt p5, p3, :cond_1

    :cond_0
    const/4 v5, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-ge p4, p5, :cond_4

    const/4 v6, 0x0

    if-gt p4, p2, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-le p5, p1, :cond_4

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-le p4, p5, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    mul-int/2addr p3, p0

    const/4 v6, 0x4

    goto :goto_0

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    mul-int p3, p2, p1

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string p2, "amH tegpxoh"

    const-string/jumbo p2, "tegHo aihxm"

    const/4 v6, 0x7

    const-string/jumbo p2, "hmi:xgtHqe "

    const-string p2, " maxHeight:"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string/jumbo v1, "h:sgb te"

    const-string/jumbo v1, "ge ihbt:"

    const/4 v6, 0x2

    const-string/jumbo v1, "g tmeih:"

    const-string v1, " height:"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string/jumbo v2, "udogo:FtdraeFRtspShwoueteram tip"

    const-string/jumbo v2, "umF gpuiatehs:rpordeFRSdwrtaetto"

    const/4 v6, 0x6

    const-string/jumbo v2, "tieFgbhdaes:rRrotwmdpSatFuop tre"

    const-string/jumbo v2, "getSupportedFrameRatesFor width:"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const-string v3, "dCPctlusTeoi"

    const-string v3, "TPCodecUtils"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-lt p0, p4, :cond_3

    const/4 v6, 0x2

    if-lt p1, p5, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    mul-int v4, p4, p5

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-lt p3, v4, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    invoke-direct {v4, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v4, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    move v6, v5

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v4, p5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string p4, " H mxomp oeiaShtpiuirmtdx omdutbmnalaxLdiptih,m mWtp ltmusm!:WgotLtaaama aLl x,uhi uires "

    const-string p4, " limit maxLumaWidth or maxLumaHeight, but not limit maxLumaSamples, do support! maxWidth:"

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v4, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string/jumbo p0, "pSs mlLmqaa:pmua"

    const-string/jumbo p0, "sa:mmalpSmpax Lu"

    const/4 v6, 0x6

    const-string/jumbo p0, "pssmaLamSaue:lmx"

    const-string p0, " maxLumaSamples:"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    invoke-virtual {v4, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 p1, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {p1, v3, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    return v0

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {p3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p3, p5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string p4, "Wm:mpxro q!situhoo an ddtp"

    const-string/jumbo p4, "pta sortqudodhmn W:pio x !"

    const/4 v6, 0x3

    const-string p4, "dapmorn x h!Wd: os tptioto"

    const-string p4, " do not support! maxWidth:"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x2

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 p1, 0x4

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-static {p1, v3, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 p0, 0x1

    const/4 v6, 0x0

    return p0

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    return v0
.end method

.method public static declared-synchronized isMediaCodecDDPlusSupported()Z
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const/4 v5, 0x0

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isAMediaCodecBlackListModel()Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    monitor-exit v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    return v2

    :cond_0
    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAMediaCodecCapList:Ljava/util/ArrayList;

    const/4 v5, 0x7

    const-string v3, "dc3a/buieo"

    const-string v3, "audio/eac3"

    const/4 v5, 0x6

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez v1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAMediaCodecCapList:Ljava/util/ArrayList;

    const/4 v4, 0x5

    and-int/2addr v5, v4

    const-string/jumbo v3, "o-io/dua3ucjca"

    const-string v3, "audio/eac3-joc"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    return v2

    :cond_2
    :goto_0
    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    monitor-exit v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v0, 0x1

    const/4 v5, 0x2

    return v0

    :catchall_0
    move-exception v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    monitor-exit v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    throw v1
.end method

.method public static declared-synchronized isMediaCodecDolbyDSSupported()Z
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const/4 v4, 0x4

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->isAMediaCodecBlackListModel()Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    return v0

    :cond_0
    :try_start_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mAMediaCodecCapList:Ljava/util/ArrayList;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string/jumbo v2, "u3/iaaopd"

    const-string v2, "3is/oadau"

    const/4 v4, 0x0

    const-string v2, "audio/ac3"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    return v1

    :catchall_0
    move-exception v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    throw v1
.end method

.method private static isSupportedMediaCodec(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mSupportedMediaCodec:Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    return p0
.end method

.method private static isTheSameVersionRange(Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;)Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->lowerboundPatchVersion:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    iget v1, p1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->lowerboundPatchVersion:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->lowerboundSystemVersion:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v1, p1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->lowerboundSystemVersion:I

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->upperboundPatchVersion:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget v1, p1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->upperboundPatchVersion:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget p0, p0, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->upperboundSystemVersion:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget p1, p1, Lcom/tencent/thumbplayer/core/common/TPCodecCapability$TPHdrSupportVersionRange;->upperboundSystemVersion:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-ne p0, p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 p0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    return p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    return p0
.end method

.method public static isVMediaCodecBlackListModel()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVMediaCodecBlackListModel:Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    return v0
.end method

.method private static replace(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/HashMap;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "T:",
            "Ljava/lang/Object;",
            ">(TK;TT;",
            "Ljava/util/HashMap<",
            "TK;TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p2, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    invoke-virtual {p2, p0}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p2, p0, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p2, p0, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method private static selectBestDecodeLevelFromCapabilityTable(III)I
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    sget-object v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mVideoCodecIdToSwCapabilityModel:Landroid/util/SparseArray;

    const/4 v8, 0x6

    invoke-virtual {v0, p0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    check-cast v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel;

    const/4 v7, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string/jumbo v1, "ocPemCdiqlUT"

    const-string/jumbo v1, "oiCmlPtecUdT"

    const/4 v8, 0x1

    const-string/jumbo v1, "ilsPTdtesocC"

    const-string v1, "TPCodecUtils"

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/4 v2, 0x3

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    const/4 v3, -0x1

    const/4 v8, 0x7

    const/4 v7, 0x5

    if-nez v0, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string/jumbo p1, "nipm ee, gfcdooocciudnoNocdIod:do sr  erd"

    const-string p1, ",odfoipddgooeeNcr:os oc drdc   ounneIcdci"

    const/4 v8, 0x1

    const-string/jumbo p1, "rd :odegocNcspdcnoc i iId,nn o ofoedoruce"

    const-string p1, "No corresponding codec id found, codecId:"

    const/4 v8, 0x5

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {v2, v1, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    return v3

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    iget-object p0, v0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$VideoSwCapabilityModel;->mCpuProducerToAllDefinitionDecTable:Landroid/util/SparseArray;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    check-cast p0, Ljava/util/HashMap;

    const/4 v7, 0x7

    move v8, v7

    if-eqz p0, :cond_4

    const/4 v8, 0x7

    invoke-virtual {p0}, Ljava/util/HashMap;->isEmpty()Z

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-eqz v0, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    goto :goto_2

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;->values()[Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    array-length v1, v0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v2, 0x0

    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-ge v2, v1, :cond_3

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    aget-object v4, v0, v2

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p0, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    check-cast v5, Ljava/lang/String;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-nez v6, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-static {p1, v5}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getCpuHWProductIndex(ILjava/lang/String;)I

    move-result v5

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-lt p2, v5, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {v4}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->convertDefinitionNameToDecodeLevel(Lcom/tencent/thumbplayer/core/common/TPCodecUtils$DefinitionName;)I

    move-result p0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    return p0

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_1

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    return v3

    :cond_4
    :goto_2
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-string p0, "curgnboifupp,epduHcopPc eo brornnrdwruodr: oeucdNsc"

    const-string/jumbo p0, "prdo bccro :unnensprreuePfoNwpdu iud,rood opHucgrcc"

    const/4 v8, 0x4

    const-string/jumbo p0, "r: oHgucrrNcp e dionu rcoer,nppuPdwocfcornoeusuupd "

    const-string p0, "No corresponding cpu producer found, cpuHwProducer:"

    const/4 v8, 0x2

    const/4 v7, 0x6

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    goto/16 :goto_0
.end method

.method public static setMediaCodecPreferredSoftwareComponent(Z)V
    .locals 2

    sput-boolean p0, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->mPreferredSoftwareComponent:Z

    const/4 v1, 0x5

    const/4 v0, 0x7

    return-void
.end method
