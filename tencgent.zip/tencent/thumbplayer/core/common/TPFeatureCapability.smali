.class public Lcom/tencent/thumbplayer/core/common/TPFeatureCapability;
.super Ljava/lang/Object;


# static fields
.field private static TAG:Ljava/lang/String; = "TPFeatureCapability"

.field private static mIsLibLoaded:Z


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryLoader;->loadLibIfNeeded(Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    sput-boolean v0, Lcom/tencent/thumbplayer/core/common/TPFeatureCapability;->mIsLibLoaded:Z
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    return-void

    :catch_0
    move-exception v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    sput-boolean v0, Lcom/tencent/thumbplayer/core/common/TPFeatureCapability;->mIsLibLoaded:Z

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method private static native _isFeatureSupport(I)Z
.end method

.method public static isFeatureSupport(I)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@osoa   oo~@s@@~rbt y@@~~if/@@m u~v@@4@d ~@ @~tf-   ~@~Sn@  ~1 @M~~~~b@o/cbli~i~~~~~@ ~ @@ ~l. o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPFeatureCapability;->isLibLoaded()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPFeatureCapability;->_isFeatureSupport(I)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    return p0

    :catchall_0
    move-exception p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {v0, p0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string/jumbo v0, "uSlmdrulratesF a _tslo piopieaeFt"

    const-string v0, "casrtiloalF dppsSir oateuFe_ltue "

    const/4 v2, 0x4

    const-string v0, "aut o_ larFp spteFuocllaSdrt.oiei"

    const-string v0, "Failed to call _isFeatureSupport."

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x3

    and-int/2addr v2, v1

    throw p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    new-instance p0, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const-string/jumbo v0, "ip:a buadbaFi ilt.Fro tmilateprtesoednluryaoS  e"

    const-string v0, " tamllveeFe:erioaar tlt.o u dpSbiniradsFuoitay p"

    const/4 v2, 0x5

    const-string/jumbo v0, "vbaerluFdpFr oaaeiriuerelyadtioa.ls :t t i nptSo"

    const-string/jumbo v0, "isFeatureSupport: Failed to load native library."

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLibraryException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    throw p0
.end method

.method private static isLibLoaded()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-boolean v0, Lcom/tencent/thumbplayer/core/common/TPFeatureCapability;->mIsLibLoaded:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method
