.class public Lcom/tencent/thumbplayer/core/common/TPCodecID;
.super Ljava/lang/Object;


# static fields
.field public static final TP_CODEC_ID_AAC:I = 0x138a

.field public static final TP_CODEC_ID_AC3:I = 0x138b

.field public static final TP_CODEC_ID_AV1:I = 0x405

.field public static final TP_CODEC_ID_AVS3:I = 0xc0

.field public static final TP_CODEC_ID_DTS:I = 0x138c

.field public static final TP_CODEC_ID_EAC3:I = 0x13b0

.field public static final TP_CODEC_ID_FLAC:I = 0x1394

.field public static final TP_CODEC_ID_H264:I = 0x1a

.field public static final TP_CODEC_ID_HEVC:I = 0xac

.field public static final TP_CODEC_ID_NONE:I = -0x1

.field public static final TP_CODEC_ID_VP8:I = 0x8a

.field public static final TP_CODEC_ID_VP9:I = 0xa6

.field public static final TP_CODEC_ID_VVC:I = 0xc1


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method
