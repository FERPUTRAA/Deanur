.class public Lcom/tencent/thumbplayer/core/common/TPCodecLimits;
.super Ljava/lang/Object;


# static fields
.field public static final maxHeight:I = -0x1

.field public static final maxWidth:I = -0x1


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method
