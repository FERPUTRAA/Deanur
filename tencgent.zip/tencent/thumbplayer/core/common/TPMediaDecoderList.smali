.class public final Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;
.super Ljava/lang/Object;


# static fields
.field private static final MEDIA_DECODER_INFO_KEY:Ljava/lang/String; = "DecoderInfos_Key"

.field private static MEDIA_DECODER_VERSION:Ljava/lang/String; = "2.31.0.134.min"

.field private static final MEDIA_DECODER_VERSION_KEY:Ljava/lang/String; = "Version_Key"

.field private static final TAG:Ljava/lang/String; = "TPMediaDecoderList"

.field private static sDecoderInfos:[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method private static buildCacheDecoderVersion()Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "ayslb~~rv so ~o id@ ~moSfi~- / @@@u@.n~o~~~if~ c@@~@~o~@@@@l~ @M  ~~~@ @@~  b4o t1~/@~Kb~ @  @~t"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->MEDIA_DECODER_VERSION:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const-string v1, "_"

    const-string v1, "_"

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getDeviceName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getProductBoard()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getProductDevice()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPSystemInfo;->getApiLevel()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-object v0
.end method

.method private static cacheDecoderInfos(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x1

    const-string v0, "Knsse_yfceeoDIdo"

    const/4 v2, 0x0

    const-string/jumbo v0, "ysdmceInDKoerof_"

    const-string v0, "DecoderInfos_Key"

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, v0, p1}, Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;->put(Ljava/lang/String;Ljava/io/Serializable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void

    :catchall_0
    const/4 v2, 0x4

    const-string p0, "TdDPoetiicroemsdeM"

    const-string p0, "ceemDPeaTrdtMiisod"

    const/4 v2, 0x7

    const-string p0, "dTdDibiraLeeMtePso"

    const-string p0, "TPMediaDecoderList"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const-string/jumbo p1, "he c euceinasa fedofolcid"

    const-string p1, "cache decode infos failed"

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {v0, p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method private static cacheVersion(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;Ljava/lang/String;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string v0, "ernKoiopsV_"

    const-string/jumbo v0, "senVoiKyr_o"

    const/4 v2, 0x3

    const-string/jumbo v0, "s_irneeyqVK"

    const-string v0, "Version_Key"

    const/4 v1, 0x7

    shl-int/2addr v2, v1

    invoke-virtual {p0, v0, p1}, Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;->put(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    return-void

    :catchall_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string p0, "DdsairoLecMdTtbese"

    const-string p0, "MrectbodLiTsediaeD"

    const/4 v2, 0x4

    const-string p0, "aPemDeridtidcsoTLM"

    const-string p0, "TPMediaDecoderList"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string p1, "cache version failed"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0, p0, p1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method private static getCachedDecoderInfos(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;
    .locals 4

    :try_start_0
    const/4 v3, 0x1

    const-string v0, "enrsfIudyeDK_oeo"

    const/4 v3, 0x0

    const-string/jumbo v0, "feoeonye_IcdDsKo"

    const-string v0, "DecoderInfos_Key"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;->getAsObject(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast p0, [Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    return-object p0

    :catchall_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string p0, "MderabLiDpdeistPcT"

    const-string/jumbo p0, "oPitdeLpMTdiacrseD"

    const/4 v3, 0x7

    const-string p0, "dtePDiuacisTeoreLd"

    const-string p0, "TPMediaDecoderList"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string/jumbo v0, "fao  deptdfdceleqigenor"

    const-string v0, "edoat niqrc lfdodeefieg"

    const/4 v3, 0x5

    const-string/jumbo v0, "geeid dtq cdo refnefoal"

    const-string/jumbo v0, "get decoder info failed"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v1, p0, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x3

    return-object p0
.end method

.method private static getCachedVersion(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const-string/jumbo v0, "sostseiMrdeaieDdTL"

    const-string/jumbo v0, "tesTseDidMoLidPrea"

    const/4 v4, 0x6

    const-string v0, "LePmdisTcdoeMaDeit"

    const-string v0, "TPMediaDecoderList"

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v1, "sm_eoVKeyin"

    const-string/jumbo v1, "ie_msyoKVen"

    const/4 v4, 0x5

    const-string/jumbo v1, "iysr_beneVo"

    const-string v1, "Version_Key"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0, v1}, Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;->getAsString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v1, "rsiooeuv"

    const-string/jumbo v1, "rinoosve"

    const/4 v4, 0x0

    const-string v1, "e:osvrip"

    const-string/jumbo v1, "version:"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {v2, v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object p0

    :catchall_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 p0, 0x4

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v1, "aivbtnefqg sdorl e"

    const-string/jumbo v1, "leoaibnsedvgirft  "

    const/4 v4, 0x1

    const-string/jumbo v1, "fsst adl onveegiir"

    const-string/jumbo v1, "get version failed"

    const/4 v3, 0x5

    move v4, v3

    invoke-static {p0, v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 p0, 0x1

    const/4 p0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object p0
.end method

.method private static final getCodecInfos()[Landroid/media/MediaCodecInfo;
    .locals 5

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Landroid/media/MediaCodecList;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v0, v1}, Landroid/media/MediaCodecList;-><init>(I)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroid/media/MediaCodecList;->getCodecInfos()[Landroid/media/MediaCodecInfo;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object v0

    :catch_0
    move-exception v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    move v4, v3

    const-string/jumbo v2, "iodmeu LoCtioess edgeIccCtdMa"

    const-string/jumbo v2, "si edouLIdeMccegiCotsan tdCeo"

    const/4 v4, 0x3

    const-string/jumbo v2, "getCodecInfos MediaCodecList "

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v1, 0x4

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-array v0, v0, [Landroid/media/MediaCodecInfo;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object v0
.end method

.method private static final getLocalCacheMediaCodecList(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string v0, "MecCLiipaoctLCoaehgelsdaedt"

    const/4 v4, 0x3

    const-string v0, "aedeoecatdhictloeLMsCLcogiC"

    const-string/jumbo v0, "getLocalCacheMediaCodecList"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v1, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->getCachedVersion(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->buildCacheDecoderVersion()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v0, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->getCachedDecoderInfos(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz p0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v2, "reI hbf ldgocqecetDsteCndohge"

    const-string v2, "c edornCqfnlhthedstoe DeggIce"

    const/4 v4, 0x4

    const-string/jumbo v2, "ldgh ouDIfcgdnerc shtetoeeCen"

    const-string/jumbo v2, "getCachedDecoderInfos length "

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    array-length v2, p0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object p0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 p0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object p0
.end method

.method private static final getSystemMediaCodecList()[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;
    .locals 15

    const/4 v14, 0x4

    const-string v0, "emtgSsipMsCysotaeiLcede"

    const-string v0, "asstdeLoceesMCetSyidgim"

    const-string v0, "dMietoamqteSgidsyesCLte"

    const-string/jumbo v0, "getSystemMediaCodecList"

    const/4 v14, 0x1

    const/4 v1, 0x2

    const/4 v14, 0x3

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v14, 0x4

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->getCodecInfos()[Landroid/media/MediaCodecInfo;

    move-result-object v0

    const/4 v14, 0x5

    if-nez v0, :cond_0

    const/4 v14, 0x2

    const/4 v0, 0x0

    const/4 v14, 0x5

    return-object v0

    :cond_0
    const/4 v14, 0x0

    new-instance v2, Ljava/util/ArrayList;

    const/4 v14, 0x4

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    array-length v3, v0

    const/4 v14, 0x3

    const/4 v4, 0x0

    const/4 v14, 0x6

    move v5, v4

    move v5, v4

    move v5, v4

    move v5, v4

    :goto_0
    const/4 v14, 0x5

    if-ge v5, v3, :cond_3

    const/4 v14, 0x0

    aget-object v6, v0, v5

    invoke-virtual {v6}, Landroid/media/MediaCodecInfo;->isEncoder()Z

    move-result v7

    const/4 v14, 0x4

    if-nez v7, :cond_2

    invoke-virtual {v6}, Landroid/media/MediaCodecInfo;->getSupportedTypes()[Ljava/lang/String;

    move-result-object v7

    const/4 v14, 0x7

    array-length v8, v7

    const/4 v14, 0x2

    move v9, v4

    move v9, v4

    move v9, v4

    move v9, v4

    :goto_1
    const/4 v14, 0x6

    if-ge v9, v8, :cond_2

    const/4 v14, 0x6

    aget-object v10, v7, v9

    const/4 v14, 0x4

    new-instance v11, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    const/4 v14, 0x1

    invoke-virtual {v6}, Landroid/media/MediaCodecInfo;->getName()Ljava/lang/String;

    move-result-object v12

    const/4 v14, 0x7

    invoke-virtual {v6, v10}, Landroid/media/MediaCodecInfo;->getCapabilitiesForType(Ljava/lang/String;)Landroid/media/MediaCodecInfo$CodecCapabilities;

    move-result-object v13

    const/4 v14, 0x1

    invoke-direct {v11, v10, v12, v13}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;-><init>(Ljava/lang/String;Ljava/lang/String;Landroid/media/MediaCodecInfo$CodecCapabilities;)V

    const/4 v14, 0x3

    invoke-virtual {v11}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;->isValidDecoder()Z

    move-result v12

    const/4 v14, 0x2

    if-eqz v12, :cond_1

    const/4 v14, 0x0

    new-instance v12, Ljava/lang/StringBuilder;

    const/4 v14, 0x4

    const-string v13, "eosocdcmieLCeadN aemdsMic"

    const-string v13, "diamooeecaCNeM se imdcLdc"

    const-string v13, "MediaCodecList codecName "

    const/4 v14, 0x2

    invoke-direct {v12, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6}, Landroid/media/MediaCodecInfo;->getName()Ljava/lang/String;

    move-result-object v13

    const/4 v14, 0x7

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v13, "potm  edeorpTus"

    const-string/jumbo v13, "putrodsoe pT pe"

    const-string v13, "eoetoppdrTpyu s"

    const-string v13, " supportedType "

    const/4 v14, 0x0

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x0

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    const/4 v14, 0x0

    invoke-static {v1, v10}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v14, 0x6

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v14, 0x5

    add-int/lit8 v9, v9, 0x1

    const/4 v14, 0x2

    goto :goto_1

    :cond_2
    const/4 v14, 0x4

    add-int/lit8 v5, v5, 0x1

    const/4 v14, 0x5

    goto :goto_0

    :cond_3
    const/4 v14, 0x2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v14, 0x2

    new-array v0, v0, [Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    const/4 v14, 0x7

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v14, 0x1

    check-cast v0, [Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    return-object v0
.end method

.method public static final declared-synchronized getTPMediaDecoderInfos(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;

    const/4 v3, 0x2

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;

    const-class v0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object v1, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->sDecoderInfos:[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-nez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->initCodecList(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    sput-object p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->sDecoderInfos:[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    sget-object p0, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->sDecoderInfos:[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez p0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-array p0, p0, [Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    return-object p0

    :cond_1
    :try_start_1
    const/4 v2, 0x4

    const/4 v3, 0x5

    array-length v1, p0

    invoke-static {p0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    check-cast p0, [Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    throw p0
.end method

.method private static final initCodecList(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p0}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->getLocalCacheMediaCodecList(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;)[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->getSystemMediaCodecList()[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->storeLocalCacheMediaCodecList(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;)V

    :cond_0
    const/4 v1, 0x6

    move v2, v1

    return-object v0
.end method

.method private static final storeLocalCacheMediaCodecList(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v0, 0x2

    const/4 v3, 0x6

    const-string/jumbo v1, "itsclbcoCeoereohdtMabeaCLsdaL"

    const-string/jumbo v1, "scLaebaeeohLeoCcrdtaidtCislMo"

    const/4 v3, 0x2

    const-string v1, "cesldeuadtLoaChceoscCaiLeMitr"

    const-string/jumbo v1, "storeLocalCacheMediaCodecList"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->cacheDecoderInfos(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;[Lcom/tencent/thumbplayer/core/common/TPMediaDecoderInfo;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->buildCacheDecoderVersion()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p0, p1}, Lcom/tencent/thumbplayer/core/common/TPMediaDecoderList;->cacheVersion(Lcom/tencent/thumbplayer/core/thirdparties/LocalCache;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method
