.class public Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;
.super Ljava/lang/Object;


# static fields
.field public static final TP_NATIVE_MEDIA_CONTAINER_TYPE_DASH:I = 0x2

.field public static final TP_NATIVE_MEDIA_CONTAINER_TYPE_HLS:I = 0x1

.field public static final TP_NATIVE_MEDIA_CONTAINER_TYPE_UNKNOWN:I = 0x0

.field public static final TP_NATIVE_MEDIA_TRACK_TYPE_AUDIO:I = 0x2

.field public static final TP_NATIVE_MEDIA_TRACK_TYPE_SUBTITLE:I = 0x3

.field public static final TP_NATIVE_MEDIA_TRACK_TYPE_UNKNOW:I = 0x0

.field public static final TP_NATIVE_MEDIA_TRACK_TYPE_VIDEO:I = 0x1


# instance fields
.field public contianerType:I

.field public dashFormat:Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;

.field public hlsTag:Lcom/tencent/thumbplayer/core/common/TPMediaTrackHlsTag;

.field public isExclusive:Z

.field public isInternal:Z

.field public isSelected:Z

.field public trackName:Ljava/lang/String;

.field public trackType:I


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    const/4 v0, 0x0

    xor-int/2addr v3, v0

    const/4 v2, 0x0

    or-int/2addr v3, v2

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->trackType:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->contianerType:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->isSelected:Z

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-boolean v1, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->isExclusive:Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-boolean v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->isInternal:Z

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackHlsTag;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/common/TPMediaTrackHlsTag;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->hlsTag:Lcom/tencent/thumbplayer/core/common/TPMediaTrackHlsTag;

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {v0}, Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/thumbplayer/core/common/TPMediaTrackInfo;->dashFormat:Lcom/tencent/thumbplayer/core/common/TPMediaTrackDashFormat;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method
