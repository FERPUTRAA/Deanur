.class final Lcom/tencent/thumbplayer/core/common/TPCodecUtils$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getDecoderMaxCapabilityMapAsync()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~lsS~aotd@ ~~@i @@~@@ b@ obmo ~ @i ~.l Mv~@bt  ~ ~~@@~~@K~~~r@ of@n~~sy@o@/~@/o 4c@f@1-~u~  ~ i@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getVMediaCodecMaxCapabilityMap()Ljava/util/HashMap;

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getAMediaCodecMaxCapabilityMap()Ljava/util/HashMap;

    const/4 v4, 0x1

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getVCodecSWMaxCapabilityMap()Ljava/util/HashMap;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->getACodecSWMaxCapabilityMap()Ljava/util/HashMap;

    const/4 v0, 0x2

    or-int/2addr v4, v0

    const/4 v0, 0x1

    move v4, v0

    const/4 v3, 0x6

    move v4, v3

    invoke-static {v0}, Lcom/tencent/thumbplayer/core/common/TPCodecUtils;->access$102(Z)Z

    const/4 v4, 0x6

    const-string v0, "cidmstCsPTlU"

    const-string/jumbo v0, "tTsCdsUielcP"

    const/4 v4, 0x6

    const-string v0, "CtoloPTdciUs"

    const-string v0, "TPCodecUtils"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v1, "ntagibprioeDddxeet aenM  erClMocdaehaymwap"

    const-string/jumbo v1, "ioimahtdMete rrcaaenCaodg aMweepxtpel yDnd"

    const/4 v4, 0x5

    const-string/jumbo v1, "yredbhuarwDaeeoin  CxlatpcgeiMopa tendadMe"

    const-string/jumbo v1, "new thread getDecoderMaxCapabilityMap done"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v2, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v2, v0, v1}, Lcom/tencent/thumbplayer/core/common/TPNativeLog;->printLog(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method
