.class public Lcom/tencent/thumbplayer/b/g;
.super Lcom/tencent/thumbplayer/b/d;

# interfaces
.implements Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;
.implements Ljava/io/Serializable;


# instance fields
.field private a:I

.field private b:I

.field private c:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(I)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/tencent/thumbplayer/b/d;-><init>()V

    const/4 v2, 0x2

    const/4 v0, -0x7

    const/4 v2, 0x1

    const/4 v0, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/b/g;->a:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput p1, p0, Lcom/tencent/thumbplayer/b/g;->b:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance p1, Ljava/util/ArrayList;

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/tencent/thumbplayer/b/d;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lcom/tencent/thumbplayer/b/g;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p2, p0, Lcom/tencent/thumbplayer/b/g;->b:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    new-instance p1, Ljava/util/ArrayList;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v1, 0x4

    return-void
.end method

.method private declared-synchronized a(Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ls@iibo~@ ~.~uSb/@ @@ c@@d  14~  n~f/~ ti@o~~~~a@~ r@sf@@~v~@~-@ Moo ~~l~o o~ @~ @~@@t@ ymK b ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    monitor-enter p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz p1, :cond_1

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;->getMediaType()I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lcom/tencent/thumbplayer/b/g;->b:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    if-ne p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void

    :cond_0
    :try_start_1
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string/jumbo v0, "t, msmclea tafpilddoiaienpa  tcm ss yi d kdea"

    const-string v0, " dskaael epadmediepios fscc    ,tatita lnmydi"

    const/4 v2, 0x1

    const-string/jumbo v0, "tasdo aic tykdortiplcp eaeeaml,n mi e fad s d"

    const-string v0, "add track clip failed, media type is not same"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    throw p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    goto :goto_0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-string v0, "dcap bb c allrunn  mceitt,idkcp anoll"

    const-string/jumbo v0, "tp mnrlkc i, aodtudlac bccelnn p ia l"

    const/4 v2, 0x0

    const-string/jumbo v0, "p  kuru,ocpltntiaclni c ldea  d blc a"

    const-string v0, "add track clip , clip can not be null"

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v2, 0x1

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x4

    throw p1
.end method


# virtual methods
.method public declared-synchronized addTrackClip(Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;)I
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/b/g;->a(Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string/jumbo v0, "ioiaoctTnCdipoomeMTskPr"

    const/4 v4, 0x2

    const-string v0, "TisoetapirnTdoiopkaMCPm"

    const-string v0, "TPMediaCompositionTrack"

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string v2, "ax a  paqrtlse dylde,cdls rii bc:kf lid aiecp"

    const-string/jumbo v2, "t rycbdfeladk s ixi e e:apd rlsipcali al,ca d"

    const/4 v4, 0x7

    const-string v2, " ss:cekdtr aecp c ai tdlal iafydxsip,di le al"

    const-string v2, "add track clip failed, clip already exists : "

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getClipId()I

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getClipId()I

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    monitor-exit p0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    return p1

    :cond_0
    :try_start_1
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getClipId()I

    move-result p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    monitor-exit p0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    return p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    monitor-exit p0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    throw p1
.end method

.method public declared-synchronized getAllTrackClips()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    monitor-exit p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    throw v0
.end method

.method public declared-synchronized getMediaType()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    iget v0, p0, Lcom/tencent/thumbplayer/b/g;->b:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    throw v0
.end method

.method public declared-synchronized getTimelineDurationMs()J
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v6, 0x3

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz v3, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    check-cast v3, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-interface {v3}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getOriginalDurationMs()J

    move-result-wide v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    add-long/2addr v1, v3

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    monitor-exit p0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    return-wide v1

    :catchall_0
    move-exception v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized getTrackClip(I)Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;
    .locals 5

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    check-cast v1, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {v1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getClipId()I

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-ne v2, p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    monitor-exit p0

    const/4 v3, 0x7

    move v4, v3

    return-object v1

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    monitor-exit p0

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 p1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x3

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    monitor-exit p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    throw p1
.end method

.method public declared-synchronized getTrackId()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/b/g;->a:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    throw v0
.end method

.method public declared-synchronized getUrl()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x5

    move v3, v2

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget v1, p0, Lcom/tencent/thumbplayer/b/g;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-static {v0, v1}, Lcom/tencent/thumbplayer/b/i;->a(Ljava/util/List;I)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    monitor-exit p0

    const/4 v3, 0x7

    const/4 v2, 0x0

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :catch_0
    move-exception v0

    :try_start_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo v1, "oiTmiasMcaedrCnkTmuPiot"

    const-string/jumbo v1, "iMitnPuTokoicerdCsaaomT"

    const/4 v3, 0x3

    const-string v1, "TcomorCiPMpkTeaoisdtiao"

    const-string v1, "TPMediaCompositionTrack"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    monitor-exit p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    throw v0
.end method

.method public declared-synchronized insertTrackClip(Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;I)I
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/thumbplayer/b/g;->a(Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo p2, "keoMdTPppacniTmiiaCsoto"

    const/4 v4, 0x3

    const-string p2, "eodiobTiakMoCrctPipnasT"

    const-string p2, "TPMediaCompositionTrack"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v1, "cire,lul  ixklc  asd aayia i:qsdrd eptlefaptc"

    const-string v1, "clacyitaq:txppss,eal fdlc  i e  erilakrda i d"

    const/4 v4, 0x3

    const-string/jumbo v1, "sa  ee:pia,c pliy  acadt  xdladcfdprlt sirekl"

    const-string v1, "add track clip failed, clip already exists : "

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getClipId()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {p2, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getClipId()I

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    monitor-exit p0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    return p1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v0, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-ne p2, v0, :cond_1

    :try_start_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object p2, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {p2, v1, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getClipId()I

    move-result p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    monitor-exit p0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    return p1

    :cond_1
    :try_start_2
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-ge v1, v0, :cond_3

    iget-object v2, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    check-cast v2, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {v2}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getClipId()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-ne v2, p2, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object p2, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {p2, v1, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getClipId()I

    move-result p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v3, 0x2

    move v4, v3

    monitor-exit p0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    return p1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_0

    :cond_3
    :try_start_3
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v0, "CooesaniqpkorPtTMadTisc"

    const-string/jumbo v0, "tosrakepascnodTPiTiiMoC"

    const/4 v4, 0x2

    const-string/jumbo v0, "omspnMorsikaTciPCiTeaod"

    const-string v0, "TPMediaCompositionTrack"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo v1, "pntmknod   l ,t ztlecemo c dtf:rpe noocfa nnsiurti aec ihi"

    const-string/jumbo v1, "lcfmoe e  echt e pi f,ontnn ti nncaitzoipr dcdoalts u :krt"

    const/4 v4, 0x4

    const-string/jumbo v1, "ifliot, eattr eap :ohniftro ezktccpden  cnocn i s trd  lon"

    const-string/jumbo v1, "insert track clip into the end, coz after clip not found :"

    const/4 v3, 0x1

    const/4 v3, 0x3

    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {v0, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getClipId()I

    move-result p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    monitor-exit p0

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    return p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    monitor-exit p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    throw p1
.end method

.method public declared-synchronized removeAllTrackClips()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/List;->clear()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    throw v0
.end method

.method public declared-synchronized removeTrackClip(Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    monitor-enter p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    return p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    :try_start_1
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string v0, "apenmbeclcullv o c  icilo robn,pkn tart "

    const-string/jumbo v0, "pntroenp cl  atekm caile ccuoolbr, i vnl"

    const/4 v2, 0x3

    const-string/jumbo v0, "remove track clip , clip can not be null"

    const/4 v1, 0x4

    or-int/2addr v2, v1

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    move v2, v1

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    throw p1
.end method

.method public declared-synchronized swapTrackClip(II)Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    monitor-enter p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-ltz p1, :cond_3

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-lt p1, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-ltz p2, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-lt p2, v1, :cond_1

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/g;->c:Ljava/util/List;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0, p1, p2}, Ljava/util/Collections;->swap(Ljava/util/List;II)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    monitor-exit p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x2

    move v3, v2

    return p1

    :cond_2
    :goto_0
    :try_start_1
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo p1, "kcrTpTuMCbPoitnmsiideao"

    const-string p1, "McTCnbtoTeiaidmpoPksiro"

    const/4 v3, 0x2

    const-string p1, "anaModrpsektopiPTCiiTmc"

    const-string p1, "TPMediaCompositionTrack"

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    const-string/jumbo v1, "f,iaolipq,idooslw ul  cp dinppo sv st  ae t"

    const-string v1, ",dfnstul o wpa pvpc  s dolstlai io, ii peoa"

    const/4 v3, 0x3

    const-string/jumbo v1, "i swlsipn, dlvpo  o: ,aa sf t ocepip aoistl"

    const-string/jumbo v1, "swap clip failed, to pos invalid , to pos :"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v1, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p1, p2}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->w(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x0

    const/4 v3, 0x5

    monitor-exit p0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    return v0

    :cond_3
    :goto_1
    :try_start_2
    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string p2, "CadmioToMsroPatppTnmiki"

    const-string p2, "adkiarMpispiTPtmeCooonT"

    const-string p2, "TmeootoiapiikrnoMacCTsP"

    const-string p2, "TPMediaCompositionTrack"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo v1, "spsa bo miapo,maq l,pfw olp:f d  v doe crilsi fi"

    const-string/jumbo v1, "foln i sqwf po r ldv csad:f ,so , mpapl iaeopiim"

    const/4 v3, 0x0

    const-string/jumbo v1, "mis,dfupcp ii ldoowapn:opiv   f fae ,loms rlas  "

    const-string/jumbo v1, "swap clip failed, from pos invalid , from pos : "

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p2, p1}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->w(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    monitor-exit p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    return v0

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    monitor-exit p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    throw p1
.end method
