.class public Lcom/tencent/thumbplayer/b/l;
.super Lcom/tencent/thumbplayer/b/d;

# interfaces
.implements Lcom/tencent/thumbplayer/api/composition/ITPMediaUrlAsset;


# instance fields
.field private a:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/thumbplayer/b/d;-><init>()V

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/b/l;->a:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x1

    return-void
.end method


# virtual methods
.method public getMediaType()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public getStreamUrl()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/l;->a:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public getUrl()Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/tencent/thumbplayer/b/i;->a(Lcom/tencent/thumbplayer/api/composition/ITPMediaUrlAsset;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0

    :catch_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string v1, "MesdTAseUislast"

    const-string/jumbo v1, "sAseritTsMleaUd"

    const/4 v3, 0x7

    const-string v1, "TUMmitAaesrePdl"

    const-string v1, "TPMediaUrlAsset"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0
.end method

.method public setStreamUrl(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/thumbplayer/b/l;->a:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method
