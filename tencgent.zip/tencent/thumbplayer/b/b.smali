.class public Lcom/tencent/thumbplayer/b/b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetExtraParam;


# instance fields
.field private a:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/io/Serializable;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/b/b;->a:Ljava/util/HashMap;

    const/4 v2, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public getExtraInt(Ljava/lang/String;)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@rso~~~f~o o~o~ y  S~@af @~4@o/ ibli@~n~@~~ @od@-c.l~ t@@ t@ 1@~ v  @~~iK@~ @bub/~~ m@~@@@  ~@Ms"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/b;->a:Ljava/util/HashMap;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/b;->a:Ljava/util/HashMap;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    check-cast p1, Ljava/io/Serializable;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    check-cast p1, Ljava/lang/Integer;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return p1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 p1, -0x1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return p1
.end method

.method public getExtraObject(Ljava/lang/String;)Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetObjectParam;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/b;->a:Ljava/util/HashMap;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    instance-of v0, v0, Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetObjectParam;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/b;->a:Ljava/util/HashMap;

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    check-cast p1, Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetObjectParam;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p1
.end method

.method public getExtraString(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/b;->a:Ljava/util/HashMap;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/b;->a:Ljava/util/HashMap;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    check-cast p1, Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p1

    :cond_0
    const/4 v1, 0x3

    move v2, v1

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x7

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p1
.end method

.method public setExtraInt(Ljava/lang/String;I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/b;->a:Ljava/util/HashMap;

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public setExtraObject(Ljava/lang/String;Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetObjectParam;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/b;->a:Ljava/util/HashMap;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public setExtraString(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/b;->a:Ljava/util/HashMap;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method
