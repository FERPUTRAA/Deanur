.class public Lcom/tencent/thumbplayer/b/d;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;


# instance fields
.field private a:Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetExtraParam;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public getExtraParam()Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetExtraParam;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "fcs@ou r~@~ @i/ o@@oa @@~i~@~ @~@~ ni@to ooM~ ~ @@~S ~-~@@b~~ vK @~  ~~1~bd~l /~ t@@~b@@mys~l.f "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/d;->a:Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetExtraParam;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public getMediaType()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public getUrl()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public setExtraParam(Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetExtraParam;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/b/d;->a:Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetExtraParam;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method
