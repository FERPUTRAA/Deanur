.class public Lcom/tencent/thumbplayer/b/i;
.super Ljava/lang/Object;


# direct methods
.method private static a(IZ)Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@rsbo@~y /~~@o~tu~~b@c@o@~imo@~i M@1 ~/@ @ d~vf@~~~s@ib @@@l~t4   l   . @fS~  o o~a~~@- @~@~Kn~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-ne p0, v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-string p0, "cv_mstakr"

    const-string/jumbo p0, "tks_scavr"

    const/4 v2, 0x4

    const-string p0, "actrov_sk"

    const-string p0, "av_tracks"

    const/4 v1, 0x6

    shl-int/2addr v2, v1

    return-object p0

    :cond_0
    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string/jumbo p0, "rakmtcva"

    const/4 v2, 0x7

    const-string/jumbo p0, "rak_tbcv"

    const-string p0, "av_track"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-ne p0, v0, :cond_3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz p1, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-string/jumbo p0, "vcetsiuador_"

    const-string p0, "eaicoto_dvrs"

    const/4 v2, 0x3

    const-string p0, "_tovcrdpksae"

    const-string/jumbo p0, "video_tracks"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0

    :cond_2
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string p0, "cbeadivrq_t"

    const-string p0, "d_avtboierc"

    const/4 v2, 0x5

    const-string/jumbo p0, "ikstdco_avr"

    const-string/jumbo p0, "video_track"

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p0

    :cond_3
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-ne p0, v0, :cond_5

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz p1, :cond_4

    const/4 v2, 0x1

    const/4 v1, 0x2

    const-string p0, "crdmoisut_uk"

    const-string p0, "adrci_uotsku"

    const/4 v2, 0x3

    const-string p0, "d_caoroituks"

    const-string p0, "audio_tracks"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0

    :cond_4
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string p0, "d_oaurcpkai"

    const/4 v2, 0x2

    const-string/jumbo p0, "idackbrta_u"

    const-string p0, "audio_track"

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p0

    :cond_5
    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p0
.end method

.method static a(Lcom/tencent/thumbplayer/api/composition/ITPMediaComposition;)Ljava/lang/String;
    .locals 12

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v11, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v11, 0x6

    const/4 v10, 0x0

    if-nez p0, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    return-object v0

    :cond_0
    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-static {}, Landroid/util/Xml;->newSerializer()Lorg/xmlpull/v1/XmlSerializer;

    move-result-object v1

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x4

    new-instance v2, Ljava/io/StringWriter;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-direct {v2}, Ljava/io/StringWriter;-><init>()V

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-interface {v1, v2}, Lorg/xmlpull/v1/XmlSerializer;->setOutput(Ljava/io/Writer;)V

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    const-string v3, "TuF8U"

    const-string v3, "UTFq8"

    const/4 v11, 0x1

    const-string v3, "T8pU-"

    const-string v3, "UTF-8"

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-interface {v1, v3, v4}, Lorg/xmlpull/v1/XmlSerializer;->startDocument(Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    const-string v3, "eaqsst"

    const-string/jumbo v3, "stsesa"

    const/4 v11, 0x6

    const-string/jumbo v3, "sesats"

    const-string v3, "assets"

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-interface {v1, v0, v3}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x3

    move v11, v10

    invoke-interface {p0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaComposition;->getAllAVTracks()Ljava/util/List;

    move-result-object v4

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-static {v4}, Lcom/tencent/thumbplayer/utils/b;->a(Ljava/util/Collection;)Z

    move-result v5

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    if-nez v5, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x5

    const/4 p0, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x3

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v11, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v10, 0x1

    shr-int/2addr v11, v10

    invoke-static {v1, v4, p0, v5, v6}, Lcom/tencent/thumbplayer/b/i;->a(Lorg/xmlpull/v1/XmlSerializer;Ljava/util/List;IJ)V

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x3

    goto :goto_0

    :cond_1
    const/4 v11, 0x3

    invoke-interface {p0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaComposition;->getAllVideoTracks()Ljava/util/List;

    move-result-object v4

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-interface {p0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaComposition;->getAllAudioTracks()Ljava/util/List;

    move-result-object v5

    const/4 v11, 0x0

    const/4 v10, 0x3

    invoke-static {v4}, Lcom/tencent/thumbplayer/utils/b;->a(Ljava/util/Collection;)Z

    move-result v6

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x1

    if-eqz v6, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-static {v5}, Lcom/tencent/thumbplayer/utils/b;->a(Ljava/util/Collection;)Z

    move-result v6

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    if-eqz v6, :cond_2

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    return-object v0

    :cond_2
    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    check-cast p0, Lcom/tencent/thumbplayer/b/e;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/b/e;->a()J

    move-result-wide v6

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/b/e;->b()J

    move-result-wide v8

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x5

    const/4 p0, 0x2

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-static {v1, v4, p0, v8, v9}, Lcom/tencent/thumbplayer/b/i;->a(Lorg/xmlpull/v1/XmlSerializer;Ljava/util/List;IJ)V

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x1

    const/4 p0, 0x3

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-static {v1, v5, p0, v6, v7}, Lcom/tencent/thumbplayer/b/i;->a(Lorg/xmlpull/v1/XmlSerializer;Ljava/util/List;IJ)V

    :goto_0
    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-interface {v1, v0, v3}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-interface {v1}, Lorg/xmlpull/v1/XmlSerializer;->endDocument()V

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v2}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    return-object p0
.end method

.method static a(Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;)Ljava/lang/String;
    .locals 13

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v12, 0x4

    const-string v0, ""

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x7

    if-nez p0, :cond_0

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x5

    return-object v0

    :cond_0
    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-static {}, Landroid/util/Xml;->newSerializer()Lorg/xmlpull/v1/XmlSerializer;

    move-result-object v1

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x4

    new-instance v2, Ljava/io/StringWriter;

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-direct {v2}, Ljava/io/StringWriter;-><init>()V

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-interface {v1, v2}, Lorg/xmlpull/v1/XmlSerializer;->setOutput(Ljava/io/Writer;)V

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x3

    const-string v3, "TmFm8"

    const-string v3, "F-8mT"

    const/4 v12, 0x5

    const-string v3, "UF-8o"

    const-string v3, "UTF-8"

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x0

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v12, 0x0

    const/4 v11, 0x5

    invoke-interface {v1, v3, v4}, Lorg/xmlpull/v1/XmlSerializer;->startDocument(Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x1

    const-string/jumbo v3, "staseb"

    const-string v3, "assets"

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-interface {v1, v0, v3}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    const-string/jumbo v4, "srokt_uva"

    const-string v4, "ck_vosrta"

    const/4 v12, 0x3

    const-string/jumbo v4, "stka_vrpa"

    const-string v4, "av_tracks"

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-interface {v1, v0, v4}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x3

    const-string/jumbo v5, "qbr_tvca"

    const-string v5, "acktvb_r"

    const/4 v12, 0x0

    const-string v5, "cas_akvt"

    const-string v5, "av_track"

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-interface {v1, v0, v5}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x6

    const-string v6, "cktmp_ariu"

    const-string/jumbo v6, "r_tpicukac"

    const/4 v12, 0x4

    const-string/jumbo v6, "track_clip"

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-interface {v1, v0, v6}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x0

    const-string/jumbo v7, "pdlpoi_"

    const-string/jumbo v7, "pdil_ip"

    const/4 v12, 0x3

    const-string v7, "d_ipibl"

    const-string v7, "clip_id"

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x7

    const/4 v8, 0x3

    const/4 v12, 0x7

    const/4 v8, 0x0

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-static {v8}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v8

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-interface {v1, v8}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x1

    const-string v7, "eicldpu_lqlproce"

    const-string/jumbo v7, "leearllcqp_dipoc"

    const/4 v12, 0x3

    const-string/jumbo v7, "rcd_oeppllcpealH"

    const-string v7, "clip_placeHolder"

    const/4 v12, 0x2

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x5

    const-string v8, "0"

    const-string v8, "0"

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-interface {v1, v8}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x4

    const-string v7, "_ptilsacq"

    const-string v7, "_lsictapp"

    const/4 v12, 0x3

    const-string v7, "ahstcippl"

    const-string v7, "clip_path"

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x3

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x0

    invoke-interface {p0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;->getDrmPlayUrl()Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-static {v9}, Lcom/tencent/thumbplayer/b/i;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x5

    invoke-interface {v1, v9}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x0

    const-string/jumbo v7, "pTmmm_yrceld"

    const-string v7, "Tpcmyedplmr_"

    const/4 v12, 0x6

    const-string/jumbo v7, "py_rodTpimcl"

    const-string v7, "clip_drmType"

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x0

    const-class v9, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDrmType;

    const-class v9, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDrmType;

    const/4 v12, 0x1

    const-class v9, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMap$MapDrmType;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-interface {p0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;->getDrmType()I

    move-result v10

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-static {v9, v10}, Lcom/tencent/thumbplayer/adapter/strategy/utils/TPNativeKeyMapUtil;->toNativeIntValue(Ljava/lang/Class;I)I

    move-result v9

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-static {v9}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-interface {v1, v9}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v11, 0x5

    move v12, v11

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x4

    const-string/jumbo v7, "mnvPcboporrdil_isoil"

    const-string/jumbo v7, "rooiolmclnUi_drPipvs"

    const/4 v12, 0x7

    const-string/jumbo v7, "sonrocuirP_vlirlidmU"

    const-string v7, "clip_drmProvisionUrl"

    const/4 v12, 0x0

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x5

    const-string/jumbo v9, "oredmb_rp_rniopv_sutrlopyi"

    const/4 v12, 0x2

    const-string/jumbo v9, "rtrsnyppoovelipurrodprm_i_"

    const-string v9, "drm_property_provision_url"

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-interface {p0, v9, v0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;->getDrmProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-static {v9}, Lcom/tencent/thumbplayer/b/i;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-interface {v1, v9}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x3

    const-string/jumbo v7, "umcdpiceqnUiLlerl_"

    const-string/jumbo v7, "mnericulsdlecLpi_U"

    const/4 v12, 0x2

    const-string/jumbo v7, "lUsip_rimdnclsceer"

    const-string v7, "clip_drmLicenseUrl"

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x4

    const-string v9, "dcsmyltp_nuepolrreprr_i_"

    const/4 v12, 0x6

    const-string/jumbo v9, "o_rml_ctmsud_rpyipnerlre"

    const-string v9, "drm_property_license_url"

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-interface {p0, v9, v0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;->getDrmProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-static {v9}, Lcom/tencent/thumbplayer/b/i;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-interface {v1, v9}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x3

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x7

    const-string v7, "erscoU1_qdmLl"

    const-string v7, "Lclm_ei1qdUrs"

    const/4 v12, 0x7

    const-string v7, "cd_LUbepmisrl"

    const-string v7, "clip_drmUseL1"

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v11, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x7

    const-string/jumbo v9, "pe_o_rustsprumdl1_r"

    const-string v9, "eps1_r_slpdruremot_"

    const/4 v12, 0x0

    const-string/jumbo v9, "r_uyrprpodestpl1m_e"

    const-string v9, "drm_property_use_l1"

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x7

    const-string v10, "1"

    const-string v10, "1"

    const/4 v12, 0x6

    const-string v10, "1"

    const-string v10, "1"

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-interface {p0, v9, v10}, Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;->getDrmProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-interface {v1, v9}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x0

    const-string v7, "divcehmmqpSrtalP"

    const-string/jumbo v7, "hapmv_tldPcrmSie"

    const/4 v12, 0x0

    const-string v7, "adsr_aSPpecihvtm"

    const-string v7, "clip_drmSavePath"

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x4

    const/4 v11, 0x1

    const-string v9, "_prm_tppsmaoaehdortv_y"

    const-string/jumbo v9, "v_aeoodhrts_tp_mpparyr"

    const/4 v12, 0x1

    const-string/jumbo v9, "rmaeo_rvtptasdyepp__oh"

    const-string v9, "drm_property_save_path"

    const/4 v12, 0x0

    invoke-interface {p0, v9, v0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;->getDrmProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-interface {v1, v9}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x4

    const-string v7, "Gm_lrbbpidud"

    const-string v7, "Gldrdbpi_umi"

    const/4 v12, 0x3

    const-string v7, "c_diuiumGrdl"

    const-string v7, "clip_drmGuid"

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    const-string/jumbo v9, "tpirdp_poyeudum_r"

    const-string/jumbo v9, "ytoe_rudr_puimrpd"

    const/4 v12, 0x1

    const-string/jumbo v9, "yprrimg_qdortupde"

    const-string v9, "drm_property_guid"

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-interface {p0, v9, v0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;->getDrmProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-interface {v1, v9}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x3

    const-string/jumbo v7, "pfsmrp_dcloairPt"

    const-string v7, "arrcdoipmlfPt_mp"

    const/4 v12, 0x7

    const-string v7, "_Prmdmrofplmclit"

    const-string v7, "clip_drmPlatform"

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    const-string/jumbo v9, "rploomerrrmt_pqayof_t"

    const-string/jumbo v9, "oyeltfmdqmtrroppr__ra"

    const/4 v12, 0x0

    const-string/jumbo v9, "rrmrfbpp_padett_rmoyo"

    const-string v9, "drm_property_platform"

    const/4 v11, 0x6

    shr-int/2addr v12, v11

    invoke-interface {p0, v9, v0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;->getDrmProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-interface {v1, v9}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x2

    const-string/jumbo v7, "isV_Aludimrroppepn"

    const-string/jumbo v7, "insoliVmsApr_dprpe"

    const/4 v12, 0x6

    const-string v7, "_ecVpripnposlimrpd"

    const-string v7, "clip_drmAppVersion"

    const/4 v11, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    const-string/jumbo v9, "r_rp_rvtqm_mpdepyopa"

    const-string v9, "epmmydrr_pp_rra_tovp"

    const/4 v12, 0x0

    const-string v9, "_pspvrr_eprmot_apdey"

    const-string v9, "drm_property_app_ver"

    const/4 v12, 0x2

    const/4 v11, 0x5

    invoke-interface {p0, v9, v0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;->getDrmProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-interface {v1, v9}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x1

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-string/jumbo v7, "pComri_comiked"

    const-string v7, "clip_drmCookie"

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x3

    const-string/jumbo v9, "oepco_o_eodirrmytko"

    const-string v9, "_topork_oedrymoceip"

    const/4 v12, 0x3

    const-string/jumbo v9, "ro_kpbcy_rerodepiom"

    const-string v9, "drm_property_cookie"

    const/4 v12, 0x1

    const/4 v11, 0x0

    invoke-interface {p0, v9, v0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;->getDrmProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-interface {v1, v9}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v11, 0x7

    move v12, v11

    const-string v7, "_oairlutsiiadznedcmnndbptcLare"

    const-string/jumbo v7, "pracibmatsdeiiiLalnenddtrzo_nc"

    const/4 v12, 0x3

    const-string v7, "dnietnrpLmztaSpneasricdo_icild"

    const-string v7, "clip_drmLicenseStandardization"

    const/4 v11, 0x5

    move v12, v11

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x1

    const-string/jumbo v9, "iaoeaaseqnzdprdr_t_ripuesy_mntdtcino"

    const-string v9, "cmns_autiiosdzaetelerr_dpipdoarny_tn"

    const/4 v12, 0x6

    const-string/jumbo v9, "r_spriosyntasdtrpemnztnldarcdiie_eoa"

    const-string v9, "drm_property_license_standardization"

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-interface {p0, v9, v8}, Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;->getDrmProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-interface {v1, v8}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v11, 0x3

    move v12, v11

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x7

    const/4 v11, 0x5

    const-string/jumbo v7, "xKmEltipXery_dc"

    const/4 v12, 0x4

    const-string/jumbo v7, "premylcxiE_KmXt"

    const-string v7, "clip_drmExtXKey"

    const/4 v12, 0x5

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x0

    const-string v8, "__ypotoyderqm_rrtx_pek"

    const-string/jumbo v8, "xe_op_yrqrde__rxtytmkp"

    const/4 v12, 0x6

    const-string/jumbo v8, "o_exebdt_tr__ykpmrrpxe"

    const-string v8, "drm_property_ext_x_key"

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-interface {p0, v8, v0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;->getDrmProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-interface {v1, v8}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v11, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x7

    const-string/jumbo v7, "prrPo_ucereilpedtfrsry"

    const-string/jumbo v7, "rrsPperfodprc_peiyelrt"

    const/4 v12, 0x3

    const-string v7, "clip_preferredProperty"

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-static {v1, p0}, Lcom/tencent/thumbplayer/b/i;->a(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)V

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-interface {v1, v0, v6}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-interface {v1, v0, v5}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-interface {v1, v0, v4}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-interface {v1, v0, v3}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v11, 0x3

    const/4 v11, 0x5

    invoke-interface {v1}, Lorg/xmlpull/v1/XmlSerializer;->endDocument()V

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-virtual {v2}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x5

    return-object p0
.end method

.method static a(Lcom/tencent/thumbplayer/api/composition/ITPMediaRTCAsset;)Ljava/lang/String;
    .locals 11

    const/4 v9, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x0

    const-string v0, ""

    const/4 v9, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-nez p0, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    return-object v0

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static {}, Landroid/util/Xml;->newSerializer()Lorg/xmlpull/v1/XmlSerializer;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    new-instance v2, Ljava/io/StringWriter;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-direct {v2}, Ljava/io/StringWriter;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-interface {v1, v2}, Lorg/xmlpull/v1/XmlSerializer;->setOutput(Ljava/io/Writer;)V

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    const-string/jumbo v3, "m8p-T"

    const-string v3, "-8FmT"

    const/4 v10, 0x4

    const-string v3, "TF-q8"

    const-string v3, "UTF-8"

    const/4 v10, 0x4

    const/4 v9, 0x0

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-interface {v1, v3, v4}, Lorg/xmlpull/v1/XmlSerializer;->startDocument(Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    const-string/jumbo v3, "tssssa"

    const-string v3, "assets"

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-interface {v1, v0, v3}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x5

    const-string v4, "akamvoctr"

    const-string v4, "atvcoarsk"

    const/4 v10, 0x6

    const-string/jumbo v4, "sarcoa_tv"

    const-string v4, "av_tracks"

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-interface {v1, v0, v4}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    const-string v5, "ba_rkbcv"

    const-string v5, "avkarb_c"

    const/4 v10, 0x2

    const-string v5, "_ktvrcua"

    const-string v5, "av_track"

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-interface {v1, v0, v5}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    const-string/jumbo v6, "kptircapc_"

    const-string/jumbo v6, "track_clip"

    const/4 v9, 0x2

    move v10, v9

    invoke-interface {v1, v0, v6}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    const-string v7, "d_pcilu"

    const/4 v10, 0x7

    const-string v7, "dqlcii_"

    const-string v7, "clip_id"

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v9, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    const/4 v8, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {v8}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x7

    const/4 v9, 0x4

    invoke-interface {v1, v8}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const-string v7, "arslpl_elpcpdHoe"

    const-string/jumbo v7, "rc_eidlpolpepalH"

    const/4 v10, 0x3

    const-string/jumbo v7, "llHmcidp_copreae"

    const-string v7, "clip_placeHolder"

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const-string v8, "0"

    const-string v8, "0"

    const/4 v10, 0x4

    const-string v8, "0"

    const-string v8, "0"

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-interface {v1, v8}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    const-string v7, "cqatoppl_"

    const-string v7, "cta_hpplq"

    const/4 v10, 0x6

    const-string v7, "_ilpcbatp"

    const-string v7, "clip_path"

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-interface {p0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaRTCAsset;->getRtcStreamUrl()Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {v8}, Lcom/tencent/thumbplayer/b/i;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-interface {v1, v8}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    const-string/jumbo v7, "lrreUeurlpcric_sv"

    const-string v7, "cisectlver_lrrrpU"

    const/4 v10, 0x1

    const-string/jumbo v7, "rprcrrlpceUiStev_"

    const-string v7, "clip_rtcServerUrl"

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-interface {p0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaRTCAsset;->getRtcServerUrl()Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-static {v8}, Lcom/tencent/thumbplayer/b/i;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x3

    invoke-interface {v1, v8}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    const-string v7, "TxcpprhiqlymepEtdS_cane"

    const-string v7, "ecxmnihaplecrcESdytpT_p"

    const/4 v10, 0x3

    const-string/jumbo v7, "pcsTyracegthnxeplSdc_Ep"

    const-string v7, "clip_rtcSdpExchangeType"

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-interface {p0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaRTCAsset;->getRtcSdpExchangeType()I

    move-result v8

    const/4 v10, 0x5

    const/4 v9, 0x4

    invoke-static {v8}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-interface {v1, v8}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const-string/jumbo v7, "rpemdepeyc_topriofPrrr"

    const-string v7, "_pfeoerciorrperlrtdpyP"

    const/4 v10, 0x4

    const-string/jumbo v7, "rppioreteyr_erflcPdore"

    const-string v7, "clip_preferredProperty"

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-static {v1, p0}, Lcom/tencent/thumbplayer/b/i;->a(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)V

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-interface {v1, v0, v6}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-interface {v1, v0, v5}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-interface {v1, v0, v4}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-interface {v1, v0, v3}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-interface {v1}, Lorg/xmlpull/v1/XmlSerializer;->endDocument()V

    const/4 v10, 0x5

    const/4 v9, 0x1

    invoke-virtual {v2}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x4

    return-object p0
.end method

.method public static a(Lcom/tencent/thumbplayer/api/composition/ITPMediaUrlAsset;)Ljava/lang/String;
    .locals 11

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    if-nez p0, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    return-object v0

    :cond_0
    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-static {}, Landroid/util/Xml;->newSerializer()Lorg/xmlpull/v1/XmlSerializer;

    move-result-object v1

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    new-instance v2, Ljava/io/StringWriter;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-direct {v2}, Ljava/io/StringWriter;-><init>()V

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-interface {v1, v2}, Lorg/xmlpull/v1/XmlSerializer;->setOutput(Ljava/io/Writer;)V

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    const-string v3, "bUFTb"

    const-string v3, "b8UFT"

    const/4 v10, 0x1

    const-string v3, "UuF8-"

    const-string v3, "UTF-8"

    const/4 v10, 0x6

    const/4 v9, 0x2

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-interface {v1, v3, v4}, Lorg/xmlpull/v1/XmlSerializer;->startDocument(Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    const-string v3, "eptass"

    const-string/jumbo v3, "usseat"

    const/4 v10, 0x2

    const-string/jumbo v3, "saqtse"

    const-string v3, "assets"

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-interface {v1, v0, v3}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    const-string/jumbo v4, "rss_akavc"

    const-string/jumbo v4, "vrcaaskp_"

    const/4 v10, 0x2

    const-string v4, "av_tracks"

    const/4 v9, 0x5

    shl-int/2addr v10, v9

    invoke-interface {v1, v0, v4}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-string v5, "aavmrcqt"

    const-string/jumbo v5, "qkavract"

    const/4 v10, 0x5

    const-string/jumbo v5, "tra_ovca"

    const-string v5, "av_track"

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-interface {v1, v0, v5}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const-string/jumbo v6, "i_kcabclsp"

    const-string/jumbo v6, "kcs_lcatip"

    const/4 v10, 0x6

    const-string v6, "ckprt_ucal"

    const-string/jumbo v6, "track_clip"

    const/4 v10, 0x1

    invoke-interface {v1, v0, v6}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v9, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-string/jumbo v7, "pi_idpl"

    const-string/jumbo v7, "idpml_i"

    const/4 v10, 0x3

    const-string v7, "_qlpiid"

    const-string v7, "clip_id"

    const/4 v10, 0x6

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v9, 0x7

    const/4 v10, 0x4

    const/4 v8, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-static {v8}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-interface {v1, v8}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x2

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    const-string/jumbo v7, "posrialHpcolle_c"

    const-string v7, "dcaeocipllro_Hlp"

    const/4 v10, 0x1

    const-string/jumbo v7, "olimapdH_elcperl"

    const-string v7, "clip_placeHolder"

    const/4 v10, 0x7

    const/4 v9, 0x2

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    const-string v8, "0"

    const-string v8, "0"

    const/4 v10, 0x2

    const-string v8, "0"

    const-string v8, "0"

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-interface {v1, v8}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    const-string/jumbo v7, "lih_otcbp"

    const-string/jumbo v7, "tlhiabpc_"

    const/4 v10, 0x0

    const-string/jumbo v7, "hpt_ibplc"

    const-string v7, "clip_path"

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-interface {p0}, Lcom/tencent/thumbplayer/api/composition/ITPMediaUrlAsset;->getStreamUrl()Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-static {v8}, Lcom/tencent/thumbplayer/b/i;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-interface {v1, v8}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    const-string/jumbo v7, "relrpdupceirPtrefyr_ou"

    const-string v7, "cdrprlutpreeyee_orrfPi"

    const/4 v10, 0x4

    const-string/jumbo v7, "irppfc_pdereperreylrPo"

    const-string v7, "clip_preferredProperty"

    const/4 v10, 0x5

    const/4 v9, 0x6

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-static {v1, p0}, Lcom/tencent/thumbplayer/b/i;->a(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)V

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-interface {v1, v0, v7}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-interface {v1, v0, v6}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x3

    const/4 v9, 0x6

    invoke-interface {v1, v0, v5}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-interface {v1, v0, v4}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-interface {v1, v0, v3}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-interface {v1}, Lorg/xmlpull/v1/XmlSerializer;->endDocument()V

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {v2}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x5

    return-object p0
.end method

.method private static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const-string/jumbo v0, "fdb//uu0q-nu /d7d0/-0/druuffff0f+0e0cf/0pu^dt-u[]f/ff//d"

    const-string/jumbo v0, "fd0/f[0p/0/ue//f807-///tdd0ruf]bfc0uf uudd-d^f0f+u-fnfu/"

    const/4 v3, 0x7

    const-string/jumbo v0, "ufsudfr-8^0+ufd0ue///00/fb0f-tf[fu//uu/ /d0fnc]7df0fdd//"

    const-string v0, "[^\t\r\n -\ud7ff\ue000-\ufffd\ud800\udc00-\udbff\udfff]+"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object p0
.end method

.method static a(Ljava/util/List;I)Ljava/lang/String;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;",
            ">;I)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {p0}, Lcom/tencent/thumbplayer/utils/b;->a(Ljava/util/Collection;)Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v7, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz v0, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x1

    return-object v1

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v0, 0x1

    const/4 v6, 0x6

    and-int/2addr v7, v6

    if-ne p1, v0, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    const-string/jumbo p1, "kcamvs_aq"

    const-string p1, "c_savrkaq"

    const/4 v7, 0x5

    const-string/jumbo p1, "vrs_oaack"

    const-string p1, "av_tracks"

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string v0, "ca_vtbka"

    const-string v0, "av_track"

    const/4 v7, 0x5

    goto :goto_0

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/4 v0, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-ne p1, v0, :cond_2

    const/4 v7, 0x5

    const-string p1, "dcsiarutoskv"

    const-string p1, "ctsosriedkav"

    const/4 v7, 0x5

    const-string/jumbo p1, "tvedsr_pioca"

    const-string/jumbo p1, "video_tracks"

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string v0, "cvoamrikqdt"

    const-string v0, "dtkmorcavie"

    const/4 v7, 0x3

    const-string v0, "a_sekdrociv"

    const-string/jumbo v0, "video_track"

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    goto :goto_0

    :cond_2
    const/4 v6, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 v0, 0x3

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-ne p1, v0, :cond_3

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-string p1, "dsumaooiart_"

    const-string/jumbo p1, "irsuotao_akd"

    const/4 v7, 0x6

    const-string/jumbo p1, "oatsorkca_di"

    const-string p1, "audio_tracks"

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string v0, "ctaurbkabo_"

    const-string v0, "coau_biarkt"

    const/4 v7, 0x5

    const-string/jumbo v0, "iradtcu_oua"

    const-string v0, "audio_track"

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    invoke-static {}, Landroid/util/Xml;->newSerializer()Lorg/xmlpull/v1/XmlSerializer;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    new-instance v3, Ljava/io/StringWriter;

    const/4 v6, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-direct {v3}, Ljava/io/StringWriter;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-interface {v2, v3}, Lorg/xmlpull/v1/XmlSerializer;->setOutput(Ljava/io/Writer;)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string v4, "-UpT8"

    const-string v4, "UuT-8"

    const/4 v7, 0x7

    const-string v4, "UF-qT"

    const-string v4, "UTF-8"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v7, 0x1

    const/4 v6, 0x3

    invoke-interface {v2, v4, v5}, Lorg/xmlpull/v1/XmlSerializer;->startDocument(Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v7, 0x4

    const-string/jumbo v4, "sesssa"

    const-string/jumbo v4, "spessa"

    const/4 v7, 0x5

    const-string v4, "essmst"

    const-string v4, "assets"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-interface {v2, v1, v4}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {v2, p0, p1, v0}, Lcom/tencent/thumbplayer/b/i;->a(Lorg/xmlpull/v1/XmlSerializer;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-interface {v2, v1, v4}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-interface {v2}, Lorg/xmlpull/v1/XmlSerializer;->endDocument()V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v3}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    return-object p0

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    return-object v1
.end method

.method private static a(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;->getExtraParam()Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetExtraParam;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string/jumbo v0, "feurrpidq_oaedr"

    const/4 v2, 0x1

    const-string/jumbo v0, "pfaooi_eeedudrr"

    const-string/jumbo v0, "preferred_audio"

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p0, p1, v0}, Lcom/tencent/thumbplayer/b/i;->a(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetExtraParam;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string/jumbo v0, "rrelbbses_teudfrtp"

    const-string v0, "brsu_dereepltirtfs"

    const/4 v2, 0x0

    const-string/jumbo v0, "rerei_uefusettblrd"

    const-string/jumbo v0, "preferred_subtitle"

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, p1, v0}, Lcom/tencent/thumbplayer/b/i;->a(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetExtraParam;Ljava/lang/String;)V

    const/4 v2, 0x2

    const-string/jumbo v0, "f_demdvpiroreee"

    const-string/jumbo v0, "re_mipordfeevde"

    const/4 v2, 0x7

    const-string v0, "eoed_vrrqeiedfr"

    const-string/jumbo v0, "preferred_video"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p0, p1, v0}, Lcom/tencent/thumbplayer/b/i;->a(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetExtraParam;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method private static a(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetExtraParam;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-interface {p1, p2}, Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetExtraParam;->getExtraObject(Ljava/lang/String;)Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetObjectParam;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    check-cast p1, Lcom/tencent/thumbplayer/b/c;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-nez p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {p0, v0, p2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaAssetOrderedMap;->getKeyValueStr()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/b/i;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {p0, p1}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {p0, v0, p2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method private static a(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p0, p1, v0, v1}, Lcom/tencent/thumbplayer/b/i;->a(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;J)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method private static a(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;J)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    instance-of v0, p1, Lcom/tencent/thumbplayer/b/a;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/thumbplayer/b/i;->b(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;J)V

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    instance-of v0, p1, Lcom/tencent/thumbplayer/b/h;

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/thumbplayer/b/i;->c(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;J)V

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method private static a(Lorg/xmlpull/v1/XmlSerializer;Ljava/util/List;IJ)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/xmlpull/v1/XmlSerializer;",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;",
            ">;IJ)V"
        }
    .end annotation

    const-string/jumbo v0, "kisdtcro"

    const-string v0, "c_rdokit"

    const-string v0, "ctkmidar"

    const-string/jumbo v0, "track_id"

    const-string v1, ""

    const-string v1, ""

    if-eqz p1, :cond_5

    :try_start_0
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_5

    const/4 v2, 0x1

    invoke-static {p2, v2}, Lcom/tencent/thumbplayer/b/i;->a(IZ)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    invoke-static {p2, v4}, Lcom/tencent/thumbplayer/b/i;->a(IZ)Ljava/lang/String;

    move-result-object v4

    invoke-interface {p0, v1, v3}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_4

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;

    invoke-interface {v5}, Lcom/tencent/thumbplayer/api/composition/ITPMediaAsset;->getMediaType()I

    move-result v6

    if-ne v6, p2, :cond_0

    invoke-interface {p0, v1, v4}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    invoke-interface {p0, v1, v0}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    invoke-interface {v5}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;->getTrackId()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v6

    invoke-interface {p0, v6}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    invoke-interface {p0, v1, v0}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    if-eq p2, v2, :cond_2

    sget-object v6, Lcom/tencent/thumbplayer/b/f;->a:Ljava/lang/String;

    const-string v7, "bouioae_sd"

    const-string v7, "du_asbiboe"

    const-string/jumbo v7, "u_daabbies"

    const-string v7, "base_audio"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-interface {v5}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;->getTimelineDurationMs()J

    move-result-wide v6

    cmp-long v6, v6, p3

    if-lez v6, :cond_2

    invoke-interface {v5}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;->getAllTrackClips()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    :goto_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_3

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    invoke-interface {v8}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getOriginalDurationMs()J

    move-result-wide v9

    add-long/2addr v6, v9

    cmp-long v9, v6, p3

    if-lez v9, :cond_1

    sub-long/2addr v6, p3

    invoke-static {p0, v8, v6, v7}, Lcom/tencent/thumbplayer/b/i;->a(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;J)V

    goto :goto_3

    :cond_1
    invoke-static {p0, v8}, Lcom/tencent/thumbplayer/b/i;->a(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;)V

    goto :goto_1

    :cond_2
    invoke-interface {v5}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;->getAllTrackClips()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_2
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_3

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    invoke-static {p0, v6}, Lcom/tencent/thumbplayer/b/i;->a(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;)V

    goto :goto_2

    :cond_3
    :goto_3
    invoke-interface {p0, v1, v4}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    goto/16 :goto_0

    :cond_4
    invoke-interface {p0, v1, v3}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_4

    :catch_0
    move-exception p0

    const-string/jumbo p1, "iapeituslMoeoPGnCidTuermnmaXrt"

    const-string/jumbo p1, "lTGriduiCmrnXinetaPmoMasopeoet"

    const-string/jumbo p1, "pTolinapmtCreroPneeiMXiGosdamo"

    const-string p1, "TPMediaCompositionXmlGenerator"

    invoke-static {p1, p0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_5
    :goto_4
    return-void
.end method

.method private static a(Lorg/xmlpull/v1/XmlSerializer;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/xmlpull/v1/XmlSerializer;",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {p0, v0, p2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v3, 0x4

    invoke-interface {p0, v0, p3}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    check-cast v1, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p0, v1}, Lcom/tencent/thumbplayer/b/i;->a(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;)V

    const/4 v2, 0x5

    or-int/2addr v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    invoke-interface {p0, v0, p3}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {p0, v0, p2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v3, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method private static b(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;J)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x4

    const-string/jumbo v1, "tkpcair_ql"

    const-string/jumbo v1, "lct_irkpap"

    const/4 v6, 0x0

    const-string v1, "crsi_acpkt"

    const-string/jumbo v1, "track_clip"

    const/4 v6, 0x0

    invoke-interface {p0, v0, v1}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string/jumbo v2, "qi_mcdi"

    const-string/jumbo v2, "iqil_cd"

    const/4 v6, 0x7

    const-string v2, "_lciopd"

    const-string v2, "clip_id"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getClipId()I

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {p0, v3}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string/jumbo v2, "lclpsbHoeedipcr_"

    const-string/jumbo v2, "iospe_Hcpedlclrl"

    const/4 v6, 0x3

    const-string v2, "_eclaiudrolHlpce"

    const-string v2, "clip_placeHolder"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string v3, "1"

    const-string v3, "1"

    const/4 v6, 0x5

    const-string v3, "1"

    const/4 v6, 0x6

    invoke-interface {p0, v3}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string/jumbo v2, "plaiiMypmcmpesl"

    const-string/jumbo v2, "plpmliMTisymaec"

    const/4 v6, 0x7

    const-string v2, "cayimMisqpeTpll"

    const-string v2, "clip_playTimeMs"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    cmp-long v3, p2, v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-lez v3, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getOriginalDurationMs()J

    move-result-wide v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    sub-long/2addr v3, p2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v3, v4}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getOriginalDurationMs()J

    move-result-wide p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {p1, p2}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {p0, p1}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-interface {p0, v0, v1}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-void
.end method

.method private static c(Lorg/xmlpull/v1/XmlSerializer;Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;J)V
    .locals 11

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x6

    const-string/jumbo v1, "lascorct_k"

    const-string/jumbo v1, "tc_rolckia"

    const-string/jumbo v1, "tlcmr_paic"

    const-string/jumbo v1, "track_clip"

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-interface {p0, v0, v1}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x0

    const-string v2, "b_pcoli"

    const-string/jumbo v2, "lcip_bi"

    const/4 v10, 0x2

    const-string v2, "diicpbl"

    const-string v2, "clip_id"

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getClipId()I

    move-result v3

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-interface {p0, v3}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    const-string/jumbo v2, "ldrccHu_lloaippe"

    const/4 v10, 0x7

    const-string/jumbo v2, "olacciupeleHl_rd"

    const-string v2, "clip_placeHolder"

    const/4 v10, 0x5

    const/4 v9, 0x4

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    const-string v3, "0"

    const-string v3, "0"

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-interface {p0, v3}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    const-string/jumbo v2, "p_pphtipa"

    const-string/jumbo v2, "pahtil_pp"

    const/4 v10, 0x3

    const-string/jumbo v2, "lcihapp_q"

    const-string v2, "clip_path"

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v9, 0x7

    move v10, v9

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getFilePath()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-static {v3}, Lcom/tencent/thumbplayer/b/i;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-interface {p0, v3}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-string v2, "Trssqe_Mttpmicsa"

    const-string v2, "_tspcTmtqeMaslir"

    const/4 v10, 0x5

    const-string/jumbo v2, "t_empsarMimTtcil"

    const-string v2, "clip_startTimeMs"

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x7

    const/4 v9, 0x7

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getStartTimeMs()J

    move-result-wide v3

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {v3, v4}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x2

    invoke-interface {p0, v3}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x3

    const/4 v9, 0x1

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x4

    const-string v2, "dpslouMrnscoit_"

    const-string v2, "_dspMilusracotn"

    const/4 v10, 0x3

    const-string v2, "clip_durationMs"

    const/4 v10, 0x5

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getOriginalDurationMs()J

    move-result-wide v3

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-static {v3, v4}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-interface {p0, v3}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-interface {p0, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    cmp-long v2, p2, v2

    const/4 v10, 0x6

    const/4 v9, 0x5

    const-string v3, "Tmey_bacpliMmis"

    const-string/jumbo v3, "pMemism_iyclTla"

    const/4 v10, 0x0

    const-string/jumbo v3, "lMiTmpul_cpiyes"

    const-string v3, "clip_playTimeMs"

    const/4 v10, 0x1

    const-string/jumbo v4, "npdTs_epclMoei"

    const-string/jumbo v4, "pncToieMesldi_"

    const/4 v10, 0x0

    const-string/jumbo v4, "icpesin_qMmTde"

    const-string v4, "clip_endTimeMs"

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-lez v2, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getEndTimeMs()J

    move-result-wide v5

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    sub-long/2addr v5, p2

    const/4 v10, 0x1

    const/4 v9, 0x0

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getOriginalDurationMs()J

    move-result-wide v7

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    sub-long/2addr v7, p2

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-interface {p0, v0, v4}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static {v5, v6}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-interface {p0, p1}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-interface {p0, v0, v4}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-interface {p0, v0, v3}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-static {v7, v8}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    goto :goto_0

    :cond_0
    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-interface {p0, v0, v4}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x0

    const/4 v9, 0x7

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getEndTimeMs()J

    move-result-wide p2

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {p2, p3}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-interface {p0, p2}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-interface {p0, v0, v4}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-interface {p0, v0, v3}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    invoke-interface {p1}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;->getOriginalDurationMs()J

    move-result-wide p1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-static {p1, p2}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-interface {p0, p1}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x1

    const/4 v9, 0x5

    invoke-interface {p0, v0, v3}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-interface {p0, v0, v1}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    return-void
.end method
