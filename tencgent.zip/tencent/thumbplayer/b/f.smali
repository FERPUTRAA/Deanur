.class Lcom/tencent/thumbplayer/b/f;
.super Ljava/lang/Object;


# static fields
.field public static a:Ljava/lang/String; = "base_video"

.field private static b:I

.field private static c:I

.field private static d:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method static a(I)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~sy@@~@@@~ @o~ l @mMo1~s @@@  n o~c@l~~.u~ tivboio S~d~@rib/~bfo~~~ ~~ @@@@/-~~ @   ~K~@~ @at4 "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-ne p0, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget p0, Lcom/tencent/thumbplayer/b/f;->d:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    add-int/lit8 v0, p0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    sput v0, Lcom/tencent/thumbplayer/b/f;->d:I

    const/4 v2, 0x6

    return p0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-ne p0, v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget p0, Lcom/tencent/thumbplayer/b/f;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    add-int/lit8 v0, p0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    sput v0, Lcom/tencent/thumbplayer/b/f;->b:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    return p0

    :cond_1
    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v2, 0x0

    move v1, v0

    move v1, v0

    const/4 v2, 0x4

    if-ne p0, v0, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget p0, Lcom/tencent/thumbplayer/b/f;->c:I

    const/4 v2, 0x7

    add-int/lit8 v0, p0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    sput v0, Lcom/tencent/thumbplayer/b/f;->c:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    return p0

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 p0, -0x1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    return p0
.end method
