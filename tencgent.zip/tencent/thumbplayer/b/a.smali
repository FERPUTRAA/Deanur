.class public Lcom/tencent/thumbplayer/b/a;
.super Lcom/tencent/thumbplayer/b/d;

# interfaces
.implements Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;
.implements Ljava/io/Serializable;


# instance fields
.field private a:I

.field private b:I

.field private c:J

.field private d:J

.field private e:J


# direct methods
.method public constructor <init>(I)V
    .locals 4

    const/4 v2, 0x0

    move v3, v2

    invoke-direct {p0}, Lcom/tencent/thumbplayer/b/d;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-wide v0, p0, Lcom/tencent/thumbplayer/b/a;->c:J

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-wide v0, p0, Lcom/tencent/thumbplayer/b/a;->d:J

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput p1, p0, Lcom/tencent/thumbplayer/b/a;->a:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/tencent/thumbplayer/b/f;->a(I)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput p1, p0, Lcom/tencent/thumbplayer/b/a;->b:I

    const/4 v3, 0x4

    return-void
.end method


# virtual methods
.method public clone(I)Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~s ~~ i@/r~~l   bf   ~~ .~o ~~ 4ts ~@@~m@ in~bu@/cM@~@@St~a@~f~-dobv@@ @~~@o~  iKo @@o@y@~~@ol1"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    const/4 v0, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eq p1, v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v0, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eq p1, v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eq p1, v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 p1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object p1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v0, Lcom/tencent/thumbplayer/b/a;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v0, p1}, Lcom/tencent/thumbplayer/b/a;-><init>(I)V

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/tencent/thumbplayer/b/f;->a(I)I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput p1, v0, Lcom/tencent/thumbplayer/b/a;->b:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-wide v1, p0, Lcom/tencent/thumbplayer/b/a;->c:J

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-wide v1, v0, Lcom/tencent/thumbplayer/b/a;->c:J

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-wide v1, p0, Lcom/tencent/thumbplayer/b/a;->d:J

    const/4 v3, 0x7

    const/4 v4, 0x2

    iput-wide v1, v0, Lcom/tencent/thumbplayer/b/a;->d:J

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-nez p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    return v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    instance-of v1, p1, Lcom/tencent/thumbplayer/b/a;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-nez v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    return v0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget v1, p0, Lcom/tencent/thumbplayer/b/a;->b:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    check-cast p1, Lcom/tencent/thumbplayer/b/a;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/b/a;->getClipId()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x6

    if-ne v1, v2, :cond_2

    const/4 v3, 0x4

    move v4, v3

    iget v1, p0, Lcom/tencent/thumbplayer/b/a;->a:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/b/a;->getMediaType()I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-ne v1, p1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 p1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    return p1

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    return v0
.end method

.method public getClipId()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/thumbplayer/b/a;->b:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public getEndTimeMs()J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-wide v0, p0, Lcom/tencent/thumbplayer/b/a;->d:J

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-wide v0
.end method

.method public getFilePath()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x5

    return-object v0
.end method

.method public getMediaType()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/b/a;->a:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public getOriginalDurationMs()J
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-wide v0, p0, Lcom/tencent/thumbplayer/b/a;->d:J

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-wide v2, p0, Lcom/tencent/thumbplayer/b/a;->c:J

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    sub-long/2addr v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-wide v0
.end method

.method public getStartPositionMs()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/tencent/thumbplayer/b/a;->e:J

    const/4 v3, 0x7

    const/4 v2, 0x4

    return-wide v0
.end method

.method public getStartTimeMs()J
    .locals 4

    const/4 v2, 0x7

    move v3, v2

    iget-wide v0, p0, Lcom/tencent/thumbplayer/b/a;->c:J

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-wide v0
.end method

.method public getUrl()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public setCutTimeRange(JJ)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    cmp-long v2, p1, v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-gez v2, :cond_0

    move-wide p1, v0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    cmp-long v0, p1, p3

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-gez v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x0

    iput-wide p1, p0, Lcom/tencent/thumbplayer/b/a;->c:J

    const/4 v3, 0x0

    or-int/2addr v4, v3

    iput-wide p3, p0, Lcom/tencent/thumbplayer/b/a;->d:J

    const/4 v4, 0x1

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x4

    const-string p2, "Rmsse:nnetr s ataeT itrmme eeCteutatiegdtitahi  grn "

    const/4 v4, 0x6

    const-string/jumbo p2, "iaimrmtTsd t ge Rmtts eugCener:etntihtean aae ret Sm"

    const-string/jumbo p2, "setCutTimeRange: Start time is greater than end time"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    throw p1
.end method

.method public setOriginalDurationMs(J)V
    .locals 2

    const/4 v1, 0x5

    return-void
.end method

.method public setStartPositionMs(J)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-wide p1, p0, Lcom/tencent/thumbplayer/b/a;->e:J

    const/4 v1, 0x6

    return-void
.end method
