.class public Lcom/tencent/thumbplayer/b/k;
.super Lcom/tencent/thumbplayer/b/d;

# interfaces
.implements Lcom/tencent/thumbplayer/api/composition/ITPMediaRTCAsset;


# instance fields
.field private a:Ljava/lang/String;

.field private b:Ljava/lang/String;

.field private c:I


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/tencent/thumbplayer/b/d;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput v0, p0, Lcom/tencent/thumbplayer/b/k;->c:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/tencent/thumbplayer/b/k;->a:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object p2, p0, Lcom/tencent/thumbplayer/b/k;->b:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/b/d;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/thumbplayer/b/k;->a:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/tencent/thumbplayer/b/k;->b:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p3, p0, Lcom/tencent/thumbplayer/b/k;->c:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public getMediaType()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l s~i@n/~~t~v@t@4r@ @~ @@~@ @ @cKsioool b~ do~@@oo~~a@@~~~  ~. @ 1 M@b@~ -/~~@~iy~   ~ S~mub~f@f"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public getRtcSdpExchangeType()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/thumbplayer/b/k;->c:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0
.end method

.method public getRtcServerUrl()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/k;->b:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public getRtcStreamUrl()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/k;->a:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public getUrl()Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/tencent/thumbplayer/b/i;->a(Lcom/tencent/thumbplayer/api/composition/ITPMediaRTCAsset;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0

    :catch_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const-string/jumbo v1, "iesmteeAWbMrTcdPsa"

    const-string/jumbo v1, "tssierbaWteTdecAPM"

    const/4 v3, 0x0

    const-string/jumbo v1, "idTsosttbcreMeAeaP"

    const-string v1, "TPMediaWebrtcAsset"

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0
.end method
