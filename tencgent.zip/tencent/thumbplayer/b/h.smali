.class public Lcom/tencent/thumbplayer/b/h;
.super Lcom/tencent/thumbplayer/b/d;

# interfaces
.implements Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;
.implements Ljava/io/Serializable;


# instance fields
.field private a:I

.field private b:I

.field private c:J

.field private d:J

.field private e:Ljava/lang/String;

.field private f:J

.field private g:J


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/tencent/thumbplayer/b/d;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v8, 0x7

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-wide/16 v5, -0x1

    const/4 v8, 0x7

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    move v2, p2

    move v2, p2

    const/4 v8, 0x3

    move v2, p2

    move v2, p2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-direct/range {v0 .. v6}, Lcom/tencent/thumbplayer/b/h;-><init>(Ljava/lang/String;IJJ)V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;IJJ)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/thumbplayer/b/d;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-nez v0, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput p2, p0, Lcom/tencent/thumbplayer/b/h;->a:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/tencent/thumbplayer/b/h;->e:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-wide p3, p0, Lcom/tencent/thumbplayer/b/h;->c:J

    const/4 v2, 0x3

    iput-wide p5, p0, Lcom/tencent/thumbplayer/b/h;->d:J

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    cmp-long p3, p3, p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-gez p3, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-wide p1, p0, Lcom/tencent/thumbplayer/b/h;->c:J

    :cond_0
    const/4 v2, 0x6

    cmp-long p1, p5, p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-gtz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/b/h;->getOriginalDurationMs()J

    move-result-wide p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-wide p1, p0, Lcom/tencent/thumbplayer/b/h;->d:J

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget p1, p0, Lcom/tencent/thumbplayer/b/h;->a:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/tencent/thumbplayer/b/f;->a(I)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput p1, p0, Lcom/tencent/thumbplayer/b/h;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    return-void

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string/jumbo p2, "pssCiiyctm:CPcPToiiaonhmrT op pditasMptal kl"

    const-string p2, "PhsTpidpTaiklmoi sirynmc Coplt acPiCtt:eaMpo"

    const/4 v2, 0x4

    const-string/jumbo p2, "hoCmlye cin sip:kpprPpi lmmtaTCcateotPiMoaTd"

    const-string p2, "TPMediaCompositionTrackClip : clipPath empty"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    throw p1
.end method


# virtual methods
.method public a(Ljava/lang/String;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ @~o@ou ~~/@ ~~@ m ybt@Scl~o@o~l 1~@@@~@v@M~-~@~ @@@~o@4  /@i~b~~~ oi ~@~b fnKio a  rdsf~~ . t~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/b/h;->e:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public clone(I)Lcom/tencent/thumbplayer/api/composition/ITPMediaTrackClip;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v0, 0x3

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eq p1, v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v0, 0x4

    const/4 v0, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eq p1, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eq p1, v0, :cond_0

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 p1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-object p1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance v0, Lcom/tencent/thumbplayer/b/h;

    const/4 v3, 0x0

    move v4, v3

    invoke-direct {v0}, Lcom/tencent/thumbplayer/b/h;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput p1, v0, Lcom/tencent/thumbplayer/b/h;->a:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget p1, p0, Lcom/tencent/thumbplayer/b/h;->a:I

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/tencent/thumbplayer/b/f;->a(I)I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput p1, v0, Lcom/tencent/thumbplayer/b/h;->b:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-wide v1, p0, Lcom/tencent/thumbplayer/b/h;->c:J

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput-wide v1, v0, Lcom/tencent/thumbplayer/b/h;->c:J

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-wide v1, p0, Lcom/tencent/thumbplayer/b/h;->d:J

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    iput-wide v1, v0, Lcom/tencent/thumbplayer/b/h;->d:J

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/tencent/thumbplayer/b/h;->e:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput-object p1, v0, Lcom/tencent/thumbplayer/b/h;->e:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x0

    xor-int/2addr v4, v3

    if-nez p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    return v0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    instance-of v1, p1, Lcom/tencent/thumbplayer/b/h;

    const/4 v4, 0x2

    if-nez v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    return v0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget v1, p0, Lcom/tencent/thumbplayer/b/h;->b:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    check-cast p1, Lcom/tencent/thumbplayer/b/h;

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/b/h;->getClipId()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    if-ne v1, v2, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v1, p0, Lcom/tencent/thumbplayer/b/h;->a:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/tencent/thumbplayer/b/h;->getMediaType()I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    if-ne v1, p1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 p1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    return p1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    return v0
.end method

.method public getClipId()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/thumbplayer/b/h;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method public getEndTimeMs()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/tencent/thumbplayer/b/h;->d:J

    const/4 v3, 0x7

    return-wide v0
.end method

.method public getFilePath()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/h;->e:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public getMediaType()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/thumbplayer/b/h;->a:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public getOriginalDurationMs()J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/tencent/thumbplayer/b/h;->g:J

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-wide v0
.end method

.method public getStartPositionMs()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-wide v0, p0, Lcom/tencent/thumbplayer/b/h;->f:J

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-wide v0
.end method

.method public getStartTimeMs()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-wide v0, p0, Lcom/tencent/thumbplayer/b/h;->c:J

    const/4 v3, 0x6

    const/4 v2, 0x2

    return-wide v0
.end method

.method public getUrl()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/h;->e:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public setCutTimeRange(JJ)V
    .locals 6

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/b/h;->getOriginalDurationMs()J

    move-result-wide v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    cmp-long v0, p1, v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v1, " innub tateaedeg amrtntitmrT:mreetor   sRaiiChutaSse"

    const-string/jumbo v1, "tsmma daaeagauiCrS  e ios:rtRnemtiuth Treitrnegten t"

    const/4 v5, 0x1

    const-string/jumbo v1, "iaanteu tmiTt:trhs uaensgtrmgtaiteinr C  eoer uadSte"

    const-string/jumbo v1, "setCutTimeRange: Start time is greater than duration"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-gez v0, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/b/h;->getOriginalDurationMs()J

    move-result-wide v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    cmp-long v0, p3, v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-gtz v0, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    cmp-long v2, p1, v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-gez v2, :cond_0

    move-wide p1, v0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    cmp-long v0, p3, v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-gtz v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/b/h;->getOriginalDurationMs()J

    move-result-wide p3

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x7

    cmp-long v0, p1, p3

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-gez v0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    iput-wide p1, p0, Lcom/tencent/thumbplayer/b/h;->c:J

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput-wide p3, p0, Lcom/tencent/thumbplayer/b/h;->d:J

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo p2, "t muanep rdCtmtiTree asei:tt smntgotir aehg eRn eeaS"

    const-string/jumbo p2, "nem o tiiita ttn  eiaemrt:meetaaRrC eh egduenrsSTtgs"

    const/4 v5, 0x4

    const-string/jumbo p2, "n Sse itqerteReniegd:haagtrtemttetiT mea arui s mC n"

    const-string/jumbo p2, "setCutTimeRange: Start time is greater than end time"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    throw p1

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {p1, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    throw p1

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {p1, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    throw p1
.end method

.method public setOriginalDurationMs(J)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-wide p1, p0, Lcom/tencent/thumbplayer/b/h;->g:J

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public setStartPositionMs(J)V
    .locals 2

    const/4 v1, 0x4

    iput-wide p1, p0, Lcom/tencent/thumbplayer/b/h;->f:J

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method
