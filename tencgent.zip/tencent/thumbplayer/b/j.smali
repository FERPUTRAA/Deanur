.class public Lcom/tencent/thumbplayer/b/j;
.super Lcom/tencent/thumbplayer/b/d;

# interfaces
.implements Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;


# instance fields
.field private a:Ljava/lang/String;

.field private b:I
    .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_DRM_TYPE;
    .end annotation
.end field

.field private c:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(ILjava/lang/String;)V
    .locals 2
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_DRM_TYPE;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/b/d;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/tencent/thumbplayer/b/j;->a:Ljava/lang/String;

    const/4 v0, 0x3

    or-int/2addr v1, v0

    iput p1, p0, Lcom/tencent/thumbplayer/b/j;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    new-instance p1, Ljava/util/HashMap;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/thumbplayer/b/j;->c:Ljava/util/Map;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public getDrmAllProperties()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "ios ~@~@~~- @ ~d ~ns@i@@1fl @o~@~ @bu i/ b~r~  ~@@K@o.a@@obt~@~o ~ of~c@@t~~~  ~~~@4S/m~Mv y@  @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/j;->c:Ljava/util/Map;

    const/4 v2, 0x1

    return-object v0
.end method

.method public getDrmPlayUrl()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/j;->a:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public getDrmProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/j;->c:Ljava/util/Map;

    const/4 v2, 0x5

    const/4 v1, 0x3

    if-eqz v0, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/j;->c:Ljava/util/Map;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    check-cast p1, Ljava/lang/String;

    if-nez p1, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p2

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p1

    :cond_2
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p2
.end method

.method public getDrmType()I
    .locals 3
    .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_DRM_TYPE;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/b/j;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public getMediaType()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public getUrl()Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/tencent/thumbplayer/b/i;->a(Lcom/tencent/thumbplayer/api/composition/ITPMediaDRMAsset;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0

    :catch_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const-string v1, "DdAmseeRsatTsiM"

    const-string/jumbo v1, "etsRasTMeiAdPDs"

    const/4 v3, 0x0

    const-string/jumbo v1, "tRdioTsPAseeMaD"

    const-string v1, "TPMediaDRMAsset"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0
.end method

.method public setDrmPlayUrl(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/thumbplayer/b/j;->a:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x0

    return-void
.end method

.method public setDrmProperty(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/j;->c:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    return-void
.end method

.method public setDrmType(I)V
    .locals 2
    .param p1    # I
        .annotation runtime Lcom/tencent/thumbplayer/api/TPCommonEnum$TP_DRM_TYPE;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p1, p0, Lcom/tencent/thumbplayer/b/j;->b:I

    const/4 v1, 0x0

    const/4 v0, 0x0

    return-void
.end method
