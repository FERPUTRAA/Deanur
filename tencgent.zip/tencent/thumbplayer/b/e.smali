.class public Lcom/tencent/thumbplayer/b/e;
.super Lcom/tencent/thumbplayer/b/d;

# interfaces
.implements Lcom/tencent/thumbplayer/api/composition/ITPMediaComposition;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;",
            ">;"
        }
    .end annotation
.end field

.field private e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;",
            ">;"
        }
    .end annotation
.end field

.field private f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/b/d;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput v0, p0, Lcom/tencent/thumbplayer/b/e;->a:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput v0, p0, Lcom/tencent/thumbplayer/b/e;->b:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput v0, p0, Lcom/tencent/thumbplayer/b/e;->c:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/thumbplayer/b/e;->d:Ljava/util/List;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/thumbplayer/b/e;->e:Ljava/util/List;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/tencent/thumbplayer/b/e;->f:Ljava/util/List;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method private declared-synchronized d()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/thumbplayer/b/e;->a:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput v0, p0, Lcom/tencent/thumbplayer/b/e;->a:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x0

    throw v0
.end method

.method private declared-synchronized e()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p0, Lcom/tencent/thumbplayer/b/e;->b:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput v0, p0, Lcom/tencent/thumbplayer/b/e;->b:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    monitor-exit p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    throw v0
.end method

.method private declared-synchronized f()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/thumbplayer/b/e;->c:I

    const/4 v2, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput v0, p0, Lcom/tencent/thumbplayer/b/e;->c:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    monitor-exit p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    throw v0
.end method


# virtual methods
.method a()J
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/e;->d:Ljava/util/List;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v7, 0x5

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz v0, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-eqz v3, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    check-cast v3, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-interface {v3}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;->getTimelineDurationMs()J

    move-result-wide v4

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    cmp-long v4, v1, v4

    const/4 v7, 0x2

    const/4 v6, 0x4

    if-gez v4, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-interface {v3}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;->getTimelineDurationMs()J

    move-result-wide v1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    goto :goto_0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    return-wide v1
.end method

.method public declared-synchronized addAVTrack()Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v0, Lcom/tencent/thumbplayer/b/g;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/tencent/thumbplayer/b/e;->f()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2}, Lcom/tencent/thumbplayer/b/g;-><init>(II)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/b/e;->f:Ljava/util/List;

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    monitor-exit p0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    monitor-exit p0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    throw v0
.end method

.method public declared-synchronized addAudioTrack()Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;
    .locals 5

    const/4 v3, 0x0

    move v4, v3

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x3

    new-instance v0, Lcom/tencent/thumbplayer/b/g;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/tencent/thumbplayer/b/e;->e()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v2, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2}, Lcom/tencent/thumbplayer/b/g;-><init>(II)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/thumbplayer/b/e;->e:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    monitor-exit p0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    monitor-exit p0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    throw v0
.end method

.method public declared-synchronized addVideoTrack()Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v0, Lcom/tencent/thumbplayer/b/g;

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/tencent/thumbplayer/b/e;->d()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v0, v1, v2}, Lcom/tencent/thumbplayer/b/g;-><init>(II)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/thumbplayer/b/e;->d:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    monitor-exit p0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    monitor-exit p0

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    throw v0
.end method

.method b()J
    .locals 8

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/e;->e:Ljava/util/List;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-wide/16 v1, 0x0

    const/4 v7, 0x4

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz v0, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eqz v3, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    check-cast v3, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-interface {v3}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;->getTimelineDurationMs()J

    move-result-wide v4

    const/4 v7, 0x5

    cmp-long v4, v1, v4

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-gez v4, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-interface {v3}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;->getTimelineDurationMs()J

    move-result-wide v1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    goto :goto_0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    return-wide v1
.end method

.method c()J
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/e;->f:Ljava/util/List;

    const/4 v7, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x6

    if-eqz v0, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-eqz v3, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    check-cast v3, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;

    const/4 v7, 0x0

    invoke-interface {v3}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;->getTimelineDurationMs()J

    move-result-wide v4

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    cmp-long v4, v1, v4

    const/4 v7, 0x4

    if-gez v4, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-interface {v3}, Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;->getTimelineDurationMs()J

    move-result-wide v1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    goto :goto_0

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x0

    return-wide v1
.end method

.method public getAllAVTracks()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/e;->f:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public declared-synchronized getAllAudioTracks()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/e;->e:Ljava/util/List;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    throw v0
.end method

.method public declared-synchronized getAllVideoTracks()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/e;->d:Ljava/util/List;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    throw v0
.end method

.method public getDurationMs()J
    .locals 12

    const/4 v11, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/e;->f:Ljava/util/List;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-static {v0}, Lcom/tencent/thumbplayer/utils/b;->a(Ljava/util/Collection;)Z

    move-result v0

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x2

    if-nez v0, :cond_0

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/b/e;->c()J

    move-result-wide v0

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x1

    return-wide v0

    :cond_0
    const/4 v11, 0x7

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/b/e;->b()J

    move-result-wide v0

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-virtual {p0}, Lcom/tencent/thumbplayer/b/e;->a()J

    move-result-wide v2

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x4

    cmp-long v4, v2, v0

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x2

    if-lez v4, :cond_1

    move-wide v5, v2

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    goto :goto_0

    :cond_1
    move-wide v5, v0

    :goto_0
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    sget-object v7, Lcom/tencent/thumbplayer/b/f;->a:Ljava/lang/String;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-virtual {v7}, Ljava/lang/String;->hashCode()I

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v7}, Ljava/lang/String;->hashCode()I

    move-result v8

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v9, -0x1

    move v11, v9

    const/4 v10, 0x4

    move v11, v10

    sparse-switch v8, :sswitch_data_0

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x0

    goto :goto_1

    :sswitch_0
    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x6

    const-string v8, "adssebsoiv"

    const-string/jumbo v8, "vesbid_aso"

    const/4 v11, 0x1

    const-string/jumbo v8, "sevmbado_i"

    const-string v8, "base_video"

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    const/4 v11, 0x3

    const/4 v10, 0x0

    if-nez v7, :cond_2

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x1

    goto :goto_1

    :cond_2
    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    goto :goto_1

    :sswitch_1
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    const-string v8, "e_dooibuam"

    const-string/jumbo v8, "euombaid_a"

    const/4 v11, 0x4

    const-string v8, "bsdoebauia"

    const-string v8, "base_audio"

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    if-nez v7, :cond_3

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x6

    goto :goto_1

    :cond_3
    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x0

    const/4 v9, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    goto :goto_1

    :sswitch_2
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    const-string/jumbo v8, "nbeeoa_ogrl"

    const/4 v11, 0x7

    const-string v8, "_enogruaslb"

    const-string v8, "base_longer"

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x4

    if-nez v7, :cond_4

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x1

    goto :goto_1

    :cond_4
    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    const/4 v9, 0x0

    :goto_1
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x0

    packed-switch v9, :pswitch_data_0

    const/4 v11, 0x0

    goto :goto_2

    :pswitch_0
    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x1

    if-lez v4, :cond_5

    :pswitch_1
    move-wide v0, v2

    :cond_5
    :pswitch_2
    move-wide v5, v0

    :goto_2
    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x4

    return-wide v5

    :sswitch_data_0
    .sparse-switch
        -0x7a0002a9 -> :sswitch_2
        -0x1d4e1b18 -> :sswitch_1
        -0x1c2ba273 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public getMediaType()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x4

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public getUrl()Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/tencent/thumbplayer/b/i;->a(Lcom/tencent/thumbplayer/api/composition/ITPMediaComposition;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    return-object v0

    :catch_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string/jumbo v1, "oiisobePmtoMpCTina"

    const/4 v3, 0x5

    const-string v1, "PtapoonpdeiCiMsimo"

    const-string v1, "TPMediaComposition"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/tencent/thumbplayer/utils/TPLogUtil;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0
.end method

.method public release()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/e;->d:Ljava/util/List;

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v1, p0, Lcom/tencent/thumbplayer/b/e;->d:Ljava/util/List;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/e;->e:Ljava/util/List;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v2, 0x2

    move v3, v2

    iput-object v1, p0, Lcom/tencent/thumbplayer/b/e;->e:Ljava/util/List;

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/e;->f:Ljava/util/List;

    const/4 v3, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object v1, p0, Lcom/tencent/thumbplayer/b/e;->f:Ljava/util/List;

    :cond_2
    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method public removeAVTrack(Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/e;->f:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    return p1

    :cond_0
    const/4 v2, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x7

    const-string/jumbo v0, "eucirelaqt,l.rd c  aaksuniuov tk mor"

    const-string/jumbo v0, "rui.aauikr cltom lcavou,ernt  k e ds"

    const/4 v2, 0x7

    const-string/jumbo v0, "umsc  tak loucl id, skreraaoenv tr.i"

    const-string/jumbo v0, "remove audio track , track is null ."

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    throw p1
.end method

.method public declared-synchronized removeAudioTrack(Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;)Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    monitor-enter p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/e;->e:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    :try_start_1
    const/4 v2, 0x0

    const/4 v1, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v0, " iom elnm tlic,a.v ksr  keupr aotudr"

    const-string/jumbo v0, "ma rkauplsoit  recd t v. rcenl oiu,k"

    const/4 v2, 0x4

    const-string/jumbo v0, "r,ouoldtsu me  taai  korlvnikec a.cr"

    const-string/jumbo v0, "remove audio track , track is null ."

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    throw p1
.end method

.method public declared-synchronized removeVideoTrack(Lcom/tencent/thumbplayer/api/composition/ITPMediaTrack;)Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    monitor-enter p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/thumbplayer/b/e;->d:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    return p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    :try_start_1
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string/jumbo v0, "mio lblt qrtcsod nurk.vv   ceeaierk,"

    const-string/jumbo v0, "r,emerklqo kua invscte v.  dtiocr  l"

    const/4 v2, 0x3

    const-string v0, ",s au urvkct  v tmlnderc  ooiier.elk"

    const-string/jumbo v0, "remove video track , track is null ."

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    throw p1
.end method
